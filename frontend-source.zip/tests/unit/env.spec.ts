import { afterEach, describe, expect, it, vi } from 'vitest'
import { parseDataMode } from '@/config/env'

afterEach(() => vi.restoreAllMocks())

describe('阶段0配置模式解析', () => {
  it.each([undefined, '', '  '])('缺省值 %s 使用示例模式', (raw) => {
    expect(parseDataMode(raw)).toBe('mock')
  })

  it.each(['mock', 'snapshot', 'api'] as const)('合法模式 %s 保真并去除空白', (mode) => {
    expect(parseDataMode(` ${mode} `)).toBe(mode)
  })

  it('非法模式回落示例时必须告警，不能静默改变模式', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    expect(parseDataMode('ap1')).toBe('mock')
    expect(warn).toHaveBeenCalledWith(expect.stringContaining('已按 mock 处理'))
  })
})
