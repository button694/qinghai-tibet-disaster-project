import { describe, expect, it } from 'vitest'
import { pointsInRegion, routesForPoint } from '@/services/hazardExplorer'
import type { FeatureDetail, RouteSummary } from '@/domain/types'

function point(id: string, coordinates: number[]): FeatureDetail {
  return {ref:{layerId:'points',id},title:id,datasetId:'test',geometry:{type:'Point',coordinates},properties:{glacierId:id},relatedResultIds:[]}
}
describe('hazard explorer associations', () => {
  it('uses original source IDs rather than array order or route hazard IDs', () => {
    const routes = [{id:'result.route.2050:R2',hazardPointId:'H2050_02'}, {id:'result.route.2050:R1',hazardPointId:'H2050_01'}] as RouteSummary[]
    const links = [{routeCode:'R1',hazardPointId:'H2050_01',sourceHazardId:'GL-A',facilityLayer:null,facilityPk:null}]
    expect(routesForPoint(point('GL-A',[1,1]),routes,links).map(r=>r.id)).toEqual(['result.route.2050:R1'])
    expect(routesForPoint(point('GL-B',[1,1]),routes,links)).toEqual([])
  })
  it('respects polygon holes and excludes points outside a selected region', () => {
    const region: FeatureDetail = {...point('region',[0,0]),geometry:{type:'Polygon',coordinates:[[[0,0],[10,0],[10,10],[0,10],[0,0]],[[4,4],[6,4],[6,6],[4,6],[4,4]]]}}
    expect(pointsInRegion([point('inside',[2,2]),point('hole',[5,5]),point('outside',[20,20])],region).map(p=>p.ref.id)).toEqual(['inside'])
  })
})
