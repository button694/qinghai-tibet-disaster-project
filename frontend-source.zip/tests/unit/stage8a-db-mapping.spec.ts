import { readFileSync, readdirSync, statSync, existsSync } from 'node:fs'
import { join, resolve } from 'node:path'
import { describe, expect, it } from 'vitest'

/**
 * 阶段8A 数据库映射契约测试（03 阶段8A 任务7）。
 *
 * 固化三类边界：
 * 1. 文档与页面不再声称「数据库未恢复」，但仍如实显示「真实服务待发布/待联调」；
 * 2. 前端（src/public/dist）不含数据库连接串、账号、FILE_PATH/SOURCE_FILE_PATH 与本机绝对路径；
 * 3. API_MAPPING 不把未验证的 HTTP 接口标成「已验证」；CRS 约束（LCC→4326、不得只改 SRID）已成文。
 *
 * 注意：docs/ 下各历史阶段 review 目录中的「未恢复」表述是当时事实记录，不在本测试范围内。
 */

const ROOT = process.cwd()

function readRel(rel: string): string {
  return readFileSync(resolve(ROOT, rel), 'utf8')
}

/** 递归收集目录下指定扩展名的文件（跳过 node_modules）。 */
function collectFiles(dir: string, exts: string[], acc: string[] = []): string[] {
  if (!existsSync(dir)) return acc
  for (const name of readdirSync(dir)) {
    if (name === 'node_modules' || name.startsWith('.')) continue
    const full = join(dir, name)
    const st = statSync(full)
    if (st.isDirectory()) collectFiles(full, exts, acc)
    else if (exts.some((e) => name.endsWith(e))) acc.push(full)
  }
  return acc
}

describe('阶段8A：文档不再声称数据库未恢复，且保留待联调口径', () => {
  it('README 不再含「尚未恢复/成果映射待补」，并声明数据库已恢复', () => {
    const text = readRel('README.md')
    expect(text).not.toContain('尚未恢复')
    expect(text).not.toContain('成果映射待补')
    expect(text).toContain('QTP_GEOHAZARD')
    expect(text).toContain('DB_MAPPING')
  })

  it('PROGRESS/ACCEPTANCE 顶部与阶段8A 节采用「已恢复」口径', () => {
    const progress = readRel('docs/PROGRESS.md')
    expect(progress).toContain('阶段8A 数据库映射记录')
    expect(progress).toContain('QTP_GEOHAZARD')
    const progress8A = progress.split('## 阶段8A')[1]?.split('## 阶段9')[0] ?? ''
    expect(progress8A.length).toBeGreaterThan(0)
    expect(progress8A).not.toContain('尚未恢复')
    expect(progress8A).not.toContain('成果映射待补')

    const acceptance = readRel('docs/ACCEPTANCE.md')
    const head = acceptance.slice(0, 1200)
    expect(head).toContain('QTP_GEOHAZARD')
    expect(head).toContain('最终本机可用版已通过')
    expect(head).not.toContain('成果映射待补')
  })

  it('页面（src）不再显示「数据库未恢复」类旧提示，仍显示待发布/待联调', () => {
    const srcDir = resolve(ROOT, 'src')
    const files = collectFiles(srcDir, ['.vue', '.ts'])
    expect(files.length).toBeGreaterThan(0)
    const stale = /尚未恢复|未恢复查询|成果映射待补|数据库未恢复/
    for (const file of files) {
      const text = readFileSync(file, 'utf8')
      expect(stale.test(text), `过期表述出现在 ${file}`).toBe(false)
    }
    // 页面以客户语言呈现当前已发布成果与待补充专题。
    const riskView = readRel('src/views/RiskView.vue')
    expect(riskView).toContain('FORMAL_RESULT_ID')
    const exposureView = readRel('src/views/ExposureView.vue')
    expect(exposureView).toContain('后续深化方向')
    expect(exposureView).toContain('exposure-planning')
  })

  it('DB_MAPPING 存在，且「数据库字段已映射」与「HTTP 已验证」是两个状态', () => {
    const text = readRel('docs/DB_MAPPING.md')
    expect(text).toContain('数据库已映射')
    expect(text).toContain('未映射')
    expect(text).toContain('HTTP')
    // 明确不得混写的状态声明
    expect(text).toContain('真实 HTTP 联调尚未通过')
    // 22 方法逐项映射表
    expect(text).toContain('getLegend')
    expect(text).toContain('listAffectedFeatures')
  })

  it('API_MAPPING 未把任何 HTTP 接口标为已验证，并记录阶段8A 映射状态', () => {
    const text = readRel('docs/API_MAPPING.md')
    expect(text).not.toContain('已验证（真实服务）')
    expect(text).toContain('22 个 HTTP 实现仍全部「待联调」')
    expect(text).toContain('阶段8A 数据库映射')
    expect(text).toContain('DB_MAPPING')
  })
})

describe('阶段8A：秘密与路径边界', () => {
  const secretPatterns = [
    /Data Source\s*=/i,
    /Initial Catalog\s*=/i,
    /Integrated Security/i,
    /User ID\s*=/i,
    /Password\s*=/i,
    /PWD\s*=/i,
    /SQLEXPRESS/,
    /[A-Za-z]:\\空间数据库实习/,
    /D:\\软件\\SQL/,
  ]

  it('src 与 public 不含连接串、实例名、凭据与本机绝对路径', () => {
    const files = [
      ...collectFiles(resolve(ROOT, 'src'), ['.ts', '.vue']),
      ...collectFiles(resolve(ROOT, 'public'), ['.json', '.geojson']),
    ]
    expect(files.length).toBeGreaterThan(0)
    for (const file of files) {
      const text = readFileSync(file, 'utf8')
      for (const pattern of secretPatterns) {
        expect(pattern.test(text), `${pattern} 命中 ${file}`).toBe(false)
      }
      expect(/SOURCE_FILE_PATH/.test(text), `SOURCE_FILE_PATH 命中 ${file}`).toBe(false)
    }
  })

  it('dist（若已构建）同样不含连接串、凭据与 FILE_PATH', () => {
    const distDir = resolve(ROOT, 'dist')
    if (!existsSync(distDir)) {
      // dist 在构建后才存在；单测环境下跳过（构建后的完整扫描由验证命令覆盖）
      return
    }
    const files = collectFiles(distDir, ['.js', '.css', '.html', '.json'])
    for (const file of files) {
      const text = readFileSync(file, 'utf8')
      for (const pattern of secretPatterns) {
        expect(pattern.test(text), `${pattern} 命中 ${file}`).toBe(false)
      }
    }
  })

  it('响应模型（domain/types.ts 与 repositories）不含 FILE_PATH/SOURCE_FILE_PATH 字段', () => {
    const types = readRel('src/domain/types.ts')
    expect(/FILE_PATH|SOURCE_FILE_PATH/.test(types)).toBe(false)
    const repoFiles = collectFiles(resolve(ROOT, 'src/repositories'), ['.ts'])
    for (const file of repoFiles) {
      expect(/FILE_PATH|SOURCE_FILE_PATH/.test(readFileSync(file, 'utf8')), `命中 ${file}`).toBe(
        false,
      )
    }
  })

  it('旧「sqlserver数据库」只出现在「已弃用/禁止」语境', () => {
    const files = [
      ...collectFiles(resolve(ROOT, 'src'), ['.ts', '.vue']),
      resolve(ROOT, 'README.md'),
      resolve(ROOT, 'docs/DB_MAPPING.md'),
    ]
    let occurrences = 0
    for (const file of files) {
      const lines = readFileSync(file, 'utf8').split(/\r?\n/)
      lines.forEach((line, index) => {
        if (!line.includes('sqlserver数据库')) return
        occurrences += 1
        // prettier 会对 HTML/Markdown 折行，弃用语境允许出现在相邻行（±1）
        const window = [lines[index - 1] ?? '', line, lines[index + 1] ?? '']
        const isDeprecatedContext = window.some((text) => /弃用|禁止/.test(text))
        expect(isDeprecatedContext, `${file}:${index + 1} 中 sqlserver数据库 未带弃用语境`).toBe(
          true,
        )
      })
    }
    expect(occurrences).toBeGreaterThan(0)
  })
})

describe('阶段8A：CRS 与坐标转换约束', () => {
  it('DB_MAPPING 明确 LCC 投影、EPSG:4326 输出与「不得只改 SRID」约束', () => {
    const text = readRel('docs/DB_MAPPING.md')
    expect(text).toContain('CGCS2000_Tibetan_Plateau_LCC')
    expect(text).toContain('EPSG:4326')
    expect(text).toContain('STSetSRID')
    expect(text).toContain('重投影')
    expect(text).toContain('0.0005 米')
  })

  it('DB_MAPPING 记录 5 个以上坐标对比对象与只读 SQL 证据', () => {
    const text = readRel('docs/DB_MAPPING.md')
    expect(text).toContain('15 点') // 3 表 × 5 点
    expect(text).toContain('coordinate-comparison.json')
    expect(text).toContain('sys.partitions') // 只读目录查询可复现
    expect(text).toContain('不得再次恢复') // 明确本阶段不执行恢复操作
  })
})
