/**
 * 阶段8「真实服务接入」契约与身份边界单元测试。
 *
 * 聚焦三类不可在 UI 层静默吞掉的事实：
 * A. 错误契约补全（mapHttpStatus / responseError 的码与可重试映射）。
 * B. 本机路径（盘符反斜杠、FILE_PATH 等键、sqlServerVerified 身份边界）不得进入前端资源。
 * C. 真实 API 失败时不回退示例数据（store 层 failed 态 + 数据 ref 保持 null/空）。
 * D. 数据来源地址与 API_MAPPING 文档的“待联调 / 未验证”身份状态。
 *
 * 仅新建本文件，不改动 src/ 与其他测试。
 */
import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

import { createRepositories, dataSourceUrl, setRepositories } from '@/repositories'
import { createHttpRepositories } from '@/repositories/http/httpRepository'
import { RepositoryError } from '@/repositories/types'
import {
  createCatalogWorkspaceService,
  setCatalogWorkspaceService,
} from '@/services/catalogWorkspace'
import { createResultsCenterService, setResultsCenterService } from '@/services/resultsCenter'
import { useOverviewStore } from '@/stores/overview'
import { useCatalogStore } from '@/stores/catalog'
import { useResultsStore } from '@/stores/results'
import { apiEnv } from './helpers/repository-fixtures'

/* ------------------------------------------------------------------ *
 * 复用的 HTTP 契约测试桩（精简自 http-repository.spec.ts）
 * ------------------------------------------------------------------ */

interface RecordedCall {
  url: string
  method: string
  body: unknown
  headers: Record<string, string>
}

function createFetchStub(
  responder: (call: RecordedCall, index: number) => Response | Promise<Response>,
): { fetcher: typeof fetch; calls: RecordedCall[] } {
  const calls: RecordedCall[] = []
  const fetcher = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const headers = (init?.headers ?? {}) as Record<string, string>
    const call: RecordedCall = {
      url: String(input),
      method: init?.method ?? 'GET',
      body: init?.body === undefined ? undefined : JSON.parse(String(init.body)),
      headers,
    }
    calls.push(call)
    return responder(call, calls.length - 1)
  }) as unknown as typeof fetch
  return { fetcher, calls }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  })
}

/** 返回给定状态码的响应；body 为空字符串时给空体（触发错误体解析失败→退回状态码映射）。 */
function statusStub(status: number, body: unknown = '') {
  return createFetchStub(() =>
    body === '' ? new Response('', { status }) : jsonResponse(body, status),
  )
}

/* ------------------------------------------------------------------ *
 * 递归遍历工具（用于身份边界断言）
 * ------------------------------------------------------------------ */

function collectKeys(node: unknown, acc: string[]): void {
  if (Array.isArray(node)) {
    for (const item of node) collectKeys(item, acc)
  } else if (node !== null && typeof node === 'object') {
    for (const [key, value] of Object.entries(node as Record<string, unknown>)) {
      acc.push(key)
      collectKeys(value, acc)
    }
  }
}

function collectStringValues(node: unknown, acc: string[]): void {
  if (typeof node === 'string') {
    acc.push(node)
  } else if (Array.isArray(node)) {
    for (const item of node) collectStringValues(item, acc)
  } else if (node !== null && typeof node === 'object') {
    for (const value of Object.values(node as Record<string, unknown>)) {
      collectStringValues(value, acc)
    }
  }
}

const FILE_PATH_KEYS = new Set(['FILE_PATH', 'filePath', 'file_path'])
const DRIVE_LETTER = /^[A-Za-z]:[\\/]/

describe('A. 阶段8 错误契约补全', () => {
  it('409 返回 QUERY_EXPIRED 且不可重试（getQuery）', async () => {
    const { fetcher } = statusStub(409)
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    const error = (await repositories.queries
      .getQuery('q-1', { page: 1, pageSize: 10 })
      .catch((e: unknown) => e)) as RepositoryError

    expect(error.code).toBe('QUERY_EXPIRED')
    expect(error.retryable).toBe(false)
    expect(error.httpStatus).toBe(409)
  })

  it('401 返回 UNAUTHORIZED（getResult）', async () => {
    const { fetcher } = statusStub(401)
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    await expect(repositories.results.getResult('r-1')).rejects.toMatchObject({
      code: 'UNAUTHORIZED',
      httpStatus: 401,
    })
  })

  it('400 与 422 均返回 INVALID_PARAMETER', async () => {
    const bad400 = createHttpRepositories({ baseUrl: '/api/v1', fetcher: statusStub(400).fetcher })
    const bad422 = createHttpRepositories({ baseUrl: '/api/v1', fetcher: statusStub(422).fetcher })

    await expect(bad400.results.listResults({})).rejects.toMatchObject({
      code: 'INVALID_PARAMETER',
    })
    await expect(bad422.results.getResult('r-9')).rejects.toMatchObject({
      code: 'INVALID_PARAMETER',
    })
  })

  it('501 返回 NOT_IMPLEMENTED', async () => {
    const { fetcher } = statusStub(501)
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    await expect(repositories.overview.getOverview()).rejects.toMatchObject({
      code: 'NOT_IMPLEMENTED',
      httpStatus: 501,
    })
  })

  it('服务端错误体 code 优先：503 但 error.code=QUERY_EXPIRED 时，最终 code 取错误体、retryable 取状态码映射(true)', async () => {
    const { fetcher } = statusStub(503, {
      error: { code: 'QUERY_EXPIRED', message: '查询已过期，请重新查询' },
    })
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    const error = (await repositories.queries
      .getQuery('q-1', { page: 1, pageSize: 10 })
      .catch((e: unknown) => e)) as RepositoryError

    expect(error.code).toBe('QUERY_EXPIRED')
    expect(error.retryable).toBe(true) // retryable 来自状态码映射（503 → SERVICE_UNAVAILABLE → retryable）
    expect(error.httpStatus).toBe(503)
  })

  it('按02契约读取顶层 requestId，并保留 error.retryable 与 details', async () => {
    const { fetcher } = statusStub(422, {
      error: {
        code: 'INVALID_PARAMETER',
        message: '缓冲距离不合法',
        retryable: true,
        details: { parameter: 'distanceMeters' },
      },
      requestId: 'request-stage8-001',
    })
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    const error = (await repositories.results
      .listResults({})
      .catch((e: unknown) => e)) as RepositoryError

    expect(error.requestId).toBe('request-stage8-001')
    expect(error.retryable).toBe(true)
    expect(error.details).toEqual({ parameter: 'distanceMeters' })
  })
})

describe('B. FILE_PATH 与本机路径不进前端', () => {
  const manifestText = readFileSync(
    resolve(process.cwd(), 'public/real-preview/manifest.json'),
    'utf8',
  )
  const datasetsText = readFileSync(resolve(process.cwd(), 'public/demo/datasets.json'), 'utf8')
  const manifest = JSON.parse(manifestText) as Record<string, unknown>
  const datasets = (JSON.parse(datasetsText) as { datasets: unknown[] }).datasets

  it('原始文本不含盘符反斜杠路径（如 C:\\）', () => {
    expect(manifestText).not.toMatch(/[A-Za-z]:[\\]/)
    expect(datasetsText).not.toMatch(/[A-Za-z]:[\\]/)
  })

  it('JSON 递归遍历后不存在 FILE_PATH / filePath / file_path 这类键', () => {
    const keys: string[] = []
    collectKeys(manifest, keys)
    collectKeys(JSON.parse(datasetsText), keys)
    for (const key of keys) {
      expect(FILE_PATH_KEYS.has(key)).toBe(false)
    }
  })

  it('datasets.json 每条记录不含以盘符开头的字符串值', () => {
    const values: string[] = []
    for (const record of datasets) collectStringValues(record, values)
    for (const value of values) {
      expect(DRIVE_LETTER.test(value)).toBe(false)
    }
  })

  it('real-preview manifest 顶层 sqlServerVerified 为 false（不声称 SQL Server 已连接）', () => {
    expect(manifest.sqlServerVerified).toBe(false)
    // 注意：任务描述要求 sample === true，但真实文件顶层 sample 为 false
    // （real-preview 是真实文件快照、非示例数据），按真实内容断言 false，不与描述静默妥协。
    expect(manifest.sample).toBe(false)
  })
})

describe('C. API 失败不回退示例（store 层）', () => {
  const throwingFetch = (async () => {
    throw new TypeError('fetch failed')
  }) as unknown as typeof fetch

  beforeEach(() => {
    setActivePinia(createPinia())
  })

  afterEach(() => {
    // 清理注入，避免污染其他用例（恢复默认单例）。
    setRepositories(null)
    setCatalogWorkspaceService(null)
    setResultsCenterService(null)
  })

  function failingRepos() {
    return createRepositories(apiEnv, { httpFetcher: throwingFetch })
  }

  it('总览 store：API 不可达 → failed，指标与要素保持 null/空（不回退示例）', async () => {
    setRepositories(failingRepos())
    const store = useOverviewStore()
    await store.load()

    expect(store.status).toBe('failed')
    expect(store.data).toBeNull()
    expect(store.zones).toEqual([])
    expect(store.error).toBeInstanceOf(RepositoryError)
    expect(store.error?.userMessage).toBeTruthy()
  })

  it('目录 store：API 不可达 → failed，列表保持空（不回退示例）', async () => {
    setCatalogWorkspaceService(createCatalogWorkspaceService(failingRepos()))
    const store = useCatalogStore()
    await store.loadList()

    expect(store.listStatus).toBe('failed')
    expect(store.rows).toEqual([])
    expect(store.total).toBe(0)
    expect(typeof store.listError).toBe('string')
    expect((store.listError ?? '').length).toBeGreaterThan(0)
  })

  it('成果 store：API 不可达 → failed，列表保持空（不回退示例）', async () => {
    setResultsCenterService(createResultsCenterService(failingRepos()))
    const store = useResultsStore()
    await store.loadList()

    expect(store.listStatus).toBe('failed')
    expect(store.rows).toEqual([])
    expect(store.total).toBe(0)
    expect(store.listError).toBeInstanceOf(RepositoryError)
    expect(store.listError?.userMessage).toBeTruthy()
  })

  it('失败错误体携带客户可理解的用户说明（仓库层 userMessage）', async () => {
    // store 层保留 RepositoryError，使错误码和客户说明都能传到 ErrorState。
    const repos = failingRepos()
    const error = (await repos.overview.getOverview().catch((e: unknown) => e)) as RepositoryError
    expect(error).toBeInstanceOf(RepositoryError)
    expect(error.userMessage).toContain('暂时无法连接数据')
    expect(error.userMessage).not.toContain('示例')
  })
})

describe('D. 身份与映射状态', () => {
  it('数据源地址按模式区分（mock / snapshot / api）', () => {
    expect(dataSourceUrl('mock')).toBe('/demo/')
    expect(dataSourceUrl('snapshot')).toBe('/snapshot/')
    expect(dataSourceUrl('api')).toBe('/api/v1')
  })

  it('API_MAPPING 仍处于待联调、未声称已验证（真实服务）', () => {
    const mapping = readFileSync(resolve(process.cwd(), 'docs/API_MAPPING.md'), 'utf8')
    expect(mapping).toContain('待联调')
    expect(mapping).not.toContain('已验证（真实服务）')
  })
})
