import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import type { FeatureLike } from 'ol/Feature'
import { describe, expect, it } from 'vitest'

import {
  baseLayerStyle,
  CATEGORICAL_FIELD_RAMPS,
  categoricalColorField,
  createLayerStyleFunction,
  IMPACT_AREA_COLOR,
  isBackgroundPolygon,
  MAP_COLORS,
  MAP_COLOR_TOKENS,
  pointShapeFor,
  POINT_SHAPES,
  resetHatchPattern,
  riskColorField,
  RISK_LEVEL_DICTIONARY_ID,
  riskLevelStyle,
  scenarioRampColor,
  SCENARIO_NULL_COLOR,
  SCENARIO_NULL_TOKEN,
  SCENARIO_RAMP,
  selectionColor,
  selectionStyles,
  THEME_COLOR,
} from '@/config/mapStyle'
import { RISK_LEVEL_COLOR, RISK_LEVELS } from '@/domain/risk'
import type { FeatureDetail, LayerDefinition } from '@/domain/types'
import { olGeometryFamily, multiPartNote, toOlFeatures } from '@/services/mapFeatures'
import { createDemoRepositories } from './helpers/repository-fixtures'

/**
 * 阶段2 地图样式与几何转换的单元测试。
 *
 * 三类断言：
 * 1. **颜色不漂移**：地图专用颜色逐个等于 tokens.css 里的令牌值（与 risk.ts 的做法一致）；
 * 2. **选择色与风险色分开**：选中态用焦点色，不等于任何风险等级色；
 * 3. **多部件与无几何**：MultiPoint / MultiLineString / MultiPolygon 按家族渲染、
 *    坐标被显式投影到 EPSG:3857；`geometry: null` 的记录不上图但不丢失。
 *
 * 说明：示例数据包不含多部件几何（见 map-registry.spec.ts），因此多部件用例使用
 * **合成夹具**；`insufficient` 的斜线纹理用 CanvasPattern，jsdom 无 2D 上下文时
 * 走纯色回落，纹理本身需在浏览器里人工核对（阶段2 验收记录中已注明）。
 */

function expandHex(value: string): string {
  const raw = value.trim().toLowerCase()
  if (/^#[0-9a-f]{3}$/.test(raw)) {
    return `#${raw[1]}${raw[1]}${raw[2]}${raw[2]}${raw[3]}${raw[3]}`
  }
  return raw
}

const tokensCss = readFileSync(resolve(process.cwd(), 'src/styles/tokens.css'), 'utf8')

function tokenValue(name: string): string | null {
  const pattern = new RegExp(`${name}\\s*:\\s*([^;{}]+);`)
  const matched = pattern.exec(tokensCss)
  return matched?.[1] === undefined ? null : expandHex(matched[1])
}

describe('阶段2 地图配色：与 tokens.css 交叉校验', () => {
  it('每个地图颜色都等于其声明的令牌值', () => {
    for (const [key, tokenName] of Object.entries(MAP_COLOR_TOKENS) as Array<
      [keyof typeof MAP_COLORS, string]
    >) {
      const token = tokenValue(tokenName)
      expect(token, `tokens.css 缺少 ${tokenName}`).toBeTruthy()
      expect(expandHex(MAP_COLORS[key]), `${key} 与 ${tokenName} 不一致`).toBe(token)
    }
  })

  it('选中色不等于任何风险等级色（选择与风险编码必须分开）', () => {
    const selection = expandHex(selectionColor())
    for (const level of RISK_LEVELS) {
      expect(selection, level).not.toBe(expandHex(RISK_LEVEL_COLOR[level]))
    }
    expect(selection).toBe(tokenValue('--color-focus'))
  })

  it('选中高亮是「白底 + 焦点色」双描边，两个样式都在', () => {
    const styles = selectionStyles()
    expect(styles.length).toBe(2)
    const halo = styles[0]?.getStroke()?.getColor()
    const focus = styles[1]?.getStroke()?.getColor()
    expect(expandHex(String(halo))).toBe(tokenValue('--color-surface'))
    expect(expandHex(String(focus))).toBe(tokenValue('--color-focus'))
  })

  it('阶段4：情景色域的每个色标都等于其声明的令牌值', () => {
    expect(SCENARIO_RAMP.length).toBe(5)
    for (const stop of SCENARIO_RAMP) {
      const token = tokenValue(stop.token)
      expect(token, `tokens.css 缺少 ${stop.token}`).toBeTruthy()
      expect(expandHex(stop.color), `${stop.token} 不一致`).toBe(token)
    }
  })

  it('阶段4：缺失值灰色来自数据不足令牌，且不在色带的任何一段上', () => {
    expect(expandHex(SCENARIO_NULL_COLOR)).toBe(tokenValue(SCENARIO_NULL_TOKEN))
    for (const stop of SCENARIO_RAMP) {
      expect(expandHex(SCENARIO_NULL_COLOR)).not.toBe(expandHex(stop.color))
    }
  })

  it('阶段4：色域取色单调、截断、可逆（同值同色，0 与 1 取端点色）', () => {
    const low = expandHex(scenarioRampColor(0))
    const high = expandHex(scenarioRampColor(1))
    expect(low).toBe(expandHex(SCENARIO_RAMP[0]?.color ?? ''))
    expect(high).toBe(expandHex(SCENARIO_RAMP[SCENARIO_RAMP.length - 1]?.color ?? ''))
    // 越界截断
    expect(expandHex(scenarioRampColor(-0.5))).toBe(low)
    expect(expandHex(scenarioRampColor(1.5))).toBe(high)
    // 同值同色（2050/2100 共用同一色域的前提）
    expect(expandHex(scenarioRampColor(0.42))).toBe(expandHex(scenarioRampColor(0.42)))
    // null → 数据不足灰
    expect(expandHex(scenarioRampColor(null))).toBe(expandHex(SCENARIO_NULL_COLOR))
  })
})

describe('阶段2 地图样式：风险等级着色只在图层声明了字典字段时生效', () => {
  const repositories = createDemoRepositories()

  async function layerById(id: string): Promise<LayerDefinition> {
    const envelope = await repositories.layers.listLayers()
    const layer = envelope.data.find((item) => item.id === id)
    if (!layer) throw new Error(`示例包缺少图层 ${id}`)
    return layer
  }

  it('风险成果图层登记了 dict.risk-level 字段，可被识别', async () => {
    const layer = await layerById('result.demo.risk')
    expect(riskColorField(layer)).toBe('riskLevel')
    expect(
      layer.fields.some(
        (field) => field.key === 'riskLevel' && field.dictionaryId === RISK_LEVEL_DICTIONARY_ID,
      ),
    ).toBe(true)
  })

  it('未登记风险等级字典的图层不着色（例如冰川面、道路线）', async () => {
    for (const id of ['tnr.glacier.polygon', 'emg.road', 'base.settlement.point']) {
      expect(riskColorField(await layerById(id)), id).toBeNull()
    }
  })

  it('要素自带等级时填充取该等级色；无该属性时回落基础样式', async () => {
    const layer = await layerById('result.demo.risk')
    const style = createLayerStyleFunction(layer)
    // 样式函数只读取要素的指定字段，这里给出最小可用的要素替身。
    const withLevel = {
      get: (key: string) => (key === 'riskLevel' ? 'high' : undefined),
    } as unknown as FeatureLike
    const withoutLevel = { get: () => undefined } as unknown as FeatureLike
    const filled = style(withLevel, 1).getFill()?.getColor()
    expect(expandHex(String(filled))).toBe(expandHex(RISK_LEVEL_COLOR.high))
    const fallbackFill = style(withoutLevel, 1).getFill()?.getColor()
    expect(expandHex(String(fallbackFill))).toBe(expandHex(RISK_LEVEL_COLOR.insufficient))
  })

  it('数据不足等级不抛错：CanvasPattern 不可用时回落纯色，可用时用纹理', () => {
    resetHatchPattern()
    const style = riskLevelStyle('insufficient')
    const fill = style.getFill()
    expect(fill).toBeTruthy()
    // jsdom 无 canvas 2D 上下文 → 纯色回落；浏览器里是纹理（人工核对项）。
    const color = fill?.getColor()
    expect(color === null || color === undefined || String(color).length > 0).toBe(true)
  })

  it('基础样式对点线面都给出了 fill / stroke / image 三类画法', () => {
    const style = baseLayerStyle()
    expect(style.getFill()).toBeTruthy()
    expect(style.getStroke()).toBeTruthy()
    expect(style.getImage()).toBeTruthy()
  })

  it('背景面用地图底色填充、数据面按所属主题上色：整片研究区不会被涂成同一种颜色', async () => {
    const boundary = await layerById('base.boundary')
    const glacier = await layerById('tnr.glacier.polygon')
    const settlementPolygon = await layerById('base.settlement.polygon')

    expect(isBackgroundPolygon(boundary), '示例研究区边界应识别为背景面').toBe(true)
    expect(isBackgroundPolygon(glacier)).toBe(false)
    expect(isBackgroundPolygon(settlementPolygon), '可查询的面不是背景面').toBe(false)

    expect(expandHex(String(baseLayerStyle(boundary).getFill()?.getColor()))).toBe(
      tokenValue('--color-map-bg'),
    )
    // 修复后：冰冻圈主题面按 THEME_COLOR.tnr 上色，不再与其它主题共用同一浅蓝填充。
    expect(expandHex(String(baseLayerStyle(glacier).getFill()?.getColor()))).toBe(
      tokenValue('--color-theme-tnr'),
    )
    expect(expandHex(String(baseLayerStyle(glacier).getFill()?.getColor()))).toBe(
      expandHex(THEME_COLOR.tnr),
    )
    // 背景面仍保留填充与描边：内部可点选、边界线可见。
    expect(baseLayerStyle(boundary).getStroke()).toBeTruthy()
  })

  it('不同主题的图层拿到不同的主色（修复「所有图层图例都相同」的核心断言）', async () => {
    const glacier = await layerById('tnr.glacier.polygon') // theme: tnr
    const road = await layerById('emg.road') // theme: emg
    const settlement = await layerById('base.settlement.polygon') // theme: base

    const glacierFill = expandHex(String(baseLayerStyle(glacier).getFill()?.getColor()))
    const roadStroke = expandHex(String(baseLayerStyle(road).getStroke()?.getColor()))
    const settlementFill = expandHex(String(baseLayerStyle(settlement).getFill()?.getColor()))

    expect(glacierFill).not.toBe(roadStroke)
    expect(glacierFill).not.toBe(settlementFill)
    expect(roadStroke).not.toBe(settlementFill)
  })

  it('线图层的语义色真正作用到 stroke，不再永远是同一个固定蓝（缺陷 A）', async () => {
    const road = await layerById('emg.road')
    const stroke = baseLayerStyle(road).getStroke()?.getColor()
    expect(expandHex(String(stroke))).toBe(expandHex(THEME_COLOR[road.theme]))
  })

  it('点图层的语义色真正作用到点符号填充，不再永远是同一个固定青色（缺陷 A）', async () => {
    const settlementPoint = await layerById('base.settlement.point')
    const image = baseLayerStyle(settlementPoint).getImage()
    expect(image).toBeTruthy()
    const imageWithFill = image as unknown as { getFill: () => { getColor: () => unknown } | null }
    const fillColor = imageWithFill.getFill()?.getColor()
    expect(expandHex(String(fillColor))).toBe(expandHex(THEME_COLOR.base))
    expect(expandHex(String(fillColor))).not.toBe(expandHex(MAP_COLORS.pointFill))
  })

  it('同一主题内的点图层按图层 ID 稳定取不同形状，可与颜色一起做区分', async () => {
    const settlementPoint = await layerById('base.settlement.point')
    const shape = pointShapeFor(settlementPoint)
    expect(POINT_SHAPES).toContain(shape)
    // 同一图层重复调用取到同一形状（稳定，不随机）。
    expect(pointShapeFor(settlementPoint)).toBe(shape)
  })

  it('分类字段配色只覆盖已查证的两个字段，且颜色与 tokens.css 一致', () => {
    expect(Object.keys(CATEGORICAL_FIELD_RAMPS).sort()).toEqual(['hazardLevel', 'roadGrade'])
    for (const values of Object.values(CATEGORICAL_FIELD_RAMPS)) {
      for (const entry of values) {
        expect(tokenValue(entry.token), `tokens.css 缺少 ${entry.token}`).toBeTruthy()
        expect(expandHex(entry.color)).toBe(tokenValue(entry.token))
      }
    }
  })

  it('登记了分类字段的图层按要素取值原样查色；未登记取值或缺失按数据不足处理', () => {
    const layer: LayerDefinition = {
      id: 'test.hazard-point',
      label: '测试危险点',
      theme: 'hazard',
      datasetId: 'test-dataset',
      geometryType: 'Point',
      source: { type: 'unavailable', reason: 'test' },
      fields: [
        {
          key: 'hazardLevel',
          label: '危险等级',
          type: 'string',
          unit: null,
          nullable: true,
          filterable: true,
          sortable: true,
        },
      ],
      defaultVisible: true,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'EPSG:4326',
    }
    const field = categoricalColorField(layer)
    expect(field?.field).toBe('hazardLevel')

    const style = createLayerStyleFunction(layer)
    const high = { get: (key: string) => (key === 'hazardLevel' ? '高' : undefined) } as unknown as FeatureLike
    const unknownValue = {
      get: (key: string) => (key === 'hazardLevel' ? '未登记的取值' : undefined),
    } as unknown as FeatureLike
    const missing = { get: () => undefined } as unknown as FeatureLike

    const highFill = style(high, 1).getFill()?.getColor()
    expect(expandHex(String(highFill))).toBe(
      expandHex(CATEGORICAL_FIELD_RAMPS.hazardLevel?.find((item) => item.value === '高')?.color ?? ''),
    )
    // 未登记取值与缺失都不得猜成中间等级，只能落到「数据不足」的表现（灰色回落）。
    const unknownFill = style(unknownValue, 1).getFill()?.getColor()
    const missingFill = style(missing, 1).getFill()?.getColor()
    expect(String(unknownFill).length > 0 || unknownFill === null).toBe(true)
    expect(String(missingFill).length > 0 || missingFill === null).toBe(true)
  })

  it('登记了分类字段的点图层按等级传入不同的符号半径（尺寸编码，返工新增）', () => {
    const pointLayer: LayerDefinition = {
      // 用固定取到 'circle' 形状的图层 ID：pointShapeFor 按 ID 哈希取形状，非圆形状会按比例
      // 缩放自己的基础尺寸（见 mapStyle.ts 的 SHAPE_BASE_RADIUS），这里只想断言「半径原样等于
      // CATEGORICAL_FIELD_RAMPS 里的 size」，所以固定用 circle，形状缩放本身已由 pointImage
      // 的换算公式保证比例正确，不在这条用例里重复断言。
      id: 'test.hazard-circle',
      label: '测试危险点',
      theme: 'hazard',
      datasetId: 'test-dataset',
      geometryType: 'Point',
      source: { type: 'unavailable', reason: 'test' },
      fields: [
        { key: 'hazardLevel', label: '危险等级', type: 'string', unit: null, nullable: true, filterable: true, sortable: true },
      ],
      defaultVisible: true,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'EPSG:4326',
    }
    const style = createLayerStyleFunction(pointLayer)
    const radiusFor = (value: string): number | undefined => {
      const feature = { get: (key: string) => (key === 'hazardLevel' ? value : undefined) } as unknown as FeatureLike
      const image = style(feature, 1).getImage() as unknown as { getRadius?: () => number } | null
      return image?.getRadius?.()
    }
    const medium = radiusFor('中')
    const high = radiusFor('高')
    const extreme = radiusFor('极高')
    expect(medium).toBe(CATEGORICAL_FIELD_RAMPS.hazardLevel?.find((item) => item.value === '中')?.size)
    expect(high).toBe(CATEGORICAL_FIELD_RAMPS.hazardLevel?.find((item) => item.value === '高')?.size)
    expect(extreme).toBe(CATEGORICAL_FIELD_RAMPS.hazardLevel?.find((item) => item.value === '极高')?.size)
    // 等级越高，符号半径越大：与颜色的单调方向一致，图例与地图同步体现。
    expect(medium).toBeLessThan(high ?? 0)
    expect(high).toBeLessThan(extreme ?? 0)
  })

  it('登记了分类字段的线图层按等级传入不同的线宽（尺寸编码，返工新增）', () => {
    const lineLayer: LayerDefinition = {
      id: 'test.road-line',
      label: '测试道路',
      theme: 'emg',
      datasetId: 'test-dataset',
      geometryType: 'LineString',
      source: { type: 'unavailable', reason: 'test' },
      fields: [
        { key: 'roadGrade', label: '道路等级', type: 'string', unit: null, nullable: true, filterable: true, sortable: true },
      ],
      defaultVisible: true,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'EPSG:4326',
    }
    const style = createLayerStyleFunction(lineLayer)
    const widthFor = (value: string): number | undefined => {
      const feature = { get: (key: string) => (key === 'roadGrade' ? value : undefined) } as unknown as FeatureLike
      return style(feature, 1).getStroke()?.getWidth()
    }
    const widths = CATEGORICAL_FIELD_RAMPS.roadGrade?.map((entry) => widthFor(entry.value)) ?? []
    for (let i = 0; i < widths.length; i += 1) {
      expect(widths[i]).toBe(CATEGORICAL_FIELD_RAMPS.roadGrade?.[i]?.size)
    }
    // 等外 → 高速，线宽必须严格递增（高速最粗、等外最细）。
    for (let i = 1; i < widths.length; i += 1) {
      expect(widths[i]).toBeGreaterThan(widths[i - 1] ?? 0)
    }
  })
})

/**
 * 第二轮返工：hazardLevel / roadGrade 的区分度断言。
 *
 * 上一轮只约束了「每档与底色对比度 ≥3.0」，结果两个字段都做成了单一色相、只改明度的色带
 * （hazardLevel 三档色相只差 0.2°~1.3°，roadGrade 六档色相只差 0.2°~0.9°）。这里用同一套
 * WCAG 相对亮度 / HSL 色相公式重新算一遍，把「相邻档位可辨」变成可执行的断言，
 * 防止以后再有人改色退化回单一色相色带。
 *
 * 第三轮返工（仅 roadGrade）：第二轮「色相差 ≥25° 或对比度 ≥2.2」二选一的放宽项被验收打回——
 * 后四档淡绿相邻对比度只有 1.01~1.12（同明度，肉眼分不出深浅），只靠色相角差在低饱和度下
 * 感知上几乎不起作用，数学达标但眼睛没通过。roadGrade 的断言改用 CIE76 ΔE（Lab 欧氏距离）
 * 这个不可规避的硬指标，不再有二选一放宽；hazardLevel 已验收通过，断言保持不变。
 */
describe('阶段2 地图配色：hazardLevel / roadGrade 的区分度（第二、三轮返工）', () => {
  const bg = MAP_COLORS.background

  function hexToRgbTuple(hex: string): [number, number, number] {
    const raw = expandHex(hex).replace('#', '')
    return [
      Number.parseInt(raw.slice(0, 2), 16),
      Number.parseInt(raw.slice(2, 4), 16),
      Number.parseInt(raw.slice(4, 6), 16),
    ]
  }

  function srgbToLinear(channel: number): number {
    const c = channel / 255
    return c <= 0.03928 ? c / 12.92 : Math.pow((c + 0.055) / 1.055, 2.4)
  }

  function relativeLuminance(hex: string): number {
    const [r, g, b] = hexToRgbTuple(hex)
    return 0.2126 * srgbToLinear(r) + 0.7152 * srgbToLinear(g) + 0.0722 * srgbToLinear(b)
  }

  /** WCAG 对比度公式：(较亮 + 0.05) / (较暗 + 0.05)。 */
  function contrastRatio(a: string, b: string): number {
    const la = relativeLuminance(a)
    const lb = relativeLuminance(b)
    const hi = Math.max(la, lb)
    const lo = Math.min(la, lb)
    return (hi + 0.05) / (lo + 0.05)
  }

  function hueOf(hex: string): number {
    const [rRaw, gRaw, bRaw] = hexToRgbTuple(hex)
    const r = rRaw / 255
    const g = gRaw / 255
    const b = bRaw / 255
    const max = Math.max(r, g, b)
    const min = Math.min(r, g, b)
    if (max === min) return 0
    const d = max - min
    let h: number
    if (max === r) h = ((g - b) / d + (g < b ? 6 : 0)) * 60
    else if (max === g) h = ((b - r) / d + 2) * 60
    else h = ((r - g) / d + 4) * 60
    return h
  }

  /** 色相是环形的，相邻色相差要取 min(d, 360-d)，否则 350° 与 10° 会被误判为差 340°。 */
  function hueDiff(a: string, b: string): number {
    const d = Math.abs(hueOf(a) - hueOf(b))
    return Math.min(d, 360 - d)
  }

  /**
   * CIE76 ΔE（Lab 欧氏距离）。第三轮返工用它作为 roadGrade 的硬指标：色相角差在低饱和度下
   * 感知上几乎不起作用（第二轮的教训——后四档淡绿色相差达标但相邻对比度只有 1.0x，肉眼分不出），
   * ΔE 直接量化感知色差，不会被“数学上达标但眼睛看不出”绕过。
   * sRGB → 线性 RGB → CIE XYZ（D65）→ CIE Lab，公式对照 colorcalc2.js 的独立实现。
   */
  function rgbToXyz(hex: string): [number, number, number] {
    const [rRaw, gRaw, bRaw] = hexToRgbTuple(hex)
    const r = srgbToLinear(rRaw)
    const g = srgbToLinear(gRaw)
    const b = srgbToLinear(bRaw)
    const x = r * 0.4124564 + g * 0.3575761 + b * 0.1804375
    const y = r * 0.2126729 + g * 0.7151522 + b * 0.072175
    const z = r * 0.0193339 + g * 0.119192 + b * 0.9503041
    return [x, y, z]
  }

  const D65 = { x: 0.95047, y: 1.0, z: 1.08883 }

  function labF(t: number): number {
    const delta = 6 / 29
    return t > delta ** 3 ? Math.cbrt(t) : t / (3 * delta * delta) + 4 / 29
  }

  function rgbToLab(hex: string): [number, number, number] {
    const [x, y, z] = rgbToXyz(hex)
    const fx = labF(x / D65.x)
    const fy = labF(y / D65.y)
    const fz = labF(z / D65.z)
    const l = 116 * fy - 16
    const a = 500 * (fx - fy)
    const bLab = 200 * (fy - fz)
    return [l, a, bLab]
  }

  function deltaE(a: string, b: string): number {
    const [l1, a1, b1] = rgbToLab(a)
    const [l2, a2, b2] = rgbToLab(b)
    return Math.sqrt((l1 - l2) ** 2 + (a1 - a2) ** 2 + (b1 - b2) ** 2)
  }

  const bannedExactColors = [
    MAP_COLORS.selectionStroke, // #176bca
    MAP_COLORS.queryStroke, // #de7c3b
    IMPACT_AREA_COLOR, // #bf454b
    RISK_LEVEL_COLOR.low,
    RISK_LEVEL_COLOR.lower,
    RISK_LEVEL_COLOR.medium,
    RISK_LEVEL_COLOR.higher,
    RISK_LEVEL_COLOR.high,
    RISK_LEVEL_COLOR.insufficient,
  ].map((c) => expandHex(c))

  it('两条色带都不复用选中蓝 / 查询橙 / 影响范围红 / RISK_LEVEL_COLOR 六色', () => {
    for (const values of Object.values(CATEGORICAL_FIELD_RAMPS)) {
      for (const entry of values) {
        expect(bannedExactColors, `${entry.value} 复用了专用色`).not.toContain(expandHex(entry.color))
      }
    }
  })

  it('hazardLevel（3 档，不允许放宽）：相邻色相差 ≥35°、相邻对比度 ≥1.8，且每档与底色对比度 ≥3.0', () => {
    const levels = CATEGORICAL_FIELD_RAMPS.hazardLevel ?? []
    expect(levels.map((item) => item.value)).toEqual(['中', '高', '极高'])
    for (const level of levels) {
      expect(contrastRatio(level.color, bg), `${level.value} 与底色对比度不足`).toBeGreaterThanOrEqual(3.0)
    }
    for (let i = 1; i < levels.length; i += 1) {
      const prev = levels[i - 1]
      const cur = levels[i]
      if (prev === undefined || cur === undefined) continue
      expect(hueDiff(prev.color, cur.color), `${prev.value}→${cur.value} 色相差不足`).toBeGreaterThanOrEqual(35)
      expect(
        contrastRatio(prev.color, cur.color),
        `${prev.value}→${cur.value} 相邻对比度不足`,
      ).toBeGreaterThanOrEqual(1.8)
    }
    // 越高等级越显眼：与底色的对比度必须单调递增。
    const contrasts = levels.map((item) => contrastRatio(item.color, bg))
    for (let i = 1; i < contrasts.length; i += 1) {
      expect(contrasts[i]).toBeGreaterThan(contrasts[i - 1] ?? 0)
    }
  })

  /**
   * 第三轮返工：roadGrade 改用 CIE76 ΔE 作为不可规避的硬指标，不再有色相角/对比度二选一的放宽项。
   * 与专用色（选中蓝、查询橙/风险较高、影响范围红/风险高、以及 RISK_LEVEL_COLOR 其余三色）的
   * ΔE 也一并锁定 ≥25，防止被误读成风险分级或影响范围提示色。
   */
  it('roadGrade（6 档）：相邻档位 ΔE ≥22、相邻对比度 ≥1.35，每档与底色对比度 ≥3.0 且单调递增', () => {
    const grades = CATEGORICAL_FIELD_RAMPS.roadGrade ?? []
    expect(grades.map((item) => item.value)).toEqual(['等外', '四级', '三级', '二级', '一级', '高速'])
    for (const grade of grades) {
      expect(contrastRatio(grade.color, bg), `${grade.value} 与底色对比度不足`).toBeGreaterThanOrEqual(3.0)
    }
    for (let i = 1; i < grades.length; i += 1) {
      const prev = grades[i - 1]
      const cur = grades[i]
      if (prev === undefined || cur === undefined) continue
      expect(deltaE(prev.color, cur.color), `${prev.value}→${cur.value} ΔE 不足`).toBeGreaterThanOrEqual(22)
      expect(
        contrastRatio(prev.color, cur.color),
        `${prev.value}→${cur.value} 相邻对比度不足`,
      ).toBeGreaterThanOrEqual(1.35)
    }
    const contrasts = grades.map((item) => contrastRatio(item.color, bg))
    for (let i = 1; i < contrasts.length; i += 1) {
      expect(contrasts[i]).toBeGreaterThan(contrasts[i - 1] ?? 0)
    }
  })

  it('roadGrade 与全部专用色（选中蓝/查询橙/影响红/RISK_LEVEL_COLOR 六色）的 ΔE ≥25', () => {
    const grades = CATEGORICAL_FIELD_RAMPS.roadGrade ?? []
    for (const grade of grades) {
      for (const banned of bannedExactColors) {
        expect(
          deltaE(grade.color, banned),
          `${grade.value}(${grade.color}) 与专用色 ${banned} 的 ΔE 太近`,
        ).toBeGreaterThanOrEqual(25)
      }
    }
  })
})

describe('阶段2 几何转换：点线面与多部件', () => {
  function detail(id: string, geometry: FeatureDetail['geometry']): FeatureDetail {
    return {
      ref: { layerId: 'test.layer', id },
      title: `测试对象 ${id}`,
      datasetId: 'test-dataset',
      geometry,
      properties: { name: `测试对象 ${id}`, sample: true },
      relatedResultIds: [],
    }
  }

  /** 昆仑山附近的合成坐标（[经度, 纬度]）。 */
  const multiPoint: FeatureDetail = detail('mp-1', {
    type: 'MultiPoint',
    coordinates: [
      [90.1, 30.1],
      [90.4, 30.4],
    ],
  })
  const multiLine: FeatureDetail = detail('ml-1', {
    type: 'MultiLineString',
    coordinates: [
      [
        [90.1, 30.1],
        [90.5, 30.5],
      ],
      [
        [90.6, 30.6],
        [91, 31],
      ],
    ],
  })
  const multiPolygon: FeatureDetail = detail('mpg-1', {
    type: 'MultiPolygon',
    coordinates: [
      [
        [
          [90, 30],
          [90.2, 30],
          [90.2, 30.2],
          [90, 30],
        ],
      ],
      [
        [
          [90.5, 30.5],
          [90.7, 30.5],
          [90.7, 30.7],
          [90.5, 30.5],
        ],
      ],
    ],
  })
  const noGeometry: FeatureDetail = detail('no-geom-1', null)

  it('多部件记录按同一家族渲染，不丢部件', () => {
    const converted = toOlFeatures([multiPoint, multiLine, multiPolygon])
    expect(converted.skipped).toBe(0)
    expect(converted.features.map((feature) => feature.getGeometry()?.getType())).toEqual([
      'MultiPoint',
      'MultiLineString',
      'MultiPolygon',
    ])
    expect(converted.features.map((feature) => olGeometryFamily(feature.getGeometry()))).toEqual([
      'Point',
      'LineString',
      'Polygon',
    ])
  })

  it('多部件记录带出可读说明，单部件返回 null', () => {
    const converted = toOlFeatures([multiPoint, multiLine, multiPolygon])
    expect(multiPartNote(converted.features[0]?.getGeometry())).toContain('MultiPoint')
    expect(multiPartNote(converted.features[1]?.getGeometry())).toContain('MultiLineString')
    expect(multiPartNote(converted.features[2]?.getGeometry())).toContain('MultiPolygon')
    const single = toOlFeatures([detail('p-1', { type: 'Point', coordinates: [90, 30] })])
      .features[0]
    expect(multiPartNote(single?.getGeometry())).toBeNull()
  })

  it('坐标被显式投影到 EPSG:3857（不是把经纬度直接当平面坐标）', () => {
    const converted = toOlFeatures([multiPoint])
    const extent = converted.features[0]?.getGeometry()?.getExtent() ?? []
    const west = extent[0] ?? 0
    const south = extent[1] ?? 0
    const east = extent[2] ?? 0
    const north = extent[3] ?? 0
    // 经度 90—91 在 Web Mercator 下约为 1.0e7 米量级，纬度 30 约为 3.5e6 米。
    expect(west).toBeGreaterThan(9_000_000)
    expect(east).toBeLessThan(11_000_000)
    expect(south).toBeGreaterThan(3_000_000)
    expect(north).toBeLessThan(4_000_000)
  })

  it('无几何记录不上图，但被计数为 skipped（属性仍在契约里可查）', () => {
    const converted = toOlFeatures([multiPoint, noGeometry])
    expect(converted.features.length).toBe(1)
    expect(converted.skipped).toBe(1)
  })

  it('要素 ID 使用 layerId:id，跨图层同 ID 不互相覆盖', () => {
    const a = toOlFeatures([detail('1', { type: 'Point', coordinates: [90, 30] })])
    const bDetail: FeatureDetail = {
      ...detail('1', { type: 'Point', coordinates: [91, 31] }),
      ref: { layerId: 'other.layer', id: '1' },
    }
    const b = toOlFeatures([bDetail])
    expect(a.features[0]?.getId()).toBe('test.layer:1')
    expect(b.features[0]?.getId()).toBe('other.layer:1')
  })

  it('几何为 GeometryCollection 时归入 null 家族，由界面按「不可定位」处理', () => {
    const collection = toOlFeatures([
      detail('gc-1', {
        type: 'GeometryCollection',
        geometries: [{ type: 'Point', coordinates: [90, 30] }],
      }),
    ]).features[0]
    expect(olGeometryFamily(collection?.getGeometry())).toBeNull()
  })
})
