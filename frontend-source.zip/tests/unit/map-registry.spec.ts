import { describe, expect, it } from 'vitest'

import {
  groupLayersByTheme,
  initialDrawOrder,
  isMapTheme,
  layerAvailability,
  layerTimeText,
  layerTypeText,
  mapLayersOf,
  mapSourceLabel,
  matchesLayerSearch,
  MAP_THEMES,
} from '@/config/mapLayers'
import { GEOMETRY_FAMILY_LABEL, THEME_LABEL } from '@/domain/labels'
import type { LayerDefinition } from '@/domain/types'
import { createDemoRepositories } from './helpers/repository-fixtures'

/**
 * 阶段2 图层注册表视图配置的单元测试。
 *
 * 这些断言的目的是把「图层树靠写死的图层 ID 拼出来」「栅格被当成可用图层」
 * 「搜索只按名称匹配」三类问题变成红灯；数据一律来自示例数据包本身，
 * 不在这里另写一份图层清单。
 */

const repositories = createDemoRepositories()

async function demoLayers(): Promise<LayerDefinition[]> {
  const envelope = await repositories.layers.listLayers()
  return envelope.data
}

describe('阶段2 图层注册表：五主题分组', () => {
  it('五主题顺序固定，且系统元数据不进入地图', () => {
    expect([...MAP_THEMES]).toEqual(['base', 'tnr', 'hazard', 'emg', 'result'])
    expect(isMapTheme('sys')).toBe(false)
    expect(isMapTheme('hazard')).toBe(true)
  })

  it('示例包的图层按主题分组后，五组都有内容且组内标签不重复', async () => {
    const layers = await demoLayers()
    const groups = groupLayersByTheme(layers)
    expect(groups.map((group) => group.theme)).toEqual([...MAP_THEMES])
    for (const group of groups) {
      expect(group.label, group.theme).toBe(THEME_LABEL[group.theme])
      const ids = group.layers.map((layer) => layer.id)
      expect(new Set(ids).size, `${group.theme} 组内图层 ID 重复`).toBe(ids.length)
    }
  })

  it('注册表里的每个图层都归属地图工作台（示例包不含 sys 图层）', async () => {
    const layers = await demoLayers()
    expect(mapLayersOf(layers).length).toBe(layers.length)
    expect(layers.length).toBeGreaterThan(0)
  })

  it('分组不重排注册表顺序：组内顺序与接口返回一致', async () => {
    const layers = await demoLayers()
    for (const group of groupLayersByTheme(layers)) {
      const expected = layers.filter((layer) => layer.theme === group.theme).map((l) => l.id)
      expect(group.layers.map((layer) => layer.id)).toEqual(expected)
    }
  })
})

describe('阶段2 图层注册表：可渲染性与诚实原因', () => {
  it('栅格图层不可渲染，并说明「已登记但服务状态另见目录」', async () => {
    const layers = await demoLayers()
    const rasters = layers.filter((layer) => layer.geometryType === 'Raster')
    expect(rasters.length).toBeGreaterThan(0)
    for (const layer of rasters) {
      const availability = layerAvailability(layer)
      expect(availability.available, layer.id).toBe(false)
      expect(availability.reason, layer.id).toContain('栅格图层')
      expect(availability.reason, layer.id).toContain('服务')
    }
  })

  it('声明 source.type = unavailable 的图层，原因包含数据包原话，不被改写', async () => {
    const layers = await demoLayers()
    const unavailable = layers.filter((layer) => layer.source.type === 'unavailable')
    expect(unavailable.length).toBeGreaterThan(0)
    for (const layer of unavailable) {
      const availability = layerAvailability(layer)
      expect(availability.available, layer.id).toBe(false)
      const reason = layer.source.type === 'unavailable' ? layer.source.reason : ''
      // 栅格 + 服务未接入同时成立时，两条原因都要出现，不能只留通用说明。
      expect(availability.reason, layer.id).toContain(reason)
      expect(mapSourceLabel(layer.source), layer.id).toBe('暂未提供')
    }
  })

  it('点/线/面矢量图层可渲染，且未被栅格规则误伤', async () => {
    const layers = await demoLayers()
    const vectors = layers.filter(
      (layer) =>
        layer.geometryType === 'Point' ||
        layer.geometryType === 'LineString' ||
        layer.geometryType === 'Polygon',
    )
    expect(vectors.length).toBeGreaterThan(0)
    for (const layer of vectors) {
      expect(layerAvailability(layer).available, layer.id).toBe(true)
      expect(layerAvailability(layer).reason, layer.id).toBeNull()
      expect(layerTypeText(layer), layer.id).toContain(GEOMETRY_FAMILY_LABEL[layer.geometryType])
    }
  })

  it('所有图层都给了可用性结论，没有「不置可否」的图层', async () => {
    const layers = await demoLayers()
    for (const layer of layers) {
      const availability = layerAvailability(layer)
      if (availability.available) {
        expect(availability.reason, layer.id).toBeNull()
      } else {
        expect(availability.reason, layer.id).toBeTruthy()
        expect((availability.reason ?? '').length, layer.id).toBeGreaterThan(8)
      }
    }
  })

  it('时相未登记时写明「时相未登记」，不编造年份', async () => {
    const layers = await demoLayers()
    const withoutTimes = layers.filter((layer) => layer.availableTimes.length === 0)
    expect(withoutTimes.length).toBeGreaterThan(0)
    for (const layer of withoutTimes) {
      expect(layerTimeText(layer), layer.id).toBe('时相未登记')
    }
  })
})

describe('阶段2 图层注册表：搜索', () => {
  it('空搜索命中全部图层', async () => {
    const layers = await demoLayers()
    for (const layer of layers) expect(matchesLayerSearch(layer, '   '), layer.id).toBe(true)
  })

  it('可按名称、layerId、主题名、几何类型与数据集 ID 命中', async () => {
    const layers = await demoLayers()
    const glacier = layers.find((layer) => layer.id === 'tnr.glacier.polygon')
    expect(glacier, '示例包应包含 tnr.glacier.polygon').toBeTruthy()
    if (!glacier) return
    for (const keyword of [
      '冰川',
      'tnr.glacier',
      '地形与冰冻圈',
      GEOMETRY_FAMILY_LABEL[glacier.geometryType],
      glacier.datasetId,
    ]) {
      expect(matchesLayerSearch(glacier, keyword), keyword).toBe(true)
    }
    expect(matchesLayerSearch(glacier, '不存在的关键词')).toBe(false)
  })

  it('搜索只过滤命中项，不改变分组与主题顺序', async () => {
    const layers = await demoLayers()
    const groups = groupLayersByTheme(layers, '冰川')
    expect(groups.length).toBeGreaterThan(0)
    for (const group of groups) {
      expect(
        group.layers.every((layer) => layer.label.includes('冰川') || layer.id.includes('glacier')),
      ).toBe(true)
    }
    const themes = groups.map((group) => group.theme)
    const ordered = [...MAP_THEMES].filter((theme) => themes.includes(theme))
    expect(themes).toEqual(ordered)
  })
})

describe('阶段2 图层注册表：叠放顺序', () => {
  it('初始叠放顺序按几何类型分层：所有点都在线之上、线都在面之上', async () => {
    const layers = await demoLayers()
    const order = initialDrawOrder(layers)
    const rankOf = (id: string): number => {
      const layer = layers.find((item) => item.id === id)
      if (!layer) return -1
      if (layer.geometryType === 'Point') return 2
      if (layer.geometryType === 'LineString') return 1
      return 0
    }
    // 数组首位在最上层：rank 必须单调不增。
    for (let index = 1; index < order.length; index += 1) {
      const previous = rankOf(order[index - 1] ?? '')
      const current = rankOf(order[index] ?? '')
      expect(current, `${order[index]} 不应压在 ${order[index - 1]} 之上`).toBeLessThanOrEqual(
        previous,
      )
    }
  })

  it('示例研究区边界（面）排在点要素之下，点选不会被边界挡住', async () => {
    const layers = await demoLayers()
    const order = initialDrawOrder(layers)
    const pointLayers = layers
      .filter((layer) => layer.geometryType === 'Point')
      .map((layer) => layer.id)
    expect(pointLayers.length).toBeGreaterThan(0)
    for (const pointId of pointLayers) {
      expect(order.indexOf(pointId), pointId).toBeLessThan(order.indexOf('base.boundary'))
    }
  })

  it('叠放顺序覆盖全部图层且不重复', async () => {
    const layers = await demoLayers()
    const order = initialDrawOrder(layers)
    expect(order.length).toBe(layers.length)
    expect(new Set(order).size).toBe(order.length)
  })
})

describe('阶段2 示例包的阶段2 相关事实（供验收核对，不是通过条件）', () => {
  it('示例包不含多部件几何：多部件支持由 tests/unit/map-style.spec.ts 的合成夹具覆盖', async () => {
    const layers = await demoLayers()
    const multi: string[] = []
    for (const layer of layers) {
      if (layer.source.type !== 'geojson') continue
      const page = await repositories.layers.listFeatures(layer.id, { page: 1, pageSize: 500 })
      for (const item of page.data.items) {
        const type = item.geometry?.type
        if (type !== undefined && type.startsWith('Multi')) multi.push(`${layer.id}:${item.ref.id}`)
      }
    }
    expect(
      multi,
      '示例包出现了多部件几何；请把本用例改为断言多部件在浏览器层被渲染，并更新阶段2 记录',
    ).toEqual([])
  })

  it('示例包存在无几何记录（阶段2 任务5 与验收项 F04 的真实用例）', async () => {
    const page = await repositories.layers.listFeatures('result.demo.risk', {
      page: 1,
      pageSize: 500,
    })
    const noGeometry = page.data.items.filter((item) => item.geometry === null)
    expect(noGeometry.length, '示例风险区应保留无几何记录').toBeGreaterThan(0)
    for (const item of noGeometry) {
      expect(Object.keys(item.properties).length, item.ref.id).toBeGreaterThan(0)
    }
  })
})
