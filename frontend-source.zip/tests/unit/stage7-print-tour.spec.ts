/**
 * 阶段7：演示模式、答辩导览与专题图打印取数。
 *
 * 演示模式/导览测试 Pinia 状态与路由推进的确定性（固定六步、可进可退可退出）；
 * 打印取数走生产代码路径（createRepositories → JSON 包适配器 → 服务层），
 * 夹具只替换 JsonFetcher（故障注入），任何读取失败都必须拒绝而不是回退。
 */
import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import { createPrintSheetService, type PrintSheet } from '@/services/printSheet'
import { createDemoRepositories, createDiskFetcher, mockEnv } from './helpers/repository-fixtures'
import type { JsonFetcher } from '@/repositories/json/loader'
import { createRepositories } from '@/repositories'
import type { Repositories } from '@/repositories/types'
import {
  API_TOUR_STEPS,
  TOUR_STEPS,
  setTourRouterBridge,
  tourStepsForMode,
  useTourStore,
} from '@/stores/tour'
import { usePresentationStore } from '@/stores/presentation'
import { useSessionStore } from '@/stores/session'

function demoPrintService() {
  return createPrintSheetService(createDemoRepositories())
}

/* ------------------------------------------------------------------ *
 * 演示模式
 * ------------------------------------------------------------------ */

describe('阶段7 演示模式（明确进入与退出）', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('enter 后 html 标记 presentation 且状态为 active；exit 完整清理', () => {
    const store = usePresentationStore()
    expect(store.active).toBe(false)
    store.enter()
    expect(store.active).toBe(true)
    expect(document.documentElement.dataset.presentation).toBe('true')
    store.exit()
    expect(store.active).toBe(false)
    expect(document.documentElement.dataset.presentation).toBeUndefined()
  })

  it('toggle 在进入与退出之间切换；reset 清理残留标记', () => {
    const store = usePresentationStore()
    store.toggle()
    expect(store.active).toBe(true)
    store.toggle()
    expect(store.active).toBe(false)
    // 模拟上一会话残留
    document.documentElement.dataset.presentation = 'true'
    store.reset()
    expect(store.active).toBe(false)
    expect(document.documentElement.dataset.presentation).toBeUndefined()
  })
})

/* ------------------------------------------------------------------ *
 * 答辩演示导览（固定六步，不随机播放）
 * ------------------------------------------------------------------ */

describe('阶段7 答辩演示导览（固定顺序，可复现）', () => {
  const pushCalls: Array<unknown> = []

  beforeEach(() => {
    setActivePinia(createPinia())
    pushCalls.length = 0
    // 注入假路由桥（与 AppShell setup 注入真 router 的方式一致）
    setTourRouterBridge({
      push: (target: unknown) => {
        pushCalls.push(target)
        return Promise.resolve()
      },
    })
  })

  it('固定五步：总览 → 风险 → 应急 → 来源/成果 → 导出', () => {
    expect(TOUR_STEPS).toHaveLength(5)
    expect(TOUR_STEPS.map((step) => step.route.path)).toEqual([
      '/overview',
      '/analysis/risk',
      '/analysis/emergency',
      '/results/result.demo.risk',
      '/map',
    ])
    // 应急步骤保留固定深链接，保证示例导览可复现；暴露专题本版未交付。
    expect(TOUR_STEPS[2]?.route.query).toEqual({
      resultId: 'result.demo.route',
      routeId: 'DEMO-ROUTE-B',
    })
  })

  it('start 从第一步开始并导航；next 按固定顺序推进并导航', () => {
    const store = useTourStore()
    store.start()
    expect(store.stepIndex).toBe(0)
    expect(store.isFirst).toBe(true)
    expect(pushCalls.length).toBe(1)

    store.next()
    expect(store.stepIndex).toBe(1)
    expect(store.progressLabel).toBe('2 / 5')
    store.next()
    store.next()
    expect(store.stepIndex).toBe(3)
    // 每次推进都有导航，且路径与步骤一一对应（确定性）
    expect(pushCalls.length).toBe(4)
  })

  it('第一步 prev 无效；最后一步 next 即退出；exit 随时退出', () => {
    const store = useTourStore()
    store.start()
    store.prev()
    expect(store.stepIndex).toBe(0)
    expect(store.isLast).toBe(false)

    store.stepIndex = TOUR_STEPS.length - 1
    expect(store.isLast).toBe(true)
    store.next()
    expect(store.active).toBe(false)

    store.start()
    store.exit()
    expect(store.stepIndex).toBeNull()
  })

  it('正式 API 导览不携带示例 ID，指向已接入的真实成果与当前页导出', () => {
    const session = useSessionStore()
    session.mode = 'api'
    const store = useTourStore()

    expect(tourStepsForMode('mock')).toBe(TOUR_STEPS)
    expect(tourStepsForMode('api')).toBe(API_TOUR_STEPS)
    expect(store.steps).toBe(API_TOUR_STEPS)
    expect(store.steps.flatMap((step) => Object.values(step.route.query ?? {}))).not.toEqual(
      expect.arrayContaining(['result.demo.impact', 'result.demo.route', 'DEMO-ROUTE-B']),
    )
    expect(store.steps[1]?.route).toEqual({
      path: '/analysis/risk',
      query: { source: 'projectAnalysis' },
    })
    expect(store.steps[2]?.route).toEqual({
      path: '/analysis/emergency',
      query: { resultId: 'result.route.combined' },
    })
    expect(store.steps[3]?.route.path).toBe('/results/result.susceptibility.combined')
    expect(store.steps[4]?.note).toContain('当前页导出')

    store.start()
    expect(pushCalls[0]).toEqual({ path: '/overview' })
    store.next()
    expect(pushCalls[1]).toEqual({
      path: '/analysis/risk',
      query: { source: 'projectAnalysis' },
    })
  })
})

/* ------------------------------------------------------------------ *
 * 专题图打印取数（三类信息完整 + 失败不回退）
 * ------------------------------------------------------------------ */

function assertCommonSheet(sheet: PrintSheet): void {
  expect(sheet.title.trim()).not.toBe('')
  expect(sheet.resultTitle.trim()).not.toBe('')
  expect(sheet.regionLabel.trim()).not.toBe('')
  expect(sheet.timeLabel.trim()).not.toBe('')
  // 示例身份必须随打印件持续存在
  expect(sheet.identityLabel).toContain('示例')
  expect(sheet.methodLabel).not.toBeNull()
  expect(sheet.sourceLines.length).toBeGreaterThan(0)
  expect(sheet.legend.length).toBeGreaterThan(0)
}

describe('阶段7 专题图打印取数（风险 / 暴露 / 应急）', () => {
  it('风险专题图：分级图例含数据不足，方法与来源齐备', async () => {
    const sheet = await demoPrintService().buildSheet('risk', 'result.demo.risk')
    expect(sheet.kind).toBe('risk')
    assertCommonSheet(sheet)
    expect(sheet.title).toBe('风险分级专题图')
    // 示例分级登记了六个类别（含数据不足）；数据不足必须以文字形式进图例，不只靠颜色
    const labels = sheet.legend.map((entry) => entry.label)
    expect(labels).toContain('数据不足')
    const insufficient = sheet.legend.find((entry) => entry.label === '数据不足')
    expect(insufficient?.note).toContain('文字')
    expect(sheet.features.length).toBeGreaterThan(0)
  })

  it('正式 API 风险打印不凭空生成五级图例，保留真实点页与登记字段口径', async () => {
    const demo = createDemoRepositories()
    const apiResults: Repositories['results'] = {
      ...demo.results,
      getResult: async (resultId, options) => {
        const envelope = await demo.results.getResult('result.demo.risk', options)
        return {
          ...envelope,
          data: {
            ...envelope.data,
            id: resultId,
            title: '正式滑坡易发性点成果',
            classification: null,
            metrics: [
              ...envelope.data.metrics,
              {
                key: 'pointCount',
                label: '正式成果点数',
                value: 1582,
                unit: '点',
                status: 'known',
              },
            ],
          },
        }
      },
    }
    const apiRepositories: Repositories = { ...demo, mode: 'api', results: apiResults }
    const sheet = await createPrintSheetService(apiRepositories).buildSheet(
      'risk',
      'result.susceptibility.combined',
    )

    expect(sheet.identityLabel).toContain('正式 API')
    expect(sheet.features.length).toBeGreaterThan(0)
    expect(sheet.features.length).toBeLessThanOrEqual(500)
    expect(sheet.legend).toHaveLength(1)
    expect(sheet.legend[0]?.label).toContain('颜色不表示分级')
    expect(sheet.notes.join('；')).toContain('HAZ_LEVEL / SCORE')
    expect(sheet.notes.join('；')).toContain('登记总量 1582 点')
  })

  it('暴露专题图：指标含人口未提供，口径说明随件', async () => {
    const sheet = await demoPrintService().buildSheet('exposure', 'result.demo.impact')
    expect(sheet.kind).toBe('exposure')
    assertCommonSheet(sheet)
    // 人口为 null（notProvided），打印件不得显示为 0
    const population = sheet.metrics.find((metric) => metric.key === 'population')
    expect(population?.value).toBeNull()
    const noteText = sheet.notes.join('；')
    expect(noteText).toMatch(/去重规则|分开显示/)
    expect(sheet.features.length).toBeGreaterThan(0)
  })

  it('应急专题图：B 方案有距离与时间来源；C 方案无路径不画线', async () => {
    const service = demoPrintService()
    const sheetB = await service.buildSheet('emergency', 'result.demo.route', 'DEMO-ROUTE-B')
    expect(sheetB.kind).toBe('emergency')
    assertCommonSheet(sheetB)
    expect(sheetB.route).not.toBeNull()
    expect(sheetB.route?.geometry).not.toBeNull()
    expect(sheetB.measureLine).toContain('距离')
    expect(sheetB.measureLine).toContain('时间')
    expect(sheetB.legend).toHaveLength(3)

    const sheetC = await service.buildSheet('emergency', 'result.demo.route', 'DEMO-ROUTE-C')
    expect(sheetC.route?.geometry).toBeNull()
    expect(sheetC.notes.join('；')).toContain('无可达路径')
  })

  it('读取失败时拒绝生成打印件，不回退示例数据', async () => {
    const failingFetcher: JsonFetcher = async () => {
      throw new Error('results.json 读取失败（模拟）')
    }
    const service = createPrintSheetService(
      createRepositories(mockEnv, { jsonFetcher: failingFetcher }),
    )
    await expect(service.buildSheet('risk', 'result.demo.risk')).rejects.toThrow(/失败/)
    await expect(service.buildSheet('exposure', 'result.demo.impact')).rejects.toThrow(/失败/)
    await expect(service.buildSheet('emergency', 'result.demo.route')).rejects.toThrow(/失败/)
    void createDiskFetcher
  })
})
