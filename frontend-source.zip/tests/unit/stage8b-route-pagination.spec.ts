/**
 * 阶段8B返工：路线列表服务端分页 · 前端契约单测。
 *
 * 覆盖：
 * 1. Repository 各模式（mock/json 包 + HTTP 适配器）都返回 Page<RouteSummary>；
 * 2. API 数据链路页：切换成果页码重置 1、翻页清除旧路线、失败不保留旧页、
 *    总页数计算正确、路线详情不破坏分页状态。
 *
 * 组件测试用 @vue/test-utils + jsdom 挂载 ApiDataView，
 * workspace 服务经 setApiDataWorkspaceService 注入替身（页面零直接 fetch）。
 */
import { flushPromises, mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import ApiDataView from '@/views/ApiDataView.vue'
import {
  setApiDataWorkspaceService,
  type ApiDataWorkspaceService,
} from '@/services/apiDataWorkspace'
import { useSessionStore } from '@/stores/session'
import type {
  Dictionary,
  FeatureDetail,
  LayerDefinition,
  Page,
  Region,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import { createHttpRepositories } from '@/repositories/http/httpRepository'

/* ------------------------------------------------------------------ *
 * 1) Repository 契约：HTTP 模式同样返回 Page（mock/json 包见 repository-contract.spec）
 * ------------------------------------------------------------------ */

describe('listRoutes 分页契约（HTTP 适配器）', () => {
  it('listRoutes 以 query(page/pageSize) 请求并返回 Page<RouteSummary>', async () => {
    const requests: string[] = []
    const pageBody = {
      data: {
        items: [{ id: 'result.route.combined:R1', resultId: 'result.route.combined' }],
        total: 4566,
        page: 2,
        pageSize: 20,
      },
      meta: {
        mode: 'api',
        snapshotId: 'live-db-readonly',
        generatedAt: '2026-09-17T00:00:00Z',
        scopeLabel: '青藏高原',
        boundaryVersion: 'v1',
        datasetVersions: {},
        sourceCrs: 'CGCS2000_Tibetan_Plateau_LCC',
        outputCrs: 'EPSG:4326',
      },
      requestId: 'req-1',
    }
    const fetcher = vi.fn().mockImplementation((input: RequestInfo | URL) => {
      requests.push(String(input))
      return Promise.resolve(new Response(JSON.stringify(pageBody), { status: 200 }))
    })
    const repositories = createHttpRepositories({
      baseUrl: 'http://127.0.0.1:18080/api/v1',
      fetcher: fetcher as unknown as typeof fetch,
    })
    const envelope = await repositories.results.listRoutes('result.route.combined', {
      page: 2,
      pageSize: 20,
    })
    // URL 带 page=2&pageSize=20（服务端分页参数）
    expect(requests[0]).toContain('/results/result.route.combined/routes')
    expect(requests[0]).toContain('page=2')
    expect(requests[0]).toContain('pageSize=20')
    expect(envelope.data.total).toBe(4566)
    expect(envelope.data.page).toBe(2)
    expect(envelope.data.pageSize).toBe(20)
    expect(Array.isArray(envelope.data.items)).toBe(true)
  })
})

/* ------------------------------------------------------------------ *
 * 2) API 数据链路页的分页行为（组件级）
 * ------------------------------------------------------------------ */

const TOTALS: Record<string, number> = {
  'result.route.combined': 4566,
  'result.route.2050': 1731,
  'result.route.2100': 1872,
}

interface RouteCall {
  resultId: string
  page: number
  pageSize: number
  hazardPointId?: string
}

function makeRoute(index: number, scope: string): RouteSummary {
  return {
    id: `${scope}:R${String(index).padStart(4, '0')}`,
    resultId: scope,
    label: `${scope} 医院${index}`,
    role: index === 0 ? 'primary' : 'alternative',
    status: 'reachable',
    distanceMeters: 1000 + index,
    durationSeconds: null,
    networkVersion: 'v1',
    blockedFeatureRefs: [],
    assumptions: [],
    generatedAt: '2026-01-01T00:00:00Z',
    hazardPointId: 'HZ000001',
    facilityType: '医院',
  }
}

/** 可编程的路线取数替身：记录调用、可注入失败与延迟。 */
function makeFakeService() {
  const calls: RouteCall[] = []
  let failNext = false
  let gate: ((value: unknown) => void) | null = null
  let deferRequests = false
  const pendingRequests: Array<{
    payload: unknown
    resolve: (value: unknown) => void
  }> = []
  const service: ApiDataWorkspaceService = {
    listLayers: vi.fn().mockResolvedValue([] as LayerDefinition[]),
    listDatasets: vi
      .fn()
      .mockResolvedValue({ items: [], total: 57, page: 1, pageSize: 10 } as Page<never>),
    listRegions: vi.fn().mockResolvedValue([] as Region[]),
    getDictionary: vi.fn().mockResolvedValue({ label: 'gb', items: [] } as unknown as Dictionary),
    listFeatures: vi
      .fn()
      .mockResolvedValue({ items: [], total: 0, page: 1, pageSize: 10 } as Page<FeatureDetail>),
    getFeature: vi.fn(),
    listRoutes: vi
      .fn()
      .mockImplementation((resultId: string, query?: { page?: number; pageSize?: number }) => {
        const page = query?.page ?? 1
        const pageSize = query?.pageSize ?? 20
        calls.push({ resultId, page, pageSize })
        if (failNext) {
          failNext = false
          return Promise.reject(new Error('后端不可达'))
        }
        const total = TOTALS[resultId] ?? 0
        const start = (page - 1) * pageSize
        const items: RouteSummary[] = []
        for (let i = start; i < Math.min(start + pageSize, total); i += 1) {
          items.push(makeRoute(i, resultId))
        }
        const payload = { items, total, page, pageSize }
        if (deferRequests) {
          return new Promise((resolve) => {
            pendingRequests.push({ payload, resolve })
          })
        }
        if (gate !== null) {
          return new Promise((resolve) => {
            gate = null
            setTimeout(() => resolve(payload), 5)
          })
        }
        return Promise.resolve(payload)
      }),
    getRoute: vi.fn().mockImplementation((routeId: string) => {
      return Promise.resolve({
        ...makeRoute(0, routeId.split(':')[0] ?? ''),
        id: routeId,
        origin: { ref: null, label: '起点', lonLat: null },
        destination: { ref: null, label: '终点', lonLat: null },
        geometry: null,
        distanceSource: '登记值',
        durationSource: null,
      } as RouteDetail)
    }),
  }
  return {
    service,
    calls,
    failNextRequest() {
      failNext = true
    },
    slowNextRequest() {
      gate = () => undefined
    },
    deferNextRouteRequests() {
      deferRequests = true
    },
    pendingRouteCount() {
      return pendingRequests.length
    },
    resolvePendingRoute(index = 0) {
      const pending = pendingRequests.splice(index, 1)[0]
      if (pending) pending.resolve(pending.payload)
    },
  }
}

async function mountView() {
  const pinia = createPinia()
  setActivePinia(pinia)
  const session = useSessionStore()
  session.mode = 'api'
  session.capabilities = {
    readLayers: true,
    attributeQuery: false,
    spatialQuery: false,
    readResults: false,
    routeRecompute: false,
    analysisSubmit: false,
    dataEdit: false,
    backupExecute: false,
    exportFormats: [],
    reasons: { attributeQuery: '未接入' },
  } as never
  session.loadCapabilities = vi.fn().mockResolvedValue(undefined)

  const fake = makeFakeService()
  setApiDataWorkspaceService(fake.service)
  const wrapper = mount(ApiDataView, {
    global: {
      plugins: [pinia],
      stubs: { RouterLink: { template: '<a><slot /></a>' } },
    },
  })
  await flushPromises()
  return { wrapper, fake, session }
}

describe('API 数据链路页 · 路线服务端分页', () => {
  beforeEach(() => {
    setApiDataWorkspaceService(null)
  })

  it('首次加载只请求第1页（page=1&pageSize=20），显示总页数', async () => {
    const { wrapper, fake } = await mountView()
    expect(fake.calls).toEqual([{ resultId: 'result.route.combined', page: 1, pageSize: 20 }])
    expect(wrapper.find('[data-testid="api-routes-total"]').text()).toBe('4566')
    // 4566 / 20 = 228.3 → 总页数 229
    expect(wrapper.find('[data-testid="api-routes-total-pages"]').text()).toBe('229')
    expect(wrapper.findAll('tbody tr').length).toBe(20)
    wrapper.unmount()
  })

  it('能力面板按布尔开关渲染 readResults，不把其说明文字误判为未接入', async () => {
    const { wrapper, session } = await mountView()
    session.capabilities = {
      ...session.capabilities!,
      readResults: true,
      reasons: {
        ...session.capabilities!.reasons,
        readResults: '成果清单/详情/统计/总览已接入（受控登记）。',
      },
    }
    await flushPromises()

    const capabilities = wrapper.get('[data-testid="api-capabilities"]')
    expect(capabilities.text()).toContain('成果查看')
    expect(capabilities.text()).toContain('可查看成果目录与详情')
    expect(capabilities.text()).not.toContain('暂未提供：成果清单/详情/统计/总览已接入')
    wrapper.unmount()
  })

  it('点击下一页请求 page=2 且先清除旧路线', async () => {
    const { wrapper, fake } = await mountView()
    fake.slowNextRequest()
    await wrapper.find('[data-testid="api-routes-next"]').trigger('click')
    // 等待返回前：旧页路线已清空（不得保留上一页内容）
    expect(wrapper.findAll('tbody tr').length).toBe(0)
    await flushPromises()
    // 替身延迟为 setTimeout 宏任务，需等待真实计时器走完
    await new Promise((resolve) => setTimeout(resolve, 10))
    await flushPromises()
    expect(fake.calls[1]).toEqual({
      resultId: 'result.route.combined',
      page: 2,
      pageSize: 20,
    })
    expect(wrapper.find('[data-testid="api-routes-page"]').text()).toBe('2')
    expect(wrapper.findAll('tbody tr').length).toBe(20)
    wrapper.unmount()
  })

  it('切换成果后页码重置为1且不保留上一成果路线', async () => {
    const { wrapper, fake } = await mountView()
    await wrapper.find('[data-testid="api-routes-next"]').trigger('click')
    await flushPromises()
    expect(wrapper.find('[data-testid="api-routes-page"]').text()).toBe('2')

    await wrapper.find('[data-testid="api-scope-select"]').setValue('result.route.2050')
    await flushPromises()
    const lastCall = fake.calls[fake.calls.length - 1]
    expect(lastCall).toEqual({ resultId: 'result.route.2050', page: 1, pageSize: 20 })
    expect(wrapper.find('[data-testid="api-routes-page"]').text()).toBe('1')
    expect(wrapper.find('[data-testid="api-routes-total"]').text()).toBe('1731')
    // 2050 页面内容只含本成果路线
    expect(wrapper.findAll('tbody tr').length).toBe(20)
    expect(wrapper.text()).not.toContain('result.route.combined:R0040')
    wrapper.unmount()
  })

  it('请求失败时清空路线并显示错误，不保留上一页数据', async () => {
    const { wrapper, fake } = await mountView()
    expect(wrapper.findAll('tbody tr').length).toBe(20)
    fake.failNextRequest()
    await wrapper.find('[data-testid="api-routes-next"]').trigger('click')
    await flushPromises()
    expect(wrapper.findAll('tbody tr').length).toBe(0)
    expect(wrapper.find('.error-note').exists()).toBe(true)
    expect(wrapper.find('[data-testid="api-routes-count"]').exists()).toBe(false)
    wrapper.unmount()
  })

  it('打开路线详情不破坏分页状态', async () => {
    const { wrapper, fake } = await mountView()
    await wrapper.find('[data-testid="api-routes-next"]').trigger('click')
    await flushPromises()
    await wrapper.find('[data-testid="api-route-0"]').trigger('click')
    await flushPromises()
    expect(wrapper.find('[data-testid="api-route-detail"]').exists()).toBe(true)
    expect(wrapper.find('[data-testid="api-routes-page"]').text()).toBe('2')
    expect(wrapper.find('[data-testid="api-routes-total"]').text()).toBe('4566')
    expect(wrapper.findAll('tbody tr').length).toBe(20)
    expect(fake.calls.length).toBe(2) // 详情不走 listRoutes
    wrapper.unmount()
  })

  it('首页/末页按钮禁用，总页数计算正确（1731→87页）', async () => {
    const { wrapper } = await mountView()
    const prev = wrapper.find('[data-testid="api-routes-prev"]')
    const next = wrapper.find('[data-testid="api-routes-next"]')
    expect((prev.element as HTMLButtonElement).disabled).toBe(true)
    expect((next.element as HTMLButtonElement).disabled).toBe(false)
    await wrapper.find('[data-testid="api-scope-select"]').setValue('result.route.2050')
    await flushPromises()
    // 1731 / 20 = 86.55 → 87
    expect(wrapper.find('[data-testid="api-routes-total-pages"]').text()).toBe('87')
    wrapper.unmount()
  })

  it('快速切换成果时，晚返回的旧路线页不会覆盖最新成果', async () => {
    const { wrapper, fake } = await mountView()
    fake.deferNextRouteRequests()

    await wrapper.find('[data-testid="api-scope-select"]').setValue('result.route.2050')
    await wrapper.find('[data-testid="api-scope-select"]').setValue('result.route.2100')
    expect(fake.pendingRouteCount()).toBe(2)

    // 先返回第二次（2100）请求；第一次（2050）随后返回也不能覆盖它。
    fake.resolvePendingRoute(1)
    await flushPromises()
    expect(wrapper.find('[data-testid="api-routes-total"]').text()).toBe('1872')
    expect(wrapper.text()).toContain('result.route.2100 医院0')

    fake.resolvePendingRoute(0)
    await flushPromises()
    expect(wrapper.find('[data-testid="api-routes-total"]').text()).toBe('1872')
    expect(wrapper.text()).not.toContain('result.route.2050 医院0')
    wrapper.unmount()
  })
})
