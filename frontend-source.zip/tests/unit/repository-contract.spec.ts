/**
 * 数据层契约测试（阶段1）。
 *
 * 目标：证明 mock 与 snapshot 走的是同一套适配器，且页面能拿到的每一个数字、
 * 每一条引用都来自示例要素现场派生，而不是包内预存的第二份口径。
 *
 * 覆盖 03 §4 的验收点：
 * - 分页不改变总数；`null` 不等于 0；跨表引用（结果↔图层↔要素）成立；
 * - 统计与图表同源（总览分布 = 成果统计分布 = 要素计数）；
 * - 示例模式只读；快照模式缺包时报 `SNAPSHOT_MISSING`；
 * - 空间查询（阶段3）在本地小样本上真正执行：范围外返回 0 条空结果而不是失败；
 *   写能力与计算类能力仍全部关闭（D-032）。
 */
import { describe, expect, it } from 'vitest'

import { NOT_PROVIDED_TEXT, formatFieldValue } from '@/domain/format'
import { polylineLengthMeters } from '@/domain/geometry'
import { RISK_LEVEL_ORDER, toRiskLevel } from '@/domain/risk'
import type {
  Capabilities,
  Dataset,
  FieldDefinition,
  Metric,
  RouteDetail,
  ResultStatistics,
} from '@/domain/types'
import { useSessionStore } from '@/stores/session'
import { createPinia, setActivePinia } from 'pinia'
import { createDemoRepositories, mockEnv, readDemoJson } from './helpers/repository-fixtures'

const repositories = createDemoRepositories()
const demoLayers = readDemoJson<{ layers: { id: string; theme: string }[] }>('layers.json').layers
const demoDatasets = readDemoJson<{ datasets: Dataset[] }>('datasets.json').datasets
const demoCapabilities = readDemoJson<{ capabilities: Capabilities }>(
  'capabilities.json',
).capabilities

function metricByKey(metrics: Metric[], key: string): Metric {
  const metric = metrics.find((item) => item.key === key)
  if (!metric) throw new Error(`未找到指标 ${key}`)
  return metric
}

describe('能力清单与模式身份', () => {
  it('示例模式下能力清单标明 mock 与快照标识，并关闭全部写能力', async () => {
    const envelope = await repositories.capabilities.getCapabilities()

    expect(repositories.mode).toBe('mock')
    expect(envelope.data.mode).toBe('mock')
    expect(envelope.data.snapshotId).toBe('demo-v1')
    expect(envelope.data.readLayers).toBe(true)
    expect(envelope.data.attributeQuery).toBe(true)
    expect(envelope.data.readResults).toBe(true)
    for (const key of [
      'dataEdit',
      'backupExecute',
      'analysisSubmit',
      'routeRecompute',
      'authEnabled',
    ] as const) {
      expect(envelope.data[key], `${key} 应在示例模式下关闭`).toBe(false)
      expect(envelope.data.reasons[key]?.trim().length ?? 0).toBeGreaterThan(0)
    }
    // 阶段3（D-032）：空间查询是只读能力，示例模式在本地小样本上真正执行，
    // 因此声明为可用，并必须给出方法与单位说明；写能力与计算类能力仍全部关闭。
    expect(envelope.data.spatialQuery).toBe(true)
    expect(envelope.data.reasons.spatialQuery?.length ?? 0).toBeGreaterThan(0)
    expect(envelope.data.reasons.spatialQuery).toContain('米')
    expect(envelope.data.exportFormats.length).toBeGreaterThan(0)
  })

  it('信封携带模式、快照、范围与数据集版本，用于来源追溯', async () => {
    const envelope = await repositories.capabilities.getCapabilities()

    expect(envelope.meta.mode).toBe('mock')
    expect(envelope.meta.snapshotId).toBe('demo-v1')
    expect(envelope.meta.scopeLabel.length).toBeGreaterThan(0)
    expect(envelope.meta.boundaryVersion.length).toBeGreaterThan(0)
    expect(Object.keys(envelope.meta.datasetVersions).length).toBeGreaterThan(0)
    expect(envelope.meta.generatedAt).toMatch(/^\d{4}-\d{2}-\d{2}T/)
    expect(envelope.requestId).toMatch(/^req-mock-\d+$/)
  })

  it('数据包内的能力声明与实现一致（未声明的能力不得被前端假定可用）', async () => {
    const envelope = await repositories.capabilities.getCapabilities()

    expect(envelope.data.spatialQuery).toBe(demoCapabilities.spatialQuery)
    expect(envelope.data.exportFormats).toEqual(demoCapabilities.exportFormats)
    expect(envelope.data.dataEdit).toBe(false)
  })
})

describe('图层与要素', () => {
  it('图层清单覆盖示例包中的全部图层，且 id 唯一、主题合法', async () => {
    const envelope = await repositories.layers.listLayers()
    const ids = envelope.data.map((layer) => layer.id)

    expect(envelope.data.length).toBe(demoLayers.length)
    expect(new Set(ids).size).toBe(ids.length)
    for (const layer of envelope.data) {
      expect(layer.fields.length, `${layer.id} 应声明字段`).toBeGreaterThan(0)
      expect(layer.legendId.length, `${layer.id} 应声明图例`).toBeGreaterThan(0)
    }
    // 主题过滤是图层树的基础能力：过滤结果必须是全集的子集。
    const hazard = await repositories.layers.listLayers({ theme: 'hazard' })
    expect(hazard.data.length).toBeGreaterThan(0)
    expect(hazard.data.every((layer) => layer.theme === 'hazard')).toBe(true)
    expect(hazard.data.length).toBeLessThan(envelope.data.length)
  })

  it('图层不存在时报 NOT_FOUND，而不是返回空图层', async () => {
    await expect(repositories.layers.getLayer('layer.does.not.exist')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
  })

  it('要素分页不改变总数，且不同页之间不重复', async () => {
    const first = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 5,
    })
    const second = await repositories.layers.listFeatures('base.settlement.point', {
      page: 2,
      pageSize: 5,
    })

    expect(first.data.total).toBe(second.data.total)
    expect(first.data.items.length).toBeGreaterThan(0)
    expect(first.data.page).toBe(1)
    expect(first.data.pageSize).toBe(5)
    // 分页不改变总数：total 必须是全量匹配数，而不是当前页长度。
    expect(first.data.total).toBeGreaterThan(first.data.items.length)

    const firstIds = first.data.items.map((item) => item.ref.id)
    const secondIds = second.data.items.map((item) => item.ref.id)
    expect(firstIds.some((id) => secondIds.includes(id))).toBe(false)
  })

  it('要素详情包含几何、属性与关联成果，且属性值保留 null', async () => {
    const page = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 50,
    })
    const withNulls = page.data.items.filter((item) =>
      Object.values(item.properties).some((value) => value === null),
    )

    expect(page.data.items.length).toBe(page.data.total)
    for (const item of page.data.items) {
      expect(item.geometry, `${item.ref.id} 应带几何`).not.toBeNull()
      expect(item.datasetId.length).toBeGreaterThan(0)
      expect(item.title.length).toBeGreaterThan(0)
    }
    // 示例包刻意保留人口等缺失值：null 必须原样穿过数据层。
    expect(withNulls.length).toBeGreaterThan(0)
    expect(withNulls[0]?.properties).toBeTypeOf('object')
  })

  it('按数值字段排序时 null 排在最后，不被当成 0', async () => {
    const page = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 50,
      sort: { field: 'population', direction: 'asc' },
    })
    const values = page.data.items.map((item) => item.properties.population)
    const firstNullIndex = values.findIndex((value) => value === null)

    if (firstNullIndex >= 0) {
      expect(values.slice(firstNullIndex).every((value) => value === null)).toBe(true)
    }
    const numbers = values.filter((value): value is number => typeof value === 'number')
    expect(numbers).toEqual([...numbers].sort((a, b) => a - b))
  })

  it('getFeature 能按引用取回同一条记录，未知 id 报 NOT_FOUND', async () => {
    const page = await repositories.layers.listFeatures('emg.road', { page: 1, pageSize: 3 })
    const ref = page.data.items[0]?.ref
    expect(ref).toBeDefined()

    const detail = await repositories.layers.getFeature(ref as NonNullable<typeof ref>)
    expect(detail.data.ref).toEqual(ref)
    expect(detail.data.geometry).not.toBeNull()

    await expect(
      repositories.layers.getFeature({ layerId: 'emg.road', id: 'NOT-EXIST' }),
    ).rejects.toMatchObject({ code: 'NOT_FOUND' })
  })

  it('图例可读取，未知图例报 NOT_FOUND', async () => {
    const layers = await repositories.layers.listLayers()
    const legendId = layers.data[0]?.legendId
    expect(legendId).toBeDefined()

    const legend = await repositories.layers.getLegend(legendId as string)
    expect(legend.data.id).toBe(legendId)
    expect(legend.data.items.length).toBeGreaterThan(0)

    await expect(repositories.layers.getLegend('legend.not.exist')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
  })
})

describe('属性查询与空间查询', () => {
  it('属性查询返回分页行与匹配总数，并给出可续查的 queryId', async () => {
    const envelope = await repositories.queries.runQuery({
      layerId: 'base.settlement.point',
      filters: [],
      page: 1,
      pageSize: 5,
    })

    expect(envelope.data.rows.total).toBeGreaterThan(5)
    expect(envelope.data.rows.items.length).toBe(5)
    expect(envelope.data.queryId).toMatch(/^demo-query-\d+$/)
    const matchedTotal = metricByKey(envelope.data.metrics, 'matchedTotal')
    expect(matchedTotal.value).toBe(envelope.data.rows.total)
    expect(String(envelope.data.mapSelection.matchedTotal)).toBe(String(matchedTotal.value))
  })

  it('按属性筛选真的生效，且总数随筛选条件变化', async () => {
    const all = await repositories.queries.runQuery({
      layerId: 'emg.road',
      filters: [],
      page: 1,
      pageSize: 1,
    })
    const blocked = await repositories.queries.runQuery({
      layerId: 'emg.road',
      filters: [{ field: 'blocked', operator: 'eq', value: true }],
      page: 1,
      pageSize: 50,
    })

    expect(blocked.data.rows.total).toBeLessThan(all.data.rows.total)
    expect(blocked.data.rows.total).toBeGreaterThan(0)
    expect(blocked.data.rows.items.every((row) => row.properties.blocked === true)).toBe(true)
  })

  it('同一 queryId 继续翻页时总数保持不变（分页只改页）', async () => {
    const first = await repositories.queries.runQuery({
      layerId: 'base.settlement.point',
      filters: [],
      page: 1,
      pageSize: 4,
    })
    const queryId = first.data.queryId
    const second = await repositories.queries.getQuery(queryId, { page: 2, pageSize: 4 })
    const again = await repositories.queries.getQuery(queryId, { page: 3, pageSize: 4 })

    expect(second.data.rows.total).toBe(first.data.rows.total)
    expect(again.data.rows.total).toBe(first.data.rows.total)
    expect(again.data.rows.page).toBe(3)
    // 复用的是同一次查询：queryId 必须保持不变，页面才能继续翻页。
    expect(again.data.queryId).toBe(queryId)
  })

  it('未知 queryId 报 QUERY_EXPIRED，提示重新查询而不是返回空结果', async () => {
    await expect(
      repositories.queries.getQuery('demo-query-9999', { page: 1, pageSize: 10 }),
    ).rejects.toMatchObject({ code: 'QUERY_EXPIRED' })
  })

  /**
   * 阶段3（D-032）：空间查询是只读能力，示例模式已在本地小样本上**真正执行**。
   * 因此这条断言从「报 NOT_IMPLEMENTED」改为「真正算、算出 0 条」——
   * 空结果与失败是两件事，这里断言的是前者：远处的范围不命中任何居民地，
   * 结果为 0 条但查询成功，指标里同时给出空间关系口径。
   */
  it('空间查询真正执行：范围外返回 0 条，是空结果而不是失败', async () => {
    const envelope = await repositories.queries.runQuery({
      layerId: 'base.settlement.point',
      filters: [],
      spatial: {
        predicate: 'within',
        geometry: {
          type: 'Polygon',
          coordinates: [
            [
              [96, 32],
              [97, 32],
              [97, 33],
              [96, 33],
              [96, 32],
            ],
          ],
        },
      },
      page: 1,
      pageSize: 10,
    })
    expect(envelope.data.rows.total).toBe(0)
    expect(envelope.data.rows.items).toHaveLength(0)
    const spatial = envelope.data.metrics.find((metric) => metric.key === 'spatialMatched')
    expect(spatial?.value).toBe(0)
    expect(spatial?.method).toContain('覆盖语义')
  })
})

describe('成果、统计与暴露清单', () => {
  it('成果列表可分页、可按类型筛选，分页不改变总数', async () => {
    const all = await repositories.results.listResults({ page: 1, pageSize: 1 })
    expect(all.data.total).toBeGreaterThanOrEqual(3)
    expect(all.data.items.length).toBe(1)

    const risk = await repositories.results.listResults({
      kind: 'risk',
      page: 1,
      pageSize: 10,
    })
    expect(risk.data.total).toBe(1)
    expect(risk.data.items.every((item) => item.kind === 'risk')).toBe(true)
  })

  it('风险成果的指标不写在成果记录里，而是由统计接口现场派生（单一口径）', async () => {
    const detail = await repositories.results.getResult('result.demo.risk')
    const statistics = await repositories.results.getStatistics('result.demo.risk')

    // 成果记录本身不预存指标，避免与要素统计出现两份数字。
    expect(detail.data.metrics).toHaveLength(0)
    expect(statistics.data.metrics.length).toBeGreaterThan(0)
    expect(statistics.data.resultId).toBe('result.demo.risk')
  })

  it('风险分级统计与风险区要素数量一致，且分布总数等于要素数', async () => {
    const zones = await repositories.layers.listFeatures('result.demo.risk', {
      page: 1,
      pageSize: 100,
    })
    const statistics = await repositories.results.getStatistics('result.demo.risk')
    const distributionTotal = statistics.data.distribution.reduce(
      (sum, item) => sum + item.count,
      0,
    )

    expect(distributionTotal).toBe(zones.data.total)
    const zoneCount = metricByKey(statistics.data.metrics, 'riskZoneCount')
    expect(zoneCount.value).toBe(zones.data.total)

    // 分级与数据不足两类互斥且穷尽。
    const graded = metricByKey(statistics.data.metrics, 'gradedZoneCount').value as number
    const insufficient = metricByKey(statistics.data.metrics, 'insufficientZoneCount')
      .value as number
    expect(graded + insufficient).toBe(zones.data.total)

    for (const item of statistics.data.distribution) {
      expect(item.count).toBeGreaterThanOrEqual(0)
      expect(item.label.length).toBeGreaterThan(0)
    }
  })

  it('分级统计带方法说明与分级版本，图表可追溯到口径', async () => {
    const statistics: ResultStatistics = (
      await repositories.results.getStatistics('result.demo.risk')
    ).data

    expect(statistics.method?.length ?? 0).toBeGreaterThan(0)
    expect(statistics.unit).toBeNull() // 单位未确认时保持 null，不写成“个”
    const highRisk = metricByKey(statistics.metrics, 'highRiskCount').value as number
    const zoneCount = metricByKey(statistics.metrics, 'riskZoneCount').value as number
    expect(highRisk).toBeLessThanOrEqual(zoneCount)
  })

  it('暴露统计与受影响对象清单同源：清单总数等于统计的匹配记录数', async () => {
    const summary = (await repositories.results.getExposureSummary('result.demo.impact')).data
    const rows = await repositories.results.listAffectedFeatures('result.demo.impact', {
      page: 1,
      pageSize: 100,
    })

    expect(rows.data.total).toBe(summary.matchedRecordCount)
    const uniqueRefs = new Set(rows.data.items.map((item) => `${item.ref.layerId}:${item.ref.id}`))
    expect(uniqueRefs.size).toBe(rows.data.items.length)
    expect(summary.uniqueEntityCount).toBeLessThanOrEqual(summary.matchedRecordCount)
    expect(summary.affectedCategories.reduce((sum, item) => sum + item.count, 0)).toBe(
      rows.data.total,
    )
    for (const category of summary.affectedCategories) {
      const categoryRows = await repositories.results.listAffectedFeatures('result.demo.impact', {
        category: category.key,
        page: 1,
        pageSize: 100,
      })
      expect(categoryRows.data.total, `分类 ${category.key} 的计数应来自同一批要素`).toBe(
        category.count,
      )
    }
  })

  it('人口未接入时暴露统计返回 null 与 notProvided，而不是 0', async () => {
    const summary = (await repositories.results.getExposureSummary('result.demo.impact')).data
    const population = metricByKey(summary.metrics, 'population')
    const populationDataset = demoDatasets.find((dataset) => dataset.id === 'demo-ds-population')

    expect(populationDataset).toBeDefined()
    if (populationDataset?.serviceAvailable === false) {
      expect(population.value).toBeNull()
      expect(population.status).toBe('notProvided')
      expect(population.value).not.toBe(0)
    } else {
      expect(population.status).toBe('known')
      expect(typeof population.value).toBe('number')
    }
    // 去重口径必须写明，避免把“记录数”当“对象数”。
    expect(summary.deduplicationRule).toBeTruthy()
    expect(String(summary.deduplicationRule).length).toBeGreaterThan(0)
    if (population.value === null) {
      // 没有人口数值就不给“人口时点”：年份会让人误以为该年确实统计过人口。
      expect(population.year ?? null).toBeNull()
      expect(summary.populationYear).toBeNull()
    } else {
      expect(typeof summary.populationYear).toBe('number')
      expect(summary.populationYear).toBe(population.year)
    }
    // 影响范围可对应多个灾害对象：此时不给单一灾害编号，但必须在说明里写清楚。
    if (summary.hazardRef === null) {
      expect(String(summary.note)).toContain('多个灾害对象')
    } else {
      expect(summary.hazardRef.layerId.length).toBeGreaterThan(0)
      expect(summary.hazardRef.id.length).toBeGreaterThan(0)
      expect(String(summary.note ?? '')).not.toContain('多个灾害对象')
    }
  })

  it('受影响对象的引用都能在图层中取回（跨表引用完整）', async () => {
    const rows = await repositories.results.listAffectedFeatures('result.demo.impact', {
      page: 1,
      pageSize: 100,
    })

    for (const row of rows.data.items) {
      const detail = await repositories.layers.getFeature(row.ref)
      expect(detail.data.ref).toEqual(row.ref)
    }
  })

  it('受影响对象分页不改变总数', async () => {
    const first = await repositories.results.listAffectedFeatures('result.demo.impact', {
      page: 1,
      pageSize: 3,
    })
    const second = await repositories.results.listAffectedFeatures('result.demo.impact', {
      page: 2,
      pageSize: 3,
    })

    expect(first.data.total).toBe(second.data.total)
    expect(first.data.items.length).toBeLessThanOrEqual(3)
  })

  it('应急路线列表按成果归属返回分页Page，无路线的成果items为空，未知成果报 NOT_FOUND', async () => {
    // 阶段8B返工：三种模式统一返回 Page<RouteSummary>（items/total/page/pageSize）。
    const routes = await repositories.results.listRoutes('result.demo.route')
    expect(routes.data.items.length).toBeGreaterThanOrEqual(1)
    expect(routes.data.total).toBeGreaterThanOrEqual(routes.data.items.length)
    expect(routes.data.page).toBe(1)
    expect(routes.data.pageSize).toBeGreaterThan(0)
    expect(routes.data.items.every((route) => route.resultId === 'result.demo.route')).toBe(true)

    // 成果存在但没有路线记录：items 空而 total=0 是真实答案，不编造路线。
    const noRoutes = await repositories.results.listRoutes('result.demo.risk')
    expect(noRoutes.data.items).toEqual([])
    expect(noRoutes.data.total).toBe(0)

    // 成果不存在：必须报错，不能与“没有路线”混淆。
    await expect(repositories.results.listRoutes('result.demo.nope')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
  })

  it('路线列表分页：第1/2页不重复，total 恒定不由 items.length 冒充', async () => {
    const first = await repositories.results.listRoutes('result.demo.route', {
      page: 1,
      pageSize: 2,
    })
    const second = await repositories.results.listRoutes('result.demo.route', {
      page: 2,
      pageSize: 2,
    })
    expect(first.data.total).toBe(second.data.total)
    const ids1 = new Set(first.data.items.map((item) => item.id))
    const ids2 = new Set(second.data.items.map((item) => item.id))
    for (const id of ids2) expect(ids1.has(id)).toBe(false)
    // 超出页码：items 空、total 保持真实总数
    const beyond = await repositories.results.listRoutes('result.demo.route', {
      page: 9999,
      pageSize: 20,
    })
    expect(beyond.data.items).toEqual([])
    expect(beyond.data.total).toBe(first.data.total)
  })

  it('可达路线的登记里程与几何长度一致，且里程来源有说明', async () => {
    const routes = await repositories.results.listRoutes('result.demo.route', {
      page: 1,
      pageSize: 50,
    })
    const reachable = routes.data.items.find((route) => route.status === 'reachable')
    expect(reachable).toBeDefined()

    const detail: RouteDetail = (await repositories.results.getRoute(reachable?.id as string)).data
    expect(detail.geometry).not.toBeNull()
    expect(detail.distanceMeters).not.toBeNull()
    expect(detail.distanceMeters as number).toBeGreaterThan(0)
    expect(detail.distanceSource.length).toBeGreaterThan(0)

    const coords =
      detail.geometry?.type === 'LineString'
        ? (detail.geometry.coordinates as [number, number][])
        : null
    expect(coords).not.toBeNull()
    const computed = polylineLengthMeters(coords as [number, number][])
    const stored = detail.distanceMeters as number
    // 容差 0.5%（与 derive.verifyRouteDistance 一致）：不允许用直线距离冒充路线里程。
    expect(Math.abs(computed - stored) / stored).toBeLessThan(0.005)
  })

  it('不可达路线不给几何、不给时长，也不做直线替代', async () => {
    const routes = await repositories.results.listRoutes('result.demo.route', {
      page: 1,
      pageSize: 50,
    })
    const unreachable = routes.data.items.find((route) => route.status === 'unreachable')
    expect(unreachable).toBeDefined()

    const detail = (await repositories.results.getRoute(unreachable?.id as string)).data
    expect(detail.status).toBe('unreachable')
    expect(detail.geometry).toBeNull()
    expect(detail.durationSeconds).toBeNull()
    expect(detail.distanceMeters).toBeNull()
    expect(detail.blockedFeatureRefs.length).toBeGreaterThan(0)
    expect(detail.assumptions.length).toBeGreaterThan(0)
  })
})

describe('数据目录', () => {
  it('数据集分页不改变总数，且可按主题筛选', async () => {
    const all = await repositories.catalog.listDatasets({ page: 1, pageSize: 5 })
    expect(all.data.total).toBe(demoDatasets.length)
    expect(all.data.items.length).toBe(5)

    const theme = demoDatasets[0]?.theme
    expect(theme).toBeDefined()
    const filtered = await repositories.catalog.listDatasets({
      theme,
      page: 1,
      pageSize: 50,
    })
    expect(filtered.data.total).toBeLessThan(all.data.total)
    expect(filtered.data.items.every((item) => item.theme === theme)).toBe(true)
  })

  it('数据集详情、来源、字典与行政区都能按 id 读取', async () => {
    const datasets = await repositories.catalog.listDatasets({ page: 1, pageSize: 50 })
    const dataset = datasets.data.items[0]
    expect(dataset).toBeDefined()

    const detail = await repositories.catalog.getDataset(dataset?.id as string)
    expect(detail.data.id).toBe(dataset?.id)
    expect(detail.data.fields.length).toBeGreaterThan(0)

    const sourceId = detail.data.sourceId
    const source = await repositories.catalog.getSource(sourceId)
    expect(source.data.id).toBe(sourceId)
    // 示例包不登记真实机构：允许为 null，但 null 必须经统一格式化后显示“未提供”，
    // 且必须同时有授权/来源说明，不能留下一个空白或 "null" 字样。
    const organization = source.data.organization
    expect(organization === null || organization.length > 0).toBe(true)
    if (organization === null) {
      const organizationField: FieldDefinition = {
        key: 'organization',
        label: '数据提供机构',
        type: 'string',
        unit: null,
        nullable: true,
        filterable: false,
        sortable: false,
      }
      expect(formatFieldValue(organizationField, organization)).toBe(NOT_PROVIDED_TEXT)
      expect(source.data.sourceUrl).toBeNull()
    }
    expect(source.data.licenseDescription?.length ?? 0).toBeGreaterThan(0)

    const dictionaryId = detail.data.fields
      .map((field) => field.dictionaryId)
      .find((value): value is string => typeof value === 'string')
    if (dictionaryId) {
      const dictionary = await repositories.catalog.getDictionary(dictionaryId)
      expect(dictionary.data.id).toBe(dictionaryId)
      expect(dictionary.data.items.length).toBeGreaterThan(0)
    }

    const regions = await repositories.catalog.listRegions()
    expect(regions.data.length).toBeGreaterThan(0)
    expect(regions.data.every((region) => region.level.length > 0)).toBe(true)
  })

  it('目录类未知 id 一律报 NOT_FOUND，不返回空对象', async () => {
    await expect(repositories.catalog.getDataset('demo-ds-nope')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
    await expect(repositories.catalog.getSource('source-nope')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
    await expect(repositories.catalog.getDictionary('dict-nope')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
  })

  it('导入日志只读分页，字段标明状态与时间精度', async () => {
    const imports = await repositories.catalog.listImports({ page: 1, pageSize: 5 })
    expect(imports.data.total).toBeGreaterThan(0)
    expect(imports.data.items.length).toBeLessThanOrEqual(5)
    for (const item of imports.data.items) {
      expect(item.datasetId.length).toBeGreaterThan(0)
      expect(['succeeded', 'failed', 'running', 'unknown']).toContain(item.status)
    }
  })
})

describe('总览与同源性', () => {
  it('总览指标与分布、成果统计、要素计数三处同源', async () => {
    const overview = (await repositories.overview.getOverview()).data
    const zones = await repositories.layers.listFeatures('result.demo.risk', {
      page: 1,
      pageSize: 100,
    })
    const statistics = await repositories.results.getStatistics('result.demo.risk')

    expect(overview.metrics.length).toBeGreaterThanOrEqual(4)
    const metricKeys = overview.metrics.map((metric) => metric.key)
    expect(new Set(metricKeys).size).toBe(metricKeys.length)
    for (const metric of overview.metrics) {
      expect(metric.label.length).toBeGreaterThan(0)
      expect(metric.status === 'notProvided' || metric.value !== null).toBe(true)
    }

    const distributionTotal = overview.riskDistribution.reduce((sum, item) => sum + item.count, 0)
    const statisticsTotal = statistics.data.distribution.reduce((sum, item) => sum + item.count, 0)

    expect(distributionTotal).toBe(zones.data.total)
    expect(distributionTotal).toBe(statisticsTotal)
    // 同一批风险区要素：总览四项计数 = 成果统计计数 = 要素清单条数。
    const zoneCount = metricByKey(overview.metrics, 'riskZoneCount')
    expect(zoneCount.value).toBe(zones.data.total)
    for (const item of overview.riskDistribution) {
      const statisticsItem = statistics.data.distribution.find((row) => row.key === item.key)
      expect(statisticsItem?.count, `等级 ${item.key} 在两处口径应一致`).toBe(item.count)
      expect(item.unit).toBe('个')
      expect(item.color).not.toBeNull()
    }
    expect(overview.riskDistribution.map((item) => item.key)).toContain('high')
  })

  it('总览分布按等级由低到高排列，重点对象按等级由高到低取前三', async () => {
    const overview = (await repositories.overview.getOverview()).data
    const orders = overview.riskDistribution.map((item) => RISK_LEVEL_ORDER[toRiskLevel(item.key)])

    expect(orders.length).toBeGreaterThan(0)
    // 图表与表统一口径：等级顺序固定为 RISK_LEVEL_ORDER（低→高，数据不足单列），
    // 不按计数大小重排，避免同一图在两页顺序不同。
    expect(orders).toEqual([...orders].sort((a, b) => a - b))

    expect(overview.keyFeatures.length).toBeLessThanOrEqual(3)
    const levels = overview.keyFeatures.map((item) =>
      item.level === null ? -1 : RISK_LEVEL_ORDER[item.level],
    )
    // 重点对象反过来：高风险优先。
    expect(levels).toEqual([...levels].sort((a, b) => b - a))
  })

  it('总览标注快照时间与情景说明，不出现“实时监测/预警”措辞', async () => {
    const envelope = await repositories.overview.getOverview()
    const notes = envelope.data.notes.join('')

    expect(envelope.data.regionLabel.length).toBeGreaterThan(0)
    expect(envelope.data.snapshotTime?.value).toBe(envelope.meta.generatedAt)
    expect(envelope.data.notes.length).toBeGreaterThan(0)
    expect(notes).toContain('2050')
    expect(notes).toContain('2100')
    // 允许出现“不是实时预报/不提供实时监测…”这类否定说明，但不允许任何
    // “实时监测/实时预警”被当作结论陈述。
    expect(notes).toContain('不是实时预报')
    for (const match of notes.matchAll(/实时(监测|预警)/g)) {
      const before = notes.slice(Math.max(0, (match.index ?? 0) - 4), match.index ?? 0)
      expect(/不|非|不是/.test(before), `“${match[0]}”必须是否定语境：…${before}${match[0]}`).toBe(
        true,
      )
    }
  })

  it('未知区域范围的请求报 NOT_FOUND，而不是静默返回全域数字', async () => {
    await expect(
      repositories.overview.getOverview({ regionId: 'region.not.exist' }),
    ).rejects.toMatchObject({ code: 'NOT_FOUND' })
  })
})

describe('会话 store 与数据层一致（模式只改配置）', () => {
  it('示例模式下 store 反映示例身份、只读能力与失败状态语义', async () => {
    // store 通过仓库单例取能力，必须先注入磁盘版示例包（jsdom 里没有服务端）。
    const { setRepositories } = await import('@/repositories')
    setRepositories(createDemoRepositories())
    setActivePinia(createPinia())
    const session = useSessionStore()

    expect(session.isSample).toBe(true)
    expect(session.isReady).toBe(false)
    expect(session.readOnly).toBe(true) // 能力未知时保守只读

    await session.loadCapabilities()

    expect(session.error).toBeNull()
    expect(session.isReady).toBe(true)
    expect(session.modeLabel).toBe('示例数据')
    expect(session.snapshotId).toBe('demo-v1')
    expect(session.readOnly).toBe(true)
    // 阶段3：空间查询已在示例包内真实执行，能力为可用；但仍必须给出方法与单位说明。
    expect(session.canSpatialQuery).toBe(true)
    expect(session.reasonFor('spatialQuery')).not.toBeNull()
    expect(session.exportFormats.length).toBeGreaterThan(0)

    setRepositories(null)
  })

  it('能力读取失败时保留错误码，不降级为示例能力', async () => {
    setActivePinia(createPinia())
    const session = useSessionStore()
    session.$patch({ status: 'idle' })

    // 把能力读取换成必然失败的实现：失败必须原样暴露。
    const failing = {
      ...createDemoRepositories(),
      capabilities: {
        getCapabilities: async () => {
          const error = new Error('模拟服务不可用')
          throw Object.assign(error, { name: 'RepositoryError' })
        },
      },
    }
    const { setRepositories } = await import('@/repositories')
    setRepositories({
      ...failing,
      capabilities: {
        getCapabilities: async () => {
          const { RepositoryError } = await import('@/repositories/types')
          throw new RepositoryError({
            code: 'SERVICE_UNAVAILABLE',
            message: '能力服务未启动。',
            retryable: true,
            httpStatus: 503,
          })
        },
      },
    })

    await session.loadCapabilities(true)

    expect(session.isFailed).toBe(true)
    expect(session.errorCode()).toBe('SERVICE_UNAVAILABLE')
    expect(session.capabilities).toBeNull()
    expect(session.readOnly).toBe(true)
    expect(session.error?.userMessage).toContain('暂时无法显示')
    expect(session.error?.userMessage).not.toContain('示例')
    expect(session.sourceUrl).toBe(mockEnv.demoBaseUrl)

    setRepositories(null)
  })
})
