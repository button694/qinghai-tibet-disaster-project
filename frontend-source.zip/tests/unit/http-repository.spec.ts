/**
 * 正式接口适配器契约测试（阶段1）。
 *
 * 核心验收点：**HTTP 未连接时显示失败，而不是示例统计**。
 * 因此这里刻意构造“接口不通”的各种情形，断言错误码、可重试标记、
 * 以及页面能看到的中文说明；同时断言请求路径、方法与参数严格按 02 §4 生成。
 */
import { describe, expect, it, vi } from 'vitest'

import type { Capabilities, Page, QueryResult, ResultSummary } from '@/domain/types'
import { createRepositories, dataSourceUrl, isSampleMode } from '@/repositories'
import { createHttpRepositories } from '@/repositories/http/httpRepository'
import { RepositoryError } from '@/repositories/types'
import { apiEnv, createDemoRepositories, mockEnv } from './helpers/repository-fixtures'

const meta = {
  mode: 'api' as const,
  snapshotId: 'api-v1',
  generatedAt: '2025-01-15T09:30:00+08:00',
  scopeLabel: '正式服务范围',
  boundaryVersion: 'bd-v1',
  datasetVersions: { 'demo-ds-settlement': '2024-12-01' },
}

interface RecordedCall {
  url: string
  method: string
  body: unknown
  headers: Record<string, string>
}

/** 记录调用的 fetch 替身：按顺序返回给定响应。 */
function createFetchStub(
  responder: (call: RecordedCall, index: number) => Response | Promise<Response>,
): { fetcher: typeof fetch; calls: RecordedCall[] } {
  const calls: RecordedCall[] = []
  const fetcher = (async (input: RequestInfo | URL, init?: RequestInit) => {
    const headers = (init?.headers ?? {}) as Record<string, string>
    const call: RecordedCall = {
      url: String(input),
      method: init?.method ?? 'GET',
      body: init?.body === undefined ? undefined : JSON.parse(String(init.body)),
      headers,
    }
    calls.push(call)
    return responder(call, calls.length - 1)
  }) as unknown as typeof fetch
  return { fetcher, calls }
}

function jsonResponse(body: unknown, status = 200): Response {
  return new Response(JSON.stringify(body), {
    status,
    headers: { 'Content-Type': 'application/json' },
  })
}

function okEnvelope<T>(data: T) {
  return jsonResponse({ data, meta, requestId: 'req-0001' })
}

const capabilities: Capabilities = {
  readLayers: true,
  attributeQuery: true,
  spatialQuery: true,
  readResults: true,
  exportFormats: ['csv'],
  authEnabled: true,
  routeRecompute: false,
  analysisSubmit: false,
  dataEdit: false,
  backupExecute: false,
  reasons: {},
  mode: 'api',
  snapshotId: 'api-v1',
}

describe('工厂：模式只改配置', () => {
  it('mock 与 snapshot 共用 JSON 包适配器，api 使用 HTTP 适配器', () => {
    const jsonFetcher = vi.fn(async () => ({}))
    const httpFetcher = vi.fn() as unknown as typeof fetch

    const mockRepositories = createRepositories(mockEnv, { jsonFetcher })
    const snapshotRepositories = createRepositories(
      { ...mockEnv, dataMode: 'snapshot' },
      { jsonFetcher },
    )
    const apiRepositories = createRepositories(apiEnv, { httpFetcher })

    expect(mockRepositories.mode).toBe('mock')
    expect(snapshotRepositories.mode).toBe('snapshot')
    expect(apiRepositories.mode).toBe('api')
    // 三种模式的数据来源只有地址与适配器不同，页面代码不因此分叉。
    expect(dataSourceUrl('mock')).toBe('/demo/')
    expect(dataSourceUrl('snapshot')).toBe('/snapshot/')
    expect(dataSourceUrl('api')).toBe('/api/v1')
    expect(isSampleMode('mock')).toBe(true)
    expect(isSampleMode('snapshot')).toBe(false)
    expect(isSampleMode('api')).toBe(false)
  })

  it('api 模式下 HTTP 适配器不会去读取示例数据包', async () => {
    const jsonFetcher = vi.fn(async () => {
      throw new Error('api 模式不得读取示例数据包')
    })
    const repositories = createRepositories(apiEnv, {
      jsonFetcher,
      httpFetcher: (async () => {
        throw new TypeError('fetch failed')
      }) as unknown as typeof fetch,
    })

    await expect(repositories.capabilities.getCapabilities()).rejects.toMatchObject({
      code: 'NETWORK_ERROR',
    })
    expect(jsonFetcher).not.toHaveBeenCalled()
  })
})

describe('正式接口失败：显示失败而非示例数据', () => {
  it('网络不可达时报 NETWORK_ERROR（可重试）并给出客户提示', async () => {
    const { fetcher } = createFetchStub(() => {
      throw new TypeError('Failed to fetch')
    })
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    const error = await repositories.capabilities.getCapabilities().catch((e: unknown) => e)

    expect(error).toBeInstanceOf(RepositoryError)
    const repositoryError = error as RepositoryError
    expect(repositoryError.code).toBe('NETWORK_ERROR')
    expect(repositoryError.retryable).toBe(true)
    expect(repositoryError.userMessage).toContain('暂时无法连接数据')
    expect(repositoryError.userMessage).not.toContain('示例')
    expect(repositoryError.userMessage).not.toMatch(/\d{2,}/) // 失败说明里不出现任何统计数字
  })

  it('503 报 SERVICE_UNAVAILABLE，且不把示例统计当作结果返回', async () => {
    const { fetcher } = createFetchStub(() =>
      jsonResponse(
        { error: { code: 'SERVICE_UNAVAILABLE', message: '服务未启动', requestId: 'r-9' } },
        503,
      ),
    )
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })
    const demo = createDemoRepositories()
    const demoOverview = (await demo.overview.getOverview()).data

    const error = (await repositories.overview
      .getOverview()
      .catch((e: unknown) => e)) as RepositoryError

    expect(error.code).toBe('SERVICE_UNAVAILABLE')
    expect(error.retryable).toBe(true)
    expect(error.httpStatus).toBe(503)
    expect(error.requestId).toBe('r-9')
    expect(error.userMessage).toContain('暂时无法显示')
    expect(error.userMessage).not.toContain('示例')
    // 这里显式对照示例数据：确认失败时页面拿不到示例指标。
    expect(demoOverview.metrics.length).toBeGreaterThan(0)
    expect(error).not.toHaveProperty('data')
  })

  it('服务端返回的错误码优先于状态码映射，便于联调定位', async () => {
    const { fetcher } = createFetchStub(() =>
      jsonResponse({ error: { code: 'FORBIDDEN', message: '无权限' } }, 403),
    )
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    await expect(repositories.results.getResult('r-1')).rejects.toMatchObject({
      code: 'FORBIDDEN',
      httpStatus: 403,
    })
  })

  it('404 报 NOT_FOUND，410 报 QUERY_EXPIRED（而不是当成空结果）', async () => {
    const notFound = createFetchStub(() => new Response('', { status: 404 }))
    const expired = createFetchStub(() => new Response('', { status: 410 }))

    await expect(
      createHttpRepositories({ baseUrl: '/api/v1', fetcher: notFound.fetcher }).results.getResult(
        'r-1',
      ),
    ).rejects.toMatchObject({ code: 'NOT_FOUND' })
    await expect(
      createHttpRepositories({ baseUrl: '/api/v1', fetcher: expired.fetcher }).queries.getQuery(
        'q-1',
        {
          page: 1,
          pageSize: 10,
        },
      ),
    ).rejects.toMatchObject({ code: 'QUERY_EXPIRED' })
  })

  it('响应缺少 meta / requestId 或不是 JSON 时一律报 INVALID_RESPONSE', async () => {
    const noMeta = createFetchStub(() => jsonResponse({ data: {}, requestId: 'r-1' }))
    const noRequestId = createFetchStub(() => jsonResponse({ data: {}, meta }))
    const partialMeta = createFetchStub(() =>
      jsonResponse({ data: {}, meta: { mode: 'api' }, requestId: 'r-1' }),
    )
    const notJson = createFetchStub(
      () => new Response('<html>502 Bad Gateway</html>', { status: 200 }),
    )

    for (const stub of [noMeta, noRequestId, partialMeta, notJson]) {
      const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher: stub.fetcher })
      const error = (await repositories.capabilities
        .getCapabilities()
        .catch((e: unknown) => e)) as RepositoryError
      expect(error.code).toBe('INVALID_RESPONSE')
      expect(error.userMessage).toBeTruthy()
    }
  })

  it('取消请求时原样抛出 AbortError，不被包装成数据故障', async () => {
    const { fetcher } = createFetchStub(() => {
      throw new DOMException('aborted', 'AbortError')
    })
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })
    const controller = new AbortController()

    await expect(
      repositories.capabilities.getCapabilities({ signal: controller.signal }),
    ).rejects.toMatchObject({ name: 'AbortError' })
  })
})

describe('请求路径与参数严格按 02 §4 生成', () => {
  it('GET /capabilities 带上统一前缀并解析信封', async () => {
    const { fetcher, calls } = createFetchStub(() => okEnvelope(capabilities))
    const repositories = createHttpRepositories({ baseUrl: '/api/v1/', fetcher })

    const envelope = await repositories.capabilities.getCapabilities()

    expect(calls).toHaveLength(1)
    expect(calls[0]?.url).toBe('/api/v1/capabilities')
    expect(calls[0]?.method).toBe('GET')
    expect(calls[0]?.headers.Accept).toBe('application/json')
    expect(envelope.data.snapshotId).toBe('api-v1')
    expect(envelope.meta.snapshotId).toBe('api-v1')
    expect(envelope.requestId).toBe('req-0001')
  })

  it('listFeatures 只发一次 POST /queries，并把 rows 作为分页结果', async () => {
    const page: Page<{ ref: { layerId: string; id: string } }> = {
      items: [{ ref: { layerId: 'base.settlement.point', id: 'S-1' } }],
      total: 42,
      page: 2,
      pageSize: 5,
    }
    const queryResult = {
      queryId: 'q-1',
      rows: page,
      metrics: [],
      mapSelection: { matchedTotal: 42, displayedTotal: 1 },
    } as unknown as QueryResult
    const { fetcher, calls } = createFetchStub(() => okEnvelope(queryResult))
    const repositories = createHttpRepositories({ baseUrl: '/api/v1', fetcher })

    const envelope = await repositories.layers.listFeatures('base.settlement.point', {
      page: 2,
      pageSize: 5,
    })

    expect(calls).toHaveLength(1)
    expect(calls[0]?.method).toBe('POST')
    expect(calls[0]?.url).toBe('/api/v1/queries')
    expect(calls[0]?.body).toEqual({
      layerId: 'base.settlement.point',
      filters: [],
      page: 2,
      pageSize: 5,
    })
    // 总数来自服务端 meta/rows.total，不用 items.length 冒充。
    expect(envelope.data.total).toBe(42)
    expect(envelope.data.items).toHaveLength(1)
  })

  it('getQuery 带 page/pageSize，getFeature 对 id 做转义', async () => {
    const { fetcher, calls } = createFetchStub(() => okEnvelope(capabilities))
    const repositories = createHttpRepositories({
      baseUrl: '/api/v1',
      fetcher,
      defaultPageSize: 10,
    })

    await repositories.queries.getQuery('q-1', { page: 3, pageSize: 25 }).catch(() => undefined)
    await repositories.layers.getFeature({ layerId: 'emg/road', id: 'R 1' }).catch(() => undefined)

    expect(calls[0]?.url).toBe('/api/v1/queries/q-1?page=3&pageSize=25')
    expect(calls[1]?.url).toBe('/api/v1/layers/emg%2Froad/features/R%201')
  })

  it('listResults 省略未提供的筛选条件，分页缺省用默认页长', async () => {
    const page: Page<ResultSummary> = { items: [], total: 0, page: 1, pageSize: 10 }
    const { fetcher, calls } = createFetchStub(() => okEnvelope(page))
    const repositories = createHttpRepositories({
      baseUrl: '/api/v1',
      fetcher,
      defaultPageSize: 10,
    })

    await repositories.results.listResults({ kind: 'risk' })

    expect(calls[0]?.url).toBe('/api/v1/results?page=1&pageSize=10&kind=risk')
  })

  it('getLayer 在没有单条接口时读取列表并挑出目标图层，缺失即 NOT_FOUND', async () => {
    const layers = [
      { id: 'hazard.landslide', label: '滑坡', theme: 'hazard', fields: [], legendId: 'l-1' },
    ]
    const stub = createFetchStub(() => okEnvelope(layers))
    const repositories = createHttpRepositories({
      baseUrl: '/api/v1',
      fetcher: stub.fetcher,
    })

    const found = await repositories.layers.getLayer('hazard.landslide')
    expect(found.data.id).toBe('hazard.landslide')
    expect(stub.calls).toHaveLength(1)
    expect(stub.calls[0]?.url).toBe('/api/v1/layers')

    await expect(repositories.layers.getLayer('nope')).rejects.toMatchObject({
      code: 'NOT_FOUND',
    })
  })

  it('鉴权头与请求头可注入，用于联调带令牌访问', async () => {
    const { fetcher, calls } = createFetchStub(() => okEnvelope(capabilities))
    const repositories = createHttpRepositories({
      baseUrl: '/api/v1',
      fetcher,
      headers: { Authorization: 'Bearer t-1' },
    })

    await repositories.capabilities.getCapabilities()

    expect(calls[0]?.headers.Authorization).toBe('Bearer t-1')
  })
})

describe('信封校验工具', () => {
  it('缺少必需 meta 字段时报告缺失清单', async () => {
    const { requireEnvelope } = await import('@/repositories/http/httpRepository')
    const error = (() => {
      try {
        requireEnvelope({ data: {}, meta: { mode: 'api', snapshotId: null }, requestId: 'r' }, '/x')
        return null
      } catch (caught) {
        return caught as RepositoryError
      }
    })()

    expect(error?.code).toBe('INVALID_RESPONSE')
    expect(String(error?.message)).toContain('generatedAt')
    expect(error?.details?.missing).toEqual(
      expect.arrayContaining([
        'snapshotId',
        'generatedAt',
        'scopeLabel',
        'boundaryVersion',
        'datasetVersions',
      ]),
    )
  })
})
