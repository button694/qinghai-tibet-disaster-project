import { existsSync, readFileSync, readdirSync } from 'node:fs'
import { relative, resolve } from 'node:path'
import { fileURLToPath } from 'node:url'
import { describe, expect, it } from 'vitest'
import { RISK_LEVELS, RISK_LEVEL_COLOR, RISK_LEVEL_TEXT_COLOR } from '@/domain/risk'

/**
 * 设计令牌与 UI 基础组件的静态校验（阶段1）。
 *
 * 这些断言只读源码文本，不需要浏览器，目的是把「两处颜色漂移」「组件自己写颜色」
 * 「组件自己实现数值格式化」三类问题变成红灯，而不是靠人工肉眼对比。
 */

/* ------------------------------------------------------------------ *
 * 路径与文件读取
 * ------------------------------------------------------------------ */

/** vitest 的 root 指向工程根目录；若 cwd 不是工程根，则退回按测试文件位置推导。 */
function resolveProjectRoot(): string {
  const fromCwd = process.cwd()
  if (existsSync(resolve(fromCwd, 'src/styles/tokens.css'))) return fromCwd
  return resolve(fileURLToPath(new URL('../..', import.meta.url)))
}

const PROJECT_ROOT = resolveProjectRoot()

function readSource(relativePath: string): string {
  return readFileSync(resolve(PROJECT_ROOT, relativePath), 'utf8')
}

/** 阶段1 交付的 UI 组件（预先声明，避免“文件缺失”被静默跳过）。 */
const PHASE1_COMPONENTS = [
  'LoadingState.vue',
  'EmptyState.vue',
  'ErrorState.vue',
  'MetricCard.vue',
  'RiskBadge.vue',
  'SourceBadge.vue',
] as const

const UI_DIR = resolve(PROJECT_ROOT, 'src/components/ui')
/** 业务组件目录：其中渲染数值的组件同样受本用例约束，不能自己写格式化规则。 */
const OVERVIEW_DIR = resolve(PROJECT_ROOT, 'src/components/overview')
/** 地图工作台组件（阶段2 新增）：与 ui / overview 同一套约束。 */
const MAP_DIR = resolve(PROJECT_ROOT, 'src/components/map')
/** 查询工作台组件（阶段3 新增）：同样不得自己写颜色与格式化规则。 */
const QUERY_DIR = resolve(PROJECT_ROOT, 'src/components/query')
/** 风险研判组件（阶段4 新增）：同样不得自己写颜色与格式化规则。 */
const RISK_DIR = resolve(PROJECT_ROOT, 'src/components/risk')
/** 暴露度组件（阶段5 新增）：同样不得自己写颜色与格式化规则。 */
const EXPOSURE_DIR = resolve(PROJECT_ROOT, 'src/components/exposure')
/** 应急保障组件（阶段5 新增）：同样不得自己写颜色与格式化规则。 */
const EMERGENCY_DIR = resolve(PROJECT_ROOT, 'src/components/emergency')
/** 数据目录组件（阶段6 新增）：同样不得自己写颜色与格式化规则。 */
const CATALOG_DIR = resolve(PROJECT_ROOT, 'src/components/catalog')
/** 成果中心组件（阶段6 新增）：同样不得自己写颜色与格式化规则。 */
const RESULTS_DIR = resolve(PROJECT_ROOT, 'src/components/results')

/**
 * 阶段2 之前已存在、本阶段未改造的组件：逐一登记豁免原因，避免把守卫放宽成空规则。
 * 这些文件仍必须出现在下方断言里（存在性、原因非空），只是暂时不参与色值与格式化约束。
 */
const LEGACY_ALLOWLIST = new Map<string, string>([
  [
    'RealPreviewMap.vue',
    '上一轮独立真实预览组件（/real-preview），本阶段未改造其配色与计数显示；其颜色字面量待阶段7 统一收敛到令牌',
  ],
])

function collectVueFiles(dir: string): string[] {
  if (!existsSync(dir)) return []
  const found: string[] = []
  for (const entry of readdirSync(dir, { withFileTypes: true })) {
    const full = resolve(dir, entry.name)
    if (entry.isDirectory()) found.push(...collectVueFiles(full))
    else if (entry.isFile() && entry.name.endsWith('.vue')) found.push(full)
  }
  return found
}

function uiVueFiles(): Array<{ name: string; source: string }> {
  // 九个目录各自取相对文件名（文件名唯一），便于断言与阅读
  return [
    UI_DIR,
    OVERVIEW_DIR,
    MAP_DIR,
    QUERY_DIR,
    RISK_DIR,
    EXPOSURE_DIR,
    EMERGENCY_DIR,
    CATALOG_DIR,
    RESULTS_DIR,
  ].flatMap((dir) =>
    collectVueFiles(dir).map((path) => ({
      // Windows 下 relative 返回反斜杠，统一成正斜杠便于断言与阅读
      name: relative(dir, path).replace(/\\/g, '/'),
      source: readFileSync(path, 'utf8'),
    })),
  )
}

/** 从 CSS 文本中提取 `--name: value;` 形式的令牌；跨行值也能取到。 */
function tokenMap(css: string): Map<string, string> {
  const map = new Map<string, string>()
  const pattern = /(--[a-z0-9-]+)\s*:\s*([^;{}]+);/g
  let matched = pattern.exec(css)
  while (matched !== null) {
    const name = matched[1]
    const value = matched[2]
    if (name !== undefined && value !== undefined) map.set(name, value.trim())
    matched = pattern.exec(css)
  }
  return map
}

/** 取出文本里引用的全部 `var(--x)` 令牌名。 */
function referencedTokens(text: string): string[] {
  const names = new Set<string>()
  const pattern = /var\(\s*(--[a-z0-9-]+)/g
  let matched = pattern.exec(text)
  while (matched !== null) {
    const name = matched[1]
    if (name !== undefined) names.add(name)
    matched = pattern.exec(text)
  }
  return [...names]
}

const tokensCss = readSource('src/styles/tokens.css')
const baseCss = readSource('src/styles/base.css')
const tokens = tokenMap(tokensCss)

/* ------------------------------------------------------------------ *
 * 一、tokens.css 与 domain/risk.ts 的交叉校验
 *    domain/risk.ts 文件头承诺「颜色值与 tokens.css 的 --color-risk-* 必须一致」，
 *    这里逐项比对，任何一处漂移都会失败。
 * ------------------------------------------------------------------ */

describe('设计令牌：风险色与 domain/risk.ts 交叉校验', () => {
  it('六个风险等级色值与 RISK_LEVEL_COLOR 逐个一致', () => {
    expect(RISK_LEVELS.length).toBe(6)
    for (const level of RISK_LEVELS) {
      const tokenName = `--color-risk-${level}`
      const value = tokens.get(tokenName)
      expect(value, `tokens.css 缺少 ${tokenName}`).toBeTruthy()
      expect(value?.toLowerCase(), `${tokenName} 与 RISK_LEVEL_COLOR.${level} 不一致`).toBe(
        RISK_LEVEL_COLOR[level].toLowerCase(),
      )
    }
  })

  it('六个风险等级的文字色与 RISK_LEVEL_TEXT_COLOR 逐个一致', () => {
    for (const level of RISK_LEVELS) {
      const tokenName = `--color-risk-${level}-text`
      const value = tokens.get(tokenName)
      expect(value, `tokens.css 缺少 ${tokenName}`).toBeTruthy()
      expect(value?.toLowerCase(), `${tokenName} 与 RISK_LEVEL_TEXT_COLOR.${level} 不一致`).toBe(
        RISK_LEVEL_TEXT_COLOR[level].toLowerCase(),
      )
    }
  })

  it('风险色在 tokens.css 中确实是颜色字面量，不是再次 var() 转发', () => {
    for (const level of RISK_LEVELS) {
      const value = tokens.get(`--color-risk-${level}`)
      expect(value, `--color-risk-${level} 应为颜色值`).toMatch(/^#[0-9a-f]{6}$/i)
    }
  })
})

/* ------------------------------------------------------------------ *
 * 二、01 §4.2 要求的核心令牌名必须存在
 * ------------------------------------------------------------------ */

const REQUIRED_TOKENS: Record<string, string[]> = {
  '布局尺寸（01 §4.2、§4.3）': [
    'header-height',
    'statusbar-height',
    'panel-left',
    'panel-right',
    'panel-left-compact',
    'result-table-height',
    'tool-button-size',
    'control-height',
    'icon-size',
  ],
  间距: ['space-1', 'space-2', 'space-3', 'space-4', 'space-6', 'space-8'],
  圆角与阴影: ['radius-sm', 'radius-md', 'radius-lg', 'shadow-panel'],
  字体: [
    'font-family-base',
    'font-size-page-title',
    'font-size-section-title',
    'font-size-body',
    'font-size-caption',
    'font-size-metric',
    'line-height-body',
    'line-height-tight',
  ],
  主题色: [
    'color-shell',
    'color-map-bg',
    'color-page',
    'color-surface',
    'color-text',
    'color-muted',
    'color-border',
    'color-primary',
    'color-focus',
    'color-glacier',
    'color-water',
    'color-map-query',
    'color-impact-area',
    'color-route-line',
  ],
  '阶段4 情景连续色域': [
    'color-scenario-ramp-0',
    'color-scenario-ramp-1',
    'color-scenario-ramp-2',
    'color-scenario-ramp-3',
    'color-scenario-ramp-4',
  ],
  动效: ['motion-fade'],
  '阶段1 按钮与焦点': [
    'color-on-primary',
    'color-primary-strong',
    'color-primary-soft',
    'color-disabled-bg',
    'color-disabled-text',
    'color-disabled-border',
    'focus-ring-color',
    'focus-ring-width',
    'focus-ring-offset',
    'button-padding-x',
    'button-radius',
    'button-font-weight',
  ],
  '阶段1 骨架与徽标': [
    'skeleton-base',
    'skeleton-highlight',
    'skeleton-line-height',
    'skeleton-radius',
    'skeleton-duration',
    'badge-padding-x',
    'badge-radius',
    'badge-font-size',
    'badge-border-color',
    'badge-surface',
    'badge-text',
    'risk-hatch-size',
  ],
  '阶段1 状态块': ['state-padding', 'state-radius', 'state-surface', 'error-surface'],
}

describe('设计令牌：核心令牌名', () => {
  for (const [group, names] of Object.entries(REQUIRED_TOKENS)) {
    it(`${group} 的令牌全部已定义且取值非空`, () => {
      const missing = names.filter((name) => {
        const value = tokens.get(`--${name}`)
        return value === undefined || value.length === 0
      })
      expect(missing, `tokens.css 缺少令牌：${missing.join('、')}`).toEqual([])
    })
  }

  it('base.css 不定义任何设计变量（变量只在 tokens.css 维护）', () => {
    expect([...tokenMap(baseCss).keys()]).toEqual([])
  })
})

/* ------------------------------------------------------------------ *
 * 三、按钮、焦点环与等宽数字
 * ------------------------------------------------------------------ */

describe('基础样式：按钮与焦点', () => {
  it('四类按钮与禁用态样式齐备', () => {
    for (const selector of [
      '.btn {',
      '.btn--primary',
      '.btn--ghost',
      '.btn--danger',
      ':disabled',
    ]) {
      expect(baseCss, `base.css 缺少 ${selector}`).toContain(selector)
    }
  })

  it('base.css 使用 :focus-visible 且焦点环来自令牌', () => {
    expect(baseCss).toContain(':focus-visible')
    expect(baseCss).toContain('var(--focus-ring-width)')
    expect(baseCss).toContain('var(--focus-ring-color)')
    expect(baseCss).toContain('var(--focus-ring-offset)')
  })

  it('数字等宽类只定义一次（tokens.css 已有的不重复定义）', () => {
    const occurrences = baseCss.split('tabular-nums').length - 1
    expect(occurrences, 'base.css 不应重复定义 .tabular-nums').toBe(0)
    expect(tokensCss).toContain('.tabular-nums')
    expect(tokensCss).toContain('font-variant-numeric: tabular-nums')
  })

  it('base.css 内部不含裸颜色字面量', () => {
    expect(baseCss.match(/#[0-9a-fA-F]{3,8}\b/g) ?? []).toEqual([])
  })
})

/* ------------------------------------------------------------------ *
 * 四、组件不得写裸颜色、不得引用未定义令牌
 * ------------------------------------------------------------------ */

/**
 * 允许清单：目前为空。
 * 如需豁免，必须在此登记「文件 → 原因」，禁止直接放宽下面的规则。
 */
const HEX_LITERAL_ALLOWLIST = new Map<string, string>()

describe('UI 组件：颜色只能来自令牌或 domain/risk.ts 常量', () => {
  const files = uiVueFiles()

  it('src/components/ui 下存在阶段1 交付的全部组件', () => {
    const names = files.map((file) => file.name)
    for (const component of PHASE1_COMPONENTS) {
      expect(names, `缺少组件 ${component}`).toContain(component)
    }
  })

  it('除允许清单外不出现裸 #rrggbb 颜色字面量', () => {
    const offenders: string[] = []
    for (const file of files) {
      if (HEX_LITERAL_ALLOWLIST.has(file.name) || LEGACY_ALLOWLIST.has(file.name)) continue
      for (const literal of file.source.match(/#[0-9a-fA-F]{3,8}\b/g) ?? []) {
        offenders.push(`${file.name} → ${literal}`)
      }
    }
    expect(offenders, `以下组件写死了颜色（应改取 var(--...) 或 domain/risk.ts 常量）`).toEqual([])
  })

  it('允许清单里的文件真实存在且写明原因', () => {
    const names = files.map((file) => file.name)
    for (const [name, reason] of HEX_LITERAL_ALLOWLIST) {
      expect(names, `允许清单中的 ${name} 已不存在，请删除该条目`).toContain(name)
      expect(reason.length, `${name} 的豁免原因不能为空`).toBeGreaterThan(0)
    }
  })

  it('阶段2 之前的豁免清单同样必须指向真实文件并写明原因（清单不得腐化）', () => {
    const names = files.map((file) => file.name)
    for (const [name, reason] of LEGACY_ALLOWLIST) {
      expect(names, `豁免清单中的 ${name} 已不存在，请删除该条目`).toContain(name)
      expect(reason.length, `${name} 的豁免原因不能为空`).toBeGreaterThan(0)
    }
  })

  it('组件引用的 var(--...) 令牌都在 tokens.css 中定义（豁免文件除外）', () => {
    const offenders: string[] = []
    for (const file of files) {
      if (LEGACY_ALLOWLIST.has(file.name)) continue
      for (const name of referencedTokens(file.source)) {
        if (!tokens.has(name)) offenders.push(`${file.name} → ${name}`)
      }
    }
    expect(offenders, '组件引用了未定义的令牌').toEqual([])
  })
})

/* ------------------------------------------------------------------ *
 * 五、格式化规则只有一份：组件必须复用 domain 的导出
 * ------------------------------------------------------------------ */

/**
 * 每个组件应当复用的模块与关键导出。
 * 这里按组件职责分别声明，而不是一律要求 import format/risk：
 * 只显示标签映射（SourceBadge）或只显示错误契约（ErrorState）的组件，
 * 强行引用格式化模块属于形式主义，无法防止重复实现。
 */
const DOMAIN_USAGE: Record<string, { module: string; symbols: string[] }> = {
  'MetricCard.vue': {
    module: '@/domain/format',
    symbols: [
      'formatMetricValue',
      'formatMetricMeta',
      'formatYear',
      'metricStatusText',
      'NOT_REGISTERED_TEXT',
    ],
  },
  'RiskBadge.vue': {
    module: '@/domain/risk',
    symbols: ['RISK_LEVEL_COLOR', 'RISK_LEVEL_TEXT_COLOR', 'riskLevelLabel'],
  },
  'SourceBadge.vue': {
    module: '@/domain/labels',
    symbols: ['DATA_MODE_LABEL', 'NOT_PROVIDED_TEXT'],
  },
  'ErrorState.vue': {
    module: '@/repositories/types',
    symbols: ['toRepositoryError', 'RepositoryError'],
  },
  'DataConnectivityPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatMetricValue', 'formatTimeValue', 'NOT_PROVIDED_TEXT'],
  },
  'LayerTree.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatPercent', 'NOT_PROVIDED_TEXT'],
  },
  'MapStatusBar.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatLonLat', 'formatNumber', 'NOT_PROVIDED_TEXT'],
  },
  'MapLegend.vue': {
    module: '@/domain/format',
    symbols: ['formatNumber', 'NOT_PROVIDED_TEXT'],
  },
  'MapObjectList.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'NOT_PROVIDED_TEXT'],
  },
  'FeatureDetailPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatFieldValue', 'formatId', 'NOT_PROVIDED_TEXT'],
  },
  'LayerMetadataPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatBbox', 'formatCount', 'formatTimeValue', 'NOT_PROVIDED_TEXT'],
  },
  'QueryPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatNumber', 'NOT_PROVIDED_TEXT'],
  },
  'QuerySpatialPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatDistance', 'NOT_PROVIDED_TEXT'],
  },
  'QueryResultTable.vue': {
    module: '@/domain/format',
    symbols: [
      'formatCount',
      'formatFieldValue',
      'formatMetricValue',
      'formatNumber',
      'NOT_PROVIDED_TEXT',
    ],
  },
  'RiskLegend.vue': {
    module: '@/domain/scenario',
    symbols: ['SCENARIO_METRIC_META', 'type ScenarioMetric'],
  },
  'RiskStatsPanel.vue': {
    module: '@/domain/scenario',
    symbols: ['SCENARIO_BIN_COUNT', 'SCENARIO_METRIC_META', 'distributionBins'],
  },
  'RiskTopList.vue': {
    module: '@/domain/scenario',
    symbols: ['SCENARIO_METRIC_META', 'formatScenarioValue'],
  },
  'RiskDetailPanel.vue': {
    module: '@/domain/scenario',
    symbols: [
      'SCENARIO_METRIC_META',
      'SCENARIO_METRICS',
      'formatScenarioValue',
      'MATCH_STATUS_TEXT',
    ],
  },
  'RiskSourcePanel.vue': {
    module: '@/domain/scenario',
    symbols: ['SCENARIO_METRIC_META', 'SCENARIO_METRICS'],
  },
  'RiskControlPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatFixed'],
  },
  'RiskMapCanvas.vue': {
    module: '@/domain/format',
    symbols: ['formatFixed'],
  },
  'ExposureControlPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount'],
  },
  'ExposureAffectedTable.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatId', 'NOT_PROVIDED_TEXT'],
  },
  'RoutePlanPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatDistance'],
  },
  'RouteDirectoryPanel.vue': {
    module: '@/domain/format',
    symbols: ['formatCount', 'formatDistance'],
  },
  'RouteInfoPanel.vue': {
    module: '@/domain/format',
    symbols: [
      'formatCount',
      'formatDistance',
      'formatDuration',
      'formatLonLat',
      'NOT_PROVIDED_TEXT',
    ],
  },
  'CatalogTable.vue': {
    module: '@/domain/format',
    symbols: ['formatCount'],
  },
  'PrecipYearBrowser.vue': {
    module: '@/domain/format',
    symbols: ['NOT_PROVIDED_TEXT'],
  },
  'ResultFilesPanel.vue': {
    module: '@/domain/format',
    symbols: ['NOT_REGISTERED_TEXT'],
  },
  'OverviewMapCanvas.vue': {
    module: '@/domain/format',
    symbols: ['formatFixed'],
  },
  'ResultMapCanvas.vue': {
    module: '@/domain/format',
    symbols: ['formatFixed'],
  },
}

/**
 * 允许不引用任何领域模块的纯展示组件。
 * 它们不渲染数值，因此不存在“重复实现格式化规则”的风险。
 */
const PURE_PRESENTATIONAL = new Map<string, string>([
  ['LoadingState.vue', '只渲染骨架条与一句加载文案，不渲染任何数值，格式化规则不适用'],
  ['EmptyState.vue', '只渲染标题、说明与操作按钮，不渲染任何数值，格式化规则不适用'],
  ['StageNotice.vue', '阶段0 路由占位组件（非阶段1 交付物），只输出文字说明，不渲染任何数值'],
  ['MapToolbar.vue', '只渲染按钮与禁用原因，数值展示由状态栏与图层树承担'],
  ['MapCanvas.vue', '只渲染地图画布与一句操作提示，数值展示由 MapStatusBar 承担'],
  [
    'QueryFilterPanel.vue',
    '只渲染字段条件控件（文本框、勾选框、下拉），不渲染任何数值；数值条件的显示值由结果表与导出承担',
  ],
  ['ExposureMapCanvas.vue', '只渲染地图画布与计数 chip（formatFixed），数值口径由指标面板承担'],
  ['RouteMapCanvas.vue', '只渲染地图画布与状态 chip（formatFixed），距离/时间数字由信息面板承担'],
  [
    'ExposureMetricsPanel.vue',
    '指标数字复用 MetricCard（其自身受 DOMAIN_USAGE 约束），本组件只渲染口径文本，不自行格式化数值',
  ],
  [
    'ExposureSourcePanel.vue',
    '只渲染方法/输入/文件可用性等文本与链接，不渲染任何数值，格式化规则不适用',
  ],
])

describe('UI 组件：复用统一格式化与领域常量', () => {
  const files = uiVueFiles()

  it('每个 UI 组件都声明了应当复用的领域模块，或登记为纯展示组件', () => {
    const undeclared = files
      .map((file) => file.name)
      .filter(
        (name) =>
          !(name in DOMAIN_USAGE) && !PURE_PRESENTATIONAL.has(name) && !LEGACY_ALLOWLIST.has(name),
      )
    expect(
      undeclared,
      '新增 UI 组件必须在 DOMAIN_USAGE 声明复用的领域模块，或登记为 PURE_PRESENTATIONAL / LEGACY_ALLOWLIST',
    ).toEqual([])
  })

  it('纯展示清单与领域复用清单指向的文件都存在（避免清单腐化）', () => {
    const names = files.map((file) => file.name)
    for (const name of [...Object.keys(DOMAIN_USAGE), ...PURE_PRESENTATIONAL.keys()]) {
      expect(names, `清单中的 ${name} 不存在`).toContain(name)
    }
    for (const [name, reason] of PURE_PRESENTATIONAL) {
      expect(reason.length, `${name} 的登记原因不能为空`).toBeGreaterThan(0)
    }
  })

  for (const [name, expected] of Object.entries(DOMAIN_USAGE)) {
    it(`${name} 从 ${expected.module} 取用共享规则`, () => {
      const file = files.find((item) => item.name === name)
      expect(file, `缺少组件 ${name}`).toBeTruthy()
      const source = file?.source ?? ''
      expect(source, `${name} 未引用 ${expected.module}`).toContain(`from '${expected.module}'`)
      for (const symbol of expected.symbols) {
        expect(source, `${name} 未使用 ${symbol}`).toContain(symbol)
      }
    })
  }

  it('UI 组件不自行实现数值格式化（不出现 toFixed / Intl.NumberFormat / toLocaleString）', () => {
    const offenders = files
      .filter((file) => !LEGACY_ALLOWLIST.has(file.name))
      .filter((file) => /toFixed\(|Intl\.NumberFormat|toLocaleString\(/.test(file.source))
      .map((file) => file.name)
    expect(offenders, '数值格式化必须放在 domain/format.ts').toEqual([])
  })
})
