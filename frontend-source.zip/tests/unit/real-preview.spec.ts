import { describe, expect, it } from 'vitest'
import { readFile } from 'node:fs/promises'
import { createHash } from 'node:crypto'
import { resolve } from 'node:path'
import { createRealPreviewRepository, type PreviewLayer } from '@/repositories/realPreview'
const read = async (file: string): Promise<unknown> =>
  JSON.parse(await readFile(resolve('public/real-preview', file), 'utf8'))
const repository = createRealPreviewRepository(read)

describe('真实预览：来源、计数与失败隔离', () => {
  it('清单为真实包、完整计数、不声称SQL Server已验证', async () => {
    const m = await repository.manifest()
    expect(m.sample).toBe(false)
    expect(m.sqlServerVerified).toBe(false)
    expect(m.vectors).toHaveLength(41)
    expect(m.vectors.reduce((sum, v) => sum + v.count, 0)).toBe(465816)
    expect(m.rasters).toHaveLength(30)
    expect(m.rasters.reduce((sum, v) => sum + v.bytes, 0)).toBe(79275600280)
    expect(m.exports).toHaveLength(5)
  })
  it('所有导出数量一致、ID唯一、哈希匹配且不含抽样', async () => {
    const m = await repository.manifest()
    const checks = await Promise.all(
      m.exports.map(async (layer) => {
        const geo = await repository.features(layer)
        const raw = await readFile(resolve('public/real-preview', layer.file))
        return {
          count: geo.features.length === layer.count,
          unique: new Set(geo.features.map((f) => f.id)).size === geo.features.length,
          hash: createHash('sha256').update(raw).digest('hex') === layer.sha256,
          sampled: layer.sampled,
        }
      }),
    )
    expect(checks.every((c) => c.count && c.unique && c.hash && !c.sampled)).toBe(true)
  })
  it('点几何为经纬度，未来情景保留原始指标、不产生风险等级', async () => {
    const m = await repository.manifest()
    const layer = m.exports.find((l) => l.id === 'scenario2050')!
    const geo = await repository.features(layer)
    expect(geo.features).toHaveLength(601)
    const invalid = geo.features.filter(
      (f) =>
        f.geometry?.type !== 'Point' ||
        Math.abs(f.geometry.coordinates[0] ?? 999) > 180 ||
        Math.abs(f.geometry.coordinates[1] ?? 999) > 90,
    )
    expect(invalid).toEqual([])
    expect(geo.features[0]?.properties).toHaveProperty('rrgi')
    expect(geo.features[0]?.properties).not.toHaveProperty('riskLevel')
  })
  it('拒绝示例包，不能换标后冒充真实数据', async () => {
    await expect(
      createRealPreviewRepository(async () => ({ sample: true })).manifest(),
    ).rejects.toThrow('误用了示例包')
  })
  it('失败后重新发起请求可以恢复，不缓存失败Promise', async () => {
    let attempts = 0
    const repo = createRealPreviewRepository(async (file) => {
      if (++attempts === 1) throw new Error('offline')
      return read(file)
    })
    await expect(repo.manifest()).rejects.toThrow('offline')
    await expect(repo.manifest()).resolves.toHaveProperty('sample', false)
  })
  it('拒绝路径穿越和记录数不一致', async () => {
    const m = await repository.manifest()
    const layer = m.exports[0] as PreviewLayer
    await expect(repository.features({ ...layer, file: '../demo/manifest.json' })).rejects.toThrow(
      '非法图层路径',
    )
    await expect(repository.features({ ...layer, count: 999 })).rejects.toThrow('数量与清单不一致')
  })
})
