import { describe, expect, it } from 'vitest'
import { createMemoryHistory } from 'vue-router'

import { createAppRouter, routes } from '@/app/router'

/**
 * 阶段0 单元测试范围：路由表结构与 404 兜底。
 * 不测试任何业务数据语义（那些属于阶段1 及以后）。
 */
describe('应用路由骨架', () => {
  it('路由名称唯一且不重复', () => {
    const names = routes.map((route) => route.name).filter((name) => name !== undefined)
    expect(new Set(names).size).toBe(names.length)
  })

  it('注册了 01 §3 规定的全部一级页面路径', () => {
    const paths = routes.map((route) => route.path)
    for (const expected of [
      '/overview',
      '/map',
      '/analysis/risk',
      '/analysis/emergency',
      '/results',
      '/results/:resultId',
      '/catalog',
      '/catalog/:datasetId',
      '/about',
    ]) {
      expect(paths).toContain(expected)
    }
  })

  it('根路径重定向到总览', () => {
    const root = routes.find((route) => route.path === '/')
    expect(root?.redirect).toEqual({ name: 'overview' })
  })

  it('每个可渲染页面都带中文标题', () => {
    for (const route of routes) {
      if (route.path === '/' || route.name === 'not-found') continue
      expect(typeof route.meta?.title).toBe('string')
      expect((route.meta?.title as string).length).toBeGreaterThan(0)
    }
  })

  it('未知路径落到 not-found，而不是静默留在首页', async () => {
    const router = createAppRouter(createMemoryHistory())
    await router.push('/不存在的路径/xyz')
    await router.isReady()
    expect(router.currentRoute.value.name).toBe('not-found')
  })

  it('带参数路由能解析出 resultId 与 datasetId', async () => {
    const router = createAppRouter(createMemoryHistory())
    await router.push('/results/demo-result-001')
    await router.isReady()
    expect(router.currentRoute.value.name).toBe('result-detail')
    expect(router.currentRoute.value.params.resultId).toBe('demo-result-001')

    await router.push('/catalog/demo-dataset-001')
    await router.isReady()
    expect(router.currentRoute.value.name).toBe('catalog-detail')
    expect(router.currentRoute.value.params.datasetId).toBe('demo-dataset-001')
  })

  it('默认首页可访问，且一级导航路径全部可解析', async () => {
    const router = createAppRouter(createMemoryHistory())
    for (const path of ['/overview', '/map', '/analysis/risk', '/results', '/catalog', '/about']) {
      await router.push(path)
      await router.isReady()
      expect(router.currentRoute.value.path).toBe(path)
      expect(router.currentRoute.value.name).not.toBe('not-found')
    }
  })
})
