import { existsSync, readFileSync } from 'node:fs'
import { resolve } from 'node:path'
import { describe, expect, it } from 'vitest'
import type { Feature, FeatureCollection, Geometry, LineString, Position } from 'geojson'
import { RISK_LEVEL_COLOR, RISK_LEVEL_LABEL, RISK_LEVEL_ORDER } from '@/domain/risk'
import { inferTimePrecision } from '@/domain/format'
import {
  classifyPointInRing,
  geometryFamilyOf,
  haversineMeters,
  isPointOnPolyline,
  polylineLengthMeters,
  representativeLonLat,
} from '@/domain/geometry'
import type {
  Capabilities,
  DataSource,
  Dataset,
  Dictionary,
  FeaturePropertyValue,
  ImportLog,
  LayerDefinition,
  Legend,
  Region,
  ResultDetail,
  RouteDetail,
} from '@/domain/types'

/**
 * 示例数据包自检。
 *
 * 目的：示例数据包的每一个数值、单位与引用关系都必须在代码层面可校验，
 * 避免“界面看起来对、数字之间互相矛盾”。这些断言只读取 public/demo 下的文件，
 * 不依赖浏览器、也不依赖 dev server。
 */

// vitest 的 root 指向工程根目录，因此相对 cwd 即可定位到 public/demo
const demoDir = `${resolve(process.cwd(), 'public/demo')}/`

function readJson<T>(relativePath: string): T {
  return JSON.parse(readFileSync(`${demoDir}${relativePath}`, 'utf8')) as T
}

const manifest = readJson<{
  packageId: string
  mode: string
  sample: boolean
  generatedAt: string
  scopeLabel: string
  boundaryVersion: string
  datasetVersions: Record<string, string>
  files: Record<string, unknown> & { features: Record<string, string> }
  notes: string[]
}>('manifest.json')

const layers = readJson<{ layers: LayerDefinition[] }>('layers.json').layers
const legends = readJson<{ legends: Legend[] }>('legends.json').legends
const dictionaries = readJson<{ dictionaries: Dictionary[] }>('dictionaries.json').dictionaries
const datasets = readJson<{ datasets: Dataset[] }>('datasets.json').datasets
const sources = readJson<{ sources: DataSource[] }>('sources.json').sources
const regions = readJson<{ regions: Region[] }>('regions.json').regions
const results = readJson<{ results: ResultDetail[] }>('results.json').results
const routes = readJson<{ routes: RouteDetail[] }>('routes.json').routes
const imports = readJson<{ imports: ImportLog[] }>('imports.json').imports
const capabilities = readJson<{ capabilities: Capabilities }>('capabilities.json').capabilities

const featuresByLayer = new Map<string, FeatureCollection>(
  Object.entries(manifest.files.features).map(([layerId, relativePath]) => [
    layerId,
    readJson<FeatureCollection>(relativePath),
  ]),
)

function layerById(layerId: string): LayerDefinition {
  const layer = layers.find((item) => item.id === layerId)
  if (!layer) throw new Error(`图层不存在：${layerId}`)
  return layer
}

function featureId(feature: Feature): string {
  const id = feature.id
  return typeof id === 'number' ? String(id) : (id ?? '')
}

function featuresOf(layerId: string): Feature[] {
  const collection = featuresByLayer.get(layerId)
  if (!collection) throw new Error(`图层缺少要素文件：${layerId}`)
  return collection.features
}

function findFeature(layerId: string, id: string): Feature {
  const feature = featuresOf(layerId).find((item) => featureId(item) === id)
  if (!feature) throw new Error(`要素不存在：${layerId}/${id}`)
  return feature
}

function allPositions(geometry: Geometry | null): Position[] {
  if (!geometry) return []
  switch (geometry.type) {
    case 'Point':
      return [geometry.coordinates]
    case 'MultiPoint':
    case 'LineString':
      return [...geometry.coordinates]
    case 'MultiLineString':
    case 'Polygon':
      return geometry.coordinates.flat()
    case 'MultiPolygon':
      return geometry.coordinates.flat(2)
    case 'GeometryCollection':
      return geometry.geometries.flatMap((item) => allPositions(item))
    default:
      return []
  }
}

function outerRings(geometry: Geometry | null): Position[][] {
  if (!geometry) return []
  if (geometry.type === 'Polygon') return [geometry.coordinates[0] ?? []]
  if (geometry.type === 'MultiPolygon') return geometry.coordinates.map((item) => item[0] ?? [])
  return []
}

function impactRings(): Position[][] {
  return featuresOf('result.demo.impact').flatMap((feature) => outerRings(feature.geometry))
}

/** 点到折线的最短球面距离：在等距圆柱近似下投影到各线段，再按球面距离回算。 */
function distancePointToPolyline(point: Position, coordinates: Position[]): number {
  const [lon, lat] = point as [number, number]
  let best = Number.POSITIVE_INFINITY
  for (let index = 1; index < coordinates.length; index += 1) {
    const from = coordinates[index - 1] as [number, number]
    const to = coordinates[index] as [number, number]
    const scale = Math.cos((((from[1] + to[1]) / 2) * Math.PI) / 180)
    const bx = (to[0] - from[0]) * scale
    const by = to[1] - from[1]
    const px = (lon - from[0]) * scale
    const py = lat - from[1]
    const lengthSquared = bx * bx + by * by
    const ratio =
      lengthSquared === 0 ? 0 : Math.max(0, Math.min(1, (px * bx + py * by) / lengthSquared))
    const projection: [number, number] = [
      from[0] + ratio * (to[0] - from[0]),
      from[1] + ratio * (to[1] - from[1]),
    ]
    best = Math.min(best, haversineMeters([lon, lat], projection))
  }
  return best
}

describe('示例数据包：清单与文件', () => {
  it('清单声明的每个文件都真实存在', () => {
    const fileKeys = Object.keys(manifest.files).filter((key) => key !== 'features')
    expect(fileKeys.length).toBeGreaterThan(5)
    for (const key of fileKeys) {
      const relativePath = manifest.files[key] as string
      expect(typeof relativePath, `manifest.files.${key}`).toBe('string')
      expect(existsSync(`${demoDir}${relativePath}`), `缺少文件 ${relativePath}`).toBe(true)
    }
    for (const [layerId, relativePath] of Object.entries(manifest.files.features)) {
      expect(
        existsSync(`${demoDir}${relativePath}`),
        `缺少图层文件 ${layerId} → ${relativePath}`,
      ).toBe(true)
    }
  })

  it('清单自身标识示例数据包，并给出范围与边界版本', () => {
    expect(manifest.packageId).toBe('demo-v1')
    expect(manifest.mode).toBe('mock')
    expect(manifest.sample).toBe(true)
    expect(manifest.scopeLabel.length).toBeGreaterThan(0)
    expect(manifest.boundaryVersion).toBe('demo-boundary-v1')
    expect(manifest.notes.join(' ')).toContain('示例数据')
  })

  it('清单登记的数据集版本与数据集文件一致', () => {
    expect(Object.keys(manifest.datasetVersions).sort()).toEqual(
      datasets.map((item) => item.id).sort(),
    )
    for (const dataset of datasets) {
      expect(manifest.datasetVersions[dataset.id], dataset.id).toBe(dataset.version)
    }
  })
})

describe('示例数据包：图层与数据集互相引用', () => {
  it('图层标识唯一，且都指向已登记的数据集', () => {
    const ids = layers.map((layer) => layer.id)
    expect(new Set(ids).size).toBe(ids.length)
    for (const layer of layers) {
      expect(
        datasets.some((item) => item.id === layer.datasetId),
        `${layer.id} → ${layer.datasetId}`,
      ).toBe(true)
    }
  })

  it('矢量图层都提供了要素文件，不可用服务都说明了原因', () => {
    for (const layer of layers) {
      const source = layer.source
      if (source.type === 'geojson') {
        expect(manifest.files.features[layer.id], `${layer.id} 缺少要素文件`).toBeTruthy()
      } else {
        expect(source.type, `${layer.id} 应为非可用服务`).toBe('unavailable')
        // 已断言类型为 unavailable，这里按该分支取 reason 校验
        const unavailable = source as { reason: string }
        expect(unavailable.reason.length, `${layer.id} 未说明原因`).toBeGreaterThan(0)
      }
    }
    for (const layerId of Object.keys(manifest.files.features)) {
      expect(layerById(layerId).source.type, `${layerId} 不应声明要素文件`).toBe('geojson')
    }
  })

  it('数据集登记的图层都真实存在，归属关系双向一致', () => {
    for (const dataset of datasets) {
      for (const layerId of dataset.layerIds) {
        const layer = layerById(layerId)
        expect(layer.datasetId, `${layerId} 归属数据集`).toBe(dataset.id)
        for (const time of layer.availableTimes) {
          expect(
            dataset.availableTimes.some((item) => item.value === time.value),
            `${dataset.id} 未登记时相 ${time.value}`,
          ).toBe(true)
        }
      }
    }
  })

  it('数据集来源都可追溯到已登记来源', () => {
    for (const dataset of datasets) {
      expect(
        sources.some((item) => item.id === dataset.sourceId),
        `${dataset.id} → ${dataset.sourceId}`,
      ).toBe(true)
    }
  })

  it('字段字典引用都存在，枚举字段必须有字典', () => {
    const dictionaryIds = new Set(dictionaries.map((item) => item.id))
    for (const dataset of datasets) {
      for (const field of dataset.fields) {
        if (field.dictionaryId) {
          expect(
            dictionaryIds.has(field.dictionaryId),
            `${dataset.id}.${field.key} → ${field.dictionaryId}`,
          ).toBe(true)
        }
        if (field.type === 'enum') {
          expect(field.dictionaryId, `${dataset.id}.${field.key} 缺少字典`).toBeTruthy()
        }
      }
    }
  })

  it('图层图例引用都存在', () => {
    const legendIds = new Set(legends.map((item) => item.id))
    for (const layer of layers) {
      expect(legendIds.has(layer.legendId), `${layer.id} → ${layer.legendId}`).toBe(true)
    }
  })

  it('未接入服务的图层不提供查询与导出，避免出现“看起来能查”的假入口', () => {
    for (const layer of layers) {
      if (layer.source.type === 'unavailable') {
        expect(layer.queryable, `${layer.id} 不应可查询`).toBe(false)
        expect(layer.exportFormats, `${layer.id} 不应可导出`).toEqual([])
        expect(datasets.find((item) => item.id === layer.datasetId)?.serviceAvailable).toBe(false)
      }
    }
  })
})

describe('示例数据包：图例数值', () => {
  it('风险等级图例与前端领域常量完全一致', () => {
    const legend = legends.find((item) => item.id === 'legend.risk-level')
    expect(legend).toBeTruthy()
    expect(legend?.classificationVersion).toBe('demo-risk-classification-v1')
    expect(legend?.items.map((item) => item.code)).toEqual([
      'low',
      'lower',
      'medium',
      'higher',
      'high',
      'insufficient',
    ])
    for (const item of legend?.items ?? []) {
      expect(item.color, item.code).toBe(
        RISK_LEVEL_COLOR[item.code as keyof typeof RISK_LEVEL_COLOR],
      )
      expect(item.label, item.code).toBe(
        RISK_LEVEL_LABEL[item.code as keyof typeof RISK_LEVEL_LABEL],
      )
    }
    expect(legend?.noDataStyle.pattern).toBe('hatch')
    expect(legend?.noDataStyle.label).toContain('数据不足')
  })

  it('分级图例的色带覆盖完整且区间单调连续', () => {
    for (const legend of legends) {
      expect(legend.items.length, legend.id).toBeGreaterThan(0)
      if (legend.kind === 'classified' || legend.kind === 'continuous') {
        expect(legend.items.length, `${legend.id} 分级项过少`).toBeGreaterThan(1)
      }
      for (const item of legend.items) {
        expect(item.color, `${legend.id}.${item.code}`).toMatch(/^#[0-9a-f]{6}$/)
        if (item.min !== null && item.max !== null) {
          expect(item.min, `${legend.id}.${item.code} 区间倒置`).toBeLessThan(item.max)
        }
      }
      if (legend.kind === 'classified') {
        const bounded = legend.items.filter((item) => item.min !== null && item.max !== null)
        for (let index = 1; index < bounded.length; index += 1) {
          expect(bounded[index]!.min, `${legend.id} 分级不连续`).toBe(bounded[index - 1]!.max)
        }
      }
    }
  })

  it('单位未确认的图例保持 unit 为 null，不猜单位', () => {
    expect(legends.find((item) => item.id === 'legend.lake-area')?.unit).toBeNull()
    expect(legends.find((item) => item.id === 'legend.scenario-index')?.unit).toBeNull()
    expect(legends.find((item) => item.id === 'legend.population')?.unit).toBeNull()
  })
})

describe('示例数据包：要素属性', () => {
  const allFeatures: Array<{ layerId: string; feature: Feature }> = []
  for (const [layerId, collection] of featuresByLayer) {
    for (const feature of collection.features) allFeatures.push({ layerId, feature })
  }

  it('每个图层都有要素，且要素标识在图层的唯一性成立', () => {
    for (const [layerId, collection] of featuresByLayer) {
      expect(collection.type, layerId).toBe('FeatureCollection')
      expect(collection.features.length, `${layerId} 无要素`).toBeGreaterThan(0)
      const ids = collection.features.map((feature) => featureId(feature))
      expect(
        ids.every((id) => id.length > 0),
        `${layerId} 存在缺少 id 的要素`,
      ).toBe(true)
      expect(new Set(ids).size, `${layerId} 要素 id 重复`).toBe(ids.length)
    }
  })

  it('每个要素都带示例标记，属性名为 camelCase，属性值类型受限于契约', () => {
    for (const { layerId, feature } of allFeatures) {
      const properties = feature.properties ?? {}
      expect(properties.sample, `${layerId}/${featureId(feature)} 缺少 sample 标记`).toBe(true)
      for (const [key, value] of Object.entries(properties)) {
        expect(/^[a-z][A-Za-z0-9]*$/.test(key), `${layerId} 属性名 ${key} 不是 camelCase`).toBe(
          true,
        )
        const valueType = value === null ? 'null' : typeof value
        expect(
          ['string', 'number', 'boolean', 'null'].includes(valueType),
          `${layerId}.${key} 类型不受支持：${valueType}`,
        ).toBe(true)
        if (typeof value === 'number') {
          expect(Number.isFinite(value), `${layerId}.${key} 不是有限数`).toBe(true)
        }
        void (value as FeaturePropertyValue)
      }
    }
  })

  it('要素属性都在图层字段定义中登记，字段定义不做无依据的声明', () => {
    const markerKeys = new Set(['sample'])
    for (const { layerId, feature } of allFeatures) {
      const layer = layerById(layerId)
      const declared = new Set(layer.fields.map((field) => field.key))
      for (const key of Object.keys(feature.properties ?? {})) {
        if (markerKeys.has(key)) continue
        expect(declared.has(key), `${layerId} 属性 ${key} 未在图层字段中登记`).toBe(true)
      }
    }
    for (const layer of layers) {
      if (!manifest.files.features[layer.id]) continue
      const observed = new Set<string>()
      for (const feature of featuresByLayer.get(layer.id)?.features ?? []) {
        for (const key of Object.keys(feature.properties ?? {})) observed.add(key)
      }
      for (const field of layer.fields) {
        if (markerKeys.has(field.key)) continue
        expect(observed.has(field.key), `${layer.id} 字段 ${field.key} 在要素中从未出现`).toBe(true)
      }
    }
  })

  it('枚举字段的取值都能在字典中找到，字典不做无依据的扩展', () => {
    for (const { layerId, feature } of allFeatures) {
      const layer = layerById(layerId)
      for (const field of layer.fields) {
        if (field.type !== 'enum') continue
        const dictionary = dictionaries.find((item) => item.id === field.dictionaryId)
        expect(dictionary, `${layerId}.${field.key} 缺少字典`).toBeTruthy()
        const value = feature.properties?.[field.key]
        if (value === null || value === undefined) continue
        const codes = dictionary!.items.map((item) => item.code)
        expect(codes, `${layerId}.${field.key} 的取值 ${String(value)} 不在字典中`).toContain(value)
      }
    }
  })

  it('要素几何与图层声明的几何类型一致（未登记几何的记录必须显式标注）', () => {
    let withoutGeometry = 0
    for (const [layerId, collection] of featuresByLayer) {
      const layer = layerById(layerId)
      for (const feature of collection.features) {
        const label = `${layerId}/${featureId(feature)}`
        if (feature.geometry === null) {
          // 允许“无位置信息”的记录存在，但必须显式说明，避免静默丢失对象
          expect(feature.properties?.geometryNote, `${label} 无几何却未标注原因`).toBeTruthy()
          withoutGeometry += 1
          continue
        }
        expect(geometryFamilyOf(feature.geometry), label).toBe(layer.geometryType)
      }
    }
    expect(withoutGeometry, '示例数据应包含无几何记录以验证展示与统计口径').toBeGreaterThan(0)
  })

  it('几何坐标都在示例样区范围内（经纬度顺序正确，未把纬经度写反）', () => {
    for (const { layerId, feature } of allFeatures) {
      for (const [lon, lat] of allPositions(feature.geometry)) {
        expect(lon, `${layerId}/${featureId(feature)} 经度越界`).toBeGreaterThan(89)
        expect(lon, `${layerId}/${featureId(feature)} 经度越界`).toBeLessThan(93)
        expect(lat, `${layerId}/${featureId(feature)} 纬度越界`).toBeGreaterThan(28)
        expect(lat, `${layerId}/${featureId(feature)} 纬度越界`).toBeLessThan(32)
      }
    }
  })

  it('缺失值保持 null，没有被改写成 0 或空字符串', () => {
    const settlementPoints = featuresOf('base.settlement.point')
    const missingPopulation = settlementPoints.filter(
      (feature) => feature.properties?.population === null,
    )
    expect(missingPopulation.length).toBeGreaterThan(0)
    for (const feature of missingPopulation) {
      expect(
        feature.properties?.populationYear,
        `${featureId(feature)} 人口缺失却有时点`,
      ).toBeNull()
    }

    const missingDepth = featuresOf('hazard.earthquake').filter(
      (feature) => feature.properties?.depthKm === null,
    )
    expect(missingDepth.length).toBeGreaterThan(0)
    for (const feature of missingDepth) {
      expect(feature.properties?.depthKm, `${featureId(feature)} 缺失深度被写成 0`).not.toBe(0)
    }
    for (const feature of featuresOf('hazard.earthquake')) {
      expect(typeof feature.properties?.magnitude, `${featureId(feature)} 震级应为数值`).toBe(
        'number',
      )
    }

    const lakeDataset = datasets.find((item) => item.id === 'demo-ds-glacial-lake')!
    expect(
      lakeDataset.fields.find((field) => field.key === 'lakeArea')?.unit,
      '单位未确认时必须为 null',
    ).toBeNull()
    expect(
      featuresOf('tnr.glacialLake').every(
        (feature) => typeof feature.properties?.lakeArea === 'number',
      ),
    ).toBe(true)
  })

  it('时间精度按记录原文推导，覆盖多种精度；缺日期时保留年份字段', () => {
    const observed = [...featuresOf('hazard.earthquake'), ...featuresOf('hazard.landslide')]
    const precisions = new Set(
      observed
        .map((feature) => feature.properties?.eventDate)
        .filter((value): value is string => typeof value === 'string')
        .map((value) => inferTimePrecision(value)),
    )
    expect(precisions.size, '示例数据应覆盖多种时间精度').toBeGreaterThan(2)
    for (const feature of observed) {
      if (feature.properties?.eventDate === null) {
        expect(feature.properties?.eventYear, `${featureId(feature)} 缺日期又缺年份`).not.toBeNull()
      }
      // 时间说明必须写在 timeNote，不得混入烈度/规模等属性说明
      const timeNote = feature.properties?.timeNote
      if (typeof timeNote === 'string') {
        expect(timeNote, `${featureId(feature)} 时间说明含数字`).not.toMatch(/[0-9]/)
      }
      for (const key of ['intensityNote', 'volumeNote'] as const) {
        const note = feature.properties?.[key]
        if (typeof note === 'string') {
          expect(note, `${featureId(feature)} 的 ${key} 混入了时间说明`).not.toContain('时间精度')
        }
      }
    }
  })
})

describe('示例数据包：成果数值一致性', () => {
  it('成果指标在包内留空，由前端从要素派生', () => {
    expect(results.length).toBe(3)
    for (const result of results) {
      expect(result.metrics, `${result.id} 不应在包内预先写死指标`).toEqual([])
      expect(result.files.length).toBeGreaterThan(0)
      for (const file of result.files) {
        if (!file.available) {
          expect(file.unavailableReason, `${result.id}/${file.id} 不可用但没有原因`).toBeTruthy()
        }
      }
    }
  })

  it('成果说明文字不写死计数，避免与派生统计对不上', () => {
    const texts = [
      results.map((result) => result.method).join(' '),
      ...results.flatMap((item) => item.qualityNotes),
    ]
    // 允许出现"2050/2100"这类情景名称，禁止的是手抄的计数（条/个/处/段/项/单位量）
    const countingPattern =
      /(?:\d+\s*(?:条|个|处|段|项|类|人|米|千米|公里|平方千米|秒))|(?:共\s*\d+)|(?:其中\s*\d+)/
    for (const text of texts) {
      expect(text, `说明文字写死了计数：${text}`).not.toMatch(countingPattern)
    }
    for (const feature of featuresOf('result.demo.impact')) {
      const method = feature.properties?.impactMethod
      if (typeof method === 'string') {
        expect(method, `影响范围说明写死了计数：${method}`).not.toMatch(countingPattern)
      }
    }
  })

  it('风险区成果：等级取值合法，缺指标记为“数据不足”，无几何记录单独标注', () => {
    const collection = featuresOf('result.demo.risk')
    const versions = new Set(collection.map((feature) => feature.properties?.classificationVersion))
    expect([...versions]).toEqual(['demo-risk-classification-v1'])

    for (const feature of collection) {
      const level = feature.properties?.riskLevel
      const hrgi = feature.properties?.hrgi
      expect(Object.keys(RISK_LEVEL_ORDER), featureId(feature)).toContain(level)
      if (level === 'insufficient') {
        expect(hrgi, `${featureId(feature)} 数据不足但仍有指数`).toBeNull()
        expect(feature.properties?.geometryNote, `${featureId(feature)} 缺少缺失说明`).toBeTruthy()
      } else {
        expect(typeof hrgi, `${featureId(feature)} 缺少指数`).toBe('number')
      }
      if (feature.geometry === null) {
        expect(
          feature.properties?.geometryNote,
          `${featureId(feature)} 无几何但未标注`,
        ).toBeTruthy()
      }
    }
  })

  it('情景图层：同情景单元在 2100 不低于 2050，取值限定在 0—1', () => {
    const build = (layerId: string) => {
      const map = new Map<string, number>()
      for (const feature of featuresOf(layerId)) {
        const key = feature.properties?.entityKey
        const value = feature.properties?.hrgi
        expect(typeof key, `${layerId} 缺少 entityKey`).toBe('string')
        expect(typeof value, `${layerId}/${String(key)} 缺少 hrgi`).toBe('number')
        map.set(String(key), Number(value))
      }
      return map
    }
    const year2050 = build('hazard.scenario2050')
    const year2100 = build('hazard.scenario2100')
    expect(year2050.size).toBeGreaterThan(0)
    const shared = [...year2050.keys()].filter((key) => year2100.has(key))
    expect(shared.length, '两个情景必须有可比单元').toBeGreaterThan(3)
    for (const key of shared) {
      const value = year2050.get(key)!
      expect(value).toBeGreaterThanOrEqual(0)
      expect(value).toBeLessThanOrEqual(1)
      expect(year2100.get(key)!, `情景单元 ${key} 的 2100 值低于 2050`).toBeGreaterThanOrEqual(
        value,
      )
      expect(year2100.get(key)!).toBeLessThanOrEqual(1)
    }
    // 只在一个情景登记过的单元允许存在，但必须在说明里写明“单年登记”，界面显示“未提供”而不补值
    const only2050 = [...year2050.keys()].filter((key) => !year2100.has(key))
    const only2100 = [...year2100.keys()].filter((key) => !year2050.has(key))
    expect(only2050.length, '示例数据应覆盖单年登记单元').toBeGreaterThan(0)
    expect(only2100.length, '示例数据应覆盖单年登记单元').toBeGreaterThan(0)
    for (const [layerId, keys] of [
      ['hazard.scenario2050', only2050],
      ['hazard.scenario2100', only2100],
    ] as const) {
      for (const key of keys) {
        const feature = featuresOf(layerId).find((item) => item.properties?.entityKey === key)!
        expect(
          String(feature.properties?.scenarioNote),
          `${layerId}/${key} 未说明单年登记`,
        ).toContain('只在')
      }
    }
    expect(layerById('hazard.scenario2050').availableTimes.map((item) => item.role)).toEqual([
      'scenario',
    ])
    expect(layerById('hazard.scenario2100').availableTimes[0]?.value).toBe('2100')
  })

  it('影响范围两两不重叠，避免同一对象被重复统计', () => {
    const impact = featuresOf('result.demo.impact')
    const boxes = impact.map((feature) => {
      const ring = outerRings(feature.geometry)[0] ?? []
      const lons = ring.map((position) => position[0]!)
      const lats = ring.map((position) => position[1]!)
      return {
        id: featureId(feature),
        minLon: Math.min(...lons),
        maxLon: Math.max(...lons),
        minLat: Math.min(...lats),
        maxLat: Math.max(...lats),
      }
    })
    for (let i = 0; i < boxes.length; i += 1) {
      for (let j = i + 1; j < boxes.length; j += 1) {
        const a = boxes[i]!
        const b = boxes[j]!
        const overlaps =
          a.minLon < b.maxLon && b.minLon < a.maxLon && a.minLat < b.maxLat && b.minLat < a.maxLat
        expect(overlaps, `${a.id} 与 ${b.id} 重叠`).toBe(false)
      }
    }
  })

  it('受影响对象按对象标识去重：记录数与实体数可复算', () => {
    const rings = impactRings()
    // 统计口径：点要素用其坐标，面要素用代表点（近似质心）判断是否落在影响范围内
    const locationOf = (feature: Feature): Position | null => {
      if (feature.geometry?.type === 'Point') return feature.geometry.coordinates
      return representativeLonLat(feature.geometry)
    }
    const matched: Array<{ ref: string; entityKey: string }> = []
    for (const layerId of ['base.settlement.point', 'base.settlement.polygon']) {
      for (const feature of featuresOf(layerId)) {
        const position = locationOf(feature)
        if (!position) continue
        const inside = rings.some(
          (ring) =>
            classifyPointInRing(position as [number, number], ring as [number, number][]) ===
            'inside',
        )
        if (inside) {
          matched.push({
            ref: `${layerId}/${featureId(feature)}`,
            entityKey: String(feature.properties?.entityKey ?? featureId(feature)),
          })
        }
      }
    }
    expect(matched.map((item) => item.ref).sort()).toEqual([
      'base.settlement.point/DEMO-SET-01',
      'base.settlement.point/DEMO-SET-02',
      'base.settlement.point/DEMO-SET-03',
      'base.settlement.polygon/DEMO-SETP-01',
      'base.settlement.polygon/DEMO-SETP-02',
      'base.settlement.polygon/DEMO-SETP-03',
    ])
    // 每个对象都有点、面两条记录，按对象标识去重后只应计一次
    expect(matched.length, '受影响记录数').toBe(6)
    expect(new Set(matched.map((item) => item.entityKey)).size, '受影响唯一实体数').toBe(3)

    // 点、面两种表达是同一对象，人口等属性必须一致，避免两套数值互相矛盾
    const pointsByKey = new Map(
      featuresOf('base.settlement.point').map((feature) => [
        String(feature.properties?.entityKey),
        feature.properties?.population ?? null,
      ]),
    )
    for (const feature of featuresOf('base.settlement.polygon')) {
      const key = String(feature.properties?.entityKey)
      if (!pointsByKey.has(key)) continue
      expect(feature.properties?.population ?? null, `${key} 点面人口不一致`).toBe(
        pointsByKey.get(key),
      )
    }
  })
})

describe('示例数据包：路线与道路', () => {
  it('可达路线的距离等于按几何折点累加的球面长度', () => {
    for (const route of routes) {
      if (route.status === 'reachable') {
        expect(route.geometry, `${route.id} 可达却无几何`).not.toBeNull()
        expect(route.distanceMeters, `${route.id} 缺少距离`).not.toBeNull()
        const length = polylineLengthMeters(
          (route.geometry as LineString).coordinates as [number, number][],
        )
        expect(
          Math.abs((route.distanceMeters as number) - length),
          `${route.id} 距离与几何不符`,
        ).toBeLessThan(1)
      }
    }
  })

  it('不可达路线不编造几何、距离与时间，并给出阻断路段', () => {
    const unreachable = routes.filter((route) => route.status === 'unreachable')
    expect(unreachable.length).toBeGreaterThan(0)
    for (const route of unreachable) {
      expect(route.geometry, `${route.id} 不可达却有几何`).toBeNull()
      expect(route.distanceMeters, `${route.id} 不可达却有距离`).toBeNull()
      expect(route.durationSeconds, `${route.id} 不可达却有通行时间`).toBeNull()
      expect(route.blockedFeatureRefs.length, `${route.id} 未登记阻断路段`).toBeGreaterThan(0)
      expect(route.resources, `${route.id} 无几何却给出资源距离`).toEqual([])
    }
  })

  it('未登记通行时间时保持 null 并说明原因，不按距离估算时间', () => {
    expect(
      routes.some((route) => route.status === 'reachable' && route.durationSeconds === null),
    ).toBe(true)
    for (const route of routes) {
      if (route.durationSeconds === null) {
        expect(route.durationSource, `${route.id} 未说明时间缺失原因`).toBeTruthy()
      }
    }
  })

  it('路线折点全部落在已登记道路上，不用直线冒充路线', () => {
    const roads = featuresOf('emg.road').filter(
      (feature): feature is Feature<LineString> => feature.geometry?.type === 'LineString',
    )
    for (const route of routes) {
      if (!route.geometry) continue
      const coordinates = (route.geometry as LineString).coordinates
      for (let index = 1; index < coordinates.length; index += 1) {
        const from = coordinates[index - 1]!
        const to = coordinates[index]!
        const middle: [number, number] = [(from[0]! + to[0]!) / 2, (from[1]! + to[1]!) / 2]
        const onRoad = roads.some((road) =>
          isPointOnPolyline(middle, road.geometry.coordinates as [number, number][], 1e-6),
        )
        expect(onRoad, `${route.id} 第 ${index} 段不在已登记道路上`).toBe(true)
      }
    }
  })

  it('路线资源距离与“设施点到路线”的最短球面距离一致', () => {
    for (const route of routes) {
      if (!route.geometry) continue
      const coordinates = (route.geometry as LineString).coordinates
      for (const resource of route.resources) {
        const target = findFeature(resource.ref.layerId, resource.ref.id)
        const point = (target.geometry as { type: 'Point'; coordinates: Position }).coordinates
        const registered = resource.distanceFromRouteMeters
        expect(registered, `${route.id} → ${resource.ref.id} 缺少资源距离`).not.toBeNull()
        const expected = distancePointToPolyline(point, coordinates)
        expect(
          Math.abs((registered as number) - expected),
          `${route.id} → ${resource.ref.id} 距离不符（登记 ${registered}，复算 ${expected}）`,
        ).toBeLessThan(1)
      }
    }
  })

  it('道路要素均为有效折线，阻断路段被显式标注且被路线引用', () => {
    const roads = featuresOf('emg.road')
    for (const road of roads) {
      const coordinates = (road.geometry as LineString | null)?.coordinates ?? []
      expect(coordinates.length, `${featureId(road)} 折点不足`).toBeGreaterThan(1)
      for (let index = 1; index < coordinates.length; index += 1) {
        const from = coordinates[index - 1] as [number, number]
        const to = coordinates[index] as [number, number]
        expect(haversineMeters(from, to), `${featureId(road)} 存在零长度段`).toBeGreaterThan(1)
      }
    }
    const blocked = roads.filter((road) => road.properties?.blocked === true)
    expect(blocked.length).toBeGreaterThan(0)
    const blockedRefs = routes.flatMap((route) => route.blockedFeatureRefs)
    expect(blockedRefs.length).toBeGreaterThan(0)
    for (const ref of blockedRefs) {
      expect(
        blocked.some((road) => featureId(road) === ref.id),
        `阻断引用 ${ref.id} 不存在`,
      ).toBe(true)
    }
  })
})

describe('示例数据包：只读身份与来源登记', () => {
  it('示例模式关闭全部写入与计算类能力，并逐条给出原因', () => {
    expect(capabilities.mode).toBe('mock')
    expect(capabilities.readLayers).toBe(true)
    expect(capabilities.attributeQuery).toBe(true)
    expect(capabilities.readResults).toBe(true)
    // 阶段3（D-032）：空间查询是只读能力，示例模式在本地小样本上真正执行，
    // 声明为可用并附方法与单位说明。写入与计算类能力仍全部关闭。
    expect(capabilities.spatialQuery).toBe(true)
    expect(capabilities.reasons.spatialQuery).toContain('米')
    expect(capabilities.routeRecompute).toBe(false)
    expect(capabilities.analysisSubmit).toBe(false)
    expect(capabilities.dataEdit).toBe(false)
    expect(capabilities.backupExecute).toBe(false)
    expect(capabilities.authEnabled).toBe(false)
    for (const key of [
      'spatialQuery',
      'routeRecompute',
      'analysisSubmit',
      'dataEdit',
      'backupExecute',
    ] as const) {
      expect(capabilities.reasons[key]?.length, `${key} 缺少原因`).toBeGreaterThan(0)
    }
  })

  it('导出格式受限且非空，不承诺无法生成的文件', () => {
    expect(capabilities.exportFormats.length).toBeGreaterThan(0)
    for (const format of capabilities.exportFormats) {
      expect(['csv', 'geojson']).toContain(format)
    }
  })

  it('导入日志的失败批次不把未登记条数写成 0', () => {
    expect(imports.some((item) => item.status === 'failed')).toBe(true)
    expect(imports.some((item) => item.status === 'succeeded')).toBe(true)
    for (const log of imports) {
      if (log.status === 'failed') {
        expect(log.sourceCount, `${log.id} 失败批次源条数`).toBeNull()
        expect(log.targetCount, `${log.id} 失败批次目标条数`).toBeNull()
      }
      if (log.startedAt && log.finishedAt) {
        expect(log.finishedAt >= log.startedAt, `${log.id} 时间顺序`).toBe(true)
      }
    }
  })

  it('来源登记逐条声明授权说明，未登记真实来源时保持 null 并注明示例', () => {
    expect(sources.length).toBeGreaterThan(2)
    for (const source of sources) {
      const license = source.licenseDescription
      expect(license, `${source.id} 未登记授权说明`).not.toBeNull()
      expect((license as string).length, source.id).toBeGreaterThan(0)
      if (source.organization === null) {
        expect(source.licenseDescription, source.id).toContain('示例')
      }
    }
  })

  it('范围登记表包含一个刻意无数据的范围，用于演示空结果', () => {
    expect(regions.length).toBeGreaterThan(1)
    const ids = regions.map((region) => region.id)
    expect(new Set(ids).size).toBe(ids.length)
    for (const region of regions) {
      expect(region.extent, `${region.id} 未登记范围`).not.toBeNull()
      const extent = region.extent as [number, number, number, number]
      expect(extent[0]).toBeLessThan(extent[2])
      expect(extent[1]).toBeLessThan(extent[3])
      if (region.parentId) expect(ids).toContain(region.parentId)
    }
    expect(regions.some((region) => region.id === 'demo-region-empty')).toBe(true)
  })
})

describe('示例数据包：来源与措辞', () => {
  const relativeFiles = [
    'manifest.json',
    'layers.json',
    'legends.json',
    'dictionaries.json',
    'datasets.json',
    'sources.json',
    'regions.json',
    'results.json',
    'routes.json',
    'imports.json',
    'capabilities.json',
    ...Object.values(manifest.files.features),
  ]

  it('所有文本中“实时预警”只以否定形式出现，情景成果不冒充实时能力', () => {
    for (const relativePath of relativeFiles) {
      const text = readFileSync(`${demoDir}${relativePath}`, 'utf8')
      let index = text.indexOf('实时预警')
      while (index >= 0) {
        const window = text.slice(Math.max(0, index - 12), index + 4)
        expect(/非|不是|不/.test(window), `${relativePath} 出现未否定的“实时预警”：${window}`).toBe(
          true,
        )
        index = text.indexOf('实时预警', index + 4)
      }
    }
  })

  it('数据层不暴露数据库原始字段名，原始名只作为 originalField 追溯值出现', () => {
    const snakePattern = /^[a-z][a-z0-9]*_[a-z0-9_]+$/
    for (const relativePath of relativeFiles) {
      const parsed: unknown = JSON.parse(readFileSync(`${demoDir}${relativePath}`, 'utf8'))
      const offenders: string[] = []
      const walk = (node: unknown, path: string, parentKey: string | null): void => {
        if (Array.isArray(node)) {
          node.forEach((item, index) => walk(item, `${path}[${index}]`, parentKey))
          return
        }
        if (node && typeof node === 'object') {
          for (const [key, child] of Object.entries(node)) {
            if (snakePattern.test(key)) offenders.push(`${path}.${key}（对象键）`)
            walk(child, `${path}.${key}`, key)
          }
          return
        }
        if (typeof node === 'string' && snakePattern.test(node) && parentKey !== 'originalField') {
          offenders.push(`${path}（字符串值）`)
        }
      }
      walk(parsed, relativePath, null)
      expect(offenders, `${relativePath} 出现疑似数据库字段名`).toEqual([])
    }
  })
})
