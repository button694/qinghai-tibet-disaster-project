import { describe, expect, it } from 'vitest'

import { createRepositories } from '@/repositories'
import type { JsonFetcher } from '@/repositories/json/loader'
import { RepositoryError } from '@/repositories/types'
import { createMapLayerService, dictionaryIdsOf } from '@/services/mapLayers'
import type { FeatureDetail, LayerDefinition } from '@/domain/types'
import { createDemoRepositories, createDiskFetcher, mockEnv } from './helpers/repository-fixtures'

/**
 * 阶段2 地图业务服务的单元测试。
 *
 * 覆盖四类必须成立的语义：
 * 1. 几何经 Repository 取回，数量与契约一致，且无几何记录不被丢弃（只是不上图）；
 * 2. 服务未接入的图层给出 `unavailable` 与数据包原因，**不算失败**；
 * 3. 读取失败给出 `failed` 与错误码，**不回退示例数据**，且不会污染缓存；
 * 4. 命中数超过单次渲染上限时如实标记 `truncated`，界面据此说明「未展示全部」。
 */

const repositories = createDemoRepositories()

async function layerById(id: string): Promise<LayerDefinition> {
  const envelope = await repositories.layers.listLayers()
  const layer = envelope.data.find((item) => item.id === id)
  if (!layer) throw new Error(`示例包缺少图层 ${id}`)
  return layer
}

/** 可在运行中切换失败的加载器：用于验证「失败即失败」与「失败后重试可恢复」。 */
function createFlakyFetcher(failWhen: string) {
  const base = createDiskFetcher()
  let failing = false
  const fetcher: JsonFetcher = async (filePath) => {
    if (failing && filePath.includes(failWhen)) {
      throw new RepositoryError({ code: 'NOT_FOUND', message: `模拟读取失败：${filePath}` })
    }
    return base(filePath)
  }
  return {
    fetcher,
    fail(value: boolean) {
      failing = value
    },
  }
}

describe('阶段2 地图服务：图层注册表', () => {
  it('listLayers 原样转发 Repository 结果（含信封 meta）', async () => {
    const service = createMapLayerService(repositories)
    const envelope = await service.listLayers()
    expect(envelope.data.length).toBeGreaterThan(0)
    expect(envelope.meta.mode).toBe('mock')
    expect(envelope.meta.snapshotId).toBe('demo-v1')
  })
})

describe('阶段2 地图服务：要素装载', () => {
  it('可渲染图层返回 ready，要素数与契约 total 一致且每条都带 ref', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('base.settlement.point')
    const result = await service.loadLayer(layer)
    expect(result.status).toBe('ready')
    expect(result.error).toBeNull()
    expect(result.matched).toBe(result.total)
    expect(result.serverTotal).toBe(result.total)
    expect(result.fetchedCount).toBe(result.total)
    expect(result.uniqueCount).toBe(result.matched)
    expect(result.complete).toBe(true)
    expect(result.truncated).toBe(false)
    expect(result.features.length).toBeGreaterThan(0)
    for (const feature of result.features) {
      expect(feature.ref.layerId, feature.ref.id).toBe(layer.id)
      expect(feature.title.length, feature.ref.id).toBeGreaterThan(0)
    }
  })

  it('无几何记录被保留在结果里（属性可查），不因缺几何被丢掉', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('result.demo.risk')
    const result = await service.loadLayer(layer)
    expect(result.status).toBe('ready')
    expect(result.features.some((feature) => feature.geometry === null)).toBe(true)
    expect(result.matched).toBe(result.total)
    expect(result.serverTotal).toBe(result.total)
    expect(result.complete).toBe(true)
  })

  it('服务未接入的图层返回 unavailable 并带上数据包原因，不计为失败', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('base.population')
    const result = await service.loadLayer(layer)
    expect(result.status).toBe('unavailable')
    expect(result.error).toBeNull()
    expect(result.features).toEqual([])
    const reason = layer.source.type === 'unavailable' ? layer.source.reason : ''
    expect(result.note).toBe(reason)
  })

  it('读取失败返回 failed 与错误码，不返回任何示例要素', async () => {
    const flaky = createFlakyFetcher('features/glacier')
    const failingRepositories = createRepositories(mockEnv, { jsonFetcher: flaky.fetcher })
    const service = createMapLayerService(failingRepositories)
    const layer = await layerById('tnr.glacier.polygon')

    flaky.fail(true)
    const failed = await service.loadLayer(layer)
    expect(failed.status).toBe('failed')
    expect(failed.features).toEqual([])
    expect(failed.total).toBe(0)
    expect(failed.error?.code).toBe('NOT_FOUND')
    expect(failed.error?.userMessage.length).toBeGreaterThan(0)
  })

  it('服务不可用类失败提供客户可理解的重试说明', async () => {
    const base = createDiskFetcher()
    const unavailableFetcher: JsonFetcher = async (filePath) => {
      if (filePath.includes('features/hospital')) {
        throw new RepositoryError({
          code: 'SERVICE_UNAVAILABLE',
          message: '模拟后端 503',
          httpStatus: 503,
          retryable: true,
        })
      }
      return base(filePath)
    }
    const service = createMapLayerService(
      createRepositories(mockEnv, { jsonFetcher: unavailableFetcher }),
    )
    const layer = await layerById('emg.hospital')
    const result = await service.loadLayer(layer)
    expect(result.status).toBe('failed')
    expect(result.features).toEqual([])
    expect(result.error?.code).toBe('SERVICE_UNAVAILABLE')
    expect(result.error?.userMessage).toContain('暂时无法显示')
    expect(result.error?.userMessage).not.toContain('示例')
  })

  it('失败后重试可恢复：失败结果不进入缓存', async () => {
    const flaky = createFlakyFetcher('features/glacier')
    const flakyRepositories = createRepositories(mockEnv, { jsonFetcher: flaky.fetcher })
    const service = createMapLayerService(flakyRepositories)
    const layer = await layerById('tnr.glacier.polygon')

    flaky.fail(true)
    expect((await service.loadLayer(layer)).status).toBe('failed')

    flaky.fail(false)
    const recovered = await service.loadLayer(layer)
    expect(recovered.status).toBe('ready')
    expect(recovered.features.length).toBeGreaterThan(0)
  })

  it('同一图层二次装载命中缓存，不重复请求', async () => {
    let calls = 0
    const base = createDiskFetcher()
    const counting: JsonFetcher = async (filePath) => {
      if (filePath.includes('features/hospital')) calls += 1
      return base(filePath)
    }
    const service = createMapLayerService(createRepositories(mockEnv, { jsonFetcher: counting }))
    const layer = await layerById('emg.hospital')
    await service.loadLayer(layer)
    await service.loadLayer(layer)
    expect(calls).toBe(1)
  })

  it('命中数超过单次渲染上限时标记 truncated 并给出「未展示全部」说明', async () => {
    const service = createMapLayerService(repositories, { maxFeatures: 3 })
    const layer = await layerById('hazard.landslide')
    const result = await service.loadLayer(layer)
    expect(result.status).toBe('ready')
    expect(result.features.length).toBe(3)
    expect(result.total).toBeGreaterThan(3)
    expect(result.truncated).toBe(true)
    expect(result.note).toContain('取回')
  })

  it('默认渲染上限遵守正式接口 pageSize=2000，并保留 total/matched/truncated', async () => {
    const calls: Array<{ page?: number; pageSize?: number }> = []
    const layer = await layerById('hazard.landslide')
    const feature = {
      ref: { layerId: layer.id, id: 'API-1' },
      title: '测试要素',
      geometry: null,
      properties: {},
    } as FeatureDetail
    const wrappedRepositories = {
      ...repositories,
      layers: {
        ...repositories.layers,
        listFeatures: async (
          _layerId: string,
          query?: Parameters<typeof repositories.layers.listFeatures>[1],
        ) => {
          calls.push(query ?? {})
          return {
            data: {
              items: [
                feature,
                { ...feature, ref: { ...feature.ref, id: 'API-2' } },
                { ...feature, ref: { ...feature.ref, id: 'API-3' } },
              ],
              total: 10,
              page: query?.page ?? 1,
              pageSize: query?.pageSize ?? 20,
            },
            meta: {
              mode: 'mock' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: 'test-request',
          }
        },
      },
    }
    const service = createMapLayerService(wrappedRepositories)
    const result = await service.loadLayer(layer)

    expect(calls[0]?.page).toBe(1)
    expect(calls[0]?.pageSize).toBe(2000)
    expect(result.features).toHaveLength(3)
    expect(result.total).toBe(10)
    expect(result.matched).toBe(3)
    expect(result.serverTotal).toBe(10)
    expect(result.fetchedCount).toBe(3)
    expect(result.uniqueCount).toBe(3)
    expect(result.renderedCount).toBe(0)
    expect(result.complete).toBe(false)
    expect(result.truncated).toBe(true)
    expect(result.note).toContain('3 / 10')
  })

  it('正式 API 点图层会自动合并全部分页，地图不受服务端单页上限限制', async () => {
    const layer: LayerDefinition = {
      id: 'api.settlement.point',
      label: '居民点',
      theme: 'base',
      datasetId: 'api.settlement.point',
      geometryType: 'Point',
      source: { type: 'geojson', url: '/features', outputCrs: 'EPSG:4326' },
      fields: [],
      defaultVisible: false,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'CGCS2000_Tibetan_Plateau_LCC',
    }
    const calls: number[] = []
    const feature = (id: number): FeatureDetail => ({
      ref: { layerId: layer.id, id: String(id) },
      title: `居民点 ${id}`,
      datasetId: layer.datasetId,
      geometry: { type: 'Point', coordinates: [90 + id / 1000, 30] },
      properties: {},
      relatedResultIds: [],
    })
    const apiRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async (_id: string, query?: { page?: number; pageSize?: number }) => {
          const page = query?.page ?? 1
          calls.push(page)
          const start = (page - 1) * 2000
          const count = page === 3 ? 200 : 2000
          return {
            data: {
              items: Array.from({ length: count }, (_, index) => feature(start + index + 1)),
              total: 4200,
              page,
              pageSize: 2000,
            },
            meta: {
              mode: 'api' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: 'test',
          }
        },
      },
    }
    const result = await createMapLayerService(apiRepositories).loadLayer(layer)
    expect(result.status).toBe('ready')
    expect(result.features).toHaveLength(4200)
    expect(result.total).toBe(4200)
    expect(result.serverTotal).toBe(4200)
    expect(result.fetchedCount).toBe(4200)
    expect(result.uniqueCount).toBe(4200)
    expect(result.renderedCount).toBe(4200)
    expect(result.complete).toBe(true)
    expect(result.truncated).toBe(false)
    expect(calls.sort((a, b) => a - b)).toEqual([1, 2, 3])
    expect(result.note).toContain('取回全部')
  })

  it('缺页/空页保留 serverTotal、标记不完整且不进入完整缓存', async () => {
    const layer = await layerById('hazard.landslide')
    const feature = (id: number): FeatureDetail => ({
      ref: { layerId: layer.id, id: String(id) },
      title: `测试点 ${id}`,
      datasetId: layer.datasetId,
      geometry: { type: 'Point', coordinates: [90 + id / 100, 30] },
      properties: {},
      relatedResultIds: [],
    })
    let calls = 0
    const apiRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async (_id: string, query?: { page?: number; pageSize?: number }) => {
          calls += 1
          const page = query?.page ?? 1
          const items = page === 1 ? [feature(1), feature(2)] : page === 2 ? [] : [feature(5)]
          return {
            data: { items, total: 5, page, pageSize: 2 },
            meta: {
              mode: 'api' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: `test-${calls}`,
          }
        },
      },
    }
    const service = createMapLayerService(apiRepositories, { maxFeatures: 2 })
    const result = await service.loadLayer(layer)
    expect(result.serverTotal).toBe(5)
    expect(result.fetchedCount).toBe(3)
    expect(result.uniqueCount).toBe(3)
    expect(result.renderedCount).toBe(3)
    expect(result.complete).toBe(false)
    expect(result.truncated).toBe(true)
    expect(result.note).toContain('3 / 5')

    await service.loadLayer(layer)
    expect(calls).toBe(6)
  })

  it('跨页重复源 ref 即使 fetchedCount 等于 serverTotal 也不完整且不缓存', async () => {
    const layer = await layerById('hazard.landslide')
    const feature = (id: number): FeatureDetail => ({
      ref: { layerId: layer.id, id: String(id) },
      title: `重复测试点 ${id}`,
      datasetId: layer.datasetId,
      geometry: { type: 'Point', coordinates: [90 + id / 100, 30] },
      properties: {},
      relatedResultIds: [],
    })
    let calls = 0
    const apiRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async (_id: string, query?: { page?: number; pageSize?: number }) => {
          calls += 1
          const page = query?.page ?? 1
          const items = page === 1 ? [feature(1), feature(2)] : [feature(2), feature(3)]
          return {
            data: { items, total: 4, page, pageSize: 2 },
            meta: {
              mode: 'api' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: `duplicate-${calls}`,
          }
        },
      },
    }
    const service = createMapLayerService(apiRepositories, { maxFeatures: 2 })
    const result = await service.loadLayer(layer)
    expect(result.fetchedCount).toBe(4)
    expect(result.serverTotal).toBe(4)
    expect(result.uniqueCount).toBe(3)
    expect(result.complete).toBe(false)
    expect(result.truncated).toBe(true)
    expect(result.note).toContain('重复源记录')

    await service.loadLayer(layer)
    expect(calls).toBe(4)
  })

  it('同页重复源 ref 也不完整，但不同 ref 相同 entityKey 仍是合法业务去重', async () => {
    const layer = await layerById('hazard.landslide')
    const feature = (id: string, entityKey?: string): FeatureDetail => ({
      ref: { layerId: layer.id, id },
      title: `同页测试点 ${id}`,
      datasetId: layer.datasetId,
      geometry: { type: 'Point', coordinates: [90, 30] },
      properties: {},
      entityKey,
      relatedResultIds: [],
    })
    const duplicateRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async () => ({
          data: {
            items: [feature('same-ref'), feature('same-ref')],
            total: 2,
            page: 1,
            pageSize: 2,
          },
          meta: {
            mode: 'api' as const,
            snapshotId: 'test',
            generatedAt: '2026-09-17T00:00:00Z',
            scopeLabel: 'test',
            boundaryVersion: 'test',
            datasetVersions: {},
          },
          requestId: 'same-page-duplicate',
        }),
      },
    }
    const duplicate = await createMapLayerService(duplicateRepositories, {
      maxFeatures: 2,
    }).loadLayer(layer)
    expect(duplicate.complete).toBe(false)
    expect(duplicate.truncated).toBe(true)
    expect(duplicate.note).toContain('同页或跨页')

    const legalAssociationRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async () => ({
          data: {
            items: [feature('source-1', 'entity-1'), feature('source-2', 'entity-1')],
            total: 2,
            page: 1,
            pageSize: 2,
          },
          meta: {
            mode: 'api' as const,
            snapshotId: 'test',
            generatedAt: '2026-09-17T00:00:00Z',
            scopeLabel: 'test',
            boundaryVersion: 'test',
            datasetVersions: {},
          },
          requestId: 'legal-entity-dedupe',
        }),
      },
    }
    const legal = await createMapLayerService(legalAssociationRepositories, {
      maxFeatures: 2,
    }).loadLayer(layer)
    expect(legal.complete).toBe(true)
    expect(legal.truncated).toBe(false)
    expect(legal.fetchedCount).toBe(2)
    expect(legal.uniqueCount).toBe(1)
  })

  it('线图层全量加载会为除首页外的每一页请求服务端几何简化，并标注 geometrySimplified', async () => {
    const layer: LayerDefinition = {
      id: 'api.road.line',
      label: '道路',
      theme: 'emg',
      datasetId: 'api.road.line',
      geometryType: 'LineString',
      source: { type: 'geojson', url: '/features', outputCrs: 'EPSG:4326' },
      fields: [],
      defaultVisible: false,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'CGCS2000_Tibetan_Plateau_LCC',
    }
    const simplifySeen: Array<number | undefined> = []
    const feature = (id: number): FeatureDetail => ({
      ref: { layerId: layer.id, id: String(id) },
      title: `道路 ${id}`,
      datasetId: layer.datasetId,
      geometry: {
        type: 'LineString',
        coordinates: [
          [90, 30],
          [91, 31],
        ],
      },
      properties: {},
      relatedResultIds: [],
    })
    const apiRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async (
          _id: string,
          query?: { page?: number; pageSize?: number; simplifyMeters?: number },
        ) => {
          const page = query?.page ?? 1
          simplifySeen.push(query?.simplifyMeters)
          const start = (page - 1) * 2000
          const count = page === 2 ? 500 : 2000
          return {
            data: {
              items: Array.from({ length: count }, (_, index) => feature(start + index + 1)),
              total: 2500,
              page,
              pageSize: 2000,
              // 真实后端行为：是否简化只取决于图层几何类型（页与页之间一致），不随页码变化。
              geometrySimplified: query?.simplifyMeters !== undefined,
              simplifyToleranceMeters: query?.simplifyMeters ?? null,
            },
            meta: {
              mode: 'api' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: 'test',
          }
        },
      },
    }
    const result = await createMapLayerService(apiRepositories).loadLayer(layer)
    expect(result.status).toBe('ready')
    expect(result.features).toHaveLength(2500)
    // 线图层每一页（含首页）都会带上渲染用简化容差；点图层完全不会（见下一组测试）。
    expect(simplifySeen[0]).toBe(150)
    expect(simplifySeen[1]).toBe(150)
    expect(result.geometrySimplified).toBe(true)
    expect(result.simplifyToleranceMeters).toBe(150)
  })

  it('onProgress 回调按已加载/全部匹配数递增，取消后返回 cancelled 而不是 failed', async () => {
    const layer: LayerDefinition = {
      id: 'api.progress.point',
      label: '进度测试点',
      theme: 'base',
      datasetId: 'api.progress.point',
      geometryType: 'Point',
      source: { type: 'geojson', url: '/features', outputCrs: 'EPSG:4326' },
      fields: [],
      defaultVisible: false,
      defaultOpacity: 1,
      availableTimes: [],
      legendId: '',
      queryable: true,
      exportFormats: [],
      sourceCrs: 'CGCS2000_Tibetan_Plateau_LCC',
    }
    const feature = (id: number): FeatureDetail => ({
      ref: { layerId: layer.id, id: String(id) },
      title: `点 ${id}`,
      datasetId: layer.datasetId,
      geometry: { type: 'Point', coordinates: [90, 30] },
      properties: {},
      relatedResultIds: [],
    })
    const progressCalls: Array<[number, number]> = []
    const simplifySeenForPoint: Array<number | undefined> = []
    const apiRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async (
          _id: string,
          query?: { page?: number; pageSize?: number; simplifyMeters?: number },
        ) => {
          const page = query?.page ?? 1
          simplifySeenForPoint.push(query?.simplifyMeters)
          const start = (page - 1) * 2000
          const count = page === 3 ? 200 : 2000
          return {
            data: {
              items: Array.from({ length: count }, (_, index) => feature(start + index + 1)),
              total: 4200,
              page,
              pageSize: 2000,
            },
            meta: {
              mode: 'api' as const,
              snapshotId: 'test',
              generatedAt: '2026-09-17T00:00:00Z',
              scopeLabel: 'test',
              boundaryVersion: 'test',
              datasetVersions: {},
            },
            requestId: 'test',
          }
        },
      },
    }
    const result = await createMapLayerService(apiRepositories).loadLayer(
      layer,
      undefined,
      (loaded, total) => progressCalls.push([loaded, total]),
    )
    expect(result.status).toBe('ready')
    expect(progressCalls.length).toBeGreaterThanOrEqual(2)
    expect(progressCalls[0]).toEqual([2000, 4200])
    expect(progressCalls[progressCalls.length - 1]).toEqual([4200, 4200])
    // 点图层没有可简化的折线/多边形几何：全部分页请求都不带 simplifyMeters。
    expect(simplifySeenForPoint.every((value) => value === undefined)).toBe(true)
    expect(result.geometrySimplified).toBe(false)

    // 取消：listFeatures 在被 abort 时抛出 AbortError，服务层必须区分「取消」与「失败」。
    const abortingRepositories = {
      ...repositories,
      mode: 'api' as const,
      layers: {
        ...repositories.layers,
        listFeatures: async () => {
          throw new DOMException('aborted', 'AbortError')
        },
      },
    }
    const cancelled = await createMapLayerService(abortingRepositories).loadLayer(layer)
    expect(cancelled.status).toBe('cancelled')
    expect(cancelled.error).toBeNull()
  })
})

describe('阶段2 地图服务：图例、数据集与代码字典', () => {
  it('图例按 legendId 读取成功', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('result.demo.risk')
    const result = await service.getLegend(layer.legendId)
    expect(result.note).toBeNull()
    expect(result.legend?.items.length).toBe(6)
    expect(result.legend?.noDataStyle.pattern).toBe('hatch')
  })

  it('图例缺失时返回 null 与失败说明，不返回空图例', async () => {
    const service = createMapLayerService(repositories)
    const result = await service.getLegend('legend.not-exist')
    expect(result.legend).toBeNull()
    expect(result.note).toContain('图例读取失败')
  })

  it('数据集元数据按 datasetId 读取成功', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('tnr.glacier.polygon')
    const result = await service.getDataset(layer.datasetId)
    expect(result.note).toBeNull()
    expect(result.dataset?.id).toBe(layer.datasetId)
  })

  it('数据集读取失败时返回 null 与说明', async () => {
    const service = createMapLayerService(repositories)
    const result = await service.getDataset('demo-ds-not-exist')
    expect(result.dataset).toBeNull()
    expect(result.note).toContain('数据集元数据读取失败')
  })

  it('代码字典按图层字段声明读取，可把 enum 代码解析为中文', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('hazard.landslide')
    const ids = dictionaryIdsOf(layer)
    expect(ids).toContain('dict.landslide-type')
    const result = await service.getDictionaries(layer)
    expect(result.notes).toEqual([])
    const items = result.items['dict.landslide-type'] ?? []
    expect(items.some((item) => item.code === 'slide' && item.label === '滑坡')).toBe(true)
  })

  it('字典读取失败只记录说明，不伪造标签', async () => {
    const base = createDiskFetcher()
    const failing: JsonFetcher = async (filePath) => {
      if (filePath.includes('dictionaries')) {
        throw new RepositoryError({ code: 'NOT_FOUND', message: '模拟字典缺失' })
      }
      return base(filePath)
    }
    const service = createMapLayerService(createRepositories(mockEnv, { jsonFetcher: failing }))
    const layer = await layerById('hazard.landslide')
    const result = await service.getDictionaries(layer)
    expect(result.items).toEqual({})
    expect(result.notes.length).toBeGreaterThan(0)
    expect(result.notes[0]).toContain('dict.landslide-type')
  })

  it('图层没有字典字段时返回空表且不报错', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('base.boundary')
    expect(dictionaryIdsOf(layer)).toEqual([])
    const result = await service.getDictionaries(layer)
    expect(result.items).toEqual({})
    expect(result.notes).toEqual([])
  })
})

describe('阶段2 地图服务：clear()', () => {
  it('clear 之后重新装载会重新走一遍服务逻辑（模式切换时清缓存）', async () => {
    const service = createMapLayerService(repositories)
    const layer = await layerById('emg.hospital')
    const first = await service.loadLayer(layer)
    const cached = await service.loadLayer(layer)
    // 未清缓存时返回同一个结果对象，说明确实命中了缓存。
    expect(cached).toBe(first)
    service.clear()
    const reloaded = await service.loadLayer(layer)
    expect(reloaded).not.toBe(first)
    expect(reloaded.status).toBe('ready')
    expect(reloaded.features.length).toBe(first.features.length)
  })
})
