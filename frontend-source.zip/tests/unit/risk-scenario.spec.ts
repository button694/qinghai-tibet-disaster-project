import { afterEach, beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import {
  computeMatchStats,
  distributionBins,
  formatScenarioValue,
  matchStatusOf,
  SCENARIO_BIN_COUNT,
  toScenarioRecord,
  valueInBinRange,
} from '@/domain/scenario'
import type { ScenarioDataset, ScenarioYear } from '@/domain/scenario'
import { createRiskScenarioService, setRiskScenarioService } from '@/services/riskScenarios'
import type { JsonFetcher } from '@/repositories/json/loader'
import { useRiskStore } from '@/stores/risk'

/* ------------------------------------------------------------------ *
 * 夹具
 * ------------------------------------------------------------------ */

function fixtureFeature(
  id: string,
  values: { hrgi?: number | null; exposure?: number | null; rrgi?: number | null },
  extra: { region?: string; basin?: string; geometry?: unknown } = {},
): Record<string, unknown> {
  // 显式传 null 保留为 null（缺失语义）；不传才用默认值。
  const pick = (value: number | null | undefined, fallback: number): number | null =>
    value === undefined ? fallback : value
  return {
    type: 'Feature',
    id,
    geometry:
      extra.geometry === undefined
        ? { type: 'Point', coordinates: [90 + (Number(id) % 10), 31 + (Number(id) % 8)] }
        : extra.geometry,
    properties: {
      glacier_id: id,
      hrgi: pick(values.hrgi, 0.5),
      exposure: pick(values.exposure, 0.4),
      rrgi: pick(values.rrgi, 0.3),
      region: extra.region ?? 'Pamir',
      basin: extra.basin ?? 'Tarim',
    },
  }
}

interface FixtureWorld {
  calls: { manifest: number; s2050: number; s2100: number }
  fail: { manifest: boolean; s2050: boolean; s2100: boolean }
  /** 清单中 2050 的登记条数（默认与夹具文件一致 = 2）。 */
  count2050?: number
  /** 2050 文件在返回前可注入额外/篡改记录（null 值、坏记录等）。 */
  mutate2050?: (features: Record<string, unknown>[]) => void
}

function fixtureFetcher(world: FixtureWorld): JsonFetcher {
  const base2050 = [fixtureFeature('1', { hrgi: 0.1 }), fixtureFeature('2', { hrgi: 0.95 })]
  const base2100 = [
    fixtureFeature('1', { hrgi: 0.2 }),
    fixtureFeature('2', { hrgi: 0.85 }),
    fixtureFeature('3', { hrgi: 0.0 }),
  ]
  return async (filePath) => {
    if (filePath.includes('manifest')) {
      world.calls.manifest += 1
      if (world.fail.manifest) throw new Error('manifest 下线（模拟读取失败）')
      return {
        schemaVersion: 1,
        sample: false,
        generatedAt: '2026-09-16T03:13:24.949000Z',
        sourceLabel: '夹具来源',
        sourceCrs: 'CGCS2000_Tibetan_Plateau_LCC',
        displayCrs: 'EPSG:4326',
        sqlServerVerified: false,
        vectors: [],
        rasters: [],
        exports: [
          {
            id: 'scenario2050',
            label: '2050 未来情景',
            file: 'scenario2050.json',
            sourceLayer: 'HAZ_SUSCEPTIBILITY_PT_2050',
            count: world.count2050 ?? base2050.length,
            sampled: false,
            sha256: 'a'.repeat(64),
          },
          {
            id: 'scenario2100',
            label: '2100 未来情景',
            file: 'scenario2100.json',
            sourceLayer: 'HAZ_SUSCEPTIBILITY_PT_2100',
            count: base2100.length,
            sampled: false,
            sha256: 'b'.repeat(64),
          },
        ],
      }
    }
    if (filePath.includes('scenario2050')) {
      world.calls.s2050 += 1
      if (world.fail.s2050) throw new Error('scenario2050 读取失败（模拟）')
      let features = base2050
      if (world.mutate2050) {
        features = structuredClone(base2050)
        world.mutate2050(features)
      }
      return { type: 'FeatureCollection', features }
    }
    if (filePath.includes('scenario2100')) {
      world.calls.s2100 += 1
      if (world.fail.s2100) throw new Error('scenario2100 读取失败（模拟）')
      return { type: 'FeatureCollection', features: base2100 }
    }
    throw new Error(`夹具未实现的路径：${filePath}`)
  }
}

function makeService(world: FixtureWorld) {
  return createRiskScenarioService(fixtureFetcher(world))
}

/** 直接构造数据集（不经过 fetch），供纯函数断言使用。 */
function datasetOf(
  year: ScenarioYear,
  ids: string[],
  valueOf: (id: string) => number | null = () => 0.5,
): ScenarioDataset {
  return {
    year,
    sourceLayer: `SRC_${year}`,
    label: `${year}`,
    sha256: 'c'.repeat(64),
    total: ids.length,
    skippedInvalid: 0,
    records: ids.map((id) => ({
      glacierId: id,
      longitude: 90,
      latitude: 31,
      values: { hrgi: valueOf(id), exposure: valueOf(id), rrgi: valueOf(id) },
      region: 'Pamir',
      basin: 'Tarim',
    })),
  }
}

/* ------------------------------------------------------------------ *
 * 领域层
 * ------------------------------------------------------------------ */

describe('阶段4 领域层：归一化与 null 语义', () => {
  it('toScenarioRecord：正常点、null 指标保留为 null、0 保留为 0', () => {
    const record = toScenarioRecord(fixtureFeature('7', { hrgi: null, exposure: 0, rrgi: null }))
    expect(record).not.toBeNull()
    expect(record?.glacierId).toBe('7')
    expect(record?.values.hrgi).toBeNull()
    expect(record?.values.exposure).toBe(0)
    expect(record?.values.rrgi).toBeNull()
    expect(record?.region).toBe('Pamir')
  })

  it('toScenarioRecord：缺 glacier_id、非点几何、非法坐标都返回 null（由调用方计数）', () => {
    const missingId = fixtureFeature('1', {})
    ;(missingId.properties as Record<string, unknown>).glacier_id = ''
    expect(toScenarioRecord(missingId)).toBeNull()
    expect(toScenarioRecord(fixtureFeature('2', {}, { geometry: { type: 'Polygon' } }))).toBeNull()
    const badCoord = fixtureFeature('3', {})
    ;(badCoord.geometry as { coordinates: unknown[] }).coordinates = ['x', 31]
    expect(toScenarioRecord(badCoord)).toBeNull()
  })

  it('formatScenarioValue：null → 未提供（不是 0）；0 → 0.000（真实为零）', () => {
    expect(formatScenarioValue(null)).toBe('未提供')
    expect(formatScenarioValue(0)).toBe('0.000')
    expect(formatScenarioValue(0.7385)).toBe('0.739')
  })
})

describe('阶段4 领域层：同对象匹配与分布分箱', () => {
  it('computeMatchStats：matched / 仅一期 分别统计', () => {
    const a = datasetOf(2050, ['A', 'B', 'C'])
    const b = datasetOf(2100, ['B', 'C', 'D', 'E'])
    expect(computeMatchStats(a, b)).toEqual({ matched: 2, onlyIn2050: 1, onlyIn2100: 2 })
  })

  it('matchStatusOf：两期未齐时不给结论（返回 null）', () => {
    expect(matchStatusOf('A', new Set(['A']), null)).toBeNull()
    expect(matchStatusOf('A', new Set(['A']), new Set())).toBe('only-2050')
    expect(matchStatusOf('A', new Set(['A']), new Set(['A']))).toBe('both')
    expect(matchStatusOf('A', new Set(), new Set(['A']))).toBe('only-2100')
  })

  it('distributionBins：0 进第一箱，1 进最后一箱，null 单列不进箱', () => {
    const records = [0, 0.05, 0.15, 0.999, 1, null, null].map((value, index) =>
      toScenarioRecord(
        fixtureFeature(String(index), {
          hrgi: value,
        }),
      ),
    )
    const valid = records.filter((item): item is NonNullable<typeof item> => item !== null)
    const { bins, nullCount } = distributionBins(valid, 'hrgi')
    expect(bins.length).toBe(SCENARIO_BIN_COUNT)
    expect(bins[0]?.count).toBe(2) // 0 与 0.05
    expect(bins[1]?.count).toBe(1) // 0.15
    expect(bins[SCENARIO_BIN_COUNT - 1]?.count).toBe(2) // 0.999 与 1（右端闭合）
    expect(nullCount).toBe(2)
    expect(bins.reduce((sum, bin) => sum + bin.count, 0)).toBe(valid.length - 2)
  })

  it('valueInBinRange：右端闭合；null 只有在无区间时才通过', () => {
    expect(valueInBinRange(0.3, [0.2, 0.3])).toBe(true)
    expect(valueInBinRange(0.31, [0.2, 0.3])).toBe(false)
    expect(valueInBinRange(null, [0, 1])).toBe(false)
    expect(valueInBinRange(null, null)).toBe(true)
  })
})

/* ------------------------------------------------------------------ *
 * 服务层（真实文件适配，夹具注入）
 * ------------------------------------------------------------------ */

describe('阶段4 服务：装载、校验、缓存与失败', () => {
  it('装载并归一化：字段、计数、skippedInvalid 如实', async () => {
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: false, s2050: false, s2100: false },
      count2050: 3,
      mutate2050: (features) => {
        // 一条真正无效的记录：无 glacier_id（归一化应跳过并计数，不静默丢弃）
        features.push({
          type: 'Feature',
          geometry: { type: 'Point', coordinates: [91, 31] },
          properties: {},
        })
      },
    }
    const service = makeService(world)
    const dataset = await service.loadScenario(2050)
    expect(dataset.year).toBe(2050)
    expect(dataset.sourceLayer).toBe('HAZ_SUSCEPTIBILITY_PT_2050')
    expect(dataset.records.length).toBe(2)
    expect(dataset.skippedInvalid).toBe(1)
    expect(dataset.records.every((record) => record.glacierId.length > 0)).toBe(true)
  })

  it('文件条数与清单不一致 → 报错，不返回半截数据', async () => {
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: false, s2050: false, s2100: false },
      // 清单仍登记 2 条，文件被注入第 3 条 → 数量校验失败
      mutate2050: (features) => {
        features.push(fixtureFeature('77', {}))
      },
    }
    const service = makeService(world)
    await expect(service.loadScenario(2050)).rejects.toThrow('数量与清单不一致')
  })

  it('清单读取失败 → 抛错；再次调用仍失败，不回退任何示例数据', async () => {
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: true, s2050: false, s2100: false },
    }
    const service = makeService(world)
    await expect(service.loadScenario(2050)).rejects.toThrow('模拟读取失败')
    await expect(service.loadScenario(2100)).rejects.toThrow('模拟读取失败')
    expect(world.calls.s2050).toBe(0)
    expect(world.calls.s2100).toBe(0)
  })

  it('同一年份装载走缓存；clear() 后重新请求', async () => {
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: false, s2050: false, s2100: false },
    }
    const service = makeService(world)
    await service.loadScenario(2050)
    await service.loadScenario(2050)
    expect(world.calls.s2050).toBe(1)
    service.clear()
    await service.loadScenario(2050)
    expect(world.calls.s2050).toBe(2)
  })
})

/* ------------------------------------------------------------------ *
 * store（Pinia）
 * ------------------------------------------------------------------ */

describe('阶段4 store：筛选、指标切换、失败与重试', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: false, s2050: false, s2100: false },
    }
    setRiskScenarioService(makeService(world))
  })

  afterEach(() => {
    setRiskScenarioService(null)
  })

  it('装载后状态 ready；对比模式两年都装载且匹配统计正确', async () => {
    const store = useRiskStore()
    store.setYearMode('compare')
    await store.load()
    expect(store.statusByYear[2050]).toBe('ready')
    expect(store.statusByYear[2100]).toBe('ready')
    expect(store.matchStats).toEqual({ matched: 2, onlyIn2050: 0, onlyIn2100: 1 })
  })

  it('区域/流域筛选改变 filteredRecords；清除筛选恢复', async () => {
    const store = useRiskStore()
    await store.load()
    const before = store.filteredRecords(2050).length
    expect(before).toBe(2)
    // 2100 里的对象 3 在夹具里是 Tarim 流域；2050 全部 Pamir/Tarim
    store.setBasin('Tarim')
    expect(store.filteredRecords(2050).length).toBe(before)
    store.setRegion('不存在的区域')
    expect(store.filteredRecords(2050).length).toBe(0)
    store.clearFilters()
    expect(store.filteredRecords(2050).length).toBe(before)
    expect(store.regionFilter).toBeNull()
    expect(store.basinFilter).toBeNull()
  })

  it('直方图区间筛选生效；切换指标后区间清空（旧区间对新指标无意义）', async () => {
    const store = useRiskStore()
    await store.load()
    store.setBinRange([0.0, 0.5])
    expect(store.filteredRecords(2050).map((record) => record.glacierId)).toEqual(['1'])
    store.setMetric('exposure')
    expect(store.binRange).toBeNull()
    expect(store.filteredRecords(2050).length).toBe(2)
  })

  it('装载失败：状态 failed、数据清空、不回退；重试成功后恢复', async () => {
    const world: FixtureWorld = {
      calls: { manifest: 0, s2050: 0, s2100: 0 },
      fail: { manifest: false, s2050: true, s2100: false },
    }
    setRiskScenarioService(makeService(world))
    const store = useRiskStore()
    await store.load()
    expect(store.statusByYear[2050]).toBe('failed')
    expect(store.statusByYear[2100]).toBe('idle') // 2100 不受影响（单图模式未装载）
    expect(store.errorByYear[2050]).toContain('模拟')
    expect(store.datasetOf(2050)).toBeNull()
    expect(store.filteredRecords(2050)).toEqual([])
    // 修复后重试
    world.fail.s2050 = false
    await store.retry()
    expect(store.statusByYear[2050]).toBe('ready')
    expect(store.datasetOf(2050)?.records.length).toBe(2)
  })

  it('选中对象：matchStatusOfId 与详情可用；未装载另一期时不给匹配结论', async () => {
    const store = useRiskStore()
    await store.load()
    // 单图模式只装了 2050，对象 3 只在 2100 → selectedRecord 为 null，详情不显示
    store.select('3')
    expect(store.selectedRecord).toBeNull()
    store.setYearMode('compare')
    await store.load()
    store.select('3')
    expect(store.selectedRecord?.glacierId).toBe('3')
    expect(store.matchStatusOfId('3')).toBe('only-2100')
    expect(store.matchStatusOfId('1')).toBe('both')
    store.select(null)
    expect(store.selectedRecord).toBeNull()
  })
})
