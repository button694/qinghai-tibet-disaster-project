/**
 * 阶段6：数据目录、成果中心与总览的服务层与 store 行为。
 *
 * 全部走生产代码路径（createRepositories → JSON 包适配器 → 服务层），
 * 夹具只替换 JsonFetcher（磁盘 / 故障注入）。
 */
import { beforeEach, describe, expect, it } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import {
  createCatalogWorkspaceService,
  setCatalogWorkspaceService,
} from '@/services/catalogWorkspace'
import { createResultsCenterService, setResultsCenterService } from '@/services/resultsCenter'
import { createDemoRepositories, mockEnv } from './helpers/repository-fixtures'
import type { JsonFetcher } from '@/repositories/json/loader'
import { createRepositories } from '@/repositories'
import { useCatalogStore } from '@/stores/catalog'
import { useResultsStore } from '@/stores/results'

function catalogService() {
  return createCatalogWorkspaceService(createDemoRepositories())
}

function resultsService() {
  return createResultsCenterService(createDemoRepositories())
}

beforeEach(() => {
  setActivePinia(createPinia())
  setCatalogWorkspaceService(null)
  setResultsCenterService(null)
})

describe('阶段6 数据目录：筛选、分页与四状态', () => {
  it('默认列表返回全部登记数据集；分页 total 与条目一致', async () => {
    const page1 = await catalogService().listDatasets({ page: 1, pageSize: 8 })
    expect(page1.total).toBe(20)
    expect(page1.items).toHaveLength(8)
    const page2 = await catalogService().listDatasets({ page: 2, pageSize: 8 })
    expect(page2.items).toHaveLength(8)
    const ids1 = new Set(page1.items.map((row) => row.dataset.id))
    for (const row of page2.items) expect(ids1.has(row.dataset.id)).toBe(false)
  })

  it('主题/类型/关键词筛选各自生效且可叠加；筛选后 total 一致', async () => {
    const service = catalogService()
    const raster = await service.listDatasets({ dataType: 'raster', page: 1, pageSize: 50 })
    expect(raster.total).toBeGreaterThan(0)
    expect(raster.items.every((row) => row.dataset.dataType === 'raster')).toBe(true)
    const tnr = await service.listDatasets({ theme: 'tnr', page: 1, pageSize: 50 })
    expect(tnr.items.every((row) => row.dataset.theme === 'tnr')).toBe(true)
    const both = await service.listDatasets({
      theme: 'tnr',
      dataType: 'raster',
      page: 1,
      pageSize: 50,
    })
    expect(both.items.length).toBeGreaterThan(0)
    expect(both.items.length).toBeLessThanOrEqual(tnr.items.length)
    const keyword = await service.listDatasets({ keyword: '降水', page: 1, pageSize: 50 })
    expect(keyword.items.some((row) => row.dataset.id === 'demo-ds-precip')).toBe(true)
  })

  it('四类状态分开：栅格「仅元数据 + 服务待接入 + 服务不可用」，矢量「已验证 + 可预览」', async () => {
    const service = catalogService()
    const all = await service.listDatasets({ page: 1, pageSize: 50 })
    const precip = all.items.find((row) => row.dataset.id === 'demo-ds-precip')
    expect(precip).toBeTruthy()
    expect(precip?.fileState).toBe('metadataOnly')
    expect(precip?.previewState).toBe('servicePending')
    expect(precip?.dataset.serviceAvailable).toBe(false)
    expect(precip?.note).toContain('栅格服务未接入')

    const glacier = all.items.find((row) => row.dataset.id === 'demo-ds-glacier')
    expect(glacier?.fileState).toBe('verified')
    expect(glacier?.previewState).toBe('previewable')
    expect(glacier?.dataset.serviceAvailable).toBe(true)
  })

  it('详情提供来源、关联图层与关联成果；不暴露本机绝对路径', async () => {
    const detail = await catalogService().getDatasetDetail('demo-ds-landslide')
    expect(detail.source?.id).toBeTruthy()
    expect(detail.relatedLayers.map((layer) => layer.id)).toContain('hazard.landslide')
    expect(detail.relatedResults.length).toBeGreaterThan(0)
    const serialized = JSON.stringify(detail)
    expect(serialized).not.toMatch(/[A-Za-z]:\\/)
    expect(serialized).not.toContain('/mnt/')
  })
})

describe('阶段6 年度降水浏览（availableTimes 驱动）', () => {
  it('年份列表由 availableTimes 派生：2001—2023 共 23 个，首尾正确', async () => {
    const detail = await catalogService().getDatasetDetail('demo-ds-precip')
    expect(detail.precipYears).toHaveLength(23)
    expect(detail.precipYears[0]).toBe('2001')
    expect(detail.precipYears[22]).toBe('2023')
    const sorted = [...detail.precipYears].sort()
    expect(detail.precipYears).toEqual(sorted)
  })

  it('非栅格数据集不提供降水分册年份', async () => {
    const detail = await catalogService().getDatasetDetail('demo-ds-glacier')
    expect(detail.precipYears).toEqual([])
  })
})

describe('阶段6 成果中心', () => {
  it('列表可按类型与状态筛选', async () => {
    const service = resultsService()
    const all = await service.listResults({ page: 1, pageSize: 50 })
    expect(all).toHaveLength(3)
    const risk = await service.listResults({ kind: 'risk', page: 1, pageSize: 50 })
    expect(risk).toHaveLength(1)
    expect(risk[0]?.id).toBe('result.demo.risk')
    const published = await service.listResults({ status: 'published', page: 1, pageSize: 50 })
    expect(published).toHaveLength(3)
  })

  it('详情包含要素、方法、输入、文件；文件只有 available 且有 url 才可下载', async () => {
    const detail = await resultsService().getResultDetail('result.demo.risk')
    expect(detail.features.length).toBeGreaterThan(0)
    expect(detail.extent).not.toBeNull()
    expect(detail.result.method).toBeTruthy()
    expect(detail.inputLabels.length).toBeGreaterThan(0)
    expect(detail.inputLabels.every((input) => input.name !== null)).toBe(true)

    const available = detail.result.files.filter((file) => file.available)
    expect(available.length).toBeGreaterThan(0)
    for (const file of available) {
      // 示例包登记的可用文件必须给出真实存在的包内地址
      expect(file.url, file.id).toBeTruthy()
      expect(file.url).not.toMatch(/[A-Za-z]:\\/)
      expect(file.url, file.id).toMatch(/^\/demo\/(?:files|features)\//)
    }
    const unavailable = detail.result.files.filter((file) => !file.available)
    expect(unavailable.length).toBeGreaterThan(0)
    for (const file of unavailable) {
      expect(file.unavailableReason, file.id).toBeTruthy()
      expect(file.url).toBeUndefined()
    }
  })

  it('成果详情深链接：任意 resultId 刷新装载（store，注入示例数据层）', async () => {
    setResultsCenterService(createResultsCenterService(createDemoRepositories()))
    const store = useResultsStore()
    await store.loadDetail('result.demo.route')
    expect(store.detailStatus).toBe('ready')
    expect(store.detail?.result.id).toBe('result.demo.route')
    expect(store.detail?.features.length).toBeGreaterThan(0)
    setResultsCenterService(null)
  })
})

describe('阶段6 总览与明细一致', () => {
  it('总览指标与风险分布、成果明细可对账', async () => {
    const data = (await createDemoRepositories().overview.getOverview()).data
    // 风险分布计数之和 = 已登记风险区对象数（同一批要素派生）
    const distributionSum = data.riskDistribution.reduce((sum, item) => sum + item.count, 0)
    const zoneCount = data.metrics.find((metric) => metric.key === 'riskZoneCount')
    expect(zoneCount?.value).toBe(distributionSum)
    // 重点对象不超过 3 个，且每个都有指标口径
    expect(data.keyFeatures.length).toBeLessThanOrEqual(3)
    for (const feature of data.keyFeatures) {
      expect(feature.metric).not.toBeNull()
      expect(feature.ref.layerId).toBeTruthy()
    }
    // 专题入口与成果中心同一份已发布成果
    expect(data.currentResults.every((result) => result.status === 'published')).toBe(true)
    // 快照时间不是“实时监测”
    expect(data.snapshotTime?.role).toBe('generated')
  })
})

describe('阶段6 API 失败不回退示例数据', () => {
  it('目录/成果/总览读取失败时抛错，不返回任何替代数据', async () => {
    const failingFetcher: JsonFetcher = async () => {
      throw new Error('数据包读取失败（模拟）')
    }
    const repos = createRepositories(mockEnv, { jsonFetcher: failingFetcher })
    await expect(
      createCatalogWorkspaceService(repos).listDatasets({ page: 1, pageSize: 10 }),
    ).rejects.toThrow()
    await expect(
      createCatalogWorkspaceService(repos).getDatasetDetail('demo-ds-glacier'),
    ).rejects.toThrow()
    await expect(
      createResultsCenterService(repos).getResultDetail('result.demo.risk'),
    ).rejects.toThrow()
    await expect(repos.overview.getOverview()).rejects.toThrow()
  })

  it('store 列表失败进入 failed 状态且不渲染任何行', async () => {
    setCatalogWorkspaceService({
      listDatasets: async () => {
        throw new Error('目录服务不可用（模拟）')
      },
      getDatasetDetail: async () => {
        throw new Error('目录服务不可用（模拟）')
      },
      listImports: async () => {
        throw new Error('目录服务不可用（模拟）')
      },
    })
    const store = useCatalogStore()
    await store.loadList(1)
    expect(store.listStatus).toBe('failed')
    expect(store.rows).toEqual([])
    expect(store.total).toBe(0)
    await store.loadDetail('demo-ds-glacier')
    expect(store.detailStatus).toBe('failed')
    expect(store.detail).toBeNull()
    setCatalogWorkspaceService(null)
  })
})
