/**
 * 单测共用的数据层装配：把 `public/demo` 当作 data 包根目录，从磁盘直接读取。
 *
 * 这样契约测试完全不依赖浏览器与 dev server，同时走的仍是**生产代码路径**
 * （`createRepositories` → JSON 包适配器），不是另写一套测试替身。
 */
import { readFileSync } from 'node:fs'
import { resolve } from 'node:path'

import type { AppEnv } from '@/config/env'
import { createRepositories } from '@/repositories'
import type { JsonFetcher } from '@/repositories/json/loader'
import { RepositoryError, type Repositories } from '@/repositories/types'

/** vitest 的 root 是工程根目录，因此相对 cwd 即可定位到 public/demo。 */
export const DEMO_DIR = resolve(process.cwd(), 'public/demo')

export function readDemoJson<T>(relativePath: string): T {
  return JSON.parse(readFileSync(resolve(DEMO_DIR, relativePath), 'utf8')) as T
}

/** 从磁盘读取数据包；文件不存在时按 `NOT_FOUND` 报错，与 fetch 版本的语义保持一致。 */
export function createDiskFetcher(baseDir: string = DEMO_DIR): JsonFetcher {
  return async (filePath: string): Promise<unknown> => {
    try {
      return JSON.parse(readFileSync(resolve(baseDir, filePath), 'utf8')) as unknown
    } catch (error) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `测试数据文件不存在：${filePath}`,
        details: { filePath, baseDir },
        cause: error,
      })
    }
  }
}

/** 一个永远返回「文件不存在」的加载器，用于验证快照包缺失的行为。 */
export const missingPackageFetcher: JsonFetcher = async (filePath: string) => {
  throw new RepositoryError({
    code: 'NOT_FOUND',
    message: `快照包中不存在 ${filePath}`,
    details: { filePath },
  })
}

export const mockEnv: AppEnv = {
  dataMode: 'mock',
  apiBaseUrl: '/api/v1',
  defaultRoute: '/overview',
  demoBaseUrl: '/demo/',
  snapshotBaseUrl: '/snapshot/',
}

export const snapshotEnv: AppEnv = { ...mockEnv, dataMode: 'snapshot' }

export const apiEnv: AppEnv = { ...mockEnv, dataMode: 'api' }

/** 示例数据模式下的完整数据层（读 `public/demo`）。 */
export function createDemoRepositories(env: AppEnv = mockEnv): Repositories {
  return createRepositories(env, { jsonFetcher: createDiskFetcher() })
}
