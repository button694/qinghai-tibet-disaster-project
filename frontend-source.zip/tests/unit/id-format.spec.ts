import { afterEach, describe, expect, it, vi } from 'vitest'
import { featureKey, formatId } from '@/domain/format'

/**
 * ID 保真与跨表同 ID（03 §4 第 7 条）。
 *
 * 背景：SQL Server 的 `bigint` 一旦经 JS `Number` 转换，超出 `Number.MAX_SAFE_INTEGER`
 * 就会静默丢精度（02 §2.1、D-019）。因此契约要求所有标识符一律字符串，
 * 且跨表相同 ID 不视为同一对象，全局对象键固定为 `layerId:id`（02 §2.2）。
 */

afterEach(() => vi.restoreAllMocks())

describe('formatId：ID 字符串保真', () => {
  it('bigint 直接转字符串，不经 Number，超出安全整数范围也不丢精度', () => {
    const beyondSafe = 9223372036854775807n
    expect(formatId(beyondSafe)).toBe('9223372036854775807')
    // 若先经过 Number 再转字符串，末位会被舍入，两者不可能相等。
    expect(formatId(beyondSafe)).not.toBe(String(Number(beyondSafe)))
  })

  it('安全整数范围内的 number 保留原值，包括 0', () => {
    expect(formatId(1024)).toBe('1024')
    expect(formatId(0)).toBe('0')
  })

  it('number 超出安全整数范围时告警，但仍返回字符串而不抛错', () => {
    const warn = vi.spyOn(console, 'warn').mockImplementation(() => {})
    const unsafe = 9007199254740992 // 2^53，已超出 Number.MAX_SAFE_INTEGER
    expect(Number.isSafeInteger(unsafe)).toBe(false)
    expect(formatId(unsafe)).toBe('9007199254740992')
    expect(warn).toHaveBeenCalledTimes(1)
  })

  it('字符串 ID 原样保留并去除首尾空白，不做数值解析', () => {
    expect(formatId('  GB-350000  ')).toBe('GB-350000')
    expect(formatId('007')).toBe('007')
  })

  it('null、undefined 与空字符串都表示未知，返回 null 而不是 "0" 或空字符串', () => {
    expect(formatId(null)).toBeNull()
    expect(formatId(undefined)).toBeNull()
    expect(formatId('')).toBeNull()
    expect(formatId('   ')).toBeNull()
  })
})

describe('featureKey：跨表同 ID 不视为同一对象', () => {
  it('相同 ID 落在不同图层时得到不同全局键', () => {
    expect(featureKey('landslide', '1')).not.toBe(featureKey('glacier', '1'))
  })

  it('同一图层同一 ID 得到相同键，可作为去重依据', () => {
    expect(featureKey('landslide', '1')).toBe(featureKey('landslide', '1'))
  })

  it('键格式固定为 layerId:id，便于追溯对象归属', () => {
    expect(featureKey('landslide', '1')).toBe('landslide:1')
  })
})
