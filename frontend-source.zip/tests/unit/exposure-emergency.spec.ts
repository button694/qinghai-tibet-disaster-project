/**
 * 阶段5：暴露度与应急保障的服务层与 store 行为。
 *
 * 全部走生产代码路径（createRepositories → JSON 包适配器 → 服务层），
 * 夹具只替换 JsonFetcher（磁盘 / 故障注入）。
 */
import { beforeEach, describe, expect, it, vi } from 'vitest'
import { createPinia, setActivePinia } from 'pinia'

import { featureKey } from '@/domain/format'
import {
  createEmergencyWorkspaceService,
  setEmergencyWorkspaceService,
} from '@/services/emergencyWorkspace'
import {
  createExposureWorkspaceService,
  setExposureWorkspaceService,
} from '@/services/exposureWorkspace'
import { createDemoRepositories, createDiskFetcher, mockEnv } from './helpers/repository-fixtures'
import type { JsonFetcher } from '@/repositories/json/loader'
import type { RequestOptions } from '@/repositories/types'
import { createRepositories } from '@/repositories'
import { RepositoryError } from '@/repositories/types'
import { useEmergencyStore } from '@/stores/emergency'
import { useExposureStore } from '@/stores/exposure'

function demoService() {
  return createExposureWorkspaceService(createDemoRepositories())
}

function demoEmergencyService() {
  return createEmergencyWorkspaceService(createDemoRepositories())
}

describe('阶段5 暴露统计（已存派生口径）', () => {
  it('摘要给出人口年份、去重规则、口径与真实关联的危险源', async () => {
    const summary = await demoService().getExposureSummary('result.demo.impact')
    expect(summary.resultId).toBe('result.demo.impact')
    expect(summary.impactLayerId).toBe('result.demo.impact')
    // 去重规则必须写明依据的业务标识（entityKey），不许含糊
    expect(summary.deduplicationRule).toContain('entityKey')
    expect(summary.scopeMethod).toContain('已存影响范围')
    // 记录数与去重后对象数分开给出
    expect(summary.matchedRecordCount).toBeGreaterThanOrEqual(summary.uniqueEntityCount)
    expect(summary.matchedRecordCount).toBeGreaterThan(0)
    // 人口：人口密度栅格服务未接入 → notProvided，且值必须是 null（不是 0）
    const population = summary.metrics.find((metric) => metric.key === 'population')
    expect(population).toBeTruthy()
    expect(population?.status).toBe('notProvided')
    expect(population?.value).toBeNull()
    // 道路长度：球面裁剪累加，单位米
    const road = summary.metrics.find((metric) => metric.key === 'affectedRoadLength')
    expect(road?.unit).toBe('米')
    // 影响范围对应 3 个不同危险源（DEMO-LS-02/13/12）：摘要按口径不合并为单一编号，
    // hazardRef 为 null 并在 note 中说明；具体对象的来源上下文由深链接 hazard 参数承载。
    expect(summary.hazardRef).toBeNull()
    expect(summary.note).toContain('多个灾害对象')
    // 真实关联验证：影响范围登记的 hazardRefId 必须能在危险源图层里找到同 ID 对象
    //（不是空间接近推算出来的）。
    const areas = await demoService().listImpactAreas('result.demo.impact')
    const hazardIds = new Set(
      (await demoService().listImpactAreas('hazard.landslide')).map((item) => item.ref.id),
    )
    const refs = areas.map((area) => String(area.properties.hazardRefId ?? ''))
    expect(refs.length).toBeGreaterThan(0)
    for (const ref of refs) expect(hazardIds.has(ref), ref).toBe(true)
  })

  it('类别计数与受影响清单分页口径一致；分页不改变总数', async () => {
    const service = demoService()
    const summary = await service.getExposureSummary('result.demo.impact')
    const categorySum = summary.affectedCategories.reduce((sum, item) => sum + item.count, 0)
    const page1 = await service.listAffectedFeatures('result.demo.impact', {
      page: 1,
      pageSize: 2,
    })
    const page2 = await service.listAffectedFeatures('result.demo.impact', {
      page: 2,
      pageSize: 2,
    })
    expect(page1.total).toBe(categorySum)
    expect(page2.total).toBe(page1.total)
    expect(page1.items).toHaveLength(2)
    // 页与页之间不重复（对象键唯一）
    const keys1 = new Set(page1.items.map((item) => featureKey(item.ref.layerId, item.ref.id)))
    for (const item of page2.items) {
      expect(keys1.has(featureKey(item.ref.layerId, item.ref.id))).toBe(false)
    }
  })

  it('类别筛选只保留该图层记录；筛选后 total 与摘要该类计数一致', async () => {
    const service = demoService()
    const summary = await service.getExposureSummary('result.demo.impact')
    const settlement = summary.affectedCategories.find((item) => item.count > 0)
    expect(settlement).toBeTruthy()
    const filtered = await service.listAffectedFeatures('result.demo.impact', {
      category: settlement?.key,
      page: 1,
      pageSize: 100,
    })
    expect(filtered.total).toBe(settlement?.count)
    expect(filtered.items.every((item) => item.ref.layerId === settlement?.key)).toBe(true)
  })

  it('受影响对象里人口为 null 的记录原样保留 null（对象清单不补 0）', async () => {
    const service = demoService()
    const page = await service.listAffectedFeatures('result.demo.impact', {
      page: 1,
      pageSize: 100,
    })
    const withPopulation = page.items.filter((item) => 'population' in item.properties)
    expect(withPopulation.length).toBeGreaterThan(0)
    for (const item of withPopulation) {
      const value = item.properties.population
      if (value !== null) expect(typeof value).toBe('number')
    }
  })
})

describe('阶段5 应急路线（已存成果，只读）', () => {
  it('方案清单：A 主方案、B 备选、C 不可达；无 routeRecompute 时全部只读', async () => {
    const service = demoEmergencyService()
    const routes = await service.listRoutes('result.demo.route')
    expect(routes.map((route) => route.id)).toEqual([
      'DEMO-ROUTE-A',
      'DEMO-ROUTE-B',
      'DEMO-ROUTE-C',
    ])
    expect(routes[0]?.role).toBe('primary')
    expect(routes[1]?.role).toBe('alternative')
    expect(routes[2]?.status).toBe('unreachable')
  })

  it('可达路线：距离与几何来自已存成果；时间为 null 时说明原因（不按速度估算）', async () => {
    const detail = await demoEmergencyService().getRoute('DEMO-ROUTE-A')
    expect(detail.geometry?.type).toBe('LineString')
    expect(detail.distanceMeters).toBeGreaterThan(0)
    expect(detail.distanceSource).toContain('已存成果')
    expect(detail.durationSeconds).toBeNull()
    expect(detail.durationSource).toContain('null')
    expect(detail.networkVersion).toBe('demo-road-network-v1')
  })

  it('不可达路线：几何为 null、距离为 null、有阻断引用；绝不造直线或耗时', async () => {
    const detail = await demoEmergencyService().getRoute('DEMO-ROUTE-C')
    expect(detail.geometry).toBeNull()
    expect(detail.distanceMeters).toBeNull()
    expect(detail.durationSeconds).toBeNull()
    expect(detail.blockedFeatureRefs).toEqual([{ layerId: 'emg.road', id: 'DEMO-ROAD-02' }])
    expect(detail.distanceSource).toContain('不可达')
  })

  it('风险路段是成果的真实引用（result.demo.impact），不是前端推测', async () => {
    const detail = await demoEmergencyService().getRoute('DEMO-ROUTE-B')
    expect(detail.riskSegments.length).toBeGreaterThan(0)
    for (const segment of detail.riskSegments) {
      expect(segment.ref?.layerId).toBe('result.demo.impact')
    }
  })
})

describe('阶段5 store 行为（上下文与切换）', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    setExposureWorkspaceService(null)
    setEmergencyWorkspaceService(null)
  })

  it('暴露 store：深链接进入、类别筛选回第 1 页、清除恢复', async () => {
    setExposureWorkspaceService(demoService())
    const store = useExposureStore()
    await store.initFromQuery({
      resultId: 'result.demo.impact',
      hazard: 'hazard.landslide:DEMO-LS-02',
    })
    expect(store.isReady).toBe(true)
    expect(store.entryHazardRef).toEqual({ layerId: 'hazard.landslide', id: 'DEMO-LS-02' })
    const allTotal = store.affectedTotal
    expect(allTotal).toBeGreaterThan(0)
    const category = store.categories.find((item) => item.count > 0)
    if (category !== undefined) {
      store.setCategory(category.key)
      await vi.waitUntil(() => store.affectedStatus === 'ready' && store.page === 1)
      expect(store.affectedTotal).toBe(category.count)
    }
    store.clearFilters()
    await vi.waitUntil(() => store.affectedStatus === 'ready')
    expect(store.category).toBeNull()
    expect(store.affectedTotal).toBe(allTotal)
  })

  it('应急 store：方案切换先清空旧详情；深链接 routeId 直接选中', async () => {
    setEmergencyWorkspaceService(demoEmergencyService())
    const store = useEmergencyStore()
    await store.initFromQuery({ resultId: 'result.demo.route' })
    expect(store.routeDetail?.id).toBe('DEMO-ROUTE-A')
    // 切换到 B：旧详情（A）必须先被清空——selectRoute 内部同步置 null
    const switchPromise = store.selectRoute('DEMO-ROUTE-B')
    expect(store.routeDetail).toBeNull()
    await switchPromise
    expect(store.routeDetail?.id).toBe('DEMO-ROUTE-B')
    // 深链接直达 C
    await store.initFromQuery({ resultId: 'result.demo.route', routeId: 'DEMO-ROUTE-C' })
    expect(store.routeDetail?.id).toBe('DEMO-ROUTE-C')
    expect(store.routeDetail?.geometry).toBeNull()
    // 阻断点要素经真实关联取回（emg.road/DEMO-ROAD-02）
    expect(store.markedFeatures.map((item) => item.ref.id)).toContain('DEMO-ROAD-02')
  })

  it('应急 store：深链接先读取 routeId，再按该路线的危险源分组加载，不静默换成首条', async () => {
    const base = demoEmergencyService()
    const routeA = await base.getRoute('DEMO-ROUTE-A')
    const routeB = await base.getRoute('DEMO-ROUTE-B')
    const groupedA = { ...routeA, hazardPointId: 'HZ-DEMO-001' }
    const groupedB = { ...routeB, hazardPointId: 'HZ-DEMO-002' }
    const service = {
      ...base,
      getRoute: vi.fn(async (routeId: string) =>
        routeId === 'DEMO-ROUTE-B' ? groupedB : groupedA,
      ),
      listRoutes: vi.fn(
        async (_resultId: string, _options?: RequestOptions, hazardPointId?: string | null) =>
          hazardPointId === 'HZ-DEMO-002' ? [groupedB] : [groupedA],
      ),
    }
    setEmergencyWorkspaceService(service)
    const store = useEmergencyStore()

    await store.initFromQuery({ resultId: 'result.demo.route', routeId: 'DEMO-ROUTE-B' })

    expect(store.routes.map((route) => route.id)).toEqual(['DEMO-ROUTE-B'])
    expect(store.routeDetail?.id).toBe('DEMO-ROUTE-B')
    expect(service.listRoutes).toHaveBeenCalledWith('result.demo.route', undefined, 'HZ-DEMO-002')
  })

  it('应急 store：不存在的深链接路线保留 NOT_FOUND，不回退到默认成果或第一条路线', async () => {
    const base = demoEmergencyService()
    const service = {
      ...base,
      getRoute: vi.fn(async () => {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: '未找到指定路线。',
          httpStatus: 404,
        })
      }),
    }
    setEmergencyWorkspaceService(service)
    const store = useEmergencyStore()

    await store.initFromQuery({ resultId: 'result.demo.route', routeId: 'DEMO-ROUTE-MISSING' })

    expect(store.listStatus).toBe('failed')
    expect(store.listError?.code).toBe('NOT_FOUND')
    expect(store.routes).toEqual([])
    expect(store.routeDetail).toBeNull()
  })
})

describe('阶段5 失败处理（不回退示例数据）', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
    setExposureWorkspaceService(null)
    setEmergencyWorkspaceService(null)
  })

  it('文件读取失败时抛错，服务不返回任何替代数据', async () => {
    const failingFetcher: JsonFetcher = async () => {
      throw new Error('results.json 读取失败（模拟）')
    }
    const service = createExposureWorkspaceService(
      createRepositories(mockEnv, { jsonFetcher: failingFetcher }),
    )
    // 包适配器会把底层错误包装为「读取 manifest.json 失败」；语义要点是拒绝而不是回退。
    await expect(service.listExposureResults()).rejects.toThrow(/失败/)
    await expect(service.getExposureSummary('result.demo.impact')).rejects.toThrow(/失败/)
  })

  it('暴露 store 失败后可重试：恢复磁盘读取即成功', async () => {
    let fail = true
    const flaky: JsonFetcher = async (filePath) => {
      if (fail) throw new Error('results.json 读取失败（模拟）')
      return createDiskFetcher()(filePath)
    }
    setExposureWorkspaceService(
      createExposureWorkspaceService(createRepositories(mockEnv, { jsonFetcher: flaky })),
    )
    const store = useExposureStore()
    await store.initFromQuery({})
    // 清单失败 → 无法选结果 → 摘要从未尝试（保持 idle），这是口径而不是漏装载。
    expect(store.listStatus).toBe('failed')
    expect(store.summaryStatus).toBe('idle')
    expect(store.affectedTotal).toBe(0)
    fail = false
    store.retry()
    await vi.waitUntil(() => store.isReady)
    expect(store.affectedTotal).toBeGreaterThan(0)
  })

  it('暴露成果清单返回501时保留 NOT_IMPLEMENTED，不覆盖成空清单 NOT_FOUND', async () => {
    const base = createDemoRepositories()
    const failingRepositories = {
      ...base,
      results: {
        ...base.results,
        listResults: async () => {
          throw new RepositoryError({
            code: 'NOT_IMPLEMENTED',
            message: '成果目录尚未接入。',
            httpStatus: 501,
          })
        },
      },
    }
    setExposureWorkspaceService(createExposureWorkspaceService(failingRepositories))
    const store = useExposureStore()

    await store.initFromQuery({})

    expect(store.listStatus).toBe('failed')
    expect(store.listError?.code).toBe('NOT_IMPLEMENTED')
    expect(store.listError?.httpStatus).toBe(501)
    expect(store.listError?.userMessage).toContain('暂未提供')
  })

  it('应急成果清单返回501时保留 NOT_IMPLEMENTED，不覆盖成空清单 NOT_FOUND', async () => {
    const base = createDemoRepositories()
    const failingRepositories = {
      ...base,
      results: {
        ...base.results,
        listResults: async () => {
          throw new RepositoryError({
            code: 'NOT_IMPLEMENTED',
            message: '成果目录尚未接入。',
            httpStatus: 501,
          })
        },
      },
    }
    setEmergencyWorkspaceService(createEmergencyWorkspaceService(failingRepositories))
    const store = useEmergencyStore()

    await store.initFromQuery({})

    expect(store.listStatus).toBe('failed')
    expect(store.listError?.code).toBe('NOT_IMPLEMENTED')
    expect(store.listError?.httpStatus).toBe(501)
    expect(store.listError?.userMessage).toContain('暂未提供')
  })
})
