import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

import {
  describeCondition,
  filterableFields,
  hiddenFieldNote,
  numberOperatorsOf,
  sortableFields,
  toAttributeFilter,
  toAttributeFilters,
  type FieldCondition,
} from '@/domain/queryFields'
import type {
  AttributeFilter,
  FeatureDetail,
  FieldDefinition,
  LayerDefinition,
  QueryInput,
  QueryResult,
} from '@/domain/types'
import type { Geometry } from 'geojson'
import { RepositoryError, type QueryRepository, type Repositories } from '@/repositories/types'
import {
  buildCsv,
  buildExportColumns,
  buildGeoJson,
  buildMetadataJson,
  EXPORT_CRS,
  exportFileName,
  FORMULA_GUARD_NOTE,
  type ExportMeta,
} from '@/services/queryExport'
import { createQueryWorkspaceService, type QueryOutcome } from '@/services/queryWorkspace'
import { toSpatialInput, useQueryStore } from '@/stores/query'
import { useMapStore } from '@/stores/map'

/**
 * 阶段3 查询服务的单元测试（03 §6-2、§6-6、§6-7、§6-8）。
 *
 * 重点不是「能不能调通」，而是四条容易被跳过的要求：
 * 1. 条件入口由字段声明驱动，不可查询字段必须被隐藏且说明；
 * 2. 改条件页码回 1；
 * 3. 旧响应不得覆盖新结果（AbortController + 序号）；
 * 4. 导出范围必须明确，拿不到全部时不得称「全部」。
 */

/* ------------------------------------------------------------------ *
 * 夹具
 * ------------------------------------------------------------------ */

const FIELD_LANDSLIDE_TYPE: FieldDefinition = {
  key: 'landslideType',
  label: '灾害类型',
  type: 'enum',
  unit: null,
  nullable: false,
  filterable: true,
  sortable: true,
  dictionaryId: 'dict.landslide-type',
}

const FIELD_VOLUME: FieldDefinition = {
  key: 'volumeM3',
  label: '方量',
  type: 'number',
  unit: '立方米',
  nullable: true,
  filterable: true,
  sortable: true,
}

const FIELD_DATE: FieldDefinition = {
  key: 'eventDate',
  label: '发生日期',
  type: 'date',
  unit: null,
  nullable: true,
  filterable: true,
  sortable: true,
}

/** 声明为不可查询的字段：界面不得给出条件入口。 */
const FIELD_INTERNAL: FieldDefinition = {
  key: 'internalCode',
  label: '内部编码',
  type: 'string',
  unit: null,
  nullable: true,
  filterable: false,
  sortable: false,
}

const HAZARD_LAYER: LayerDefinition = {
  id: 'hazard.landslide',
  label: '示例地质灾害点',
  theme: 'hazard',
  datasetId: 'demo-ds-landslide',
  geometryType: 'Point',
  source: { type: 'geojson', url: 'features/landslide.geojson', outputCrs: 'EPSG:4326' },
  fields: [FIELD_LANDSLIDE_TYPE, FIELD_VOLUME, FIELD_DATE, FIELD_INTERNAL],
  defaultVisible: true,
  defaultOpacity: 1,
  availableTimes: [],
  legendId: 'legend.hazard',
  queryable: true,
  exportFormats: ['csv', 'geojson'],
  sourceCrs: 'EPSG:4326',
}

function feature(id: string, properties: Record<string, unknown>): FeatureDetail {
  return {
    ref: { layerId: 'hazard.landslide', id },
    title: `对象 ${id}`,
    datasetId: 'demo-ds-landslide',
    geometry: { type: 'Point', coordinates: [91.1, 30.1] },
    properties: properties as FeatureDetail['properties'],
    relatedResultIds: [],
  }
}

function page(items: FeatureDetail[], total: number, pageNumber = 1, pageSize = 20): QueryResult {
  return {
    rows: { items, total, page: pageNumber, pageSize },
    queryId: 'demo-query-0001',
    metrics: [],
    mapSelection: {
      featureRefs: items.map((item) => item.ref),
      matchedTotal: total,
      renderedCount: items.length,
      truncated: items.length < total,
    },
  }
}

const CONTEXT = {
  mode: 'mock' as const,
  snapshotId: 'demo-v1',
  generatedAt: '2025-01-15T09:30:00+08:00',
  scopeLabel: '示例样区（合成，非正式研究区边界）',
  boundaryVersion: 'demo-boundary-v1',
  datasetVersions: { 'demo-ds-landslide': 'demo-hazard-1.0' },
}

/** 只实现 `queries` 的替身仓储：用于确定性地制造「旧响应晚到」。 */
function fakeRepositories(options: {
  /** 每次 runQuery 的延迟（按顺序取值，超出取最后一个）。 */
  delays?: number[]
  pages?: FeatureDetail[]
  total?: number
}): Repositories {
  let callIndex = 0
  const delays = options.delays ?? [0]
  const items = options.pages ?? []
  const total = options.total ?? items.length
  const queries: QueryRepository = {
    async runQuery(input: QueryInput, requestOptions?: { signal?: AbortSignal }) {
      const index = callIndex
      callIndex += 1
      const delay = delays[Math.min(index, delays.length - 1)] ?? 0
      await new Promise((resolve) => setTimeout(resolve, delay))
      if (requestOptions?.signal?.aborted) {
        throw new DOMException('请求已取消。', 'AbortError')
      }
      return {
        data: page(items, total, input.page, input.pageSize),
        meta: CONTEXT,
        requestId: `req-${index}`,
      }
    },
    async getQuery(_queryId: string, pageInput: { page: number; pageSize: number }) {
      const start = (pageInput.page - 1) * pageInput.pageSize
      return {
        data: page(
          items.slice(start, start + pageInput.pageSize),
          total,
          pageInput.page,
          pageInput.pageSize,
        ),
        meta: CONTEXT,
        requestId: 'req-page',
      }
    },
  }
  return { queries } as unknown as Repositories
}

const META: ExportMeta = {
  modeLabel: '示例数据',
  snapshotId: 'demo-v1',
  scopeLabel: '示例样区',
  boundaryVersion: 'demo-boundary-v1',
  datasetVersion: 'demo-hazard-1.0',
  layerId: 'hazard.landslide',
  layerLabel: '示例地质灾害点',
  conditions: ['灾害类型 属于 滑坡（landslide）'],
  spatial: '对象缓冲：以「A」为中心 5000 米',
  distanceMethod: null,
  sort: null,
  total: 2,
  exportedCount: 2,
  scope: 'page',
  complete: true,
  generatedAt: '2026-09-16T04:00:00.000Z',
  sample: true,
  notes: [],
}

/* ------------------------------------------------------------------ *
 * 一、条件生成
 * ------------------------------------------------------------------ */

describe('条件生成：由字段声明驱动（03 §6-1）', () => {
  it('只有声明可查询的字段才进入条件入口，隐藏条数被如实说明', () => {
    const available = filterableFields(HAZARD_LAYER)
    expect(available.map((field) => field.key)).toEqual(['landslideType', 'volumeM3', 'eventDate'])
    expect(available.map((field) => field.key)).not.toContain('internalCode')
    expect(hiddenFieldNote(HAZARD_LAYER)).toContain('1 个字段')
    expect(hiddenFieldNote(HAZARD_LAYER)).toContain('未在数据包中声明可查询')
  })

  it('排序入口同样只给声明可排序的字段', () => {
    expect(sortableFields(HAZARD_LAYER).map((field) => field.key)).toEqual([
      'landslideType',
      'volumeM3',
      'eventDate',
    ])
  })

  it('数值字段支持等于/大于等于/小于等于/介于', () => {
    expect(numberOperatorsOf(FIELD_VOLUME)).toEqual(['gte', 'lte', 'between', 'eq'])
    expect(numberOperatorsOf(FIELD_LANDSLIDE_TYPE)).toEqual([])
  })

  it('文本条件转契约：空文本不构成条件', () => {
    expect(toAttributeFilter({ field: 'name', kind: 'text', text: '' })).toBeNull()
    expect(toAttributeFilter({ field: 'name', kind: 'text', text: '示例' })).toEqual({
      field: 'name',
      operator: 'containsText',
      value: '示例',
    })
  })

  it('分类条件转契约：未选任何代码不构成条件', () => {
    expect(toAttributeFilter({ field: 'landslideType', kind: 'enum', codes: [] })).toBeNull()
    expect(
      toAttributeFilter({ field: 'landslideType', kind: 'enum', codes: ['landslide'] }),
    ).toEqual({ field: 'landslideType', operator: 'in', value: ['landslide'] })
  })

  it('数值区间转契约：两端都要有值；单端用 gte/lte', () => {
    const between: FieldCondition = {
      field: 'volumeM3',
      kind: 'number',
      operator: 'between',
      min: '1000',
      max: '5000',
    }
    expect(toAttributeFilter(between)).toEqual({
      field: 'volumeM3',
      operator: 'between',
      value: [1000, 5000],
    })
    expect(toAttributeFilter({ ...between, operator: 'between', max: '' })).toBeNull()
    expect(toAttributeFilter({ ...between, operator: 'gte', max: '' })).toEqual({
      field: 'volumeM3',
      operator: 'gte',
      value: 1000,
    })
  })

  it('日期区间转契约：双端 between、单端 gte/lte；非法数值不变成 0', () => {
    expect(
      toAttributeFilter({ field: 'eventDate', kind: 'date', from: '2010-01-01', to: '2020-12-31' }),
    ).toEqual({ field: 'eventDate', operator: 'between', value: ['2010-01-01', '2020-12-31'] })
    expect(
      toAttributeFilter({ field: 'eventDate', kind: 'date', from: '2010-01-01', to: '' }),
    ).toEqual({ field: 'eventDate', operator: 'gte', value: '2010-01-01' })
    expect(
      toAttributeFilter({
        field: 'volumeM3',
        kind: 'number',
        operator: 'gte',
        min: 'abc',
        max: '',
      }),
    ).toBeNull()
  })

  it('空值条件与布尔条件各自成立，不互相混淆', () => {
    expect(toAttributeFilter({ field: 'volumeM3', kind: 'isNull' })).toEqual({
      field: 'volumeM3',
      operator: 'isNull',
    })
    expect(toAttributeFilter({ field: 'blocked', kind: 'boolean', value: true })).toEqual({
      field: 'blocked',
      operator: 'eq',
      value: true,
    })
  })

  it('批量转换会剔除不完整条件（不把半截条件发给接口）', () => {
    const filters: AttributeFilter[] = toAttributeFilters([
      { field: 'name', kind: 'text', text: '' },
      { field: 'volumeM3', kind: 'number', operator: 'gte', min: '10', max: '' },
    ])
    expect(filters).toHaveLength(1)
    expect(filters[0]?.field).toBe('volumeM3')
  })

  it('条件摘要把原始代码翻成中文标签，并保留代码', () => {
    const text = describeCondition(
      { field: 'landslideType', kind: 'enum', codes: ['landslide'] },
      FIELD_LANDSLIDE_TYPE,
      { 'dict.landslide-type': [{ code: 'landslide', label: '滑坡' }] },
    )
    expect(text).toBe('灾害类型 属于 滑坡（landslide）')
  })
})

/* ------------------------------------------------------------------ *
 * 二、空间条件 → 契约
 * ------------------------------------------------------------------ */

describe('空间条件：geometry / sourceFeature / regionId 恰选一个', () => {
  const geometry: Geometry = {
    type: 'Polygon',
    coordinates: [
      [
        [91, 30],
        [92, 30],
        [92, 31],
        [91, 30],
      ],
    ],
  }

  it('绘制范围给 geometry，不给另外两个', () => {
    const input = toSpatialInput({
      predicate: 'within',
      source: 'draw',
      geometry,
      regionId: null,
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: null,
      limit: null,
    })
    expect(input).toEqual({ predicate: 'within', geometry })
  })

  it('行政区给 regionId', () => {
    const input = toSpatialInput({
      predicate: 'intersects',
      source: 'region',
      geometry: null,
      regionId: 'demo-region-west',
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: null,
      limit: null,
    })
    expect(input).toEqual({ predicate: 'intersects', regionId: 'demo-region-west' })
  })

  it('对象缓冲给 sourceFeature + 半径；半径为空则条件不成立', () => {
    const base = {
      predicate: 'bufferIntersects' as const,
      source: 'feature' as const,
      geometry: null,
      regionId: null,
      sourceFeature: { layerId: 'hazard.landslide', id: '1' },
      sourceLabel: 'A',
      limit: null,
    }
    expect(toSpatialInput({ ...base, distanceMeters: 5000 })).toEqual({
      predicate: 'bufferIntersects',
      sourceFeature: { layerId: 'hazard.landslide', id: '1' },
      distanceMeters: 5000,
    })
    expect(toSpatialInput({ ...base, distanceMeters: null })).toBeNull()
  })

  it('最近邻必须同时有半径与数量，缺一即条件不成立', () => {
    const base = {
      predicate: 'nearest' as const,
      source: 'feature' as const,
      geometry: null,
      regionId: null,
      sourceFeature: { layerId: 'hazard.landslide', id: '1' },
      sourceLabel: 'A',
    }
    expect(toSpatialInput({ ...base, distanceMeters: 1000, limit: 3 })).toMatchObject({
      predicate: 'nearest',
      distanceMeters: 1000,
      limit: 3,
    })
    expect(toSpatialInput({ ...base, distanceMeters: 1000, limit: null })).toBeNull()
    expect(toSpatialInput({ ...base, distanceMeters: null, limit: 3 })).toBeNull()
  })
})

/* ------------------------------------------------------------------ *
 * 三、竞态防护
 * ------------------------------------------------------------------ */

describe('查询服务：旧响应不得覆盖新结果（03 §6-6）', () => {
  it('先发后到的旧响应被丢弃（返回 null）', async () => {
    const service = createQueryWorkspaceService(
      fakeRepositories({ delays: [60, 0], pages: [feature('1', {})], total: 1 }),
    )
    const first = service.run({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: null,
      sort: null,
      page: 1,
      pageSize: 20,
    })
    const second = service.run({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: null,
      sort: null,
      page: 1,
      pageSize: 20,
    })
    const [firstOutcome, secondOutcome] = await Promise.all([first, second])
    // 第二次是最新请求：必须拿到结果；第一次已被取代：必须是 null。
    expect(secondOutcome).not.toBeNull()
    expect(firstOutcome).toBeNull()
  })

  it('取消在途请求返回 null，不把取消当故障抛出', async () => {
    const service = createQueryWorkspaceService(
      fakeRepositories({ delays: [50], pages: [feature('1', {})], total: 1 }),
    )
    const pending = service.run({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: null,
      sort: null,
      page: 1,
      pageSize: 20,
    })
    service.cancel()
    await expect(pending).resolves.toBeNull()
  })

  it('真正的读取失败仍然抛出，不被当成「取消」吞掉', async () => {
    const failing: Repositories = {
      queries: {
        async runQuery() {
          throw new RepositoryError({ code: 'SERVICE_UNAVAILABLE', message: '服务不可用。' })
        },
        async getQuery() {
          throw new RepositoryError({ code: 'QUERY_EXPIRED', message: '已过期。' })
        },
      },
    } as unknown as Repositories
    const service = createQueryWorkspaceService(failing)
    await expect(
      service.run({
        layerId: 'hazard.landslide',
        filters: [],
        spatial: null,
        sort: null,
        page: 1,
        pageSize: 20,
      }),
    ).rejects.toMatchObject({ code: 'SERVICE_UNAVAILABLE' })
  })

  it('翻页复用同一查询快照，并带回 requestId 供追溯', async () => {
    const service = createQueryWorkspaceService(
      fakeRepositories({ pages: [feature('1', {}), feature('2', {})], total: 2 }),
    )
    const outcome: QueryOutcome | null = await service.pageTo('demo-query-0001', 1, 20)
    expect(outcome?.queryId).toBe('demo-query-0001')
    expect(outcome?.requestId).toBe('req-page')
  })

  it('fetchAll 逐页受控获取同一快照；取不满时如实标记未完成', async () => {
    const items = Array.from({ length: 25 }, (_, index) => feature(String(index + 1), {}))
    const service = createQueryWorkspaceService(fakeRepositories({ pages: items, total: 25 }))
    const all = await service.fetchAll('demo-query-0001', 10)
    expect(all.rows).toHaveLength(25)
    expect(all.complete).toBe(true)
    expect(all.note).toBeNull()

    const limited = await service.fetchAll('demo-query-0001', 10, 1)
    expect(limited.rows).toHaveLength(10)
    expect(limited.complete).toBe(false)
    expect(limited.note).toContain('不是全部结果')
  })

  it('fetchAll 遇到同页重复源 ref 时也停止为 duplicate-source，不提供完整导出', async () => {
    const items = [feature('1', {}), feature('2', {}), feature('2', {}), feature('3', {})]
    const duplicateRepositories = {
      queries: {
        async runQuery() {
          return {
            data: page(items, 4, 1, 4),
            meta: CONTEXT,
            requestId: 'same-page-run',
          }
        },
        async getQuery(_queryId: string, input: { page: number; pageSize: number }) {
          return {
            data: page(items, 4, input.page, input.pageSize),
            meta: CONTEXT,
            requestId: 'same-page-query',
          }
        },
      },
    } as unknown as Repositories
    const outcome = await createQueryWorkspaceService(duplicateRepositories).fetchAll(
      'demo-query-0001',
      4,
      10,
    )
    expect(outcome.complete).toBe(false)
    expect(outcome.stopReason).toBe('duplicate-source')
    expect(outcome.note).toContain('同页或跨页')
  })

  it('fetchAll 遇到跨页重复源 ref 时不标记 complete，也不生成全量导出语义', async () => {
    const items = [feature('1', {}), feature('2', {}), feature('2', {}), feature('3', {})]
    const duplicateRepositories = {
      queries: {
        async runQuery() {
          return {
            data: page(items.slice(0, 2), 4, 1, 2),
            meta: CONTEXT,
            requestId: 'duplicate-run',
          }
        },
        async getQuery(_queryId: string, input: { page: number; pageSize: number }) {
          const start = (input.page - 1) * input.pageSize
          return {
            data: page(items.slice(start, start + input.pageSize), 4, input.page, input.pageSize),
            meta: CONTEXT,
            requestId: `duplicate-${input.page}`,
          }
        },
      },
    } as unknown as Repositories
    const outcome = await createQueryWorkspaceService(duplicateRepositories).fetchAll(
      'demo-query-0001',
      2,
      10,
    )
    expect(outcome.rows).toHaveLength(4)
    expect(outcome.complete).toBe(false)
    expect(outcome.stopReason).toBe('duplicate-source')
    expect(outcome.note).toContain('重复源记录')
  })
})

/* ------------------------------------------------------------------ *
 * 四、导出
 * ------------------------------------------------------------------ */

describe('导出：范围、转义与元数据（02 §7、03 §6-7）', () => {
  const rows = [
    feature('1', { landslideType: 'landslide', volumeM3: -5, eventDate: '2015-04-25' }),
    feature('2', { landslideType: 'debris', volumeM3: 12000, eventDate: null }),
  ]
  const columns = buildExportColumns(HAZARD_LAYER.fields)
  const dictionaries = {
    'dict.landslide-type': [
      { code: 'landslide', label: '滑坡' },
      { code: 'debris', label: '泥石流' },
    ],
  }

  it('CSV 以 UTF-8 BOM 开头，并带条件、来源、CRS 与示例标识', () => {
    const csv = buildCsv({ rows, columns, meta: META, dictionaries })
    expect(csv.charCodeAt(0)).toBe(0xfeff)
    expect(csv).toContain('示例数据')
    expect(csv).toContain('示例数据，非真实统计')
    expect(csv).toContain(EXPORT_CRS)
    expect(csv).toContain('灾害类型 属于 滑坡（landslide）')
    expect(csv).toContain('对象缓冲')
    expect(csv).toContain(FORMULA_GUARD_NOTE.slice(0, 12))
  })

  it('数值列保持数值，合法负数不被公式保护误伤', () => {
    const csv = buildCsv({ rows, columns, meta: META, dictionaries })
    expect(csv).toContain('"-5"')
    expect(csv).not.toContain("'-5")
  })

  it('以 = + - @ 开头的文本前置单引号，防止表格软件按公式解释', () => {
    const nameField: FieldDefinition = {
      key: 'name',
      label: '名称',
      type: 'string',
      unit: null,
      nullable: true,
      filterable: true,
      sortable: true,
    }
    const tricky = [feature('3', { name: '=1+1' })]
    const csv = buildCsv({
      rows: tricky,
      columns: [{ key: 'name', label: '名称', field: nameField, unit: null }],
      meta: META,
      dictionaries,
    })
    expect(csv).toContain('"\'=1+1"')
  })

  it('空值写「未提供」而不是 0', () => {
    const csv = buildCsv({ rows, columns, meta: META, dictionaries })
    expect(csv).toContain('未提供')
  })

  it('GeoJSON 不写 crs 成员，保留原始几何与属性', () => {
    const geojson = buildGeoJson(rows)
    expect(geojson).not.toContain('"crs"')
    const parsed = JSON.parse(geojson) as { features: Array<{ geometry: unknown }> }
    expect(parsed.features).toHaveLength(2)
    expect(parsed.features[0]?.geometry).toEqual({ type: 'Point', coordinates: [91.1, 30.1] })
  })

  it('metadata.json 独立成文，含来源、条件、范围、生成时间与坐标顺序', () => {
    const parsed = JSON.parse(buildMetadataJson(META)) as Record<string, unknown>
    expect(JSON.stringify(parsed)).toContain('示例数据')
    expect(JSON.stringify(parsed)).toContain('[经度, 纬度]')
    expect(JSON.stringify(parsed)).toContain('demo-hazard-1.0')
    expect(JSON.stringify(parsed)).toContain('当前页')
  })

  it('未取到全部时，文件内明确写出「不是全部结果」', () => {
    const csv = buildCsv({
      rows,
      columns,
      meta: { ...META, scope: 'all', complete: false, exportedCount: 2, total: 25 },
      dictionaries,
    })
    expect(csv).toContain('未完成全部获取')
    expect(csv).toContain('不是全部结果')
  })

  it('文件名包含图层、范围与时间戳，便于归档核对', () => {
    const name = exportFileName('hazard.landslide', 'all', new Date(2026, 8, 16, 12, 5, 9))
    expect(name).toContain('hazard.landslide')
    expect(name).toContain('all')
    expect(name).toContain('20260916-120509')
  })
})

/* ------------------------------------------------------------------ *
 * 五、store 行为：改条件页码回 1
 * ------------------------------------------------------------------ */

describe('查询 store：改条件页码回 1（03 §6-2）', () => {
  beforeEach(() => {
    setActivePinia(createPinia())
  })

  it('换图层、加删条件、改排序、改空间条件都会把页码重置为 1', () => {
    const mapStore = useMapStore()
    mapStore.applyRegistry([HAZARD_LAYER])
    const store = useQueryStore()
    store.setLayer('hazard.landslide')

    store.page = 4
    store.addCondition({ field: 'volumeM3', kind: 'number', operator: 'gte', min: '1', max: '' })
    expect(store.page).toBe(1)

    store.page = 3
    store.removeCondition('volumeM3')
    expect(store.page).toBe(1)

    store.page = 3
    store.setSort('volumeM3')
    expect(store.page).toBe(1)

    store.page = 3
    store.setSpatial({
      predicate: 'intersects',
      source: 'draw',
      geometry: null,
      regionId: null,
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: null,
      limit: null,
    })
    expect(store.page).toBe(1)
  })

  it('排序同字段二次点击切换升降序', () => {
    const mapStore = useMapStore()
    mapStore.applyRegistry([HAZARD_LAYER])
    const store = useQueryStore()
    store.setLayer('hazard.landslide')
    store.setSort('volumeM3')
    expect(store.sort).toEqual({ field: 'volumeM3', direction: 'asc' })
    store.setSort('volumeM3')
    expect(store.sort).toEqual({ field: 'volumeM3', direction: 'desc' })
  })

  it('空间条件不完整时给出说明，而不是静默忽略', () => {
    const mapStore = useMapStore()
    mapStore.applyRegistry([HAZARD_LAYER])
    const store = useQueryStore()
    store.setLayer('hazard.landslide')
    store.setSpatial({
      predicate: 'bufferIntersects',
      source: 'feature',
      geometry: null,
      regionId: null,
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: 5000,
      limit: null,
    })
    expect(store.spatialIncompleteReason).toContain('源对象')
    expect(store.spatialInput).toBeNull()
  })

  it('不可查询字段不会出现在可添加列表里', () => {
    const mapStore = useMapStore()
    mapStore.applyRegistry([HAZARD_LAYER])
    const store = useQueryStore()
    store.setLayer('hazard.landslide')
    expect(store.availableFields.map((field) => field.key)).not.toContain('internalCode')
    expect(store.addableFields.map((field) => field.key)).not.toContain('internalCode')
  })
})
