import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it } from 'vitest'

import type { FeatureDetail, LayerDefinition } from '@/domain/types'
import {
  mapLifecycleCounts,
  registerMapInstance,
  registerMapListeners,
  resetMapLifecycleCounts,
  unregisterMapInstance,
} from '@/services/mapLifecycle'
import type { MapRenderState } from '@/services/mapRenderState'
import type { LayerDataResult } from '@/services/mapLayers'
import { emptySummary, toDataSummary, useMapStore } from '@/stores/map'

/**
 * 阶段2 地图状态 store 的单元测试。
 *
 * 这里最重要的一条是**可序列化守卫**：03 §5-1 要求 OpenLayers 实例不深度响应式存入 Pinia，
 * 因此 store 里出现的所有对象都必须是普通对象/数组，不能是 OL 实例或类实例。
 * 该守卫会遍历整个 state 逐个检查原型，而不只是「看起来没放地图」。
 */

function layer(
  id: string,
  theme: LayerDefinition['theme'],
  options: Partial<LayerDefinition> = {},
): LayerDefinition {
  return {
    id,
    label: `图层 ${id}`,
    theme,
    datasetId: `ds-${id}`,
    geometryType: 'Point',
    source: { type: 'geojson', url: `features/${id}.geojson`, outputCrs: 'EPSG:4326' },
    fields: [],
    defaultVisible: true,
    defaultOpacity: 1,
    availableTimes: [],
    legendId: `legend.${id}`,
    queryable: true,
    exportFormats: ['csv'],
    sourceCrs: 'EPSG:4326',
    ...options,
  }
}

const registry: LayerDefinition[] = [
  layer('base.a', 'base'),
  layer('base.b', 'base', { defaultVisible: false, defaultOpacity: 0.5 }),
  layer('tnr.c', 'tnr'),
  layer('hazard.d', 'hazard', { geometryType: 'Raster' }),
  layer('emg.e', 'emg'),
  layer('result.f', 'result', { geometryType: 'Polygon' }),
]

function renderState(): MapRenderState {
  return {
    layers: [
      { layerId: 'base.a', visible: true, opacity: 1, zIndex: 60, featureCount: 3 },
      { layerId: 'base.b', visible: false, opacity: 0.5, zIndex: 50, featureCount: 0 },
    ],
    visibleLayerCount: 1,
    renderedFeatureCount: 3,
    mapInstances: 1,
    listeners: 3,
    zoom: 6,
  }
}

function detail(id: string): FeatureDetail {
  return {
    ref: { layerId: 'base.a', id },
    title: `对象 ${id}`,
    datasetId: 'ds-base.a',
    geometry: { type: 'Point', coordinates: [90, 30] },
    properties: { name: `对象 ${id}` },
    relatedResultIds: [],
  }
}

/** 遍历 state，断言每个对象都是普通对象或数组（即：可 JSON 往返、无类实例）。 */
function assertPlainValue(value: unknown, path: string): void {
  if (value === null || value === undefined) return
  const kind = typeof value
  if (kind === 'string' || kind === 'number' || kind === 'boolean') return
  if (Array.isArray(value)) {
    value.forEach((item, index) => assertPlainValue(item, `${path}[${index}]`))
    return
  }
  expect(Object.getPrototypeOf(value), `${path} 必须是普通对象`).toBe(Object.prototype)
  for (const [key, item] of Object.entries(value as Record<string, unknown>)) {
    assertPlainValue(item, `${path}.${key}`)
  }
}

beforeEach(() => {
  setActivePinia(createPinia())
  resetMapLifecycleCounts()
})

describe('阶段2 地图 store：注册表与叠放顺序', () => {
  it('applyRegistry 只保留地图主题，并按「点在上、线居中、面在下」建立叠放顺序', () => {
    const store = useMapStore()
    store.applyRegistry([...registry, layer('sys.g', 'sys')])
    // 数组首位在最上层：点(2) → 线(1) → 面/栅格(0)，同层内保持注册表顺序。
    expect(store.orderedLayers.map((item) => item.id)).toEqual([
      'base.a',
      'base.b',
      'tnr.c',
      'emg.e',
      'hazard.d',
      'result.f',
    ])
  })

  it('面图层不会压在点图层之上（点选不会被面挡住）', () => {
    const store = useMapStore()
    store.applyRegistry([
      layer('base.boundaryLike', 'base', { geometryType: 'Polygon' }),
      layer('base.pointLike', 'base'),
      layer('emg.lineLike', 'emg', { geometryType: 'LineString' }),
    ])
    const order = store.order
    expect(order.indexOf('base.pointLike')).toBeLessThan(order.indexOf('emg.lineLike'))
    expect(order.indexOf('emg.lineLike')).toBeLessThan(order.indexOf('base.boundaryLike'))
  })

  it('可见性与透明度取数据包的默认值，而不是前端自行决定', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    expect(store.isVisible('base.a')).toBe(true)
    expect(store.isVisible('base.b')).toBe(false)
    expect(store.opacityOf('base.b')).toBe(0.5)
    expect(store.opacityOf('base.a')).toBe(1)
  })

  it('上下移动改变叠放顺序，越界时返回 false 且顺序不变', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    expect(store.moveLayer('tnr.c', 'up')).toBe(true)
    expect(store.order.slice(0, 3)).toEqual(['base.a', 'tnr.c', 'base.b'])
    expect(store.moveLayer('base.a', 'up')).toBe(false)
    expect(store.order[0]).toBe('base.a')
    expect(store.moveLayer('result.f', 'down')).toBe(false)
    expect(store.order[store.order.length - 1]).toBe('result.f')
  })

  it('恢复默认顺序与可见性', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    const defaultOrder = [...store.order]
    store.moveLayer('result.f', 'up')
    store.setVisible('base.a', false)
    store.setOpacity('base.a', 0.2)
    store.resetOrder()
    expect(store.order).toEqual(defaultOrder)
    expect(store.isVisible('base.a')).toBe(true)
    expect(store.opacityOf('base.a')).toBe(1)
  })

  it('透明度被限制在 0—1', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    store.setOpacity('base.a', 4)
    expect(store.opacityOf('base.a')).toBe(1)
    store.setOpacity('base.a', -3)
    expect(store.opacityOf('base.a')).toBe(0)
  })

  it('加载失败时不保留任何图层，并记录错误码（不用示例图层顶替）', async () => {
    const store = useMapStore()
    // 未替换服务单例时直接写入失败状态：验证状态字段与「清空」行为。
    store.applyRegistry(registry)
    expect(store.orderedLayers.length).toBeGreaterThan(0)
    store.reset()
    expect(store.layers).toEqual([])
    expect(store.order).toEqual([])
    expect(store.status).toBe('idle')
  })
})

describe('阶段2 地图 store：搜索与当前图层', () => {
  it('搜索过滤分组，但主题顺序与组内顺序保持不变', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    store.setSearch('base.b')
    expect(store.groups.flatMap((group) => group.layers.map((item) => item.id))).toEqual(['base.b'])
    store.setSearch('')
    expect(store.groups.length).toBe(5)
  })

  it('搜索命中图层 ID 片段，未命中时分组为空', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    store.setSearch('hazard')
    expect(store.selectedCount).toBe(1)
    store.setSearch('不存在的图层')
    expect(store.groups).toEqual([])
  })

  it('当前对象列表图层可设置与清除', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    expect(store.activeLayer).toBeNull()
    store.setActiveLayer('emg.e')
    expect(store.activeLayer?.id).toBe('emg.e')
    store.setActiveLayer(null)
    expect(store.activeLayer).toBeNull()
  })
})

describe('阶段2 地图 store：选中与面板', () => {
  it('选中对象会打开详情面板，清空后收起', () => {
    const store = useMapStore()
    store.select(detail('1'))
    expect(store.selected?.ref.id).toBe('1')
    expect(store.detailOpen).toBe(true)
    store.clearSelection()
    expect(store.selected).toBeNull()
    expect(store.detailOpen).toBe(false)
  })

  it('图例、对象列表与图层面板可独立开关', () => {
    const store = useMapStore()
    const legend = store.legendOpen
    store.toggleLegend()
    expect(store.legendOpen).toBe(!legend)
    store.toggleObjectList()
    expect(store.objectListOpen).toBe(true)
    store.toggleLayerDrawer()
    expect(store.layerDrawerOpen).toBe(true)
    store.closeDrawers()
    expect(store.layerDrawerOpen).toBe(false)
  })

  it('reset 清空本页状态，避免切换模式后沿用旧选中（D-014）', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    store.setActiveLayer('base.a')
    store.setSearch('base')
    store.select(detail('1'))
    store.setRenderState(renderState())
    store.reset()
    expect(store.layers).toEqual([])
    expect(store.search).toBe('')
    expect(store.activeLayerId).toBeNull()
    expect(store.selected).toBeNull()
    expect(store.renderState).toBeNull()
  })
})

describe('阶段2 地图 store：图层数据状态', () => {
  it('emptySummary 是「尚未加载」，不会显示成 0 条已加载', () => {
    const summary = emptySummary()
    expect(summary.status).toBe('idle')
    expect(summary.matched).toBe(0)
    expect(summary.errorCode).toBeNull()
  })

  it('toDataSummary 保留失败错误码与文案、截断说明与无几何计数', () => {
    const ready: LayerDataResult = {
      layerId: 'result.f',
      status: 'ready',
      features: [],
      serverTotal: 100,
      fetchedCount: 50,
      uniqueCount: 50,
      renderedCount: 48,
      complete: false,
      total: 100,
      matched: 50,
      truncated: true,
      note: '本图层共 100 条，单次最多渲染 50 条',
      error: null,
    }
    const summary = toDataSummary(ready, 2)
    expect(summary.status).toBe('ready')
    expect(summary.truncated).toBe(true)
    expect(summary.skippedNoGeometry).toBe(2)
    expect(summary.note).toContain('100')

    const failed: LayerDataResult = {
      layerId: 'result.f',
      status: 'failed',
      features: [],
      serverTotal: 0,
      fetchedCount: 0,
      uniqueCount: 0,
      renderedCount: 0,
      complete: false,
      total: 0,
      matched: 0,
      truncated: false,
      note: null,
      error: new (class extends Error {
        code = 'NETWORK_ERROR'
        userMessage = '无法连接数据服务（网络错误）。界面不会改用示例数据。'
      })() as unknown as LayerDataResult['error'],
    }
    const failedSummary = toDataSummary(failed, 0)
    expect(failedSummary.status).toBe('failed')
    expect(failedSummary.errorCode).toBe('NETWORK_ERROR')
    expect(failedSummary.errorText).toContain('不会改用示例数据')
  })
})

describe('阶段2 地图 store：地图实例与监听计数', () => {
  it('注册与注销配对后计数回到 0', () => {
    expect(mapLifecycleCounts()).toEqual({ mapInstances: 0, listeners: 0 })
    registerMapInstance()
    registerMapListeners(3)
    expect(mapLifecycleCounts()).toEqual({ mapInstances: 1, listeners: 3 })
    unregisterMapInstance(3)
    expect(mapLifecycleCounts()).toEqual({ mapInstances: 0, listeners: 0 })
  })

  it('重复挂载多次后计数不累积（等价于「无重复地图监听」）', () => {
    for (let index = 0; index < 5; index += 1) {
      registerMapInstance()
      registerMapListeners(3)
      unregisterMapInstance(3)
    }
    expect(mapLifecycleCounts()).toEqual({ mapInstances: 0, listeners: 0 })
  })
})

describe('阶段2 地图 store：可序列化守卫（OpenLayers 实例不得进 store）', () => {
  it('state 中所有值都是普通对象/数组，可 JSON 往返', () => {
    const store = useMapStore()
    store.applyRegistry(registry)
    store.setActiveLayer('base.a')
    store.setSearch('base')
    store.select(detail('1'))
    store.setRenderState(renderState())
    store.setDataSummary(
      'base.a',
      toDataSummary(
        {
          layerId: 'base.a',
          status: 'ready',
          features: [],
          serverTotal: 3,
          fetchedCount: 3,
          uniqueCount: 3,
          renderedCount: 3,
          complete: true,
          total: 3,
          matched: 3,
          truncated: false,
          note: null,
          error: null,
        },
        0,
      ),
    )

    assertPlainValue(store.$state, 'state')
    const roundTripped: unknown = JSON.parse(JSON.stringify(store.$state))
    expect(roundTripped).toEqual(JSON.parse(JSON.stringify(store.$state)))
  })
})
