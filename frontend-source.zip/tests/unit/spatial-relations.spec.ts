import { describe, expect, it } from 'vitest'

import { haversineMeters } from '@/domain/geometry'
import {
  bufferIntersects,
  distanceMeters,
  DISTANCE_METHOD_TEXT,
  geometryIntersects,
  geometryWithin,
  nearestByDistance,
  pointToSegmentMeters,
  segmentsOf,
  verticesOf,
} from '@/domain/spatialRelations'
import type { Geometry } from 'geojson'
import { createDemoRepositories } from './helpers/repository-fixtures'

/**
 * 空间关系与米制距离的单元测试（阶段3：03 §6-8）。
 *
 * 逐条对应 02 §3.1 的语义要求：
 * - 相交与覆盖是**两套判定**，部分重叠只算相交；
 * - 覆盖允许边界（内部或边界），不允许任何部分在外；
 * - 距离一律是米，绝不经纬度差；
 * - 缓冲半径变化必须改变命中；最近邻必须受限制半径与数量约束。
 */

function polygon(ring: number[][]): Geometry {
  return { type: 'Polygon', coordinates: [ring as [number, number][]] }
}

function point(lon: number, lat: number): Geometry {
  return { type: 'Point', coordinates: [lon, lat] }
}

function line(coords: number[][]): Geometry {
  return { type: 'LineString', coordinates: coords as [number, number][] }
}

/** 一个 1° × 1° 的方形范围（约 111 km × 111 km）。 */
const square = polygon([
  [91, 30],
  [92, 30],
  [92, 31],
  [91, 31],
  [91, 30],
])

describe('相交与覆盖是两套判定（02 §3.1）', () => {
  it('完全落在范围内的线：相交与覆盖都为真', () => {
    const inside = line([
      [91.2, 30.2],
      [91.8, 30.8],
    ])
    expect(geometryIntersects(inside, square)).toBe(true)
    expect(geometryWithin(inside, square)).toBe(true)
  })

  it('部分重叠的线：只算相交，不算覆盖', () => {
    const crossing = line([
      [90.5, 30.5],
      [91.5, 30.5],
    ])
    expect(geometryIntersects(crossing, square)).toBe(true)
    expect(geometryWithin(crossing, square)).toBe(false)
  })

  it('完全在范围外的线：两者都为假', () => {
    const outside = line([
      [95, 30.5],
      [96, 30.5],
    ])
    expect(geometryIntersects(outside, square)).toBe(false)
    expect(geometryWithin(outside, square)).toBe(false)
  })

  it('范围包含目标顶点但目标更大的面：相交为真、覆盖为假', () => {
    const bigger = polygon([
      [90, 29],
      [93, 29],
      [93, 32],
      [90, 32],
      [90, 29],
    ])
    expect(geometryIntersects(bigger, square)).toBe(true)
    expect(geometryWithin(bigger, square)).toBe(false)
    // 反过来：小方形整体在大方形内，覆盖成立。
    expect(geometryWithin(square, bigger)).toBe(true)
  })
})

describe('边界相触按「内部或边界」处理', () => {
  it('点落在范围边界上：覆盖成立', () => {
    expect(geometryWithin(point(91, 30.5), square)).toBe(true)
    expect(geometryIntersects(point(91, 30.5), square)).toBe(true)
  })

  it('点落在范围外一点点：覆盖不成立', () => {
    expect(geometryWithin(point(90.99, 30.5), square)).toBe(false)
    expect(geometryIntersects(point(90.99, 30.5), square)).toBe(false)
  })

  it('目标顶点都在内部、但中间穿过凹口时覆盖不成立（不只看顶点）', () => {
    // U 形凹多边形：两端点在范围内，连线却从缺口穿出。
    const uShape = polygon([
      [91, 30],
      [91.4, 30],
      [91.4, 30.4],
      [91.6, 30.4],
      [91.6, 30],
      [92, 30],
      [92, 31],
      [91, 31],
      [91, 30],
    ])
    const chord = line([
      [91.2, 30.2],
      [91.8, 30.2],
    ])
    // 弦的两个端点都在 U 形内部，但中间有一段落在缺口里 → 严格穿越边界。
    expect(geometryIntersects(chord, uShape)).toBe(true)
    expect(geometryWithin(chord, uShape)).toBe(false)
  })
})

describe('距离一律是米，不是经纬度差', () => {
  it('1 度纬度差约 111 千米，而不是 1', () => {
    const meters = distanceMeters(point(91, 30), point(91, 31))
    expect(meters).toBeGreaterThan(110_000)
    expect(meters).toBeLessThan(112_000)
    // 若把经纬度差当米，这里会得到 1；断言刻意远离该错误量级。
    expect(meters).toBeGreaterThan(1000)
  })

  it('点到线段的距离取垂足，不取端点', () => {
    // 线段沿经度方向延伸，点在其正南方 0.1 度（约 11 千米）。
    const meters = pointToSegmentMeters([91.5, 30.4], [91, 30.5], [92, 30.5])
    expect(meters).toBeGreaterThan(10_000)
    expect(meters).toBeLessThan(13_000)
  })

  it('相交的两个几何距离为 0', () => {
    expect(distanceMeters(point(91.5, 30.5), square)).toBe(0)
  })

  it('球面距离随纬度收敛：同样 1° 经度差，在 30°N 约 96 千米而非 111 千米', () => {
    // 这条断言同时是「不能把经纬度差当米」的反例：纬度 1° ≈ 111 km，
    // 但经度 1° 在 30°N 只有 111 × cos30° ≈ 96 km，两者不能混用同一个换算系数。
    const latStep = haversineMeters([91, 30], [91, 31])
    const lonStep = haversineMeters([91, 30], [92, 30])
    expect(latStep).toBeGreaterThan(110_000)
    expect(latStep).toBeLessThan(112_000)
    expect(lonStep).toBeGreaterThan(95_000)
    expect(lonStep).toBeLessThan(98_000)
    expect(lonStep).toBeLessThan(latStep)
  })

  it('正方形对角线（1°×1°）约 147 千米（两点距离走球面）', () => {
    const meters = haversineMeters([91, 30], [92, 31])
    expect(meters).toBeGreaterThan(143_000)
    expect(meters).toBeLessThan(151_000)
  })
})

describe('缓冲：半径变化必须改变命中', () => {
  it('同一批点，半径增大后命中数不减少且真实增加', () => {
    const targets = [
      point(91.001, 30.0), // 约 100 米
      point(91.05, 30.0), // 约 4.8 千米
      point(92.5, 30.0), // 很远
    ]
    const center = point(91, 30)
    const near = targets.filter((target) => bufferIntersects(target, center, 1000)).length
    const far = targets.filter((target) => bufferIntersects(target, center, 20_000)).length
    expect(near).toBe(1)
    expect(far).toBe(2)
    expect(far).toBeGreaterThan(near)
  })

  it('半径为 0 时退化为相交判定', () => {
    expect(bufferIntersects(point(91.5, 30.5), square, 0)).toBe(true)
    expect(bufferIntersects(point(95, 30.5), square, 0)).toBe(false)
  })
})

describe('最近邻：限制半径与数量都生效', () => {
  const items = [
    { id: 'far', geometry: point(93, 30) },
    { id: 'near', geometry: point(91.01, 30) },
    { id: 'mid', geometry: point(91.5, 30) },
  ]

  function run(radius: number, limit: number) {
    return nearestByDistance(
      items,
      (item) => distanceMeters(item.geometry, point(91, 30)),
      radius,
      limit,
    )
  }

  it('按距离升序返回，且距离以米为单位', () => {
    const result = run(200_000, 3)
    expect(result.map((item) => item.item.id)).toEqual(['near', 'mid', 'far'])
    expect(result[0]?.distanceMeters ?? 0).toBeLessThan(result[1]?.distanceMeters ?? 0)
    expect(result[0]?.distanceMeters ?? 0).toBeGreaterThan(500)
  })

  it('超出限制半径的不返回（不是「最近的 N 条」，是「半径内的最近 N 条」）', () => {
    const result = run(20_000, 3)
    expect(result.map((item) => item.item.id)).toEqual(['near'])
  })

  it('数量上限生效', () => {
    expect(run(200_000, 2).map((item) => item.item.id)).toEqual(['near', 'mid'])
  })

  it('距离方法文案写明单位与方法', () => {
    expect(DISTANCE_METHOD_TEXT).toContain('米')
    expect(DISTANCE_METHOD_TEXT).toContain('haversine')
    expect(DISTANCE_METHOD_TEXT).toContain('不使用经纬度差')
  })
})

describe('几何拆解：多部件与集合不丢部件', () => {
  it('多部件几何的顶点与线段都被拆出', () => {
    const multi: Geometry = {
      type: 'MultiPolygon',
      coordinates: [
        [
          [
            [91, 30],
            [91.1, 30],
            [91.1, 30.1],
            [91, 30],
          ],
        ],
        [
          [
            [92, 31],
            [92.1, 31],
            [92.1, 31.1],
            [92, 31],
          ],
        ],
      ],
    }
    expect(verticesOf(multi)).toHaveLength(8)
    // 每个三角环 3 条边 + 1 条闭合边 = 4 段，两块共 8 段。
    expect(segmentsOf(multi)).toHaveLength(8)
  })
})

/* ------------------------------------------------------------------ *
 * 与真实数据包集成：危险点缓冲查询（验收句「改半径命中变化」）
 * ------------------------------------------------------------------ */

describe('示例包内的空间查询：危险点缓冲（03 §6-4）', () => {
  async function bufferCount(radiusMeters: number): Promise<number> {
    const repositories = createDemoRepositories()
    // 以第一个居民地为中心，统计落在缓冲内的地质灾害点。
    const settlements = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 5,
    })
    const center = settlements.data.items[0]
    expect(center, '示例包应有居民地').toBeTruthy()
    const envelope = await repositories.queries.runQuery({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: {
        predicate: 'bufferIntersects',
        sourceFeature: center?.ref,
        distanceMeters: radiusMeters,
      },
      page: 1,
      pageSize: 100,
    })
    return envelope.data.rows.total
  }

  it('半径从小到大，命中数单调不减且确实增加', async () => {
    const small = await bufferCount(5_000)
    const large = await bufferCount(200_000)
    expect(large).toBeGreaterThanOrEqual(small)
    expect(large).toBeGreaterThan(small)
  })

  it('缓冲结果带半径指标，单位米并写明方法', async () => {
    const repositories = createDemoRepositories()
    const settlements = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 5,
    })
    const center = settlements.data.items[0]
    const envelope = await repositories.queries.runQuery({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: {
        predicate: 'bufferIntersects',
        sourceFeature: center?.ref,
        distanceMeters: 50_000,
      },
      page: 1,
      pageSize: 100,
    })
    const radius = envelope.data.metrics.find((metric) => metric.key === 'bufferRadiusMeters')
    expect(radius?.value).toBe(50_000)
    expect(radius?.unit).toBe('m')
    expect(radius?.method).toContain('米')
  })

  it('最近邻返回逐条距离（米）且受半径与数量限制', async () => {
    const repositories = createDemoRepositories()
    const settlements = await repositories.layers.listFeatures('base.settlement.point', {
      page: 1,
      pageSize: 5,
    })
    const center = settlements.data.items[0]
    const envelope = await repositories.queries.runQuery({
      layerId: 'hazard.landslide',
      filters: [],
      spatial: {
        predicate: 'nearest',
        sourceFeature: center?.ref,
        distanceMeters: 200_000,
        limit: 3,
      },
      page: 1,
      pageSize: 100,
    })
    expect(envelope.data.rows.total).toBeLessThanOrEqual(3)
    const distances = Object.values(envelope.data.nearestDistances ?? {})
    expect(distances.length).toBe(envelope.data.rows.total)
    for (const value of distances) {
      expect(value).toBeLessThanOrEqual(200_000)
      expect(value).toBeGreaterThan(0)
    }
    // 距离升序：最近邻的排序语义不被分页或排序覆盖。
    const sorted = [...distances].sort((a, b) => a - b)
    expect(distances).toEqual(sorted)
  })
})
