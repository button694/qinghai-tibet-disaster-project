import { mount } from '@vue/test-utils'
import { createPinia, setActivePinia } from 'pinia'
import { beforeEach, describe, expect, it, vi } from 'vitest'

import QueryPanel from '@/components/query/QueryPanel.vue'
import type { Capabilities, LayerDefinition } from '@/domain/types'
import { useMapStore } from '@/stores/map'
import { useQueryStore } from '@/stores/query'
import { useSessionStore } from '@/stores/session'

function testLayer(): LayerDefinition {
  return {
    id: 'hazard.test',
    label: '测试危险点',
    theme: 'hazard',
    datasetId: 'dataset.test',
    geometryType: 'Point',
    source: { type: 'geojson', url: 'features/test.geojson', outputCrs: 'EPSG:4326' },
    fields: [],
    defaultVisible: true,
    defaultOpacity: 1,
    availableTimes: [],
    legendId: 'legend.test',
    queryable: true,
    exportFormats: ['csv'],
    sourceCrs: 'EPSG:4326',
  }
}

function capabilities(mode: 'api' | 'mock', queryEnabled: boolean): Capabilities {
  return {
    readLayers: true,
    attributeQuery: queryEnabled,
    spatialQuery: queryEnabled,
    readResults: true,
    exportFormats: ['csv', 'geojson'],
    authEnabled: false,
    routeRecompute: false,
    analysisSubmit: false,
    dataEdit: false,
    backupExecute: false,
    reasons: queryEnabled
      ? {}
      : {
          attributeQuery: '属性筛选查询尚未接入。',
          spatialQuery: '空间查询尚未接入。',
        },
    mode,
    snapshotId: mode === 'api' ? 'live-db-readonly' : 'demo-v1',
  }
}

function mountPanel() {
  const map = useMapStore()
  map.applyRegistry([testLayer()])
  const query = useQueryStore()
  query.setLayer('hazard.test')

  return mount(QueryPanel, {
    props: { dictionaries: {}, regions: [], drawMode: 'none' },
    global: {
      stubs: {
        QueryFilterPanel: true,
        QuerySpatialPanel: true,
        QueryResultTable: true,
      },
    },
  })
}

beforeEach(() => {
  setActivePinia(createPinia())
})

describe('QueryPanel：正式接口能力边界', () => {
  it('API 的属性与空间查询均关闭时停用运行按钮，且不触发查询', async () => {
    const session = useSessionStore()
    session.mode = 'api'
    session.status = 'ready'
    session.capabilities = capabilities('api', false)

    const query = useQueryStore()
    const run = vi.spyOn(query, 'run')
    const wrapper = mountPanel()

    const notice = wrapper.get('[data-testid="query-capability-notice"]')
    expect(notice.text()).toContain('当前暂未提供属性筛选与空间查询')
    expect(wrapper.get('[data-testid="run-query"]').attributes('disabled')).toBeDefined()

    await wrapper.get('[data-testid="run-query"]').trigger('click')
    expect(run).not.toHaveBeenCalled()
    wrapper.unmount()
  })

  it('mock 能力开启时保留运行按钮，未把 API 的占位策略带入示例模式', () => {
    const session = useSessionStore()
    session.mode = 'mock'
    session.status = 'ready'
    session.capabilities = capabilities('mock', true)

    const wrapper = mountPanel()

    expect(wrapper.find('[data-testid="query-capability-notice"]').exists()).toBe(false)
    expect(wrapper.get('[data-testid="run-query"]').attributes('disabled')).toBeUndefined()
    wrapper.unmount()
  })
})
