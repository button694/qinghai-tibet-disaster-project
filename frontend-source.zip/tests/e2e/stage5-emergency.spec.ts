import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段5（应急保障）浏览器用例。
 *
 * 覆盖：方案 A/B/C 切换（旧状态清空）、起终点/距离/时间/网络版本/阻断/风险段/资源、
 * 无可达路径专用状态（不画直线）、只读条件说明、深度链接 routeId、
 * 1366/390 布局、示例数据标识。
 *
 * 数据口径（示例包 routes.json）：
 * DEMO-ROUTE-A 主方案可达（无耗时）、DEMO-ROUTE-B 备选可达（12600 秒）、
 * DEMO-ROUTE-C 备选不可达（几何 null、阻断 DEMO-ROAD-02）。
 */

async function openEmergency(page: Page, query = ''): Promise<void> {
  await page.goto(`/analysis/emergency${query}`)
  await expect(page.getByTestId('emergency-page')).toBeVisible()
  await expect(page.getByTestId('emergency-pending-banner')).toBeVisible()
  await expect(page.getByTestId('route-plans')).toBeVisible()
}

test('方案清单与默认选中：A 主方案可达、起终点与距离来源可见', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await openEmergency(page)

  await expect(page.getByTestId('plan-DEMO-ROUTE-A')).toContainText('主方案')
  await expect(page.getByTestId('plan-DEMO-ROUTE-B')).toContainText('备选')
  await expect(page.getByTestId('plan-DEMO-ROUTE-C')).toContainText('不可达')

  // 默认选中第一个方案（A）
  await expect(page.getByTestId('route-info')).toContainText('示例路线 A')
  await expect(page.getByTestId('route-distance')).toContainText('米')
  await expect(page.getByTestId('route-distance-source')).toContainText('已存成果')
  // A 方案成果未登记通行时间 → 「未提供」+ 原因，绝不按距离估算
  await expect(page.getByTestId('route-duration')).toHaveText('未提供')
  await expect(page.getByTestId('route-duration-source')).toContainText('null')
  await expect(page.getByTestId('route-info')).toContainText('demo-road-network-v1')

  // 示例身份持续可见
  await expect(page.getByTestId('route-info')).toContainText('示例数据')
  // 只读说明（routeRecompute=false）
  await expect(page.getByTestId('route-readonly-note')).toBeVisible()
})

test('方案切换：旧状态同步清空，B 方案出现耗时与风险段', async ({ page }) => {
  await openEmergency(page)
  const map = page.getByTestId('route-map')

  await page.getByTestId('plan-DEMO-ROUTE-B').click()
  // store 层的「先清空后装载」由单元测试覆盖；这里断言最终态不含旧方案痕迹。
  await expect(page.getByTestId('route-info')).toContainText('示例路线 B')
  await expect(page.getByTestId('route-info')).not.toContainText('示例路线 A')
  await expect(page.getByTestId('route-duration')).toContainText('时')
  await expect(page.getByTestId('route-info')).toContainText('12600')
  await expect(page.getByTestId('route-info')).toContainText('穿越示例影响范围 03')
  await expect(map).toHaveAttribute('data-line', '1')

  // 切到 C（不可达）再切回 B：地图重新画线
  await page.getByTestId('plan-DEMO-ROUTE-C').click()
  await expect(map).toHaveAttribute('data-line', '0')
  await page.getByTestId('plan-DEMO-ROUTE-B').click()
  await expect(map).toHaveAttribute('data-line', '1')
})

test('无可达路径：专用状态块，无距离无耗时，阻断点来自真实引用', async ({ page }) => {
  await openEmergency(page, '?resultId=result.demo.route&routeId=DEMO-ROUTE-C')

  // 深链接直达 C 方案
  await expect(page.getByTestId('route-info')).toContainText('示例路线 C')
  await expect(page.getByTestId('route-unreachable')).toBeVisible()
  await expect(page.getByTestId('route-distance')).toHaveText('未提供')
  await expect(page.getByTestId('route-duration')).toHaveText('未提供')
  // 地图不画线（data-line=0），阻断点要素（emg.road/DEMO-ROAD-02）经真实关联上图
  await expect(page.getByTestId('route-map')).toHaveAttribute('data-line', '0')
  await expect(page.getByTestId('route-info')).toContainText('DEMO-ROAD-02')
})

test('阻断条件只读：无重算入口，条件说明写明来自既有方案', async ({ page }) => {
  await openEmergency(page)
  await page.getByTestId('plan-DEMO-ROUTE-C').click()
  await expect(page.getByTestId('route-info')).toContainText('阻断条件')
  await expect(page.getByTestId('route-readonly-note')).toContainText('既有方案')
  // 页面上不存在任何「重算/提交」按钮
  await expect(
    page.getByTestId('emergency-page').getByRole('button', { name: /重算|重新计算|提交/ }),
  ).toHaveCount(0)
})

test('上下文回链：应急 → 暴露（携带 hazard）', async ({ page }) => {
  await openEmergency(page, '?hazard=hazard.landslide:DEMO-LS-02')
  await page.getByTestId('to-exposure').click()
  await expect(page.getByTestId('exposure-page')).toBeVisible()
  await expect(page.getByTestId('exposure-hazard-line')).toContainText('示例地质灾害点 02')
})

test('1366×768：无横向溢出', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openEmergency(page)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
  const map = page.getByTestId('route-map')
  const box = await map.boundingBox()
  expect(box?.height ?? 0).toBeGreaterThan(240)
})

test('390 宽：可完成方案切换与来源阅读，无横向溢出', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await openEmergency(page)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )

  await page.getByTestId('plan-DEMO-ROUTE-B').click()
  await expect(page.getByTestId('route-info')).toContainText('示例路线 B')
  await page.getByTestId('emergency-footer').scrollIntoViewIfNeeded()
  await expect(page.getByTestId('emergency-footer')).toContainText('只读')
})

test('1920×1080 截图留档', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openEmergency(page, '?resultId=result.demo.route&routeId=DEMO-ROUTE-C')
  await expect(page.getByTestId('route-unreachable')).toBeVisible()
  await page.screenshot({ path: testInfo.outputPath('emergency-1920.png'), fullPage: true })
})

test('390 宽截图留档', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await openEmergency(page)
  await expect(page.getByTestId('route-info')).toContainText('示例路线 A')
  await page.screenshot({ path: testInfo.outputPath('emergency-390.png'), fullPage: true })
})
