import { expect, test } from '@playwright/test'

/**
 * 阶段0 端到端范围：外壳可打开、一级导航可切换、404 生效、数据模式标识存在。
 * 业务功能（地图、查询、成果）尚不存在，因此这里不做任何业务断言。
 */
test('总览页可打开并显示应用外壳', async ({ page }) => {
  await page.goto('/')
  await expect(page).toHaveURL(/\/overview$/)
  await expect(page.getByRole('heading', { name: '总览', level: 1 })).toBeVisible()
  await expect(page.getByText('青藏高原地质灾害风险平台')).toBeVisible()
})

test('数据模式标识在界面持续可见', async ({ page }) => {
  await page.goto('/overview')
  await expect(page.getByTestId('mode-badge')).toHaveText('示例数据')
})

test('一级导航可切换到每个已注册页面', async ({ page }) => {
  await page.goto('/overview')

  const targets: Array<[string, string, RegExp]> = [
    ['风险一张图', '风险一张图', /\/map$/],
    ['专题研判', '风险研判', /\/analysis\/risk$/],
    ['成果中心', '成果中心', /\/results$/],
    ['数据目录', '数据目录', /\/catalog$/],
    ['项目说明', '项目说明', /\/about$/],
    ['总览', '总览', /\/overview$/],
  ]

  for (const [linkText, heading, url] of targets) {
    await page.getByRole('link', { name: linkText, exact: true }).click()
    await expect(page).toHaveURL(url)
    await expect(page.getByRole('heading', { name: heading, level: 1 })).toBeVisible()
    await expect(page.getByRole('link', { name: linkText, exact: true })).toHaveClass(/is-active/)
    await expect(page.locator('.nav-link.is-active')).toHaveCount(1)
    await expect(page.getByTestId('mode-badge')).toHaveText('示例数据')
  }
})

test('未知路径显示 404 且可返回总览', async ({ page }) => {
  await page.goto('/no-such-page/abc')
  await expect(page.getByTestId('not-found')).toBeVisible()
  await expect(page.getByTestId('not-found-path')).toHaveText('/no-such-page/abc')

  await page.getByRole('link', { name: '返回总览' }).click()
  await expect(page).toHaveURL(/\/overview$/)
})

test('带参数路由深链接刷新后仍能解析参数（阶段6 起详情页真实取数）', async ({ page }) => {
  for (const [path, nameTestid] of [
    ['/results/result.demo.risk', 'result-detail-name'],
    ['/catalog/demo-ds-glacier', 'catalog-detail-name'],
  ] as const) {
    await page.goto(path)
    await expect(page.getByTestId(nameTestid)).toBeVisible()
    await page.reload()
    await expect(page.getByTestId(nameTestid)).toBeVisible()
  }
})
