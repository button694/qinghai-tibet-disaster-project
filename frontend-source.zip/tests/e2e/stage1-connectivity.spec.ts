import { expect, test } from '@playwright/test'

/**
 * 阶段1 端到端范围：数据接入自检面板在两种数据模式下的行为（D-033）。
 *
 * 覆盖阶段1 的三条验收句：
 * 1. 共用视觉和数据层——面板走 `OverviewRepository`，指标卡、来源徽标与状态组件全部来自 `components/ui`；
 * 2. 模式只改配置——两个服务跑同一份代码，只有 `VITE_DATA_MODE` 不同，页面代码零改动；
 * 3. HTTP 未连接显示失败而非示例统计——api 模式且后端未接通时显示错误码，不出现任何示例统计。
 *
 * 本文件不做业务断言：地图、查询、成果等业务功能属于阶段2 以后。
 */

/** 第二个开发服务以 api 模式启动，端口见 playwright.stage1.config.ts。 */
const API_ORIGIN = 'http://127.0.0.1:16399'

test('示例模式：面板真实取数，示例身份与来源可追溯', async ({ page }, testInfo) => {
  await page.goto('/overview')

  await page.getByTestId('overview-diagnostics').locator(':scope > summary').click()

  const panel = page.getByTestId('connectivity-panel')
  await expect(panel).toBeVisible()

  // 取数成功：出现指标卡，并且不是空状态、也不是错误状态。
  await expect(panel.getByTestId('metric-card').first()).toBeVisible()
  await expect(panel.getByTestId('error-state')).toHaveCount(0)
  await expect(panel.getByTestId('empty-state')).toHaveCount(0)

  // 示例身份持续可见：外壳徽标与面板来源徽标都指向示例模式。
  await expect(page.getByTestId('mode-badge')).toHaveText('示例数据')
  await expect(panel.getByTestId('source-badge').first()).toHaveAttribute('data-mode', 'mock')

  // 来源可追溯：列出数据包标识与边界版本，说明数字从何而来。
  await expect(panel).toContainText('数据包 / 快照标识')
  await expect(panel).toContainText('demo-v1')
  await expect(panel).toContainText('边界版本')

  // 运行截图（不是设计图），作为阶段1 的界面证据留存。
  await page.screenshot({ path: testInfo.outputPath('stage1-mock-overview.png'), fullPage: true })
})

test('api 模式且后端未接通：显示错误状态，不出现任何示例统计', async ({ page }, testInfo) => {
  await page.goto(`${API_ORIGIN}/overview`)

  const panel = page.getByTestId('connectivity-panel')
  await expect(panel).toBeVisible()

  // 失败即失败：显示错误状态与错误码，并写明没有回退示例数据。
  const errorState = panel.getByTestId('error-state')
  await expect(errorState).toBeVisible()
  await expect(errorState).toContainText('错误码：')
  await expect(errorState).toContainText('不会改用示例数据')

  // 不回退示例统计：没有指标卡、没有风险分布表、没有来源追溯列表。
  await expect(panel.getByTestId('metric-card')).toHaveCount(0)
  await expect(panel.locator('.dist-table')).toHaveCount(0)
  await expect(panel.locator('.prov-list')).toHaveCount(0)

  // 模式标识按配置切换，不残留示例身份。
  await expect(page.getByTestId('mode-badge')).toHaveText('正式接口')
  await expect(panel.getByTestId('source-badge').first()).toHaveAttribute('data-mode', 'api')

  await page.screenshot({ path: testInfo.outputPath('stage1-api-error.png'), fullPage: true })
})
