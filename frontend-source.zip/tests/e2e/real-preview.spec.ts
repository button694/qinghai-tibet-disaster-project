import { expect, test } from '@playwright/test'

for (const width of [1920, 1366, 390]) {
  test(`真实预览与视觉回归 ${width}`, async ({ page }, info) => {
    await page.setViewportSize({ width, height: width === 1920 ? 1080 : 844 })
    const errors: string[] = []
    page.on('pageerror', (e) => errors.push(e.message))
    await page.route('**/*', (route) =>
      new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort(),
    )
    await page.goto('/overview')
    await expect(page.getByTestId('overview-metric-riskZoneCount')).toBeVisible()
    expect(
      await page.evaluate(() =>
        getComputedStyle(document.documentElement).getPropertyValue('--color-shell').trim(),
      ),
    ).toBe('#101d2b')
    await expect(page.locator('.shell-header')).toHaveCSS('background-color', 'rgb(16, 29, 43)')
    const clipped = await page
      .getByTestId('risk-badge')
      .evaluateAll((elements) => elements.filter((e) => e.scrollWidth > e.clientWidth).length)
    expect(clipped).toBe(0)
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
    await page.screenshot({ path: info.outputPath(`overview-${width}.png`), fullPage: true })
    // 阶段6 总览改版后，真实预览入口改为总览页「专题入口」面板内的文字链接
    await page.getByRole('link', { name: '打开真实数据预览' }).click()
    await expect(page.getByTestId('mode-badge')).toHaveText('真实文件预览 · 只读')
    await expect(page.getByTestId('real-map-status')).toContainText('601 条')
    await expect(page.locator('.real-stats')).toContainText('465,816')
    await expect(page.locator('.map-canvas canvas').first()).toBeVisible()
    await page.getByLabel('显示图层', { exact: true }).selectOption('scenario2100')
    await expect(page.getByTestId('real-map-status')).toContainText('652 条')
    await page.getByLabel('显示图层', { exact: true }).selectOption('hospitals')
    await expect(page.getByTestId('real-map-status')).toContainText('1,529 条')
    await page.getByLabel('透明度', { exact: true }).fill('0.4')
    await page.getByRole('button', { name: '定位全部' }).click()
    await page.getByLabel('数据类型', { exact: true }).selectOption('raster')
    await page.getByLabel('搜索真实数据集').fill('PRECIP')
    await expect(page.locator('.pager')).toContainText('共 23 项')
    await page.getByRole('button', { name: '下一页' }).click()
    await expect(page.locator('tbody tr')).toHaveCount(11)
    await page.getByLabel('搜索真实数据集').fill('DOES_NOT_EXIST')
    await expect(page.getByText('没有匹配的数据集。')).toBeVisible()
    await page.getByLabel('搜索真实数据集').fill('')
    expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
    await page.screenshot({ path: info.outputPath(`real-preview-${width}.png`), fullPage: true })
    await page.reload()
    await expect(page.getByTestId('real-map-status')).toContainText('601 条')
    await page.getByRole('link', { name: '总览', exact: true }).click()
    await expect(page.getByTestId('mode-badge')).toHaveText('示例数据')
    expect(errors).toEqual([])
  })
}

test('真实清单失败不显示示例数据，重试可恢复', async ({ page }) => {
  await page.route('**/real-preview/manifest.json', (route) =>
    route.fulfill({ status: 503, body: '{}' }),
  )
  await page.goto('/real-preview')
  await expect(page.getByRole('alert')).toContainText('读取失败')
  await expect(page.locator('.real-stats')).toHaveCount(0)
  await page.unroute('**/real-preview/manifest.json')
  await page.getByRole('button', { name: '重新读取' }).click()
  await expect(page.getByTestId('real-map-status')).toContainText('601 条')
})

test('图层失败清空旧层，重试恢复', async ({ page }) => {
  await page.goto('/real-preview')
  await expect(page.getByTestId('real-map-status')).toContainText('601 条')
  await page.route('**/real-preview/hospitals.json', (route) =>
    route.fulfill({ status: 500, body: '{}' }),
  )
  await page.getByLabel('显示图层', { exact: true }).selectOption('hospitals')
  await expect(page.getByTestId('real-map-status')).toContainText('加载失败')
  await expect(page.locator('.feature-panel')).toContainText('点击青色点')
  await page.unroute('**/real-preview/hospitals.json')
  await page.getByRole('button', { name: '重试图层' }).click()
  await expect(page.getByTestId('real-map-status')).toContainText('1,529 条')
})

test('点击真实点返回原始属性', async ({ page }) => {
  await page.goto('/real-preview')
  await expect(page.getByTestId('real-map-status')).toContainText('601 条')
  await page.locator('.map-canvas').scrollIntoViewIfNeeded()
  // Locate a rendered cyan point, not an arbitrary screen coordinate or a test-only app API.
  const point = await page.locator('.map-canvas').evaluate((host) => {
    const viewport = host.getBoundingClientRect()
    for (const canvas of host.querySelectorAll('canvas')) {
      const context = canvas.getContext('2d')
      if (!context) continue
      const pixels = context.getImageData(0, 0, canvas.width, canvas.height).data
      const rect = canvas.getBoundingClientRect()
      for (let y = 0; y < canvas.height; y += 2) {
        for (let x = 0; x < canvas.width; x += 2) {
          const i = (y * canvas.width + x) * 4
          const red = pixels[i] ?? 0,
            green = pixels[i + 1] ?? 0,
            blue = pixels[i + 2] ?? 0
          const px = rect.left + (x * rect.width) / canvas.width
          const py = rect.top + (y * rect.height) / canvas.height
          if (
            green - red > 70 &&
            blue - red > 60 &&
            green > 150 &&
            px > viewport.left + 30 &&
            px < viewport.right - 10 &&
            py > viewport.top + 40 &&
            py < viewport.bottom - 10
          )
            return { x: px, y: py }
        }
      }
    }
    return null
  })
  expect(point).not.toBeNull()
  await page.mouse.click(point!.x, point!.y)
  await expect(page.locator('.feature-panel dl')).toContainText('rrgi')
  await expect(page.locator('.feature-panel dl')).toContainText('glacier_id')
})
