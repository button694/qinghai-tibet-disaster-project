﻿import { expect, test } from '@playwright/test'

// 本次验收追加证据；不写入 docs/screenshots 或旧验收目录。
for (const width of [1366, 1920]) {
  test(`阶段0全路由与视口 ${width}`, async ({ page }, testInfo) => {
    await page.setViewportSize({ width, height: width === 1366 ? 768 : 1080 })
    const errors: string[] = []
    const external: string[] = []
    page.on('pageerror', (error) => errors.push(error.message))
    page.on('console', (message) => {
      if (message.type() === 'error') errors.push(message.text())
    })
    await page.route('**/*', async (route) => {
      if (new URL(route.request().url()).hostname !== '127.0.0.1') {
        external.push(route.request().url())
        await route.abort()
      } else await route.continue()
    })
    const paths = [
      '/overview',
      '/map',
      '/analysis/risk',
      '/analysis/exposure',
      '/analysis/emergency',
      '/results',
      '/results/audit-result',
      '/catalog',
      '/catalog/audit-dataset',
      '/about',
      '/missing-audit',
    ]
    for (const [index, path] of paths.entries()) {
      await page.goto(path)
      await page.reload()
      await expect(page.getByRole('heading', { level: 1 })).toBeVisible()
      await expect(page.getByTestId('mode-badge')).toHaveText('示例数据')
      // 页脚必须如实说明数据库恢复事实、首批只读API状态与尚未完成的主链路。
      await expect(page.locator('.shell-footer')).toContainText('QTP_GEOHAZARD 数据库已恢复')
      await expect(page.locator('.shell-footer')).toContainText('首批只读 HTTP API 已接通')
      await expect(page.locator('.shell-footer')).toContainText('尚未完成')
      expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(
        true,
      )
      if (path.startsWith('/analysis/')) {
        await expect(page.getByRole('link', { name: '专题研判' })).toHaveClass(/is-active/)
      }
      await page.screenshot({ path: testInfo.outputPath(`${index}-${width}.png`), fullPage: true })
    }
    expect(errors).toEqual([])
    expect(external).toEqual([])
  })
}
