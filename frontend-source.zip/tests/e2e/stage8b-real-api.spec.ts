/**
 * 阶段8B：真实API垂直链路 E2E（独立验收证据）。
 *
 * 前提（由 playwright.stage8b-real-api.config.ts 保证）：
 * - 后端 qtp-risk-api 从干净进程启动（reuseExistingServer: false，独占 18080）；
 * - 前端以 VITE_DATA_MODE=api + VITE_API_BASE_URL 从干净进程启动（独占 16580）。
 *
 * 覆盖：API 身份持续可见、真实数量（57 数据集/1529 医院/4566 路线）、
 * SYS_DATASET 真实图层、数据库真实要素详情、QTP_RESULT 真实路线详情、
 * EPSG:4326 GeoJSON、禁出字段、停服错误态且无 mock 数字、未接入能力显式说明、
 * 正常流程 pageerror/console error 为 0。
 *
 * 口径说明：console/pageerror 计数为 0 只约束「正常浏览」用例；「停服错误态」
 * 用例按定义会制造网络中断（浏览器必然产生资源加载错误），不计入。
 */
import { expect, test, type Page, type Response } from '@playwright/test'

const FORBIDDEN_SUBSTRINGS = [
  'FILE_PATH',
  'SOURCE_FILE_PATH',
  'SOURCE_GDB',
  'SQLEXPRESS',
  'QTP_GEOHAZARD',
  'Trusted_Connection',
]

interface ErrorCollector {
  consoleErrors: string[]
  pageErrors: string[]
  responses: Response[]
}

function attachCollector(page: Page): ErrorCollector {
  const collector: ErrorCollector = {
    consoleErrors: [],
    pageErrors: [],
    responses: [],
  }
  page.on('console', (message) => {
    if (message.type() === 'error') collector.consoleErrors.push(message.text())
  })
  page.on('pageerror', (error) => {
    collector.pageErrors.push(String(error))
  })
  page.on('response', (response) => {
    if (response.url().includes('/api/v1/')) collector.responses.push(response)
  })
  return collector
}

function assertNoForbidden(text: string): void {
  for (const needle of FORBIDDEN_SUBSTRINGS) {
    expect(text, `响应/页面不得包含 ${needle}`).not.toContain(needle)
  }
}

/**
 * 页面 DOM 扫描：与响应扫描相比豁免 "QTP_GEOHAZARD"——
 * 页脚的「QTP_GEOHAZARD 已恢复并确认存在正式成果表；……正式 HTTP 接口待发布/待联调」
 * 是阶段8A 规定的页面状态句式（明示待联调身份，非连接信息）。
 */
function assertPageNoForbidden(text: string): void {
  for (const needle of FORBIDDEN_SUBSTRINGS) {
    if (needle === 'QTP_GEOHAZARD') continue
    expect(text, `页面不得包含 ${needle}`).not.toContain(needle)
  }
}

test.describe('阶段8B 真实API垂直链路', () => {
  test('真实主地图按服务端分页完整加载，并分别显示源总数与实际渲染数', async ({
    page,
  }, testInfo) => {
    const badResponses: number[] = []
    page.on('response', (response) => {
      if (response.url().includes('/queries') && response.status() >= 400)
        badResponses.push(response.status())
    })
    await page.goto('/map')
    // API 地图默认按服务端分页完整加载正式易发性成果点；单页保护不改变用户可见总数。
    await expect(page.getByTestId('visible-DS_RES_SUSCEPTIBILITY_PT')).toBeChecked()
    await expect(page.getByTestId('layer-DS_RES_SUSCEPTIBILITY_PT')).toContainText('共 1582 条')
    await expect(page.getByTestId('layer-DS_RES_SUSCEPTIBILITY_PT')).toContainText(
      '已显示 1582 / 共 1582',
    )
    await expect(page.getByTestId('status-visible')).toContainText('已渲染要素 1582')
    await page.getByTestId('visible-DS_BASE_QTP_BOUNDARY').check()
    await page.getByTestId('visible-DS_EMG_AMAP_HOSPITAL').check()
    await expect(page.getByTestId('status-visible')).toContainText('已渲染要素 2594')
    await expect(page.getByTestId('layer-DS_EMG_AMAP_HOSPITAL')).toContainText('共 1529 条')
    await expect(page.getByTestId('layer-DS_EMG_AMAP_HOSPITAL')).toContainText(
      '已显示 1006 / 去重 1529 / 源总 1529',
    )
    expect(badResponses).toEqual([])
    await page.screenshot({
      path: testInfo.outputPath('real-map-full-pagination.png'),
      fullPage: true,
    })
  })

  test('真实总览页展示库内真实指标与分布（不再是501）', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/overview')
    await expect(page.getByTestId('overview-page')).toBeVisible()
    // 四项主指标全部来自真实表计数
    await expect(page.getByTestId('overview-metric-pointCount')).toContainText('1582')
    await expect(page.getByTestId('overview-metric-routeCount')).toContainText('4566')
    await expect(page.getByTestId('overview-metric-hospitalCount')).toContainText('1529')
    await expect(page.getByTestId('overview-metric-datasetCount')).toContainText('57')
    // 风险分布为库内 HAZ_LEVEL 实测（极高24/高288/中1270）
    await expect(page.getByTestId('overview-distribution')).toContainText('极高')
    await expect(page.getByTestId('overview-distribution')).toContainText('24')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('正式风险研判分页展示全部易发性点，并区分当前页与地图全量', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/analysis/risk')
    await expect(page.getByTestId('formal-risk-result')).toBeVisible({ timeout: 20000 })
    await expect(page.getByTestId('formal-risk-total')).toContainText('1582')
    await expect(page.getByTestId('formal-risk-rendered')).toContainText('200')
    await expect(page.getByTestId('formal-risk-result')).toContainText('HAZ_LEVEL')
    await expect(page.getByTestId('formal-risk-result')).toContainText('SCORE')
    await expect(page.getByTestId('formal-risk-result')).toContainText('表格当前页外尚有')
    await expect(page.getByTestId('formal-risk-method')).toContainText('CatBoost')
    await expect(page.getByTestId('formal-risk-method')).toContainText('SHAP')
    await expect(page.getByTestId('formal-risk-method')).toContainText('§5.4.1')
    await page.getByTestId('formal-risk-next').click()
    await expect(page.getByTestId('formal-risk-page')).toContainText('第 2 / 8 页')
    await expect(page.getByTestId('formal-risk-rendered')).toContainText('200')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('正式 API 风险专题图保留当前真实点页；暴露专题打印明确规划', async ({ page }) => {
    const resultResponse = page.waitForResponse(
      (response) =>
        response.url().includes('/api/v1/results/result.susceptibility.combined') && response.ok(),
    )
    await page.goto('/print/risk')
    const resultBody = (await resultResponse).json() as Promise<{
      data: { classification: unknown }
    }>
    const classification = (await resultBody).data.classification
    await expect(page.getByTestId('print-page')).toBeVisible()
    await expect(page.getByTestId('print-sheet')).toBeVisible({ timeout: 20000 })
    await expect(page.getByTestId('print-identity')).toContainText('正式 API')
    await expect(page.getByTestId('print-notes')).toContainText('当前页')
    if (classification === null) {
      await expect(page.getByTestId('print-legend')).toContainText('颜色不表示分级')
    } else {
      await expect(page.getByTestId('print-legend')).toContainText('低')
      await expect(page.getByTestId('print-legend')).toContainText('极高')
      await expect(page.getByTestId('print-notes')).toContainText('分级边界规则')
    }
    await expect(page.getByTestId('print-map-image')).toBeVisible()

    await page.goto('/print/exposure')
    await expect(page.getByTestId('print-planning')).toBeVisible()
    await expect(page.getByTestId('print-planning')).toContainText('完整影响范围')
    await expect(page.getByTestId('print-error')).toHaveCount(0)
  })

  test('正式风险研判保留外部情景入口，默认不把静态快照当作API成果', async ({ page }) => {
    await page.goto('/analysis/risk')
    await expect(page.getByTestId('formal-risk-result')).toBeVisible({ timeout: 20000 })
    await expect(page.getByTestId('source-kind-projectAnalysis')).toBeChecked()
    await page.goto('/analysis/risk?source=externalScenario')
    await expect(page.getByTestId('source-kind-externalScenario')).toBeChecked()
    await expect(page.getByTestId('risk-map-2050').locator('canvas').first()).toBeVisible()
    await expect(page.getByTestId('project-analysis-pending')).toHaveCount(0)
  })

  test('成果中心显示受控登记的真实成果（4项）', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/results')
    await expect(page.getByTestId('results-page')).toBeVisible()
    await expect(page.getByTestId('results-count')).toContainText('4')
    await expect(page.locator('main')).toContainText('易发性点成果')
    await expect(page.locator('main')).toContainText('综合救援路线成果')
    // 情景成果标注未来情景身份
    await expect(page.locator('main')).toContainText('2050')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('应急页真实链路：按危险源分组方案 + 角色未登记 + 多玛乡卫生院终点', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/analysis/emergency')
    await expect(page.getByTestId('emergency-page')).toBeVisible()
    // 应急成果清单为真实登记（不再是501），默认选中排序第一的 2050 情景路线成果
    await expect(page.locator('main')).toContainText('2050 情景救援路线成果')
    // 方案按同一危险源分组：同组 3 条（医院/消防站/救援站），角色未登记如实显示
    await expect(page.getByTestId('route-info')).toBeVisible({ timeout: 20000 })
    await expect(page.locator('main')).toContainText('角色未登记')
    // 库内样例 QR2050_00000001 → 多玛乡卫生院（终点设施白名单映射）
    await expect(page.locator('main')).toContainText('多玛乡卫生院')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('API分页路线任意详情可携带 routeId 深链接并保持同组', async ({ page }) => {
    await page.goto('/api-data')
    await page.getByTestId('api-route-0').click()
    await expect(page.getByTestId('api-route-detail')).toBeVisible()
    const link = page.getByTestId('api-route-workspace-link')
    const href = await link.getAttribute('href')
    expect(href).toBeTruthy()
    const target = new URL(href ?? '', 'http://127.0.0.1:16580')
    expect(target.pathname).toBe('/analysis/emergency')
    expect(target.searchParams.get('resultId')).toBe('result.route.combined')
    expect(target.searchParams.get('routeId')).toMatch(/^result\.route\.combined:/)
  })

  test('API应急深链接指定2050第二条路线，不静默换成第一条', async ({ page }) => {
    await page.goto(
      '/analysis/emergency?resultId=result.route.2050&routeId=result.route.2050:QR2050_00000002',
    )
    await expect(page.getByTestId('route-info')).toBeVisible({ timeout: 20000 })
    await expect(page.getByTestId('route-id')).toContainText('QR2050_00000002')
    await expect(page.getByTestId('route-distance')).toContainText('1200841 米')
    await expect(page.locator('main')).not.toContainText('QR2050_00000001')
  })

  test('API暴露页显示后续深化规划，不自动请求501或展示伪统计', async ({ page }) => {
    const exposureRequests: string[] = []
    page.on('request', (request) => {
      if (
        request.url().includes('/api/v1/results/') &&
        (request.url().includes('/exposure-summary') ||
          request.url().includes('/affected-features'))
      ) {
        exposureRequests.push(request.url())
      }
    })
    await page.goto('/analysis/exposure')
    await expect(page.getByTestId('exposure-page')).toBeVisible()
    await expect(page.getByTestId('exposure-planning')).toBeVisible()
    await expect(page.getByTestId('exposure-planning')).toContainText('后续深化方向')
    await expect(page.getByTestId('exposure-planning')).toContainText('完整影响范围')
    await expect(page.getByTestId('exposure-planning')).not.toContainText('错误码：')
    await expect(page.getByTestId('exposure-list-error')).toHaveCount(0)
    expect(exposureRequests, 'API 暴露规划页不应自动请求未接入端点').toEqual([])
  })

  test('后端健康检查与 API 模式身份持续可见', async ({ page }) => {
    const collector = attachCollector(page)

    // 后端从干净进程启动且数据库可达
    const health = await page.request.get('http://127.0.0.1:18080/health')
    expect(health.ok()).toBeTruthy()
    const healthBody = (await health.json()) as {
      status: string
      database: string
      version: string
    }
    expect(healthBody.status).toBe('ok')
    expect(healthBody.database).toBe('up')
    assertNoForbidden(JSON.stringify(healthBody))

    // 直接进入 API 数据链路页（不经过会触发 501 能力的页面，保持 console 干净）
    await page.goto('/api-data')
    // 顶栏仅显示面向客户的数据同步状态。
    await expect(page.getByTestId('mode-badge')).toHaveText('数据已同步')
    await expect(page.getByTestId('snapshot-id')).toHaveCount(0)
    // 数据链路页：客户化数据状态与可用功能说明
    await page.goto('/api-data')
    await expect(page.getByTestId('api-data-page')).toBeVisible()
    await expect(page.locator('#cap-title')).toContainText('功能状态')
    const capabilities = page.getByTestId('api-capabilities')
    await expect(capabilities).toContainText('可查看图层与要素')
    await expect(capabilities).toContainText('暂未提供')
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('数据目录显示数据库真实数量（57）而非示例 20 条', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/catalog')
    const count = page.getByTestId('catalog-count')
    await expect(count).toContainText('共 57 个数据集')
    // 目录行探测：白名单图层可预览，非白名单标「不可用」，不出现示例身份
    await expect(page.getByTestId('catalog-page')).not.toContainText('示例样区')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('真实图层、真实要素与 EPSG:4326 GeoJSON', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/api-data')

    // 图层来自 SYS_DATASET 真实登记
    const layerSelect = page.getByTestId('api-layer-select')
    await expect(layerSelect).toBeVisible()
    await expect(layerSelect.locator('option', { hasText: '医院' }).first()).toBeAttached()

    // 触发要素查询并捕获响应
    const queryPromise = page.waitForResponse(
      (response) =>
        response.url().includes('/api/v1/queries') &&
        response.request().method() === 'POST' &&
        response.ok(),
    )
    await layerSelect.selectOption({ index: 1 })
    const queryResponse = await queryPromise
    const queryBody = (await queryResponse.json()) as {
      data: {
        rows: {
          total: number
          items: Array<{ geometry: { type: string; coordinates: unknown } | null }>
        }
      }
      meta: { sourceCrs: string; outputCrs: string }
      requestId: string
    }
    expect(queryBody.data.rows.total).toBeGreaterThan(0)
    expect(queryBody.meta.sourceCrs).toBe('CGCS2000_Tibetan_Plateau_LCC')
    expect(queryBody.meta.outputCrs).toBe('EPSG:4326')
    expect(queryBody.requestId).toBeTruthy()

    // 浏览器收到的是 EPSG:4326（经度、纬度），不是 LCC 米制坐标
    const geometry = queryBody.data.rows.items
      .map((item) => item.geometry)
      .find((value) => value !== null)
    expect(geometry, '首页至少一条要素带几何').toBeTruthy()
    // 递归取第一个坐标点（Point/LineString/Polygon/MultiPolygon 通用）
    let node: unknown = (geometry as { coordinates: unknown }).coordinates
    while (Array.isArray(node) && Array.isArray((node as unknown[])[0]))
      node = (node as unknown[])[0]
    const [lon, lat] = node as number[]
    expect(Math.abs(lon)).toBeLessThanOrEqual(180)
    expect(Math.abs(lat)).toBeLessThanOrEqual(90)
    expect(lon).toBeGreaterThanOrEqual(60)
    expect(lon).toBeLessThanOrEqual(110)
    expect(lat).toBeGreaterThanOrEqual(20)
    expect(lat).toBeLessThanOrEqual(45)
    assertNoForbidden(await queryResponse.text())

    // 真实要素详情来自数据库
    const featuresTable = page.getByTestId('api-features-table')
    await expect(featuresTable).toBeVisible()
    await page.locator('[data-testid^="api-feature-"]').first().click()
    const detail = page.getByTestId('api-feature-detail')
    await expect(detail).toBeVisible()
    await expect(detail).toContainText('要素详情')
    await expect(detail).toContainText('EPSG:4326')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('真实路线服务端分页：首页/翻页/切成果，total 为真实总数', async ({ page }) => {
    const collector = attachCollector(page)
    await page.goto('/api-data')

    // 首次路线请求必须带 page=1&pageSize（服务端分页，非前端 slice）
    const firstRoutes = page.waitForResponse(
      (response) => response.url().includes('/routes') && response.ok(),
    )
    await expect(page.getByTestId('api-routes-pager')).toBeVisible()
    const firstResponse = await firstRoutes
    expect(firstResponse.url()).toContain('page=1')
    expect(firstResponse.url()).toMatch(/pageSize=\d+/)
    const firstBody = (await firstResponse.json()) as {
      data: { items: Array<{ id: string }>; total: number; page: number; pageSize: number }
    }
    expect(firstBody.data.page).toBe(1)
    // total=4566 是真实总数，不是 items.length
    expect(firstBody.data.total).toBe(4566)
    expect(firstBody.data.items.length).toBeLessThanOrEqual(firstBody.data.pageSize)
    // 单次路线列表响应体小于 500KB（此前全量 2.59MB）
    const bodyBytes = (await firstResponse.body()).byteLength
    expect(bodyBytes, `路线列表响应 ${bodyBytes} 字节应 < 500KB`).toBeLessThan(500 * 1024)
    assertNoForbidden(await firstResponse.text())

    // 页面显示总页数与真实 total，而非「数据库原样 4566 条全量」
    await expect(page.getByTestId('api-routes-total')).toHaveText('4566')
    await expect(page.getByTestId('api-routes-total-pages')).toHaveText('229')

    // 点击下一页 → 请求 page=2，两页路线不重复
    const secondRoutes = page.waitForResponse(
      (response) => response.url().includes('/routes') && response.url().includes('page=2'),
    )
    await page.getByTestId('api-routes-next').click()
    const secondResponse = await secondRoutes
    const secondBody = (await secondResponse.json()) as typeof firstBody
    expect(secondBody.data.page).toBe(2)
    expect(secondBody.data.total).toBe(4566)
    const ids1 = new Set(firstBody.data.items.map((item) => item.id))
    for (const item of secondBody.data.items) {
      expect(ids1.has(item.id), `第2页路线 ${item.id} 不得与第1页重复`).toBe(false)
    }

    // 打开路线详情：分页状态保持
    await page.locator('[data-testid="api-route-0"]').click()
    const detail = page.getByTestId('api-route-detail')
    await expect(detail).toBeVisible()
    await expect(detail).toContainText('路线详情')
    await expect(detail).toContainText(/距离：\d+(\.\d+)? 米/)
    await expect(detail).toContainText('未提供（数据库未登记）') // 通行时间 null 不补造
    await expect(detail).toContainText('EPSG:4326')
    await expect(page.getByTestId('api-routes-page')).toHaveText('2')
    await expect(page.getByTestId('api-routes-total')).toHaveText('4566')

    // 切换 2050 成果：页码回 1、total=1731（而非上一成果的 4566）
    const scope2050 = page.waitForResponse(
      (response) => response.url().includes('result.route.2050') && response.ok(),
    )
    await page.getByTestId('api-scope-select').selectOption('result.route.2050')
    const scopeResponse = await scope2050
    expect(scopeResponse.url()).toContain('page=1')
    const scopeBody = (await scopeResponse.json()) as typeof firstBody
    expect(scopeBody.data.total).toBe(1731)
    await expect(page.getByTestId('api-routes-page')).toHaveText('1')
    await expect(page.getByTestId('api-routes-total')).toHaveText('1731')
    assertPageNoForbidden(await page.content())
    expect(collector.consoleErrors).toEqual([])
    expect(collector.pageErrors).toEqual([])
  })

  test('页面加载期间不得请求完整路线列表（仅分页请求）', async ({ page }) => {
    const routeRequests: string[] = []
    page.on('request', (request) => {
      if (request.url().includes('/api/v1/') && request.url().includes('/routes')) {
        routeRequests.push(request.url())
      }
    })
    await page.goto('/api-data')
    await expect(page.getByTestId('api-routes-pager')).toBeVisible()
    // 所有 /routes 请求都必须带分页参数（不存在一次拉全 4566 条的请求）
    expect(routeRequests.length).toBeGreaterThan(0)
    for (const url of routeRequests) {
      expect(url, `路线请求 ${url} 必须带 page 参数`).toContain('page=')
      expect(url).toMatch(/pageSize=\d+/)
    }
  })

  test('API 数据链路页在桌面与手机视口无横向溢出并留存截图', async ({ page }) => {
    await page.goto('/api-data')
    await expect(page.getByTestId('api-datasets-total')).toContainText('57')
    await expect(page.getByTestId('api-routes-total')).toContainText('4566')

    for (const viewport of [
      { name: '1920', width: 1920, height: 1080 },
      { name: '390', width: 390, height: 844 },
    ]) {
      await page.setViewportSize({ width: viewport.width, height: viewport.height })
      await expect(page.getByTestId('api-data-page')).toBeVisible()
      const overflow = await page.evaluate(
        () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
      )
      expect(overflow, `API 数据页 ${viewport.name} 视口横向溢出`).toBeLessThanOrEqual(1)
      await page.screenshot({
        path: `docs/review-stage8b/api-data-${viewport.name}.png`,
        fullPage: true,
      })
    }
  })

  test('停止后端后出现错误态与重试入口，且不出现 mock 数字', async ({ page }) => {
    // 模拟后端停止：网络层断开所有 /api/v1 请求（等效服务中断）
    await page.route('**/api/v1/**', (route) => route.abort('connectionrefused'))
    await page.goto('/api-data')
    await expect(page.getByTestId('api-data-page')).toBeVisible()
    // 错误态：目录摘要与图层的失败说明 + 重试入口
    await expect(page.locator('.error-note').first()).toBeVisible()
    await expect(page.getByRole('button', { name: '重试' }).first()).toBeVisible()
    // 不出现真实数量，也不出现任何 mock 数字/路线（含 mock 示例身份）
    await expect(page.getByTestId('api-datasets-total')).toHaveCount(0)
    await expect(page.getByTestId('api-routes-total')).toHaveCount(0)
    await expect(page.getByTestId('api-routes-pager')).toHaveCount(0)
    await expect(page.getByTestId('api-data-page')).not.toContainText('result.demo.route')

    // 目录页同样错误态：不显示真实 57 也不显示示例 20
    await page.goto('/catalog')
    await expect(page.getByTestId('catalog-error')).toBeVisible()
    await expect(page.getByTestId('catalog-count')).not.toContainText('共 57 个数据集')
    await expect(page.getByTestId('catalog-count')).not.toContainText('共 20 个数据集')
    await expect(page.getByTestId('catalog-page')).not.toContainText('示例样区')
  })

  test('正式一张图开放真实属性查询，并保留服务端分页结果', async ({ page }) => {
    const badQueryResponses: number[] = []
    page.on('response', (response) => {
      if (response.url().includes('/api/v1/queries') && response.status() >= 400) {
        badQueryResponses.push(response.status())
      }
    })
    await page.goto('/map')
    await expect(page.getByTestId('layer-DS_RES_SUSCEPTIBILITY_PT')).toContainText('共 1582 条')
    await page.getByTestId('toggle-query').click()
    await expect(page.getByTestId('query-panel')).toBeVisible()
    await page.getByTestId('query-layer').selectOption('DS_EMG_AMAP_HOSPITAL')
    await page.getByTestId('run-query').click()
    await expect(page.getByTestId('query-panel')).toContainText('全部匹配 1529 条', {
      timeout: 20_000,
    })
    await expect(page.getByTestId('query-panel')).toContainText('第 1 / 77 页')
    await expect(page.getByTestId('query-capability-notice')).toHaveCount(0)
    expect(badQueryResponses).toEqual([])
  })

  test('真实栅格页加载现有 TIFF 像元预览且窄屏无横向溢出', async ({ page }) => {
    await page.goto('/rasters')
    await expect(page.getByTestId('raster-select')).toContainText('TNR_PERMAFROST_RS.tif')
    await expect(page.getByTestId('raster-metadata')).toContainText('TNR_PERMAFROST_RS', {
      timeout: 20_000,
    })
    await expect(page.getByTestId('raster-metadata')).toContainText('数据尺寸')
    await expect(page.getByTestId('raster-metadata')).toContainText('本次显示网格')
    await page.setViewportSize({ width: 390, height: 844 })
    await expect(page.getByTestId('raster-page')).toBeVisible()
    const overflow = await page.evaluate(
      () => document.documentElement.scrollWidth - document.documentElement.clientWidth,
    )
    expect(overflow).toBeLessThanOrEqual(1)
  })
})
