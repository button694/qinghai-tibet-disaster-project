import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段7（视觉和演示导出）浏览器用例。
 *
 * 覆盖：三类专题图打印信息完整与示例身份、演示导览前进/后退/退出、
 * 演示模式进入/退出、键盘焦点与 Enter/Esc、断网（屏蔽外部资源）运行、
 * 外部资源审计、1920/1366/390 三视口截图（等待业务内容加载完成后截图）。
 *
 * 断言方式与阶段2—6 一致：读界面真实状态与计数，不做整页截图比对。
 */

/* ------------------------------ 打印视图 ------------------------------ */

test.describe('阶段7 专题图打印', () => {
  const cases = [
    {
      kind: 'risk',
      url: '/print/risk?resultId=result.demo.risk',
      title: '风险分级专题图',
      legendText: '数据不足',
    },
    {
      kind: 'exposure',
      url: '/print/exposure?resultId=result.demo.impact',
      title: '暴露度与影响评估专题图',
      legendText: '影响范围',
    },
    {
      kind: 'emergency',
      url: '/print/emergency?resultId=result.demo.route&routeId=DEMO-ROUTE-B',
      title: '应急保障专题图',
      legendText: '主方案路线',
    },
  ] as const

  for (const item of cases) {
    test(`打印信息完整：${item.kind}`, async ({ page }) => {
      await page.goto(item.url)
      await expect(page.getByTestId('print-page')).toBeVisible()
      await expect(page.getByTestId('print-title')).toHaveText(item.title)
      await expect(page.getByTestId('print-region')).not.toBeEmpty()
      await expect(page.getByTestId('print-time')).not.toBeEmpty()
      await expect(page.getByTestId('print-method')).not.toBeEmpty()
      // 来源行 ≥1 条且非空（风险件为「输入（示例）」行，应急件为距离/时间来源行）
      await expect(page.locator('[data-testid="print-source"] li').first()).not.toBeEmpty()
      // 示例身份持续存在
      await expect(page.getByTestId('print-identity')).toContainText('示例')
      // 图例 ≥1 项，且包含该专题图的关键图例文字
      await expect(page.locator('[data-legend-item]').first()).toBeVisible()
      await expect(
        page.locator('[data-legend-item]').filter({ hasText: item.legendText }).first(),
      ).toBeVisible()
      // 地图快照成功（禁止看似成功的空白地图）：img 且比例尺已生成
      await expect(page.getByTestId('print-map-image')).toBeVisible()
      await expect(page.getByTestId('print-map-image')).toHaveAttribute('src', /^data:image\/png/)
      await expect(page.getByTestId('print-scale')).toContainText('比例尺')
      // 打印按钮可用、无地图失败警告
      await expect(page.getByTestId('print-button')).toBeEnabled()
      await expect(page.getByTestId('print-unavailable')).toBeHidden()
    })
  }

  test('应急 C 方案（无可达路径）：明确说明，不画线不造数字', async ({ page }) => {
    await page.goto('/print/emergency?resultId=result.demo.route&routeId=DEMO-ROUTE-C')
    await expect(page.getByTestId('print-title')).toHaveText('应急保障专题图')
    await expect(page.getByTestId('print-notes')).toContainText('无可达路径')
    await expect(page.getByTestId('print-identity')).toContainText('示例')
  })
})

/* ------------------------------ 演示导览与演示模式 ------------------------------ */

test.describe('阶段7 演示导览与演示模式', () => {
  test('导览：start → 前进 → 后退 → Esc 退出 → 手动退出', async ({ page }) => {
    await page.goto('/overview')
    await expect(page.getByTestId('overview-map')).toBeVisible()

    await page.getByTestId('tour-start').click()
    await expect(page.getByTestId('tour-panel')).toBeVisible()
    await expect(page.getByTestId('tour-progress')).toHaveText('1 / 6')
    await expect(page.getByTestId('tour-prev')).toBeDisabled()

    await page.getByTestId('tour-next').click()
    await expect(page).toHaveURL(/\/analysis\/risk$/)
    await expect(page.getByTestId('tour-progress')).toHaveText('2 / 6')

    await page.getByTestId('tour-next').click()
    await expect(page).toHaveURL(/resultId=result\.demo\.impact/)
    await expect(page.getByTestId('tour-progress')).toHaveText('3 / 6')

    await page.getByTestId('tour-prev').click()
    await expect(page).toHaveURL(/\/analysis\/risk$/)
    await expect(page.getByTestId('tour-progress')).toHaveText('2 / 6')

    // Esc 退出导览
    await page.keyboard.press('Escape')
    await expect(page.getByTestId('tour-panel')).toBeHidden()

    // 重新进入后用退出按钮
    await page.getByTestId('tour-start').click()
    await expect(page.getByTestId('tour-panel')).toBeVisible()
    await page.getByTestId('tour-exit').click()
    await expect(page.getByTestId('tour-panel')).toBeHidden()
  })

  test('导览完整走完六步：最后一步为完成并退出', async ({ page }) => {
    await page.goto('/overview')
    await page.getByTestId('tour-start').click()
    for (let step = 2; step <= 6; step += 1) {
      await page.getByTestId('tour-next').click()
      await expect(page.getByTestId('tour-progress')).toHaveText(`${step} / 6`)
    }
    // 第六步是导出（一张图），下一步按钮变为完成并退出
    await expect(page).toHaveURL(/\/map$/)
    await page.getByTestId('tour-finish').click()
    await expect(page.getByTestId('tour-panel')).toBeHidden()
  })

  test('演示模式：进入后正文 16px，可明确退出', async ({ page }) => {
    await page.goto('/overview')
    const toggle = page.getByTestId('presentation-toggle')
    await expect(toggle).toHaveAttribute('aria-pressed', 'false')

    await toggle.click()
    await expect(toggle).toHaveAttribute('aria-pressed', 'true')
    const bodyFontSize = await page.evaluate(
      () => getComputedStyle(document.querySelector('main') ?? document.body).fontSize,
    )
    // tokens.css 演示模式：正文提升到 16px（main 内文字继承）
    expect(Number.parseFloat(bodyFontSize)).toBe(16)
    expect(await page.evaluate(() => document.documentElement.dataset.presentation)).toBe('true')

    await toggle.click()
    await expect(toggle).toHaveAttribute('aria-pressed', 'false')
    expect(await page.evaluate(() => document.documentElement.dataset.presentation)).toBeUndefined()
  })
})

/* ------------------------------ 键盘可访问性 ------------------------------ */

test.describe('阶段7 键盘可访问性', () => {
  test('Tab 有可见焦点；Enter 触发导览下一步；Esc 退出', async ({ page }) => {
    await page.goto('/overview')
    await expect(page.getByTestId('overview-map')).toBeVisible()

    // 连续 Tab 后焦点落在可交互元素上且有焦点环
    await page.keyboard.press('Tab')
    await page.keyboard.press('Tab')
    const focused = await page.evaluate(() => {
      const el = document.activeElement
      if (el === null) return null
      const style = getComputedStyle(el)
      return {
        tag: el.tagName,
        outlineStyle: style.outlineStyle,
        outlineWidth: style.outlineWidth,
      }
    })
    expect(focused).not.toBeNull()
    expect(['A', 'BUTTON']).toContain(focused?.tag ?? '')
    expect(focused?.outlineStyle).not.toBe('none')

    // Enter 触发导览（焦点在 tour-start 上按 Enter）
    await page.getByTestId('tour-start').focus()
    await page.keyboard.press('Enter')
    await expect(page.getByTestId('tour-panel')).toBeVisible()

    // Esc 退出导览（也验证导览面板的键盘可达性）
    await page.keyboard.press('Escape')
    await expect(page.getByTestId('tour-panel')).toBeHidden()
  })
})

/* ------------------------------ 断网与外部资源 ------------------------------ */

test.describe('阶段7 断网与外部资源', () => {
  test('屏蔽一切外部域名后，总览与一张图仍完整可用（不依赖在线字体/图标/底图）', async ({
    page,
    context,
  }) => {
    const blocked: string[] = []
    await context.route('**/*', (route) => {
      const host = new URL(route.request().url()).hostname
      if (host === 'localhost' || host === '127.0.0.1') {
        void route.continue()
      } else {
        blocked.push(host)
        void route.abort()
      }
    })
    await page.goto('/overview')
    await expect(page.getByTestId('overview-map')).toBeVisible()
    await expect(page.getByTestId('overview-map')).toHaveAttribute('data-count', /\d+/)
    await page.goto('/map')
    await expect(page.getByTestId('map-workspace')).toBeVisible()
    // 没有任何外部资源被依赖（被拦即说明有依赖；0 才是合格）
    expect(blocked).toEqual([])
  })

  test('全站请求审计：只访问本机源（离线可用的前提）', async ({ page }) => {
    const externalHosts = new Set<string>()
    page.on('request', (request) => {
      const host = new URL(request.url()).hostname
      if (host !== 'localhost' && host !== '127.0.0.1') externalHosts.add(host)
    })
    for (const path of ['/overview', '/map', '/results/result.demo.risk', '/catalog', '/about']) {
      await page.goto(path)
      await expect(page.locator('main')).toBeVisible()
    }
    expect([...externalHosts]).toEqual([])
  })
})

/* ------------------------------ 多视口截图（加载完成后） ------------------------------ */

test.describe('阶段7 多视口截图', () => {
  const viewports = [
    { width: 1920, height: 1080 },
    { width: 1366, height: 768 },
    { width: 390, height: 844 },
  ]

  /** 每个页面的「业务内容加载完成」信号：截图前必须先满足。 */
  const pages: Array<{
    name: string
    path: string
    ready: (page: Page) => Promise<void>
  }> = [
    {
      name: 'overview',
      path: '/overview',
      ready: async (page) => {
        await expect(page.getByTestId('overview-map')).toBeVisible()
        await expect(page.getByTestId('overview-map')).toHaveAttribute('data-count', /\d+/)
      },
    },
    {
      name: 'map',
      path: '/map',
      ready: async (page) => {
        await expect(page.getByTestId('map-workspace')).toBeVisible()
        await expect(page.locator('canvas').first()).toBeVisible()
      },
    },
    {
      name: 'risk',
      path: '/analysis/risk',
      ready: async (page) => {
        // 业务就绪信号：情景横幅 + 地图区 + 画布（不是加载骨架）
        await expect(page.getByTestId('risk-page')).toBeVisible()
        await expect(page.getByTestId('future-banner')).toBeVisible()
        await expect(page.getByTestId('risk-map-area')).toBeVisible()
        await expect(page.locator('canvas').first()).toBeVisible()
      },
    },
    {
      name: 'exposure',
      path: '/analysis/exposure?resultId=result.demo.impact',
      ready: async (page) => {
        await expect(page.locator('[data-metric-key="population"]')).toBeVisible()
        await expect(page.getByTestId('category-all')).toContainText('全部（5）')
      },
    },
    {
      name: 'emergency',
      path: '/analysis/emergency?resultId=result.demo.route&routeId=DEMO-ROUTE-B',
      ready: async (page) => {
        await expect(page.getByTestId('route-info')).toContainText(/示例路线/)
        await expect(page.getByTestId('route-info')).toContainText('米')
      },
    },
    {
      name: 'result-detail',
      path: '/results/result.demo.risk',
      ready: async (page) => {
        await expect(page.getByTestId('result-map')).toBeVisible()
        await expect(page.getByTestId('result-map')).toHaveAttribute('data-count', /\d+/)
      },
    },
    {
      name: 'catalog',
      path: '/catalog',
      ready: async (page) => {
        await expect(page.getByTestId('catalog-count')).toBeVisible()
      },
    },
    {
      name: 'about',
      path: '/about',
      ready: async (page) => {
        await expect(page.getByTestId('about-page')).toBeVisible()
      },
    },
  ]

  for (const viewport of viewports) {
    for (const item of pages) {
      test(`截图 ${item.name} @ ${viewport.width}×${viewport.height}`, async ({
        page,
      }, testInfo) => {
        await page.setViewportSize({ width: viewport.width, height: viewport.height })
        await page.goto(item.path)
        // 等业务内容（不是骨架、不是 h1）
        await item.ready(page)
        // 无横向溢出
        expect(
          await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
        ).toBe(true)
        await page.screenshot({
          path: testInfo.outputPath(`${item.name}-${viewport.width}.png`),
          fullPage: true,
        })
      })
    }
  }
})
