import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段4（风险研判）浏览器用例。
 *
 * 断言方式与阶段2/3 一致：读界面真实状态、计数与下载内容，不做整页截图比对。
 * 数据来自 public/real-preview/ 的真实文件快照（601 条 2050 / 652 条 2100，
 * 按 glacier_id 匹配 565 / 仅 2050 36 / 仅 2100 87）。
 *
 * 覆盖（DeepSeek下一步任务.md 验收门槛）：
 * - 2050/2100 切换与双图对比、同对象详情、未匹配统计；
 * - 统一连续色域（无等级名）；
 * - 直方图分箱筛选与地图同步、清除筛选；
 * - null 与 0 分开（路由改写注入）；
 * - 文件读取失败与重试，不回退示例数据；
 * - 1366/390 宽布局与「未来情景，不是实时预警」持续可见；
 * - projectAnalysis 显示「正式成果服务待发布」（QTP_GEOHAZARD 已确认成果表，HTTP 联调未完成）。
 */

const EXPECTED = { total2050: 601, total2100: 652, matched: 565, only2050: 36, only2100: 87 }

async function openRisk(page: Page): Promise<void> {
  await page.goto('/analysis/risk')
  await expect(page.getByTestId('risk-page')).toBeVisible()
  await expect(page.getByTestId('future-banner')).toContainText('未来情景，不是实时预警')
  await expect(page.getByTestId('risk-map-2050').locator('canvas').first()).toBeVisible()
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )
}

async function assertNoHorizontalOverflow(page: Page): Promise<void> {
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
}

test('1920×1080：真实情景加载、横幅与统一色域图例持续可见、未匹配统计正确', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openRisk(page)

  // 图例：连续指数、无等级名（页面不得出现「高风险」类分级命名）
  const legend = page.getByTestId('risk-legend')
  await expect(legend).toContainText('统一连续色域')
  await expect(legend).toContainText('未划分等级')
  await expect(legend).not.toContainText('高风险')

  // 指标语义：原字段名 + 非概率说明
  await expect(page.getByTestId('metric-hint')).toContainText('hrgi')
  await expect(page.getByTestId('metric-hint')).toContainText('不是发生概率')

  // 匹配统计需要两期数据；单图模式不显示（不伪造未匹配结论）
  await expect(page.getByTestId('match-stats')).toHaveCount(0)

  // 统计口径：0 与 null 分开显示（hrgi 在 2050 数据中无 0、无 null）
  await expect(page.getByTestId('risk-stats')).toContainText('真实为零')
  await expect(page.getByTestId('stats-zero')).toHaveText('0 条')
  await expect(page.getByTestId('stats-null')).toHaveText('0 条')

  // 来源、版本与年份
  await expect(page.getByTestId('source-label')).toContainText('NewDefault.gdb')
  await expect(page.getByTestId('source-version-2050')).toContainText('HAZ_SUSCEPTIBILITY_PT_2050')
  await expect(page.getByTestId('source-mode-badge')).toContainText('只读')

  await assertNoHorizontalOverflow(page)
  await page.screenshot({ path: 'docs/review-stage4/production/risk-1920.png', fullPage: true })
})

test('2050/2100 切换与双图对比：同对象详情并排可比，横幅持续可见', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openRisk(page)

  // 切到 2100 单图：计数变化
  await page.getByTestId('year-2100').click()
  await expect(page.getByTestId('risk-map-2100')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2100),
  )
  await expect(page.getByTestId('risk-map-2050')).toHaveCount(0)
  await expect(page.getByTestId('future-banner')).toBeVisible()

  // 双图对比：两期同时装载，视野同步不产生循环（页面保持可用）
  await page.getByTestId('year-mode-compare').click()
  await expect(page.getByTestId('map-cell-2050')).toBeVisible()
  await expect(page.getByTestId('map-cell-2100')).toBeVisible()
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )
  await expect(page.getByTestId('risk-map-2100')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2100),
  )
  await expect(page.getByTestId('match-stats')).toBeVisible()
  // 未匹配统计：全量口径、精确数字
  await expect(page.getByTestId('match-matched')).toHaveText(String(EXPECTED.matched))
  await expect(page.getByTestId('match-only-2050')).toHaveText(String(EXPECTED.only2050))
  await expect(page.getByTestId('match-only-2100')).toHaveText(String(EXPECTED.only2100))

  // 选中 2050 指数最高的对象（实测两期均有），详情两期并排且都是数值
  await page.getByTestId('top-row-1').click()
  const detail = page.getByTestId('risk-detail')
  await expect(detail).toBeVisible()
  await expect(detail.getByTestId('match-status-both')).toHaveText('两期均有')
  for (const metric of ['hrgi', 'exposure', 'rrgi']) {
    for (const year of [2050, 2100]) {
      const text = (await detail.getByTestId(`detail-${metric}-${year}`).textContent()) ?? ''
      expect(text.trim(), `${metric}@${year}`).toMatch(/^0\.\d{3}$/)
    }
  }
  // 2050 与 2100 的 hrgi 都有数值且可不同（同对象对比成立）
  const hrgi2050 = await detail.getByTestId('detail-hrgi-2050').textContent()
  const hrgi2100 = await detail.getByTestId('detail-hrgi-2100').textContent()
  expect(hrgi2050).not.toBe('未提供')
  expect(hrgi2100).not.toBe('未提供')
  await expect(page.getByTestId('future-banner')).toBeVisible()

  // 回到单图 2050
  await page.getByTestId('year-2050').click()
  await expect(page.getByTestId('map-cell-2050')).toBeVisible()
  await expect(page.getByTestId('map-cell-2100')).toHaveCount(0)
})

test('直方图分箱筛选与地图同步；清除筛选恢复全部', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openRisk(page)

  await expect(page.getByTestId('filter-count')).toContainText(`601 / 全部 601`)
  const before = await page.getByTestId('risk-map-2050').getAttribute('data-count')
  expect(before).toBe(String(EXPECTED.total2050))

  // 点击最高区间（实测 2050 hrgi 有 10 条落在 0.9—1.0）
  await page.getByTestId('bin-9').click()
  await expect(page.getByTestId('bin-range-hint')).toContainText('0.90')
  await expect(page.getByTestId('filter-count')).toContainText('筛选后 10 / 全部 601')
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute('data-count', '10')
  // 高亮分箱用查询橙，再次点击同一箱取消
  await expect(page.getByTestId('bin-9')).toHaveAttribute('aria-pressed', 'true')

  // 区域筛选叠加
  await page.getByTestId('region-select').selectOption('Pamir')
  const combined = Number(
    ((await page.getByTestId('filter-count').textContent()) ?? '').match(/筛选后 (\d+)/)?.[1] ??
      '-1',
  )
  expect(combined).toBeGreaterThanOrEqual(0)
  expect(combined).toBeLessThanOrEqual(10)

  // 清除筛选：恢复全部
  await page.getByTestId('clear-filters').click()
  await expect(page.getByTestId('filter-count')).toContainText('601 / 全部 601')
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )
  await expect(page.getByTestId('bin-range-hint')).toHaveCount(0)
})

test('重点对象的定位按钮聚焦对象，而不是重新适配全部点', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openRisk(page)

  const map = page.getByTestId('risk-map-2050')
  await page.getByTestId('top-locate-1').click()

  await expect(page.getByTestId('risk-detail')).toBeVisible()
  // “适配全部点”的 maxZoom 是 9；对象定位必须进入更近的 10 级视野。
  await expect
    .poll(async () => Number(await map.getAttribute('data-zoom')))
    .toBeGreaterThanOrEqual(10)
})

test('null 与 0 在界面上分开：注入缺失值后单独计数，不进分箱、不当低值', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  // 改写第一条 2050 记录：hrgi 置为 null；再把另一条置为 0
  await page.route('**/real-preview/scenario2050.json', async (route) => {
    const response = await route.fetch()
    const body = (await response.json()) as {
      features: Array<{ properties: Record<string, unknown> }>
    }
    body.features[0].properties.hrgi = null
    body.features[1].properties.hrgi = 0
    await route.fulfill({ response, body: JSON.stringify(body) })
  })
  await page.goto('/analysis/risk')
  await expect(page.getByTestId('risk-map-2050').locator('canvas').first()).toBeVisible()

  await expect(page.getByTestId('stats-null')).toContainText('1 条')
  await expect(page.getByTestId('stats-zero')).toContainText('1 条')
  await expect(page.getByTestId('histogram-null-note')).toContainText('1 条值为缺失')
  // 图例同步说明缺失条数
  await expect(page.getByTestId('risk-legend')).toContainText('1 条')
})

test('清单读取失败显示错误与重试，不回退示例数据；修复后重试成功', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.route('**/real-preview/manifest.json', (route) =>
    route.fulfill({ status: 500, body: 'server error' }),
  )
  await page.goto('/analysis/risk')
  const errorBox = page.getByTestId('risk-manifest-error')
  await expect(errorBox).toBeVisible()
  await expect(errorBox).toContainText('读取失败')
  await expect(errorBox).toContainText('不会改用示例数据')
  await expect(page.getByTestId('risk-map-2050')).toHaveCount(0)

  await page.unroute('**/real-preview/manifest.json')
  await page.getByTestId('risk-retry').click()
  await expect(page.getByTestId('risk-map-2050').locator('canvas').first()).toBeVisible()
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )
})

test('项目分析成果视图显示「正式成果服务待发布」，不用情景冒充', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openRisk(page)
  await page.getByTestId('source-kind-projectAnalysis').check()
  const pending = page.getByTestId('project-analysis-pending')
  await expect(pending).toBeVisible()
  await expect(pending).toContainText('正式成果服务待发布')
  await expect(pending).toContainText('不会用 2050 / 2100 情景数据冒充')
  await expect(page.getByTestId('risk-map-2050')).toHaveCount(0)
  // 切回情景视图恢复
  await page.getByTestId('source-kind-externalScenario').check()
  await expect(page.getByTestId('risk-map-2050')).toBeVisible()
})

test('1366×768：无横向溢出，地图与筛选可操作', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openRisk(page)
  await assertNoHorizontalOverflow(page)
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )
  await page.getByTestId('bin-9').click()
  await expect(page.getByTestId('filter-count')).toContainText('筛选后 10')
  await page.getByTestId('clear-filters').click()
  await page.screenshot({ path: 'docs/review-stage4/production/risk-1366.png', fullPage: true })
})

test('390 宽：可切换情景、查看对象详情、阅读来源说明，无横向溢出', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await openRisk(page)
  await assertNoHorizontalOverflow(page)

  // 情景切换可用
  await page.getByTestId('year-2100').click()
  await expect(page.getByTestId('risk-map-2100')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2100),
  )
  await page.getByTestId('year-2050').click()
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute(
    'data-count',
    String(EXPECTED.total2050),
  )

  // 查看对象：点重点对象第一行 → 详情出现
  await page.getByTestId('top-row-1').click()
  await expect(page.getByTestId('risk-detail')).toBeVisible()
  await expect(page.getByTestId('detail-glacier-id')).toBeVisible()

  // 来源说明与横幅可读
  await expect(page.getByTestId('future-banner')).toBeVisible()
  await expect(page.getByTestId('risk-source-panel')).toBeVisible()
  await expect(page.getByTestId('source-label')).toContainText('NewDefault.gdb')
  await assertNoHorizontalOverflow(page)
  await page.screenshot({ path: 'docs/review-stage4/production/risk-390.png', fullPage: true })
})
