import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段2（地图与图层）浏览器用例。
 *
 * 设计取向与 04 §7 一致：**不做脆弱的整页截图比对**，而是
 * 1. 断言可访问控件与对象列表的状态；
 * 2. 从 OpenLayers 对象读回「实际渲染结果」（状态栏 chip、图层树 zIndex），
 *    控件没真正作用到地图上时断言会失败；
 * 3. 用地图画布的颜色指纹变化作为「地图真的重绘了」的视觉证据（沿用真实预览用例的
 *    像素扫描思路）。注意：研究区边界是不透明填充，开关内部图层时「不透明像素数」
 *    基本不变，**颜色指纹**才是有效指标；
 * 4. 只在 1920×1080 与 1366×768 各留一张运行截图作为人工核对材料。
 *
 * 断网口径：所有几何都来自本机数据包。用例既拦截全部非 127.0.0.1 请求，
 * 也断言运行期根本没有向外网发起过请求。
 */

/** 地图容器内所有 OL 画布的像素统计与尺寸：hash = 颜色指纹，drawn = 不透明像素数。 */
async function canvasSignature(page: Page): Promise<{
  drawn: number
  hash: number
  width: number
  height: number
}> {
  return page.getByTestId('map-canvas').evaluate((host) => {
    let drawn = 0
    let hash = 0
    let width = 0
    let height = 0
    for (const canvas of host.querySelectorAll('canvas')) {
      const context = canvas.getContext('2d')
      if (!context) continue
      const canvasWidth = canvas.width
      const canvasHeight = canvas.height
      if (canvasWidth === 0 || canvasHeight === 0) continue
      width += canvasWidth
      height += canvasHeight
      const data = context.getImageData(0, 0, canvasWidth, canvasHeight).data
      // 按面积自适应抽样，保证统计稳定又不拖慢用例。
      const step = Math.max(1, Math.floor(Math.sqrt((canvasWidth * canvasHeight) / 40_000)))
      for (let y = 0; y < canvasHeight; y += step) {
        for (let x = 0; x < canvasWidth; x += step) {
          const index = (y * canvasWidth + x) * 4
          if ((data[index + 3] ?? 0) === 0) continue
          drawn += 1
          hash =
            (hash * 31 +
              (data[index] ?? 0) +
              (data[index + 1] ?? 0) * 3 +
              (data[index + 2] ?? 0) * 7) %
            2_147_483_647
        }
      }
    }
    return { drawn, hash, width, height }
  })
}

/** 状态栏里的「可见图层 N」——来自地图图层的真实可见性，不是界面勾选状态。 */
async function visibleLayerCount(page: Page): Promise<number> {
  const text = (await page.getByTestId('status-visible').textContent()) ?? ''
  const matched = /可见图层\s*(\d+)/.exec(text)
  return matched?.[1] === undefined ? -1 : Number(matched[1])
}

/** 展开某个图层行（透明度、顺序、定位、元数据按钮都在展开区里）。 */
async function expandLayer(page: Page, layerId: string): Promise<void> {
  const expand = page.getByTestId(`expand-${layerId}`)
  if ((await expand.textContent()) === '设置') await expand.click()
  await expect(expand).toHaveText('收起')
}

/**
 * 等到地图停止重绘（连续两次读取的画布指纹与画布尺寸都一致）。
 *
 * 两个坑：勾选图层后画布并非立刻重绘；打开对象列表等面板会改变地图容器高度，
 * OL 的 `updateSize` 与随后的重绘也滞后若干帧。此时去扫描像素会读到**旧帧**，
 * 算出的屏幕坐标也可能对应旧尺寸，于是点到别的东西。像素相关断言前都先等本函数。
 */
async function waitForMapSettled(page: Page): Promise<void> {
  await expect
    .poll(
      async () => {
        const first = await canvasSignature(page)
        await page.waitForTimeout(150)
        const second = await canvasSignature(page)
        return (
          first.hash === second.hash &&
          first.drawn === second.drawn &&
          first.width === second.width &&
          first.height === second.height
        )
      },
      { timeout: 10_000 },
    )
    .toBe(true)
}

/** 打开 /map 并等到注册表加载完成、首批图层真正渲染到地图上。 */
async function openMap(page: Page): Promise<void> {
  await page.goto('/map')
  await expect(page.getByTestId('map-workspace')).toBeVisible()
  await expect(page.getByTestId('map-canvas').locator('canvas').first()).toBeVisible()
  await expect(page.getByTestId('status-visible')).toContainText('已渲染要素')
  await expect.poll(() => visibleLayerCount(page), { timeout: 15_000 }).toBeGreaterThan(5)
  await expect.poll(async () => (await canvasSignature(page)).hash, { timeout: 15_000 }).not.toBe(0)
}

test('1920×1080：图层开关、透明度、叠放顺序与定位都真实作用于地图', async ({ page }, info) => {
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)

  // 五主题分组都在，图层数量来自注册表。
  for (const theme of ['base', 'tnr', 'hazard', 'emg', 'result']) {
    await expect(page.getByTestId(`theme-${theme}`)).toBeVisible()
  }
  await expect(page.getByTestId('layer-tree')).toContainText('来自接口注册表')
  expect(await page.locator('[data-testid^="name-"]').count()).toBeGreaterThanOrEqual(20)

  // 开关：关掉冰川面后「可见图层」计数下降，且地图画布重绘（颜色指纹变化）。
  const visibleBefore = await visibleLayerCount(page)
  const beforeOff = await canvasSignature(page)
  await page.getByTestId('visible-tnr.glacier.polygon').uncheck()
  await expect.poll(() => visibleLayerCount(page), { timeout: 5_000 }).toBe(visibleBefore - 1)
  await expect
    .poll(async () => (await canvasSignature(page)).hash, { timeout: 5_000 })
    .not.toBe(beforeOff.hash)

  // 重新勾选后可见图层计数回到原值。
  await page.getByTestId('visible-tnr.glacier.polygon').check()
  await expect.poll(() => visibleLayerCount(page), { timeout: 5_000 }).toBe(visibleBefore)

  // 透明度：拖动滑块后图层状态与画布都变化。
  await expandLayer(page, 'tnr.glacier.polygon')
  const beforeOpacity = await canvasSignature(page)
  await page.getByTestId('opacity-tnr.glacier.polygon').fill('0.2')
  await expect(page.getByTestId('layer-tnr.glacier.polygon')).toContainText('透明度 20%')
  await expect
    .poll(async () => (await canvasSignature(page)).hash, { timeout: 5_000 })
    .not.toBe(beforeOpacity.hash)

  // 叠放顺序：上移后 OL 图层 zIndex 变化，且在图层树中的位置真的前移。
  await expandLayer(page, 'result.demo.impact')
  const orderBefore = await page
    .locator('[data-testid^="name-"]')
    .evaluateAll((elements) => elements.map((element) => element.getAttribute('data-testid')))
  const zIndexBefore = await page.getByTestId('zindex-result.demo.impact').textContent()
  await page.getByTestId('up-result.demo.impact').click()
  await expect(page.getByTestId('zindex-result.demo.impact')).not.toHaveText(zIndexBefore ?? '')
  const orderAfter = await page
    .locator('[data-testid^="name-"]')
    .evaluateAll((elements) => elements.map((element) => element.getAttribute('data-testid')))
  expect(orderAfter).not.toEqual(orderBefore)

  // 定位：定位到地震图层后缩放级别变化（地图视野真的动了）。
  await expandLayer(page, 'hazard.earthquake')
  const zoomBefore = await page.getByTestId('status-zoom').textContent()
  await page.getByTestId('focus-hazard.earthquake').click()
  await expect(page.getByTestId('status-zoom')).not.toHaveText(zoomBefore ?? '')

  // 恢复默认顺序与可见性，检查布局并截图留档。
  await page.getByRole('button', { name: '恢复默认顺序与可见性' }).click()
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  expect(await page.evaluate(() => getComputedStyle(document.body).transform)).toBe('none')
  const canvasBox = await page.getByTestId('map-canvas').boundingBox()
  expect(canvasBox?.height ?? 0).toBeLessThan(1080)
  await page.screenshot({ path: info.outputPath('map-1920.png'), fullPage: true })
  expect(errors).toEqual([])
})

test('1366×768：无横向溢出、地图保持可操作面积、截图留档', async ({ page }, info) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openMap(page)

  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  expect(await page.evaluate(() => getComputedStyle(document.body).transform)).toBe('none')
  const canvasBox = await page.getByTestId('map-canvas').boundingBox()
  expect(canvasBox?.width ?? 0).toBeGreaterThan(400)
  expect(canvasBox?.height ?? 0).toBeGreaterThan(300)

  // 窄屏下仍能完成一次真实交互：开关图层并看到地图重绘。
  const visibleBefore = await visibleLayerCount(page)
  const before = await canvasSignature(page)
  await page.getByTestId('visible-emg.road').uncheck()
  await expect.poll(() => visibleLayerCount(page), { timeout: 5_000 }).toBe(visibleBefore - 1)
  await expect
    .poll(async () => (await canvasSignature(page)).hash, { timeout: 5_000 })
    .not.toBe(before.hash)

  // 截图前恢复默认状态并把图层目录滚回顶部，便于两个视口的截图互相对照。
  await page.getByTestId('visible-emg.road').check()
  await page.getByTestId('layer-tree').evaluate((element) => {
    element.scrollTo(0, 0)
  })
  await page.screenshot({ path: info.outputPath('map-1366.png'), fullPage: true })
})

test('无选中对象时右栏默认收起，图例按钮按需打开和关闭', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)

  await expect(page.getByTestId('right-column')).toHaveCount(0)
  await page.getByTestId('toggle-legend').click()
  await expect(page.getByTestId('right-column')).toBeVisible()
  await expect(page.getByTestId('map-legend')).toBeVisible()
  await page.getByTestId('toggle-legend').click()
  await expect(page.getByTestId('right-column')).toHaveCount(0)
})
test('栅格图层不可渲染：复选框禁用并说明原因，元数据可查', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)

  await expect(page.getByTestId('visible-base.population')).toBeDisabled()
  await expect(page.getByTestId('state-base.population')).toContainText('暂未提供')
  await expect(page.getByTestId('layer-base.population')).toContainText('不渲染像元')

  await expandLayer(page, 'base.population')
  await page.getByTestId('metadata-base.population').click()
  const metadata = page.getByTestId('layer-metadata')
  await expect(metadata).toBeVisible()
  await expect(metadata).toContainText('base.population')
  await expect(metadata).toContainText('暂未提供')
  await expect(metadata.getByTestId('layer-metadata-dataset')).toContainText('不可用')
  await page.getByTestId('metadata-close').click()
  await expect(metadata).toHaveCount(0)
})

test('点选地图要素：属性与对象列表一一对应', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)

  // 只留居民地点图层可见，保证点选结果可预期。
  for (const layerId of [
    'base.facility.point',
    'tnr.meteostation',
    'hazard.earthquake',
    'hazard.landslide',
    'emg.hospital',
    'emg.rescue',
    'result.demo.risk',
    'result.demo.impact',
    'result.demo.route',
  ]) {
    await page.getByTestId(`visible-${layerId}`).uncheck()
  }
  await page.getByTestId('toggle-object-list').click()
  await expect(page.getByTestId('object-list')).toBeVisible()
  await expect(page.getByTestId('object-list-layer')).toContainText('居民地')
  await expect(page.locator('[data-testid^="object-row-"]')).toHaveCount(12)

  // 先把鼠标移进地图，让「坐标文案变化」这类悬停副作用先发生，再等布局与画布稳定，
  // 然后才扫描像素并点击：否则扫描用的画布尺寸与点击时的尺寸可能不是同一帧。
  const box = await page.getByTestId('map-canvas').boundingBox()
  await page.mouse.move((box?.x ?? 0) + 20, (box?.y ?? 0) + 90)
  await waitForMapSettled(page)

  // 找一个真实的点像素（填充色来自 --color-primary），而不是任意屏幕坐标。
  // 先找抗锯齿边缘之外的“核心像素”，找不到再放宽；点边缘容易落在多个几何之间。
  const point = await page.getByTestId('map-canvas').evaluate((host) => {
    const viewport = host.getBoundingClientRect()
    const strict: Array<{ x: number; y: number }> = []
    const loose: Array<{ x: number; y: number }> = []
    for (const canvas of host.querySelectorAll('canvas')) {
      const context = canvas.getContext('2d')
      if (!context) continue
      const data = context.getImageData(0, 0, canvas.width, canvas.height).data
      const rect = canvas.getBoundingClientRect()
      for (let y = 0; y < canvas.height; y += 2) {
        for (let x = 0; x < canvas.width; x += 2) {
          const index = (y * canvas.width + x) * 4
          const red = data[index] ?? 0
          const green = data[index + 1] ?? 0
          const blue = data[index + 2] ?? 0
          const alpha = data[index + 3] ?? 0
          if (alpha < 200) continue
          const isCore =
            alpha === 255 &&
            Math.abs(red - 8) < 8 &&
            Math.abs(green - 127) < 8 &&
            Math.abs(blue - 140) < 8
          const isLoose =
            Math.abs(red - 8) < 26 && Math.abs(green - 127) < 30 && Math.abs(blue - 140) < 30
          if (!isCore && !isLoose) continue
          const px = rect.left + (x * rect.width) / canvas.width
          const py = rect.top + (y * rect.height) / canvas.height
          if (
            px <= viewport.left + 40 ||
            px >= viewport.right - 40 ||
            py <= viewport.top + 60 ||
            py >= viewport.bottom - 40
          ) {
            continue
          }
          if (isCore) strict.push({ x: px, y: py })
          else loose.push({ x: px, y: py })
        }
      }
    }
    return strict[0] ?? loose[0] ?? null
  })
  expect(point).not.toBeNull()
  await page.mouse.click(point!.x, point!.y)

  const detail = page.getByTestId('feature-detail')
  await expect(detail).toBeVisible()
  await expect(detail.getByTestId('detail-layer')).toContainText('居民地')
  await expect(detail.getByTestId('detail-properties')).toContainText('对象标识')
  await expect(detail.getByTestId('detail-locate')).toBeEnabled()

  // 详情里的对象标题必须在对象列表里找到且只找到一行，行标题与详情标题一致。
  const detailTitle = (await detail.getByTestId('detail-title').textContent())?.trim() ?? ''
  expect(detailTitle.length).toBeGreaterThan(0)
  await expect(
    page.locator('[data-testid^="object-row-"]').filter({ hasText: detailTitle }),
  ).toHaveCount(1)

  // 清空选中后右栏收起。
  await page.getByTestId('clear-selection').click()
  await expect(page.getByTestId('feature-detail')).toHaveCount(0)
})

test('无几何记录：属性可查、定位禁用并说明原因', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)

  // 把对象列表切到风险成果图层，该图层在示例包里含一条无几何记录。
  await page.getByTestId('name-result.demo.risk').click()
  await page.getByTestId('toggle-object-list').click()
  await expect(page.getByTestId('object-list-layer')).toContainText('风险区')
  await expect(page.getByTestId('object-list-count')).toContainText('无几何')

  await page.getByLabel('对象列表筛选').selectOption('noGeometry')
  const noGeometryRow = page.locator('[data-testid^="object-row-"]').first()
  await expect(noGeometryRow).toContainText('无几何')
  await expect(noGeometryRow).toContainText('定位不可用：该记录无几何')
  await expect(noGeometryRow.locator('[data-testid^="row-locate-"]')).toBeDisabled()

  // 属性仍可查看：详情显示字段与「无几何」说明，定位按钮禁用并给出原因。
  await noGeometryRow.locator('button').first().click()
  const detail = page.getByTestId('feature-detail')
  await expect(detail.getByTestId('detail-geometry-note')).toContainText('该记录无几何')
  await expect(detail.getByTestId('detail-properties')).toContainText('风险等级')
  await expect(detail.getByTestId('detail-locate')).toBeDisabled()
  await expect(detail.getByTestId('detail-locate-note')).toContainText('定位不可用')
})

test('单层读取失败只影响该层，其它图层照常渲染，重试可恢复', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.route('**/demo/features/glacier.geojson', (route) =>
    route.fulfill({ status: 500, body: '{}' }),
  )
  await openMap(page)

  await expect(page.getByTestId('state-tnr.glacier.polygon')).toContainText('读取失败')
  // 其它图层没有被拖垮。
  await expect(page.getByTestId('status-visible')).toContainText('已渲染要素')
  expect(await visibleLayerCount(page)).toBeGreaterThan(5)
  await expect.poll(async () => (await canvasSignature(page)).hash, { timeout: 10_000 }).not.toBe(0)

  await page.unroute('**/demo/features/glacier.geojson')
  await expandLayer(page, 'tnr.glacier.polygon')
  await page.getByTestId('retry-tnr.glacier.polygon').click()
  await expect(page.getByTestId('state-tnr.glacier.polygon')).toContainText('已渲染')
})

test('断网：不依赖任何外网资源，示例几何照常浏览', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  const externalHosts = new Set<string>()
  page.on('request', (request) => {
    const host = new URL(request.url()).hostname
    if (host !== '127.0.0.1' && host !== 'localhost') externalHosts.add(host)
  })
  await page.route('**/*', (route) =>
    new URL(route.request().url()).hostname === '127.0.0.1' ? route.continue() : route.abort(),
  )

  await openMap(page)
  expect([...externalHosts]).toEqual([])

  // 断网环境下仍能完成一次图层控制：计数下降且地图重绘。
  const visibleBefore = await visibleLayerCount(page)
  const before = await canvasSignature(page)
  await page.getByTestId('visible-tnr.river').uncheck()
  await expect.poll(() => visibleLayerCount(page), { timeout: 5_000 }).toBe(visibleBefore - 1)
  await expect
    .poll(async () => (await canvasSignature(page)).hash, { timeout: 5_000 })
    .not.toBe(before.hash)
})

test('窄屏：1024 宽紧凑三栏不溢出，960 宽图层面板改为可开合抽屉', async ({ page }) => {
  await page.setViewportSize({ width: 1024, height: 768 })
  await openMap(page)
  // 1024 落在紧凑三栏档：左栏收窄但仍可见，地图可用，无横向溢出。
  await expect(page.getByTestId('layer-tree')).toBeVisible()
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  expect((await page.getByTestId('map-canvas').boundingBox())?.height ?? 0).toBeGreaterThan(300)

  // 960 宽：图层目录改为抽屉，默认收起，一次只开一个面板。
  await page.setViewportSize({ width: 960, height: 768 })
  await expect(page.getByTestId('layer-tree')).toBeHidden()
  expect((await page.getByTestId('map-canvas').boundingBox())?.height ?? 0).toBeGreaterThan(300)

  await page.getByTestId('toggle-layer-drawer').click()
  await expect(page.getByTestId('layer-tree')).toBeVisible()
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)
  expect((await page.getByTestId('map-canvas').boundingBox())?.height ?? 0).toBeGreaterThan(200)

  await page.getByTestId('toggle-layer-drawer').click()
  await expect(page.getByTestId('layer-tree')).toBeHidden()
})

test('反复进出页面：地图实例与监听不累积', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await openMap(page)
  await expect(page.getByTestId('status-lifecycle')).toHaveText('地图实例 1 · 事件监听 3')

  for (let index = 0; index < 5; index += 1) {
    await page.getByRole('link', { name: '总览', exact: true }).click()
    await expect(page).toHaveURL(/\/overview/)
    await page.getByRole('link', { name: '风险一张图', exact: true }).click()
    await expect(page.getByTestId('map-workspace')).toBeVisible()
    // 回来时应重新把几何灌进新的地图实例，而不是空白画布。
    await expect(page.getByTestId('status-visible')).toContainText('已渲染要素')
    await expect(page.getByTestId('status-lifecycle')).toHaveText('地图实例 1 · 事件监听 3')
  }

  await expect.poll(() => visibleLayerCount(page), { timeout: 10_000 }).toBeGreaterThan(5)
  await expect.poll(async () => (await canvasSignature(page)).hash, { timeout: 10_000 }).not.toBe(0)
  expect(errors).toEqual([])
})
