import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段5（暴露度与影响评估）浏览器用例。
 *
 * 断言方式与阶段2—4 一致：读界面真实状态、计数与文案，不做整页截图比对。
 * 覆盖：深链接（resultId/hazard）、类别筛选与地图同步、清除筛选、
 * 人口 null ≠ 0、去重口径可见、无几何记录定位禁用、失败与重试、
 * 上下文链接到应急方案、1366/390 布局、「示例数据」持续可见。
 *
 * 数字口径（来自 tests/unit/exposure-emergency.spec.ts 的同一数据包）：
 * 受影响 5 条记录 = 居民地（点）3 + 医院 2；其中 1 条人口为 null、2 条有数值。
 */

const EXPECTED_TOTAL = 5
const HOSPITAL_COUNT = 2

async function openExposure(page: Page, query = ''): Promise<void> {
  await page.goto(`/analysis/exposure${query}`)
  await expect(page.getByTestId('exposure-page')).toBeVisible()
  await expect(page.getByTestId('exposure-pending-banner')).toBeVisible()
}

test('深链接进入：统计、去重口径、人口「未提供」与来源对象一次到位', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await openExposure(page, '?hazard=hazard.landslide:DEMO-LS-02')

  // 控制面板：成果信息与示例身份
  await expect(page.getByTestId('exposure-control')).toContainText('示例数据')
  // 来源对象上下文：深链接携带的 FeatureRef 被真实取回
  await expect(page.getByTestId('exposure-hazard-line')).toContainText('来源对象')
  await expect(page.getByTestId('locate-entry-hazard')).toBeVisible()

  // 指标：人口为 notProvided（显示「未提供」，不是 0），道路长度单位米
  const population = page.locator('[data-metric-key="population"]')
  await expect(population).toHaveAttribute('data-metric-status', 'notProvided')
  await expect(population).toContainText('未提供')
  const road = page.locator('[data-metric-key="affectedRoadLength"]')
  await expect(road).toContainText('米')

  // 去重与口径
  await expect(page.getByTestId('dedup-rule')).toContainText('entityKey')
  await expect(page.getByTestId('scope-method')).toContainText('已存影响范围')

  // 计数：全部 5（3 居民地 + 2 医院）
  await expect(page.getByTestId('category-all')).toContainText(`全部（${EXPECTED_TOTAL}）`)
  await expect(page.locator('[data-testid^="category-"].chip')).toHaveCount(3)
})

test('类别筛选与地图同步；清除筛选一键恢复；页码回 1', async ({ page }) => {
  await openExposure(page)
  const map = page.getByTestId('exposure-map')
  await expect(map).toHaveAttribute('data-count', String(EXPECTED_TOTAL))

  await page.getByTestId('category-emg.hospital').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText(String(HOSPITAL_COUNT))
  await expect(map).toHaveAttribute('data-count', String(HOSPITAL_COUNT))
  // 受影响表：医院行 2 条
  const rows = page.locator('[data-testid^="affected-row-"]')
  await expect(rows).toHaveCount(HOSPITAL_COUNT)

  await page.getByTestId('exposure-clear').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText(String(EXPECTED_TOTAL))
  await expect(map).toHaveAttribute('data-count', String(EXPECTED_TOTAL))
  await expect(rows).toHaveCount(EXPECTED_TOTAL)
})

test('人口 null 显示「未提供」而不是 0；无几何记录定位禁用并说明', async ({ page }) => {
  await openExposure(page)
  // 示例居民地 02 的人口为 null
  const nullRow = page.locator('[data-testid^="affected-row-"]').filter({
    has: page.getByTestId('affected-name').filter({ hasText: '示例居民地 02' }),
  })
  await expect(nullRow).toHaveCount(1)
  await expect(nullRow.locator('[data-population="null"]')).toHaveText('未提供')
  // 有数值的记录照常显示数值 + 单位
  const numberedRow = page.locator('[data-population="1200"]')
  await expect(numberedRow).toContainText('1200')
})

test('表格行点击与地图选中同步；点地图也可选中', async ({ page }) => {
  await openExposure(page)
  const firstRow = page.locator('[data-testid^="affected-row-"]').first()
  await firstRow.click()
  await expect(page.locator('[data-testid^="affected-row-"].is-selected')).toHaveCount(1)
})

test('上下文链路：从 /map 危险源进入 → 暴露 → 应急', async ({ page }) => {
  // 1) /map 查询危险层并定位一条记录 → 详情出现「查看影响评估」入口
  await page.goto('/map')
  await expect(page.getByTestId('map-workspace')).toBeVisible()
  await page.getByTestId('toggle-query').click()
  await page.getByTestId('query-layer').selectOption('hazard.landslide')
  await page.getByTestId('run-query').click()
  const locate = page.getByTestId('query-locate-DEMO-LS-02')
  await expect(locate).toBeVisible()
  await locate.click()
  await expect(page.getByTestId('feature-detail')).toBeVisible()
  await expect(page.getByTestId('analyze-entry')).toBeVisible()
  await page.getByTestId('analyze-entry').click()

  // 2) 深链接落到暴露页，来源对象即该危险源
  await expect(page.getByTestId('exposure-page')).toBeVisible()
  await expect(page.getByTestId('exposure-hazard-line')).toContainText('示例地质灾害点 02')

  // 3) 暴露 → 应急
  await page.getByTestId('to-emergency').click()
  await expect(page.getByTestId('emergency-page')).toBeVisible()
  await expect(page.getByTestId('route-plans')).toBeVisible()
})

test('影响范围读取失败：明确错误 + 重试，不回退示例数据', async ({ page }) => {
  await page.route('**/demo/features/impact-area.geojson', (route) => route.abort())
  await openExposure(page)
  await expect(page.getByTestId('exposure-page')).toBeVisible()
  // 影响范围失败不影响统计（fail-isolated），地图区域显示重试
  await expect(page.locator('[role="alert"]', { hasText: '影响范围' }).first()).toBeVisible()
  await page.getByTestId('exposure-retry-areas').click()
  // 继续拦截：仍然失败且仍是错误态，不出现假成功
  await expect(page.locator('[role="alert"]', { hasText: '影响范围' }).first()).toBeVisible()
})

test('1366×768：无横向溢出，地图与侧栏完整', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openExposure(page)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
  const map = page.getByTestId('exposure-map')
  const box = await map.boundingBox()
  expect(box?.height ?? 0).toBeGreaterThan(240)
  expect(box?.width ?? 0).toBeGreaterThan(400)
})

test('390 宽：单列布局可完成筛选与来源阅读', async ({ page }) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await openExposure(page)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
  await page.getByTestId('category-emg.hospital').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText(String(HOSPITAL_COUNT))
  await page.getByTestId('exposure-clear').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText(String(EXPECTED_TOTAL))
  await page.getByTestId('exposure-source').scrollIntoViewIfNeeded()
  await expect(page.getByTestId('exposure-source')).toContainText('示例数据')
})

test('上下文查询参数在页面间保持（暴露 → 应急带回 hazard）', async ({ page }) => {
  await openExposure(page, '?hazard=hazard.landslide:DEMO-LS-02')
  await page.getByTestId('to-emergency-top').click()
  await expect(page).toHaveURL(
    /hazard=hazard\.landslide%3ADEMO-LS-02|hazard=hazard\.landslide:DEMO-LS-02/,
  )
  await expect(page.getByTestId('emergency-page')).toBeVisible()
})

test('1920×1080 截图留档', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openExposure(page, '?hazard=hazard.landslide:DEMO-LS-02')
  await expect(page.getByTestId('exposure-metrics')).toBeVisible()
  await page.screenshot({ path: testInfo.outputPath('exposure-1920.png'), fullPage: true })
})

test('1366×768 截图留档', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openExposure(page)
  await expect(page.getByTestId('exposure-metrics')).toBeVisible()
  await page.screenshot({ path: testInfo.outputPath('exposure-1366.png'), fullPage: true })
})

test('390 宽截图留档', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 390, height: 844 })
  await openExposure(page)
  await expect(page.getByTestId('exposure-metrics')).toBeVisible()
  await page.screenshot({ path: testInfo.outputPath('exposure-390.png'), fullPage: true })
})
