import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段9 答辩演练用例（04 §7 八分钟脚本的可执行版）。
 *
 * 在**生产构建 + 独占端口**（playwright.real-review.config.ts，127.0.0.1:17498）下
 * 按答辩顺序实际操作一遍主线链路并截图留证：
 *   ① 总览与六步演示导览（0:00—0:40 / 7:10—8:00）
 *   ② 一张图：属性查询、空间缓冲、CSV/GeoJSON 导出（0:40—2:30）
 *   ③ 风险成果：2050/2100 情景切换与双图对比（2:30—4:20）
 *   ④ 暴露筛选与应急 A/B/C、无路径状态（4:20—6:20）
 *   ⑤ 成果中心：深链接刷新与成果文件下载（6:20—7:10）
 *   ⑥ 三类专题图打印（导出环节）
 *   ⑦ 三视口无溢出与断网可用
 *
 * 截图前**必须等业务内容就绪**（计数/指标/画布可见），不把加载骨架当证据。
 * 数据来自本机示例包，界面持续标注「示例数据」；2050/2100 为未来情景（横幅常驻）。
 */

test.use({ acceptDownloads: true })

async function openOverview(page: Page): Promise<void> {
  await page.goto('/overview')
  await expect(page.getByTestId('overview-page')).toBeVisible()
  await expect(page.getByTestId('overview-map').locator('canvas').first()).toBeVisible()
  await expect(page.locator('[data-metric-key]').first()).toBeVisible()
}

async function openMap(page: Page): Promise<void> {
  await page.goto('/map')
  await expect(page.getByTestId('map-workspace')).toBeVisible()
  await expect(page.getByTestId('map-canvas').locator('canvas').first()).toBeVisible()
  await expect(page.getByTestId('status-visible')).toContainText('已渲染要素')
}

test('① 总览与六步演示导览：前进、后退、结束（0:00—0:40 / 7:10—8:00）', async ({
  page,
}, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openOverview(page)
  await page.screenshot({
    path: testInfo.outputPath('rehearsal-overview-1920.png'),
    fullPage: true,
  })

  // 六步导览：总览 → 风险 → 暴露 → 应急 → 来源/成果 → 导出
  await page.getByTestId('tour-start').click()
  await expect(page.getByTestId('tour-panel')).toBeVisible()
  await expect(page.getByTestId('tour-progress')).toHaveText('1 / 6')
  await expect(page).toHaveURL(/\/overview$/)

  await page.getByTestId('tour-next').click()
  await expect(page).toHaveURL(/\/analysis\/risk/)
  await expect(page.getByTestId('tour-progress')).toHaveText('2 / 6')
  await page.getByTestId('tour-next').click()
  await expect(page).toHaveURL(/\/analysis\/exposure/)
  await expect(page.getByTestId('tour-progress')).toHaveText('3 / 6')
  await page.getByTestId('tour-next').click()
  await expect(page).toHaveURL(/\/analysis\/emergency/)
  await expect(page.getByTestId('tour-progress')).toHaveText('4 / 6')
  await page.getByTestId('tour-next').click()
  await expect(page).toHaveURL(/\/results\/result\.demo\.risk/)
  await expect(page.getByTestId('tour-progress')).toHaveText('5 / 6')

  // 后退一步回到应急，再前进两次到导出步
  await page.getByTestId('tour-prev').click()
  await expect(page).toHaveURL(/\/analysis\/emergency/)
  await expect(page.getByTestId('tour-progress')).toHaveText('4 / 6')
  await page.getByTestId('tour-next').click()
  await page.getByTestId('tour-next').click()
  await expect(page).toHaveURL(/\/map/)
  await expect(page.getByTestId('tour-finish')).toBeVisible()
  await page.getByTestId('tour-finish').click()
  await expect(page.getByTestId('tour-panel')).toBeHidden()
})

test('② 一张图：属性查询、缓冲空间查询、CSV/GeoJSON 导出（0:40—2:30）', async ({
  page,
}, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)
  await page.screenshot({ path: testInfo.outputPath('rehearsal-map-1920.png'), fullPage: true })

  await page.getByTestId('toggle-query').click()
  await expect(page.getByTestId('query-panel')).toBeVisible()
  await page.getByTestId('query-layer').selectOption('hazard.landslide')

  // 属性查询：全部记录 → 加数值条件后命中数不大于全量
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-result')).toContainText('全部匹配')
  const allText = (await page.getByTestId('query-total').textContent()) ?? ''
  const all = Number(/(\d+)/.exec(allText)?.[1] ?? '-1')
  expect(all).toBeGreaterThan(0)
  await page.getByTestId('add-condition').selectOption('volumeM3::number')
  await page.getByTestId('condition-min-volumeM3').fill('0')
  await page.getByTestId('run-query').click()
  const filteredText = (await page.getByTestId('query-total').textContent()) ?? ''
  const filtered = Number(/(\d+)/.exec(filteredText)?.[1] ?? '-1')
  expect(filtered).toBeGreaterThanOrEqual(0)
  expect(filtered).toBeLessThanOrEqual(all)

  // 导出（带条件、来源与示例标识）：CSV 与 GeoJSON 都真实下载
  const [csv] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('export-csv-all').click(),
  ])
  expect(csv.suggestedFilename()).toContain('.csv')
  const [geojson] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('export-geojson-all').click(),
  ])
  expect(geojson.suggestedFilename()).toContain('.geojson')

  // 空间查询：以选中对象为源的缓冲查询（可解释、命中数显示）。
  // 查询面板与对象列表共用同一底部区域（v-else-if），先关查询面板再开对象列表。
  await page.getByTestId('toggle-query').click()
  await expect(page.getByTestId('query-panel')).toBeHidden()
  await page.getByTestId('toggle-object-list').click()
  await expect(page.getByTestId('object-list')).toBeVisible()
  await page.locator('[data-testid^="object-row-"]').first().locator('button.link').click()
  await expect(page.getByTestId('feature-detail')).toBeVisible()
  await page.getByTestId('toggle-object-list').click()
  await page.getByTestId('toggle-query').click()
  await expect(page.getByTestId('query-panel')).toBeVisible()
  await page.getByTestId('spatial-mode').selectOption('buffer')
  await page.getByTestId('use-selected').click()
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-result')).toBeVisible()
  const bufferText = (await page.getByTestId('query-total').textContent()) ?? ''
  expect(Number(/(\d+)/.exec(bufferText)?.[1] ?? '-1')).toBeGreaterThanOrEqual(0)
  // 缓冲查询口径可解释（方法/半径/来源声明）
  await expect(page.getByTestId('spatial-source')).toBeVisible()
})

test('③ 风险成果：2050/2100 情景切换与双图对比（2:30—4:20）', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.goto('/analysis/risk')
  await expect(page.getByTestId('risk-page')).toBeVisible()
  await expect(page.getByTestId('risk-map-area').locator('canvas').first()).toBeVisible()
  // 业务内容就绪的标志：真实快照计数与未来情景横幅
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute('data-count', '601')
  await expect(page.getByTestId('future-banner')).toBeVisible()
  await page.screenshot({ path: testInfo.outputPath('rehearsal-risk-1920.png'), fullPage: true })

  // 切到 2100：真实快照计数 652
  await page.getByTestId('year-2100').click()
  await expect(page.getByTestId('risk-map-2100')).toHaveAttribute('data-count', '652')
  // 双图对比：2050（601）与 2100（652）并排
  await page.getByTestId('year-mode-compare').click()
  await expect(page.getByTestId('map-cell-2050')).toBeVisible()
  await expect(page.getByTestId('map-cell-2100')).toBeVisible()
  await expect(page.getByTestId('risk-map-2050')).toHaveAttribute('data-count', '601')
  await expect(page.getByTestId('risk-map-2100')).toHaveAttribute('data-count', '652')
  // 未匹配统计（同对象口径）
  await expect(page.getByTestId('match-stats')).toBeVisible()
})

test('④ 暴露筛选与应急 A/B/C、无路径状态（4:20—6:20）', async ({ page }, testInfo) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.goto('/analysis/exposure?resultId=result.demo.impact')
  await expect(page.getByTestId('exposure-page')).toBeVisible()
  await expect(page.getByTestId('exposure-map').locator('canvas').first()).toBeVisible()
  await expect(page.locator('[data-metric-key]').first()).toBeVisible()
  await page.screenshot({
    path: testInfo.outputPath('rehearsal-exposure-1920.png'),
    fullPage: true,
  })

  // 类别筛选与清除
  await page.getByTestId('category-emg.hospital').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText('2')
  await page.getByTestId('exposure-clear').click()
  await expect(page.getByTestId('exposure-filtered-count')).toHaveText('5')

  // 应急 A → B → C（无可达路径专用状态，不画线）
  await page.goto('/analysis/emergency?resultId=result.demo.route')
  await expect(page.getByTestId('emergency-page')).toBeVisible()
  await expect(page.getByTestId('route-info')).toContainText('示例路线 A')
  await page.getByTestId('plan-DEMO-ROUTE-B').click()
  await expect(page.getByTestId('route-info')).toContainText('示例路线 B')
  await page.getByTestId('plan-DEMO-ROUTE-C').click()
  await expect(page.getByTestId('route-unreachable')).toBeVisible()
  await expect(page.getByTestId('route-readonly-note')).toContainText('不重算路径')
  await page.screenshot({
    path: testInfo.outputPath('rehearsal-emergency-1920.png'),
    fullPage: true,
  })
})

test('⑤ 成果中心：深链接刷新、方法/输入展示与成果文件下载（6:20—7:10）', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await page.goto('/results/result.demo.risk')
  await expect(page.getByTestId('result-detail-page')).toBeVisible()
  await expect(page.getByTestId('result-detail-name')).toContainText('风险')
  await expect(page.getByTestId('result-map')).toHaveAttribute('data-count', '6')

  // 深链接刷新：路由参数重新解析，页面完整恢复
  await page.reload()
  await expect(page.getByTestId('result-detail-page')).toBeVisible()
  await expect(page.getByTestId('result-detail-name')).toContainText('风险')

  // 方法与输入来源可见（可追溯口径）
  await expect(page.getByTestId('result-method')).toBeVisible()
  await expect(page.getByTestId('result-inputs')).toBeVisible()

  // 成果文件下载（示例包内真实存在的 CSV）
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('download-file.risk.csv').click(),
  ])
  expect(download.suggestedFilename()).toContain('risk-zones.csv')
})

test('⑥ 三类专题图打印：地图快照、示例身份与打印按钮（导出环节）', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  const cases = [
    { path: '/print/risk?resultId=result.demo.risk', title: '风险分级专题图' },
    { path: '/print/exposure?resultId=result.demo.impact', title: '暴露度与影响评估专题图' },
    {
      path: '/print/emergency?resultId=result.demo.route&routeId=DEMO-ROUTE-B',
      title: '应急保障专题图',
    },
  ] as const
  for (const item of cases) {
    await page.goto(item.path)
    await expect(page.getByTestId('print-page')).toBeVisible()
    // 地图快照成功（PNG 数据），打印按钮才可用
    await expect(page.getByTestId('print-map-image')).toHaveAttribute('src', /^data:image\/png/)
    await expect(page.getByTestId('print-title')).toContainText(item.title)
    await expect(page.getByTestId('print-identity')).toContainText('示例')
    await expect(page.getByTestId('print-scale')).toContainText('比例尺')
    await expect(page.getByTestId('print-unavailable')).toBeHidden()
    await expect(page.getByTestId('print-button')).toBeEnabled()
  }
})

test('⑦ 三视口无横向溢出（截图等待业务就绪）与断网可用', async ({ page }, testInfo) => {
  const viewports = [
    { width: 1920, height: 1080 },
    { width: 1366, height: 768 },
    { width: 390, height: 844 },
  ] as const
  for (const viewport of viewports) {
    await page.setViewportSize({ ...viewport })
    await openOverview(page)
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
    ).toBe(true)
    await page.screenshot({
      path: testInfo.outputPath(`rehearsal-overview-${viewport.width}.png`),
      fullPage: true,
    })

    await openMap(page)
    expect(
      await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth),
    ).toBe(true)
    await page.screenshot({
      path: testInfo.outputPath(`rehearsal-map-${viewport.width}.png`),
      fullPage: true,
    })
  }

  // 断网（屏蔽一切非本机请求）后总览与一张图仍完整可用：示例模式离线可用
  await page.context().route(/^https?:\/\/(?!127\.0\.0\.1|localhost)/, (route) => route.abort())
  await openOverview(page)
  await openMap(page)
})
