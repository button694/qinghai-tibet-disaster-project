import { readFileSync } from 'node:fs'

import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段3（属性与空间查询）浏览器用例。
 *
 * 断言方式与阶段2 一致（04 §7）：**不做整页截图比对**，只读界面上真实的状态、
 * 计数、文案与下载到的文件内容。逐条对应 03 §6 与验收句：
 * - 条件生成、过滤、分页、排序、清除；改条件页码回 1；
 * - 危险点缓冲查询可解释，改半径命中变化；
 * - 框选绘制与点选互斥、Esc 取消；
 * - 空结果与服务失败分开；
 * - 表格行定位与地图点选同步；
 * - 导出带条件、来源、示例标识，范围明确。
 *
 * 说明：所有数据来自本机示例包，断网可跑；下载用例只校验文件内容，不校验浏览器下载 UI。
 */

test.use({ acceptDownloads: true })

/** 打开 /map 并等待图层真正渲染（沿用阶段2 的等待口径）。 */
async function openMap(page: Page): Promise<void> {
  await page.goto('/map')
  await expect(page.getByTestId('map-workspace')).toBeVisible()
  await expect(page.getByTestId('map-canvas').locator('canvas').first()).toBeVisible()
  await expect(page.getByTestId('status-visible')).toContainText('已渲染要素')
}

/** 打开查询面板。 */
async function openQuery(page: Page): Promise<void> {
  await page.getByTestId('toggle-query').click()
  await expect(page.getByTestId('query-panel')).toBeVisible()
}

/** 选择查询图层（值即 layerId，来自注册表，不写死中文名）。 */
async function selectLayer(page: Page, layerId: string): Promise<void> {
  await page.getByTestId('query-layer').selectOption(layerId)
  await expect(page.getByTestId('query-layer')).toHaveValue(layerId)
}

/** 读取「全部匹配」的数字。 */
async function matchedTotal(page: Page): Promise<number> {
  const text = (await page.getByTestId('query-total').textContent()) ?? ''
  const matched = /(\d+)/.exec(text)
  return matched?.[1] === undefined ? -1 : Number(matched[1])
}

/** 读取「本页」的数字。 */
async function pageCount(page: Page): Promise<number> {
  const text = (await page.getByTestId('query-page-count').textContent()) ?? ''
  const matched = /(\d+)/.exec(text)
  return matched?.[1] === undefined ? -1 : Number(matched[1])
}

/** 用对象列表选中第一条记录（源对象与地图选中都由此产生）。 */
async function selectFirstObject(page: Page): Promise<string> {
  await page.getByTestId('toggle-object-list').click()
  await expect(page.getByTestId('object-list')).toBeVisible()
  const row = page.locator('[data-testid^="object-row-"]').first()
  await expect(row).toBeVisible()
  const title = ((await row.locator('button.link').textContent()) ?? '').trim()
  await row.locator('button.link').click()
  await expect(page.getByTestId('feature-detail')).toBeVisible()
  return title
}

test('条件生成、过滤、排序、分页：改条件后页码回到第 1 页', async ({ page }) => {
  const errors: string[] = []
  page.on('pageerror', (error) => errors.push(error.message))
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')

  // 未加条件：在全部记录上查询。
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-result')).toContainText('全部匹配')
  const all = await matchedTotal(page)
  expect(all).toBeGreaterThan(0)
  expect(await pageCount(page)).toBeLessThanOrEqual(all)

  // 每页 5 条 → 至少两页，翻到第 2 页。
  await page.getByTestId('query-page-size').selectOption('5')
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-page-info')).toContainText('第 1 /')
  await page.getByTestId('query-next').click()
  await expect(page.getByTestId('query-page-info')).toContainText('第 2 /')
  await expect(page.getByTestId('query-page-info')).toContainText('本页 5 条')

  // 加一条数值条件：页码必须回到 1（否则用户会停在一个不存在的结果页上）。
  await page.getByTestId('add-condition').selectOption('volumeM3::number')
  await expect(page.getByTestId('condition-row-volumeM3')).toBeVisible()
  await page.getByTestId('condition-min-volumeM3').fill('0')
  await expect(page.getByTestId('query-page-info')).toContainText('第 1 /')

  await page.getByTestId('run-query').click()
  const filtered = await matchedTotal(page)
  expect(filtered).toBeGreaterThanOrEqual(0)
  expect(filtered).toBeLessThanOrEqual(all)

  // 排序：点一次升序、再点一次降序，按钮上的箭头随之变化。
  const sortButton = page.getByTestId('sort-volumeM3')
  await sortButton.click()
  await page.getByTestId('run-query').click()
  const asc = await page.getByTestId('query-table').textContent()
  await sortButton.click()
  await page.getByTestId('run-query').click()
  const desc = await page.getByTestId('query-table').textContent()
  expect(asc).not.toBe(desc)

  // 清除条件：回到无条件的全部记录。
  await page.getByTestId('clear-query').click()
  await expect(page.getByTestId('no-condition')).toBeVisible()

  expect(errors, `页面异常：${errors.join('；')}`).toEqual([])
})

test('危险点缓冲查询可解释：改半径命中变化，指标写明米与方法', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)
  const title = await selectFirstObject(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')

  // 对象缓冲：源对象来自地图选中，半径以米为单位。
  await page.getByTestId('spatial-mode').selectOption('buffer')
  await expect(page.getByTestId('spatial-method')).toContainText('米')
  await page.getByTestId('spatial-radius').fill('5000')
  await page.getByTestId('use-selected').click()
  await expect(page.getByTestId('spatial-source')).toContainText(title)

  await page.getByTestId('run-query').click()
  const near = await matchedTotal(page)
  // 0 条命中时也必须能解释：缓冲半径与方法说明不随空状态一起被藏掉。
  await expect(page.getByTestId('query-metrics')).toContainText('缓冲半径')
  await expect(page.getByTestId('query-metrics')).toContainText('米')
  await expect(page.getByTestId('query-metrics')).toContainText('haversine')

  // 半径放大：命中数必须变化（这正是「可解释」的证据）。
  await page.getByTestId('spatial-radius').fill('160000')
  await page.getByTestId('run-query').click()
  const far = await matchedTotal(page)
  expect(far).toBeGreaterThan(near)

  // 未选源对象时如实提示，而不是静默忽略空间条件。
  await page.getByTestId('spatial-mode').selectOption('buffer')
  await expect(page.getByTestId('query-block-reason')).toContainText('源对象')
})

test('框选绘制与点选互斥，Esc 可取消', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')

  // 选择「框选」即进入绘制态（不需要先点按钮）：界面必须说明正在绘制且可 Esc 取消。
  await page.getByTestId('spatial-mode').selectOption('box')
  await expect(page.getByTestId('spatial-draw-state')).toContainText('Esc 取消')

  // Esc 取消：不产生范围，并给出明确提示。
  await page.keyboard.press('Escape')
  await expect(page.getByTestId('spatial-draw-state')).toContainText('未绘制')
  await expect(page.getByTestId('query-block-reason')).toContainText('还没有绘制范围')

  // 真正拉一个框：绘制与点选互斥，绘制期间点地图不应产生选中。
  await page.getByTestId('start-draw').click()
  await expect(page.getByTestId('spatial-draw-state')).toContainText('Esc 取消')
  const canvas = page.getByTestId('map-canvas')
  await canvas.scrollIntoViewIfNeeded()
  const box = await canvas.boundingBox()
  expect(box).not.toBeNull()
  if (!box) return
  const centerX = box.x + box.width / 2
  const centerY = box.y + box.height / 2
  await page.mouse.move(centerX - 120, centerY - 90)
  await page.mouse.down()
  await page.mouse.move(centerX + 120, centerY + 90, { steps: 10 })
  await page.mouse.up()

  await expect(page.getByTestId('spatial-draw-state')).toContainText('已绘制范围')
  await expect(page.getByTestId('query-block-reason')).toHaveCount(0)
  // 绘制期间的点击没有变成「选中对象」——详情面板不应出现。
  await expect(page.getByTestId('feature-detail')).toHaveCount(0)

  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-result')).toContainText('全部匹配')
  expect(await matchedTotal(page)).toBeGreaterThanOrEqual(0)
})

test('空结果与服务失败是两件事', async ({ page }) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')

  // 一、空结果：条件不可能满足 → 有结果（0 条），不是失败。
  // 注意：条件入口来自字段声明，`name` 在示例包中未声明可查询，文本条件取 `entityKey`。
  await page.getByTestId('add-condition').selectOption('entityKey::text')
  await page.getByTestId('condition-text-entityKey').fill('不存在的标识zzz')
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-empty')).toBeVisible()
  await expect(page.getByTestId('query-error')).toHaveCount(0)
  expect(await matchedTotal(page)).toBe(0)
})

test('要素文件读取失败时显示错误状态，不保留上一次结果', async ({ page }) => {
  // 从打开页面起就让该图层的要素文件失败：失败必须原样暴露。
  await page.route('**/features/landslide.geojson', (route) =>
    route.fulfill({ status: 500, contentType: 'text/plain', body: 'boom' }),
  )
  await page.setViewportSize({ width: 1366, height: 768 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')
  await page.getByTestId('run-query').click()

  await expect(page.getByTestId('query-error')).toBeVisible()
  await expect(page.getByTestId('query-empty')).toHaveCount(0)
  // 失败时不显示任何行，也不沿用上一次结果。
  await expect(page.locator('[data-testid^="query-row-"]')).toHaveCount(0)
})

test('表格行定位与地图点选同步，导出 CSV 带条件与示例标识', async ({ page }) => {
  await page.setViewportSize({ width: 1920, height: 1080 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-total')).toBeVisible()

  // 行定位：点击「定位」应选中该对象并打开详情（与地图点选同一套选中状态）。
  const firstRow = page.locator('[data-testid^="query-row-"]').first()
  await expect(firstRow).toBeVisible()
  const rowTitle = ((await firstRow.textContent()) ?? '').trim()
  await firstRow.locator('[data-testid^="query-locate-"]').click()
  await expect(page.getByTestId('feature-detail')).toBeVisible()
  expect(rowTitle.length).toBeGreaterThan(0)

  // 导出 CSV：文件内必须带来源、条件、坐标参考与示例标识。
  const [download] = await Promise.all([
    page.waitForEvent('download'),
    page.getByTestId('export-csv-page').click(),
  ])
  expect(download.suggestedFilename()).toContain('query-export-')
  expect(download.suggestedFilename()).toContain('.csv')
  const file = await download.path()
  expect(file).not.toBeNull()
  if (file === null) return
  const content = readFileSync(file, 'utf8')
  // UTF-8 BOM：否则 Excel 打开中文列头会乱码。
  expect(content.charCodeAt(0)).toBe(0xfeff)
  expect(content).toContain('示例数据')
  expect(content).toContain('示例数据，非真实统计')
  expect(content).toContain('EPSG:4326')
  expect(content).toContain('[经度, 纬度]')
  expect(content).toContain('hazard.landslide')
  // 本次没有加属性条件：文件里必须写明「无（未加条件）」，不能什么都不写让人以为是漏了。
  expect(content).toContain('无（未加条件）')
  expect(content).toContain('空间条件：无（未加空间条件）')
  expect(content).toContain('当前页')
})

test('1366×768：查询面板打开后地图仍有可操作面积，且无横向溢出', async ({ page }, info) => {
  await page.setViewportSize({ width: 1366, height: 768 })
  await openMap(page)
  await openQuery(page)
  await selectLayer(page, 'hazard.landslide')
  await page.getByTestId('run-query').click()
  await expect(page.getByTestId('query-total')).toBeVisible()

  const canvas = page.getByTestId('map-canvas')
  await canvas.scrollIntoViewIfNeeded()
  const box = await canvas.boundingBox()
  // 240px 是设计里「查询面板打开时地图的最小高度」：地图不被面板挤没。
  expect(box?.height ?? 0).toBeGreaterThanOrEqual(240)
  expect(box?.width ?? 0).toBeGreaterThan(400)
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= innerWidth)).toBe(true)

  await page.screenshot({ path: info.outputPath('query-1366.png'), fullPage: true })
})
