import { expect, test, type Page } from '@playwright/test'

/**
 * 阶段6（成果中心、总览与项目说明）浏览器用例。
 *
 * 覆盖：成果筛选与详情深链接、不可用文件禁用与原因、总览指标与明细一致、
 * 三个专题入口、项目说明与只读导入日志、示例身份标注、
 * 1920/1366/390 宽度无横向溢出。
 *
 * 数字口径（示例包固定记录）：3 个已发布成果；风险区 7 个对象；
 * 总览四项指标与风险分布计数同源。
 */

async function assertNoHorizontalOverflow(page: Page): Promise<void> {
  expect(await page.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth)).toBe(
    true,
  )
}

test('成果中心：筛选与清除，卡片口径完整', async ({ page }) => {
  await page.goto('/results')
  await expect(page.getByTestId('results-page')).toBeVisible()
  await expect(page.getByTestId('results-count')).toContainText('共 3 个成果')
  await expect(page.getByTestId('mode-badge')).toContainText('示例')

  await page.getByTestId('results-kind-exposure').click()
  await expect(page.getByTestId('results-count')).toContainText('共 1 个成果')
  await expect(page.getByTestId('result-card-result.demo.impact')).toBeVisible()

  await page.getByTestId('results-status-archived').click()
  await expect(page.getByTestId('results-count')).toContainText('共 0 个成果')

  await page.getByTestId('results-clear').click()
  await expect(page.getByTestId('results-count')).toContainText('共 3 个成果')
})

test('成果详情深链接：地图、指标、方法、输入与文件一次到位', async ({ page }) => {
  await page.goto('/results/result.demo.risk')
  await expect(page.getByTestId('result-detail-page')).toBeVisible()
  await expect(page.getByTestId('result-detail-name')).toContainText('风险')
  await expect(page.getByTestId('result-map')).toBeVisible()
  // 示例风险成果固定为 6 个有几何要素；精确断言同时保证 data-count 确实存在，
  // 避免 `not.toHaveAttribute(..., '0')` 在属性缺失时误判通过。
  await expect(page.getByTestId('result-map')).toHaveAttribute('data-count', '6')
  await expect(page.getByTestId('result-method')).not.toContainText('方法说明未登记')
  await expect(page.getByTestId('result-inputs')).toContainText('地质灾害点')

  // 可用文件给下载入口；不可用文件禁用并显示原因
  await expect(page.getByTestId('download-file.risk.csv')).toBeVisible()
  await expect(page.getByTestId('download-file.risk.geojson')).toBeVisible()
  await expect(page.getByTestId('download-file.risk.csv')).toHaveAttribute(
    'href',
    '/demo/files/risk-zones.csv',
  )
  await expect(page.getByTestId('download-file.risk.geojson')).toHaveAttribute(
    'href',
    '/demo/features/risk-zones.geojson',
  )
  await expect(page.getByTestId('download-disabled-file.risk.pdf')).toBeVisible()
  await expect(page.getByTestId('result-files')).toContainText('示例数据包未提供 PDF')

  // 情景类成果带「未来情景」提示；风险成果提供工作台入口
  await expect(page.getByTestId('result-workspace-link')).toBeVisible()
})

test('应急成果详情：只读路线文件入口与空间范围', async ({ page }) => {
  await page.goto('/results/result.demo.route')
  await expect(page.getByTestId('result-detail-page')).toBeVisible()
  await expect(page.getByTestId('result-map')).toBeVisible()
  await expect(page.getByTestId('download-disabled-file.route.csv')).toBeVisible()
  await expect(page.getByTestId('download-file.route.geojson')).toBeVisible()
  await expect(page.getByTestId('result-workspace-link')).toHaveAttribute(
    'href',
    '/analysis/emergency?resultId=result.demo.route',
  )
})

test('暴露成果详情：工作台入口保留当前 resultId', async ({ page }) => {
  await page.goto('/results/result.demo.impact')
  await expect(page.getByTestId('result-detail-page')).toBeVisible()
  await expect(page.getByTestId('result-workspace-link')).toHaveAttribute(
    'href',
    '/analysis/exposure?resultId=result.demo.impact',
  )
})

test('总览：四项指标、风险分布与成果明细一致，三个专题入口', async ({ page }) => {
  await page.goto('/overview')
  await expect(page.getByTestId('overview-page')).toBeVisible()
  await expect(page.getByTestId('overview-map')).toBeVisible()
  await expect(page.getByTestId('overview-error')).toBeHidden()

  // 四项指标全部渲染且不是「未提供」占位（示例包口径指标齐全）。
  // 自检面板默认收起；这里直接按总览主指标的唯一测试标识断言，避免命中诊断区。
  await expect(page.getByTestId('overview-metric-riskZoneCount')).toBeVisible()

  // 风险分布计数之和 = 已登记风险区对象数（7，含 1 条无几何记录）；
  // 主地图如实只上图 6 个有几何要素，chip 写明「1 条无几何未上图」。
  const distribution = page.getByTestId('overview-distribution')
  await expect(distribution).toBeVisible()
  const counts = await page.locator('[data-dist-key]').allInnerTexts()
  const sum = counts.reduce((total, text) => total + Number(text), 0)
  expect(sum).toBe(7)
  await expect(page.getByTestId('overview-map')).toHaveAttribute('data-count', '6')
  await expect(page.locator('.overview-map-wrap')).toContainText('1 条无几何未上图')

  // 重点对象 ≤3；专题入口齐全
  const keyFeatures = page.getByTestId('overview-key-features')
  await expect(keyFeatures).toBeVisible()
  await expect(page.getByTestId('overview-entries')).toContainText('风险')
  await expect(page.getByTestId('overview-entries')).toContainText('暴露')
  await expect(page.getByTestId('overview-entries')).toContainText('应急')
  await expect(page.locator('[data-testid="overview-entries"] a').first()).toBeVisible()
})

test('总览指标可在成果明细中找到依据（风险区数量）', async ({ page }) => {
  await page.goto('/overview')
  await expect(page.getByTestId('overview-page')).toBeVisible()
  const zoneMetric = page.locator('[data-metric-key="riskZoneCount"]').first()
  const overviewText = await zoneMetric.innerText()
  const match = overviewText.match(/(\d+)/)
  expect(match).toBeTruthy()
  const zoneCount = Number(match?.[1])
  expect(zoneCount).toBe(7)

  // 成果中心进入风险成果详情：上图 6 + 无几何 1 = 7，与总览指标同源
  await page.goto('/results/result.demo.risk')
  await expect(page.getByTestId('result-map')).toHaveAttribute('data-count', '6')
  await expect(page.locator('.result-map-wrap')).toContainText('1 条无几何未上图')
})

test('项目说明：一库六体系、三种模式、边界与只读导入日志', async ({ page }) => {
  await page.goto('/about')
  await expect(page.getByTestId('about-page')).toBeVisible()
  const body = page.locator('[data-testid="about-page"]')
  await expect(body).toContainText('一库六体系')
  await expect(body).toContainText('mock（示例数据）')
  await expect(body).toContainText('snapshot（成果快照）')
  await expect(body).toContainText('api（正式接口）')
  await expect(body).toContainText('同一个年度降水数据集')
  await expect(body).toContainText('不回退示例数据')

  // 导入日志只读展示，明确「不是完整审计日志」
  await expect(body).toContainText('不是完整审计日志')
  await expect(page.getByTestId('about-imports')).toBeVisible()
  await expect(page.locator('[data-import-id="imp.demo.004"]')).toContainText('失败')

  // 报告索引列出但不提供浏览器直链
  await expect(page.getByTestId('about-reports')).toContainText('docs/PROGRESS.md')
})

test('1920/1366/390 宽度：成果中心、总览、详情与说明无横向溢出', async ({ page }) => {
  for (const width of [1920, 1366]) {
    await page.setViewportSize({ width, height: 1080 })
    for (const path of ['/results', '/overview', '/results/result.demo.risk', '/about']) {
      await page.goto(path)
      await expect(
        page
          .locator(
            '[data-testid="results-page"], [data-testid="overview-page"], [data-testid="result-detail-page"], [data-testid="about-page"]',
          )
          .first(),
      ).toBeVisible()
      await assertNoHorizontalOverflow(page)
    }
  }

  await page.setViewportSize({ width: 390, height: 844 })
  for (const path of ['/results', '/overview', '/results/result.demo.risk', '/about']) {
    await page.goto(path)
    await assertNoHorizontalOverflow(page)
  }
  // 手机宽度可完成筛选操作
  await page.goto('/results')
  await page.getByTestId('results-kind-risk').click()
  await expect(page.getByTestId('results-count')).toContainText('共 1 个成果')
})
