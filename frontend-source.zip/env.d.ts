/// <reference types="vite/client" />

/**
 * 前端只读取非秘密配置（见 02 §7）。
 * VITE_ 变量会打进浏览器包，禁止放数据库账号、连接字符串或私密令牌。
 */
interface ImportMetaEnv {
  /** 数据模式：mock | snapshot | api，默认 mock */
  readonly VITE_DATA_MODE?: string
  /** 正式接口前缀，默认 /api/v1 */
  readonly VITE_API_BASE_URL?: string
  /** 进入应用时的默认路由，默认 /overview */
  readonly VITE_DEFAULT_ROUTE?: string
  /** 示例数据包目录，默认 /demo/ */
  readonly VITE_DEMO_BASE_URL?: string
  /** 成果快照目录，默认 /snapshot/ */
  readonly VITE_SNAPSHOT_BASE_URL?: string
}

interface ImportMeta {
  readonly env: ImportMetaEnv
}
