/**
 * 阶段4：2050/2100 未来情景的业务服务。
 *
 * 数据链路（B2 要求：真实数据必须经数据适配层，组件禁止直接 fetch JSON）：
 *   RiskView / stores/risk.ts → 本服务 → repositories/realPreview.ts → public/real-preview/*.json
 *
 * 与地图服务同样的约定：
 * - 读取失败原样抛出，调用方显示错误并允许重试，**不回退示例数据**；
 * - 每年数据装载成功后缓存，模式/年份切换不重复请求；clear() 清缓存；
 * - 归一化在服务层完成（domain/scenario.toScenarioRecord），坏记录计数不静默。
 */
import { toScenarioRecord, type ScenarioDataset, type ScenarioYear } from '@/domain/scenario'
import type { PreviewManifest } from '@/repositories/realPreview'
import { createRealPreviewRepository } from '@/repositories/realPreview'
import type { JsonFetcher } from '@/repositories/json/loader'
import { createJsonFetcher } from '@/repositories/json/loader'

export interface RiskScenarioService {
  /** 真实清单（来源、时间、坐标系、SHA-256），供来源面板显示。 */
  manifest(): Promise<PreviewManifest>
  /** 读取并归一化指定年份的情景数据；同一年份装载成功后走缓存。 */
  loadScenario(year: ScenarioYear): Promise<ScenarioDataset>
  /** 模式切换或强制刷新时清空缓存。 */
  clear(): void
}

export function createRiskScenarioService(fetcher?: JsonFetcher): RiskScenarioService {
  const repository = createRealPreviewRepository(
    fetcher ?? createJsonFetcher({ baseUrl: `${import.meta.env.BASE_URL}real-preview/` }),
  )
  const cache = new Map<ScenarioYear, ScenarioDataset>()

  async function manifest(): Promise<PreviewManifest> {
    return repository.manifest()
  }

  async function loadScenario(year: ScenarioYear): Promise<ScenarioDataset> {
    const cached = cache.get(year)
    if (cached) return cached
    const { layer, features } = await repository.scenarioFeatures(year)
    const records = []
    let skippedInvalid = 0
    for (const feature of features.features) {
      const raw = feature as unknown as Record<string, unknown>
      const record = toScenarioRecord(raw)
      if (record === null) {
        skippedInvalid += 1
        continue
      }
      records.push(record)
    }
    const dataset: ScenarioDataset = {
      year,
      sourceLayer: layer.sourceLayer,
      label: layer.label,
      sha256: layer.sha256,
      records,
      total: layer.count,
      skippedInvalid,
    }
    cache.set(year, dataset)
    return dataset
  }

  function clear(): void {
    cache.clear()
  }

  return { manifest, loadScenario, clear }
}

/* ------------------------------------------------------------------ *
 * 应用级单例
 * ------------------------------------------------------------------ */

let current: RiskScenarioService | null = null

/** 应用级单例；`setRiskScenarioService(null)` 用于测试替换。 */
export function getRiskScenarioService(): RiskScenarioService {
  if (current === null) current = createRiskScenarioService()
  return current
}

export function setRiskScenarioService(service: RiskScenarioService | null): void {
  current = service
}
