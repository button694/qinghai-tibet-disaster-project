/**
 * 阶段7：专题图打印视图取数服务。
 *
 * 把风险、暴露、应急三类专题图打印页需要的「标题 / 范围 / 时间 / 方法口径 /
 * 来源 / 图例 / 要素 / 指标 / 示例身份」组合成一个可打印的数据集。
 * 取数一律经 Repository 与既有工作台服务；任何读取失败都向上抛错，
 * 由打印页显示明确错误，**不回退示例数据、不输出看似成功的空白地图**。
 */
import { getRepositories } from '@/repositories'
import { createEmergencyWorkspaceService } from '@/services/emergencyWorkspace'
import { createExposureWorkspaceService } from '@/services/exposureWorkspace'
import { createResultsCenterService } from '@/services/resultsCenter'
import { RISK_LEVEL_COLOR, RISK_LEVEL_LABEL, GRADED_RISK_LEVELS } from '@/domain/risk'
import { MAP_COLORS } from '@/config/mapStyle'
import { formatDistance } from '@/domain/format'
import type { FeatureDetail, FeatureRef, Metric, RouteDetail } from '@/domain/types'
import type { Repositories } from '@/repositories/types'

export type PrintKind = 'risk' | 'exposure' | 'emergency'

export interface PrintLegendEntry {
  /** 图例色块颜色（来自 domain/risk 与 mapStyle 常量，不另造色）。 */
  color: string
  label: string
  /** 补充说明（如「斜线纹理」）。 */
  note?: string
  /** 线型图例（主/备选路线用 dashed 区分）。 */
  dashed?: boolean
}

export interface PrintSheet {
  kind: PrintKind
  /** 页面主标题（如「风险分级专题图」）。 */
  title: string
  /** 成果标题与版本。 */
  resultTitle: string
  /** 统计范围（成果登记的 regionLabel）。 */
  regionLabel: string
  /** 成果生成时间（已格式化）。 */
  timeLabel: string
  /** 方法或口径（缺失时显示「未提供」）。 */
  methodLabel: string | null
  /** 来源行（输入数据集 + 数据模式身份）。 */
  sourceLines: string[]
  /** 示例/真实标识（打印件必须持续携带）。 */
  identityLabel: string
  legend: PrintLegendEntry[]
  /** 地图要素（风险区 / 影响范围+受影响对象 / 路线相关标记）。 */
  features: FeatureDetail[]
  /** 应急路线（仅 emergency；无路径时几何为 null，地图不画线）。 */
  route: RouteDetail | null
  /** 指标行（已格式化前的一次性数据）。 */
  metrics: Metric[]
  /** 口径与缺失说明（人口未提供、去重规则、阻断条件等）。 */
  notes: string[]
  /** 距离/时间行（emergency；已按口径格式化）。 */
  measureLine: string | null
}

export interface PrintSheetsService {
  buildSheet(kind: PrintKind, resultId: string, routeId?: string | null): Promise<PrintSheet>
}

const SAMPLE_IDENTITY = '示例数据 / 合成成果 · 只读 · 不可作为正式分析结论'

const API_IDENTITY = '正式 API / QTP_GEOHAZARD 已登记成果 · 只读 · 不含前端重算'

/** 简单时间格式化：TimeValue.value 为登记字符串；缺时间或值为 null 显示「未提供」。 */
function timeText(time: { value: string | null; precision: string; role: string } | null): string {
  if (time === null || time.value === null) return '未提供'
  const precisionText = time.precision === 'day' ? '' : time.precision === 'year' ? '（年）' : ''
  return `${time.value}${precisionText}`
}

export function createPrintSheetService(repositories: Repositories): PrintSheetsService {
  const resultsCenter = createResultsCenterService(repositories)
  // 打印服务持有自己的工作台实例（注入同一份仓储），便于测试替换失败取数器。
  const exposure = createExposureWorkspaceService(repositories)
  const emergency = createEmergencyWorkspaceService(repositories)
  const identityLabel = repositories.mode === 'api' ? API_IDENTITY : SAMPLE_IDENTITY

  async function buildSheet(
    kind: PrintKind,
    resultId: string,
    routeId?: string | null,
  ): Promise<PrintSheet> {
    if (kind === 'risk') return buildRiskSheet(resultId)
    if (kind === 'exposure') return buildExposureSheet(resultId)
    return buildEmergencySheet(resultId, routeId ?? null)
  }

  async function buildRiskSheet(resultId: string): Promise<PrintSheet> {
    const detail = await resultsCenter.getResultDetail(resultId)
    const classification = detail.result.classification
    const legend: PrintLegendEntry[] = (classification?.classes ?? []).map((item) => ({
      color: RISK_LEVEL_COLOR[item.code],
      label: item.label,
      note: item.code === 'insufficient' ? '斜线纹理 + 文字标注' : undefined,
    }))
    if (legend.length === 0 && repositories.mode === 'api') {
      // 正式 API 未登记分级阈值时使用中性点图例，不能凭空生成五级风险图例。
      legend.push({
        color: MAP_COLORS.pointFill,
        label: '已登记易发性成果点（颜色不表示分级）',
        note: 'HAZ_LEVEL / SCORE 保留数据库原值',
      })
    } else if (legend.length === 0) {
      // 示例/快照的历史口径仍沿用既有分级图例。
      for (const level of GRADED_RISK_LEVELS) {
        legend.push({ color: RISK_LEVEL_COLOR[level], label: RISK_LEVEL_LABEL[level] })
      }
    }
    const notes = [...detail.result.qualityNotes]
    const total = detail.result.metrics.find((metric) => metric.key === 'pointCount')?.value
    if (repositories.mode === 'api') {
      notes.push(
        `正式 API 打印地图仅取当前页（服务端当前返回页）${detail.features.length} 点${typeof total === 'number' ? ` / 登记总量 ${total} 点` : ''}，不代表全量一次性展开。`,
      )
    }
    if (detail.result.classification !== null) {
      notes.push(`分级边界规则：${detail.result.classification.boundaryRule}`)
    } else if (repositories.mode === 'api') {
      notes.push(
        '正式 API 未登记分级阈值；本图使用中性点样式，颜色不表示风险等级。HAZ_LEVEL / SCORE 保留数据库原值。',
      )
    }
    const countWithGeometry = detail.features.filter((item) => item.geometry !== null).length
    if (detail.features.length > countWithGeometry) {
      notes.push(`${detail.features.length - countWithGeometry} 条记录无几何，未上图（不补造坐标）`)
    }
    return {
      kind: 'risk',
      title: '风险分级专题图',
      resultTitle: `${detail.result.title}（版本 ${detail.result.version}）`,
      regionLabel: detail.result.regionLabel,
      timeLabel: timeText(detail.result.time),
      methodLabel: detail.result.method,
      sourceLines: detail.inputLabels.map(
        (input) =>
          `${input.role}：${input.name ?? input.datasetId}${input.version ? `（${input.version}）` : ''}`,
      ),
      identityLabel,
      legend,
      features: detail.features,
      route: null,
      metrics: detail.result.metrics,
      notes,
      measureLine: null,
    }
  }

  async function buildExposureSheet(resultId: string): Promise<PrintSheet> {
    const [result, summary] = await Promise.all([
      exposure.getResult(resultId),
      exposure.getExposureSummary(resultId),
    ])
    const impactAreas = await exposure.listImpactAreas(summary.impactLayerId)
    // 受影响对象：按类别全量取（打印不分页；总数与统计同口径）。
    const affected: FeatureDetail[] = []
    for (const category of summary.affectedCategories) {
      let page = 1
      for (;;) {
        const pageData = await exposure.listAffectedFeatures(resultId, {
          category: category.key,
          page,
          pageSize: 200,
        })
        affected.push(...pageData.items)
        if (affected.length >= pageData.total || pageData.items.length === 0) break
        page += 1
      }
    }
    const legend: PrintLegendEntry[] = [
      { color: RISK_LEVEL_COLOR.high, label: '已存影响范围（面）' },
      { color: RISK_LEVEL_COLOR.low, label: '受影响对象（点/线）' },
    ]
    const notes: string[] = []
    if (summary.deduplicationRule !== null) notes.push(`去重规则：${summary.deduplicationRule}`)
    if (summary.populationYear !== null) notes.push(`人口数据年份：${summary.populationYear}`)
    if (summary.scopeMethod !== null) notes.push(`裁切口径：${summary.scopeMethod}`)
    if (summary.note !== null) notes.push(summary.note)
    notes.push(
      `统计记录数 ${summary.matchedRecordCount} 条 / 去重后对象 ${summary.uniqueEntityCount} 个（分开显示）`,
    )
    return {
      kind: 'exposure',
      title: '暴露度与影响评估专题图',
      resultTitle: `${result.title}（版本 ${result.version}）`,
      regionLabel: result.regionLabel,
      timeLabel: timeText(result.time),
      methodLabel: summary.scopeMethod ?? result.method,
      sourceLines: [
        `影响范围图层：${summary.impactLayerId}`,
        summary.hazardRef === null
          ? '来源对象：多个危险源（按 hazardRefId 真实关联，不合并）'
          : `来源对象：${summary.hazardRef.layerId}/${summary.hazardRef.id}`,
      ],
      identityLabel,
      legend,
      features: [...impactAreas, ...affected],
      route: null,
      metrics: summary.metrics,
      notes,
      measureLine: null,
    }
  }

  async function buildEmergencySheet(
    resultId: string,
    routeId: string | null,
  ): Promise<PrintSheet> {
    const [result, routes] = await Promise.all([
      emergency.getResult(resultId),
      emergency.listRoutes(resultId),
    ])
    const chosen =
      (routeId !== null ? routes.find((item) => item.id === routeId) : undefined) ??
      routes.find((item) => item.role === 'primary') ??
      routes[0]
    if (chosen === undefined) {
      throw new Error(`成果 ${resultId} 未登记任何已存路线，无法生成应急专题图打印件`)
    }
    const detail = await emergency.getRoute(chosen.id)

    // 风险段/阻断点标记：只经真实关联取数（hazardRefId/FeatureRef），失败只少画一个标记。
    const marked: FeatureDetail[] = []
    const refs = [
      ...detail.blockedFeatureRefs,
      ...detail.riskSegments
        .map((segment) => segment.ref)
        .filter((ref): ref is FeatureRef => ref !== null),
    ]
    const seenRefs = new Set<string>()
    for (const ref of refs) {
      const refKey = `${ref.layerId}/${ref.id}`
      if (seenRefs.has(refKey)) continue
      seenRefs.add(refKey)
      try {
        marked.push(await emergency.getFeature(ref))
      } catch {
        // 引用要素不可读：在说明中如实记录，不在地图上猜位置。
      }
    }
    const legend: PrintLegendEntry[] = [
      { color: RISK_LEVEL_COLOR.low, label: '主方案路线', dashed: false },
      { color: RISK_LEVEL_COLOR.low, label: '备选方案路线', dashed: true },
      { color: RISK_LEVEL_COLOR.high, label: '风险路段 / 阻断点' },
    ]
    const notes: string[] = [`路网版本：${detail.networkVersion}`]
    for (const segment of detail.riskSegments) {
      notes.push(
        `风险段：${segment.label}（${segment.kind === 'blocked' ? '阻断' : '风险'}${segment.note ? `；${segment.note}` : ''}）`,
      )
    }
    for (const blocked of detail.blockedFeatureRefs) {
      notes.push(`阻断引用：${blocked.layerId}/${blocked.id}（既有方案条件，只读，不可重算）`)
    }
    if (seenRefs.size > marked.length) {
      notes.push(`${seenRefs.size - marked.length} 个引用要素不可读，未上图（不猜测位置）`)
    }
    if (detail.geometry === null) {
      notes.push('无可达路径：地图不画线、无距离与时间数字（不按固定速度估算）')
    }
    for (const resource of detail.resources) {
      const distanceText =
        resource.distanceFromRouteMeters === null
          ? '距离未提供'
          : `距路线 ${formatDistance(resource.distanceFromRouteMeters)}`
      notes.push(`应急资源：${resource.label}（${resource.kind}；${distanceText}）`)
    }
    const measureParts: string[] = []
    if (detail.distanceMeters !== null) {
      measureParts.push(`距离 ${formatDistance(detail.distanceMeters)}（${detail.distanceSource}）`)
    }
    if (detail.durationSeconds !== null && detail.durationSource !== null) {
      measureParts.push(
        `时间 ${Math.round(detail.durationSeconds / 60)} 分钟（${detail.durationSource}）`,
      )
    }
    return {
      kind: 'emergency',
      title: '应急保障专题图',
      resultTitle: `${result.title} · ${chosen.label}（${chosen.id}）`,
      regionLabel: result.regionLabel,
      timeLabel: timeText(result.time),
      methodLabel: result.method,
      sourceLines: [
        detail.distanceSource,
        detail.durationSource ?? '时间来源：未登记（无预计时间）',
      ],
      identityLabel,
      legend,
      features: marked,
      route: detail,
      metrics: result.metrics,
      notes,
      measureLine: measureParts.length > 0 ? measureParts.join('；') : null,
    }
  }

  return { buildSheet }
}

let current: PrintSheetsService | null = null

/** 应用级单例；测试可 setPrintSheetService(null) 恢复。 */
export function getPrintSheetService(): PrintSheetsService {
  if (current === null) current = createPrintSheetService(getRepositories())
  return current
}

export function setPrintSheetService(service: PrintSheetsService | null): void {
  current = service
}
