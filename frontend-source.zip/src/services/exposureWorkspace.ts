/**
 * 阶段5：暴露度工作台服务。
 *
 * 职责：把 ResultRepository / LayerRepository 的取数组合成暴露页需要的最小集合，
 * 页面与组件只经本服务（经 store）取数，不直接触碰 Repository，也不直接 fetch JSON。
 *
 * 真实性边界（本轮任务）：
 * - 只读**已存**影响范围、统计与对象清单（mock 模式下由数据包派生，派生口径随指标说明返回）；
 * - 承灾体反查危险源必须使用真实关联（影响范围记录的 `hazardRefId` 属性），
 *   不做空间接近猜测；
 * - 任何读取失败都向上抛错，由页面显示错误与重试，不回退示例数据。
 */
import { getRepositories } from '@/repositories'
import type {
  ExposureSummary,
  FeatureDetail,
  FeatureRef,
  Page,
  ResultDetail,
  ResultSummary,
} from '@/domain/types'
import type { AffectedFeatureQuery, Repositories, RequestOptions } from '@/repositories/types'
import { fetchAllLayerFeatures } from '@/services/mapLayers'

export interface ExposureWorkspaceService {
  /** 暴露类成果清单（成果入口）。 */
  listExposureResults(options?: RequestOptions): Promise<ResultSummary[]>
  /** 成果详情（方法、输入、质量说明、文件可用性）。 */
  getResult(resultId: string, options?: RequestOptions): Promise<ResultDetail>
  /** 已存暴露统计（人口年份、裁切口径、去重规则、分单位指标）。 */
  getExposureSummary(resultId: string, options?: RequestOptions): Promise<ExposureSummary>
  /** 受影响对象清单：分页 + 类别筛选；分页不改变统计总数。 */
  listAffectedFeatures(
    resultId: string,
    query?: Partial<AffectedFeatureQuery>,
    options?: RequestOptions,
  ): Promise<Page<FeatureDetail>>
  /** 影响范围图层要素（上图的已存范围边界）。 */
  listImpactAreas(layerId: string, options?: RequestOptions): Promise<FeatureDetail[]>
  /** 单个要素（危险源来源对象等）。 */
  getFeature(ref: FeatureRef, options?: RequestOptions): Promise<FeatureDetail>
}

export function createExposureWorkspaceService(
  repositories: Repositories,
): ExposureWorkspaceService {
  const { results, layers } = repositories

  async function listExposureResults(options?: RequestOptions): Promise<ResultSummary[]> {
    const envelope = await results.listResults({ kind: 'exposure', page: 1, pageSize: 50 }, options)
    return envelope.data.items
  }

  async function getResult(resultId: string, options?: RequestOptions): Promise<ResultDetail> {
    const envelope = await results.getResult(resultId, options)
    return envelope.data
  }

  async function getExposureSummary(
    resultId: string,
    options?: RequestOptions,
  ): Promise<ExposureSummary> {
    const envelope = await results.getExposureSummary(resultId, options)
    return envelope.data
  }

  async function listAffectedFeatures(
    resultId: string,
    query?: Partial<AffectedFeatureQuery>,
    options?: RequestOptions,
  ): Promise<Page<FeatureDetail>> {
    const envelope = await results.listAffectedFeatures(resultId, query, options)
    return envelope.data
  }

  async function listImpactAreas(
    layerId: string,
    options?: RequestOptions,
  ): Promise<FeatureDetail[]> {
    // 全量取数（翻页循环）：影响范围数量有限，但不再依赖某个固定首页大小；
    // 总量再大也如实按 total 循环取完。
    const result = await fetchAllLayerFeatures({ layers }, layerId, { requestOptions: options })
    return result.features
  }

  async function getFeature(ref: FeatureRef, options?: RequestOptions): Promise<FeatureDetail> {
    const envelope = await layers.getFeature(ref, options)
    return envelope.data
  }

  return {
    listExposureResults,
    getResult,
    getExposureSummary,
    listAffectedFeatures,
    listImpactAreas,
    getFeature,
  }
}

let current: ExposureWorkspaceService | null = null

/** 应用级单例；`setExposureWorkspaceService(null)` 用于测试替换。 */
export function getExposureWorkspaceService(): ExposureWorkspaceService {
  if (current === null) current = createExposureWorkspaceService(getRepositories())
  return current
}

/** 测试替换用；传 null 恢复默认单例。 */
export function setExposureWorkspaceService(service: ExposureWorkspaceService | null): void {
  current = service
}
