/**
 * 阶段8B：API 数据链路工作台服务。
 *
 * 只在 api 模式下提供真实数据浏览能力（数据目录摘要、行政区/字典、
 * 白名单矢量图层要素、已存救援路线）。全部取数经 Repository，页面零直接 fetch。
 *
 * 真实性边界：
 * - 仅展示 HTTP Repository 返回的真实数据库数据，不与示例包混写；
 * - 失败如实抛错（页面显示错误态），绝不回退 mock；
 * - 未接入的能力（统计、空间查询、总览等）由 capabilities 显式关闭并给原因。
 */
import { getRepositories } from '@/repositories'
import type {
  Dataset,
  Dictionary,
  FeatureDetail,
  FeatureRef,
  LayerDefinition,
  Page,
  Region,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import type { RequestOptions } from '@/repositories/types'

export interface ApiDataQuery {
  page: number
  pageSize: number
}

export interface ApiDataWorkspaceService {
  listLayers(options?: RequestOptions): Promise<LayerDefinition[]>
  listDatasets(page: number, pageSize: number, options?: RequestOptions): Promise<Page<Dataset>>
  listRegions(options?: RequestOptions): Promise<Region[]>
  getDictionary(dictionaryId: string, options?: RequestOptions): Promise<Dictionary>
  listFeatures(
    layerId: string,
    query: ApiDataQuery,
    options?: RequestOptions,
  ): Promise<Page<FeatureDetail>>
  getFeature(ref: FeatureRef, options?: RequestOptions): Promise<FeatureDetail>
  /** 阶段8B返工：服务端分页——page 缺省 1，pageSize 缺省 20（路线接口上限 100）。 */
  listRoutes(
    resultId: string,
    query?: { page?: number; pageSize?: number },
    options?: RequestOptions,
  ): Promise<Page<RouteSummary>>
  getRoute(routeId: string, options?: RequestOptions): Promise<RouteDetail>
}

export function createApiDataWorkspaceService(): ApiDataWorkspaceService {
  const { layers, catalog, results } = getRepositories()

  return {
    listLayers(options) {
      return layers.listLayers(undefined, options).then((envelope) => envelope.data)
    },
    listDatasets(page, pageSize, options) {
      return catalog.listDatasets({ page, pageSize }, options).then((envelope) => envelope.data)
    },
    listRegions(options) {
      return catalog.listRegions(undefined, options).then((envelope) => envelope.data)
    },
    getDictionary(dictionaryId, options) {
      return catalog.getDictionary(dictionaryId, options).then((envelope) => envelope.data)
    },
    listFeatures(layerId, query, options) {
      return layers
        .listFeatures(layerId, { page: query.page, pageSize: query.pageSize }, options)
        .then((envelope) => envelope.data)
    },
    getFeature(ref, options) {
      return layers.getFeature(ref, options).then((envelope) => envelope.data)
    },
    listRoutes(resultId, query, options) {
      return results.listRoutes(resultId, query, options).then((envelope) => envelope.data)
    },
    getRoute(routeId, options) {
      return results.getRoute(routeId, options).then((envelope) => envelope.data)
    },
  }
}

let current: ApiDataWorkspaceService | null = null

export function getApiDataWorkspaceService(): ApiDataWorkspaceService {
  if (current === null) current = createApiDataWorkspaceService()
  return current
}

/** 测试替换用。 */
export function setApiDataWorkspaceService(service: ApiDataWorkspaceService | null): void {
  current = service
}
