/**
 * 阶段6：成果中心服务。
 *
 * 职责：把 ResultRepository / LayerRepository / CatalogRepository 的取数组合成
 * 成果中心列表与成果详情页需要的最小集合。页面与组件只经本服务（经 store）取数。
 *
 * 真实性边界：
 * - 文件下载只对「available 且登记了 url」的文件开放；不可用文件保留元数据并
 *   显示 unavailableReason，禁用下载入口（01 §5.5）。
 * - 成果地图只画已存成果要素（result 图层）；无几何时显示空间范围或专用说明，
 *   不伪造几何。
 * - 任何读取失败都向上抛错，由页面显示错误与重试，不回退示例数据。
 */
import { getRepositories } from '@/repositories'
import type {
  Bbox,
  FeatureDetail,
  LayerDefinition,
  ResultDetail,
  ResultKind,
  ResultStatus,
  ResultSummary,
} from '@/domain/types'
import type { Repositories, RequestOptions } from '@/repositories/types'
import { createMapLayerService } from '@/services/mapLayers'

export interface ResultListQuery {
  kind?: ResultKind
  status?: ResultStatus
  page: number
  pageSize: number
}

export interface ResultCenterDetail {
  result: ResultDetail
  /** 成果关联图层的已存要素（用于详情地图；图层不可用时为空数组）。 */
  features: FeatureDetail[]
  /** 参与渲染的图层定义（含样式选择依据）。 */
  layers: LayerDefinition[]
  /** 已存要素整体范围框（西、南、东、北）；无几何要素时为 null。 */
  extent: Bbox | null
  /** 输入数据集名称（按 datasetId 解析；解析失败保留 id）。 */
  inputLabels: Array<{
    datasetId: string
    name: string | null
    version: string | null
    role: string
  }>
}

export interface ResultsCenterService {
  /** 成果列表：类型/状态筛选 + 分页。 */
  listResults(query: ResultListQuery, options?: RequestOptions): Promise<ResultSummary[]>
  /** 成果详情：指标、方法、输入、文件、已存要素与范围。 */
  getResultDetail(resultId: string, options?: RequestOptions): Promise<ResultCenterDetail>
}

export function createResultsCenterService(repositories: Repositories): ResultsCenterService {
  const { results, layers, catalog } = repositories
  // 独立实例（不是应用级单例）：与地图工作台各自维护自己的全量加载缓存，
  // 避免成果详情页装载状态和主地图图层树的加载状态互相影响。
  const mapLayerService = createMapLayerService(repositories)

  async function listResults(
    query: ResultListQuery,
    options?: RequestOptions,
  ): Promise<ResultSummary[]> {
    const envelope = await results.listResults(
      {
        kind: query.kind,
        status: query.status,
        page: query.page,
        pageSize: query.pageSize,
      },
      options,
    )
    return envelope.data.items
  }

  async function getResultDetail(
    resultId: string,
    options?: RequestOptions,
  ): Promise<ResultCenterDetail> {
    const detailEnvelope = await results.getResult(resultId, options)
    const result = detailEnvelope.data

    // 成果图层要素：一个成果通常只有 1 个图层，这里按登记顺序全部尝试装载。
    const layerDefs: LayerDefinition[] = []
    for (const layerId of result.layerIds) {
      try {
        const envelope = await layers.getLayer(layerId, options)
        layerDefs.push(envelope.data)
      } catch {
        // 图层未登记：详情地图少画一层，方法与文件信息不受影响。
      }
    }

    const features: FeatureDetail[] = []
    for (const layer of layerDefs) {
      if (layer.source.type !== 'geojson') continue
      try {
        // 阶段8C：改用 MapLayerService 的全量分页加载——
        // 成果详情地图（如救援路线 4566/1731/1872 条）不再只画首个服务页，
        // 现在按同一套翻页循环取全部要素；线/面几何按渲染容差简化，属性不受影响。
        const result = await mapLayerService.loadLayer(layer, options)
        if (result.status === 'ready') features.push(...result.features)
      } catch {
        // 要素读取失败：地图显示无要素说明，不阻塞指标与文件。
      }
    }

    let extent: Bbox | null = null
    for (const feature of features) {
      if (feature.geometry === null) continue
      // FeatureDetail.geometry 为 GeoJSON 几何；逐要素取坐标范围（粗粒度，仅用于概览定位）。
      collectGeometryExtent(feature.geometry, (box) => {
        if (extent === null) extent = box
        else
          extent = [
            Math.min(extent[0], box[0]),
            Math.min(extent[1], box[1]),
            Math.max(extent[2], box[2]),
            Math.max(extent[3], box[3]),
          ]
      })
    }

    const inputLabels = await Promise.all(
      result.inputs.map(async (input) => {
        try {
          const envelope = await catalog.getDataset(input.datasetId, options)
          return {
            datasetId: input.datasetId,
            name: envelope.data.name,
            version: input.version,
            role: input.role,
          }
        } catch {
          // 输入数据集未登记：保留 id 如实显示。
          return {
            datasetId: input.datasetId,
            name: null,
            version: input.version,
            role: input.role,
          }
        }
      }),
    )

    return { result, features, layers: layerDefs, extent, inputLabels }
  }

  return { listResults, getResultDetail }
}

/** 从 GeoJSON 几何收集范围框（西、南、东、北）；GeometryCollection 递归展开。 */
function collectGeometryExtent(
  geometry: { type: string; coordinates?: unknown; geometries?: unknown[] },
  push: (box: Bbox) => void,
): void {
  let box: Bbox | null = null
  const visitCoordinates = (coordinates: unknown): void => {
    if (!Array.isArray(coordinates)) return
    if (typeof coordinates[0] === 'number' && typeof coordinates[1] === 'number') {
      const lon = coordinates[0] as number
      const lat = coordinates[1] as number
      if (box === null) box = [lon, lat, lon, lat]
      else {
        box = [
          Math.min(box[0], lon),
          Math.min(box[1], lat),
          Math.max(box[2], lon),
          Math.max(box[3], lat),
        ]
      }
      return
    }
    for (const child of coordinates) visitCoordinates(child)
  }
  if (Array.isArray(geometry.geometries)) {
    for (const child of geometry.geometries) {
      if (child && typeof child === 'object') collectGeometryExtent(child as typeof geometry, push)
    }
    return
  }
  visitCoordinates(geometry.coordinates)
  if (box !== null) push(box)
}

let current: ResultsCenterService | null = null

/** 应用级单例；`setResultsCenterService(null)` 用于测试替换。 */
export function getResultsCenterService(): ResultsCenterService {
  if (current === null) current = createResultsCenterService(getRepositories())
  return current
}

/** 测试替换用；传 null 恢复默认单例。 */
export function setResultsCenterService(service: ResultsCenterService | null): void {
  current = service
}
