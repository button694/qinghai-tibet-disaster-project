import GeoJSON from 'ol/format/GeoJSON'
import type { FeatureDetail, RouteSummary } from '@/domain/types'

export type Scope = 'combined' | '2050' | '2100'
export const scopeLayers: Record<Scope, { points: string; routes: string }> = {
  combined: { points: 'DS_RES_SUSCEPTIBILITY_PT', routes: 'DS_RES_HAZARD_RESCUE_ROUTE_LN' },
  '2050': { points: 'DS_HAZ_SUSCEPTIBILITY_2050', routes: 'DS_RES_HAZ_RESC_ROUTE_2050_LN' },
  '2100': { points: 'DS_HAZ_SUSCEPTIBILITY_2100', routes: 'DS_RES_HAZ_RESC_ROUTE_2100_LN' },
}
const cache = new Map<string, Promise<any>>()
export function snapshotFile<T>(name: string): Promise<T> {
  if (!cache.has(name)) {
    const request = fetch(`${import.meta.env.BASE_URL}published-snapshot/${name}`).then(r => {
      if (!r.ok) throw new Error(`Data request failed (${r.status}): ${name}`)
      return r.json()
    }).catch(error => { cache.delete(name); throw error })
    cache.set(name, request)
  }
  return cache.get(name)!
}
export async function snapshotLayer(id: string): Promise<FeatureDetail[]> {
  return (await snapshotFile<{items: FeatureDetail[]}>(`layers/${id}.json`)).items
}
export function pointId(point: FeatureDetail): string {
  return String(point.properties.hazardPointId ?? point.properties.glacierId ?? point.ref.id)
}
/** Match against the selected polygon, including holes and MultiPolygon components. */
export function pointsInRegion(points: FeatureDetail[], region: FeatureDetail | null): FeatureDetail[] {
  if (!region) return points
  if (!region.geometry) return []
  const polygon = new GeoJSON().readGeometry(region.geometry)
  if (!polygon) return []
  return points.filter(p => p.geometry?.type === 'Point' && polygon.intersectsCoordinate(p.geometry.coordinates))
}
export interface RouteLink {
  routeCode: string
  hazardPointId: string
  sourceHazardId: string | null
  facilityLayer: string | null
  facilityPk: string | null
}
export function routesForPoint(point: FeatureDetail, routes: RouteSummary[], links: RouteLink[]): RouteSummary[] {
  const id = pointId(point)
  const keys = new Set(links.filter(l => l.sourceHazardId === id || l.hazardPointId === id).map(l => l.routeCode))
  return routes.filter(r => r.hazardPointId === id || keys.has(r.id.split(':')[1]!))
}
