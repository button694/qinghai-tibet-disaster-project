import { appEnv } from '@/config/env'

export interface RasterAsset {
  id: string
  name: string
  bytes: number
  /** 是否为分类栅格（同名 .vat.dbf 属性表存在）。 */
  classified?: boolean
  /** 是否为角度型循环量栅格（目前只有坡向）。 */
  circular?: boolean
  /** true 表示当前条目来自交付包内 PNG 预览而非原始栅格。 */
  previewOnly?: boolean
  /** 属于同一年份序列时的全部年份；不是序列资产则为 null。 */
  seriesYears?: number[] | null
}

/** 渲染方式：连续色阶 / 分类定性配色 / 角度型循环色轮。 */
export type RasterRenderMode = 'continuous' | 'categorical' | 'circular'

/** 分类栅格图例条目：来自源栅格属性表（.vat.dbf）的真实类别与计数。 */
export interface RasterCategoricalLegendItem {
  value: number
  name: string | null
  color: string
  count: number | null
}

/** 循环色轮图例条目：罗盘方向刻度，或平坦（无坡向）说明。 */
export interface RasterCircularLegendItem {
  degree: number | null
  label: string
  color: string
}

/** 同一数据集的年份序列信息（目前只有年度降水）。 */
export interface RasterSeriesInfo {
  years: number[]
  currentYear: number
  assets: Record<string, string>
  sharedDomain: [number, number] | null
  domainNote: string | null
}

export interface RasterPreview {
  id: string
  bounds: [number, number, number, number]
  sourceWidth: number
  sourceHeight: number
  /** Native-grid dimensions read before the bounded preview is rendered. */
  sampleWidth?: number
  sampleHeight?: number
  width: number
  height: number
  sampleMin: number | null
  sampleMax: number | null
  note: string
  /** true 表示详情由交付包内预生成 PNG 提供。 */
  previewOnly?: boolean
  imageUrl: string
  renderMode: RasterRenderMode
  legend: RasterCategoricalLegendItem[] | RasterCircularLegendItem[] | null
  legendNote?: string | null
  /** 连续栅格实际用于拉伸色阶的值域；分类/循环栅格为 null。 */
  colorScaleMin?: number | null
  colorScaleMax?: number | null
  series?: RasterSeriesInfo | null
}

const base = () => appEnv.apiBaseUrl.replace(/\/$/, '')

function requestUrl(path: string): string {
  return `${base()}${path.startsWith('/') ? path : `/${path}`}`
}

/**
 * 栅格接口专用错误：携带后端契约错误码（如 SERVICE_UNAVAILABLE），
 * 供调用方区分「真实故障」与「栅格数据目录本就未随包分发」这类预期状态，
 * 不能都渲染成同一种告警态。
 */
export class RasterServiceError extends Error {
  readonly code: string
  constructor(code: string, message: string) {
    super(message)
    this.name = 'RasterServiceError'
    this.code = code
  }
}

function errorInfo(body: unknown, fallback: string): { code: string; message: string } {
  if (typeof body !== 'object' || body === null) return { code: 'UNKNOWN', message: fallback }
  const error = (body as { error?: unknown }).error
  if (typeof error !== 'object' || error === null) return { code: 'UNKNOWN', message: fallback }
  const { code, message } = error as { code?: unknown; message?: unknown }
  return {
    code: typeof code === 'string' && code.trim() !== '' ? code : 'UNKNOWN',
    message: typeof message === 'string' && message.trim() !== '' ? message : fallback,
  }
}

async function jsonData<T>(response: Response, fallback: string): Promise<T> {
  let body: unknown
  try {
    body = await response.json()
  } catch {
    throw new RasterServiceError('UNKNOWN', fallback)
  }
  if (!response.ok) {
    const { code, message } = errorInfo(body, fallback)
    throw new RasterServiceError(code, message)
  }
  if (typeof body !== 'object' || body === null || !('data' in body)) {
    throw new RasterServiceError('UNKNOWN', `${fallback}：响应格式无效`)
  }
  return (body as { data: T }).data
}

async function get<T>(path: string, signal?: AbortSignal): Promise<T> {
  const response = await fetch(requestUrl(path), { signal })
  return jsonData<T>(response, '真实栅格服务读取失败')
}

export const rasterData = {
  list: (signal?: AbortSignal) =>
    get<{ items: RasterAsset[]; total: number; previewOnly?: boolean; note?: string }>(
      '/rasters',
      signal,
    ),
  detail: (id: string, signal?: AbortSignal) =>
    get<RasterPreview>(`/rasters/${encodeURIComponent(id)}`, signal),
  image: async (url: string, signal?: AbortSignal) => {
    const response = await fetch(requestUrl(url), { signal })
    if (!response.ok) {
      // 失败时后端仍按统一错误信封返回 JSON（而非图片字节），复用同一套解析逻辑，
      // 避免 SERVICE_UNAVAILABLE 状态被这里的兜底文案吞掉。
      const { code, message } = errorInfo(
        await response.json().catch(() => null),
        '真实栅格像元读取失败，请重试',
      )
      throw new RasterServiceError(code, message)
    }
    return response.blob()
  },
}
