/**
 * 阶段6：数据目录工作台服务。
 *
 * 职责：把 CatalogRepository / LayerRepository / ResultRepository 的取数组合成
 * 目录页与数据集详情页需要的最小集合。页面与组件只经本服务（经 store）取数，
 * 不直接触碰 Repository，也不直接 fetch JSON。
 *
 * 状态口径（任务硬性要求：四类状态分开显示，不混为一谈）：
 * - 已登记：数据集出现在目录登记表中（status 为 registered / published）。
 * - 文件存在：vector/table 数据集的关联图层在数据包内登记了要素文件且实际可读
 *   （以 pageSize=1 的 listFeatures 探测验证）；raster 只有元数据登记，无浏览器
 *   可用文件 → 「仅元数据」；无关联图层 → 「未登记图层」。
 * - 前端可预览：vector 且全部关联图层要素可读 → true；栅格/表格 → false。
 * - 服务可用：数据集登记的 serviceAvailable 字段，false 时必须带 serviceNote。
 *
 * 真实性边界：
 * - 年度降水的年份列表只能由 availableTimes 派生（当前真实登记 2001—2023）；
 *   没有年度统计服务时统计一律「未提供 / 统计服务待接入」，禁止生成曲线或数值。
 * - 任何读取失败都向上抛错，由页面显示错误与重试，不回退示例数据。
 */
import { getRepositories } from '@/repositories'
import type {
  DataSource,
  Dataset,
  DatasetType,
  ImportLog,
  LayerDefinition,
  Page,
  ResultSummary,
  Theme,
} from '@/domain/types'
import type { Repositories, RequestOptions } from '@/repositories/types'
import { isRepositoryError } from '@/repositories/types'

/** 数据集文件存在性状态（与「已登记」「服务可用」互相独立）。 */
export type DatasetFileState =
  | /** 全部关联图层的要素文件已验证存在且可读 */ 'verified'
  | /** 仅有元数据登记，浏览器无可用文件（栅格） */ 'metadataOnly'
  | /** 未登记任何关联图层，无法校验 */ 'noLayers'

/** 数据集前端可预览状态。 */
export type DatasetPreviewState =
  | /** vector 且全部关联图层要素可读，可进入 /map 查看 */ 'previewable'
  | /** 栅格服务未接入，地图预览待接入 */ 'servicePending'
  | /** 表格等无地图预览语义 */ 'notApplicable'

export interface CatalogDatasetRow {
  dataset: Dataset
  fileState: DatasetFileState
  previewState: DatasetPreviewState
  /** 关联图层总数（含不可用图层）。 */
  layerCount: number
  /** 文件存在/预览状态的补充说明（栅格服务原因等）。 */
  note: string | null
}

export interface CatalogDatasetDetail {
  dataset: Dataset
  source: DataSource | null
  relatedLayers: LayerDefinition[]
  relatedResults: ResultSummary[]
  /**
   * 阶段8B 补充：关联成果能力未接入时的说明（NOT_IMPLEMENTED → 如实降级为空清单，
   * 详情页显示「能力未接入」而非「暂无登记」，不伪造空结果语义）。
   */
  relatedResultsNote: string | null
  /**
   * 降水分册年份：仅当数据集为栅格且 availableTimes 为年精度时非空，
   * 由 availableTimes 逐条派生，不补造年份。
   */
  precipYears: string[]
}

export interface CatalogListQuery {
  theme?: Theme
  dataType?: DatasetType
  keyword?: string
  page: number
  pageSize: number
}

export interface CatalogWorkspaceService {
  /** 数据目录：筛选 + 分页 + 四状态富化。 */
  listDatasets(query: CatalogListQuery, options?: RequestOptions): Promise<Page<CatalogDatasetRow>>
  /** 数据集详情：来源、关联图层、关联成果、降水分册年份。 */
  getDatasetDetail(datasetId: string, options?: RequestOptions): Promise<CatalogDatasetDetail>
  /** 导入登记日志（只读展示，不是完整审计日志）。 */
  listImports(
    query: { page: number; pageSize: number },
    options?: RequestOptions,
  ): Promise<Page<ImportLog>>
}

export function createCatalogWorkspaceService(repositories: Repositories): CatalogWorkspaceService {
  const { catalog, layers, results } = repositories

  /** 图层注册表缓存：同一批探测不重复取数。 */
  const layerCache = new Map<string, LayerDefinition>()

  async function getLayerCached(
    layerId: string,
    options?: RequestOptions,
  ): Promise<LayerDefinition | null> {
    if (layerCache.has(layerId)) return layerCache.get(layerId) ?? null
    try {
      const envelope = await layers.getLayer(layerId, options)
      layerCache.set(layerId, envelope.data)
      return envelope.data
    } catch {
      // 图层未登记：该数据集的关联图层不可用，如实降级为 noLayers。
      layerCache.set(layerId, null as unknown as LayerDefinition)
      return null
    }
  }

  /**
   * 要素文件可读性探测：pageSize=1 只证明文件存在且可解析，
   * 不取全量要素（全量上图是 /map 的职责）。
   */
  async function featuresReadable(layerId: string, options?: RequestOptions): Promise<boolean> {
    try {
      await layers.listFeatures(layerId, { page: 1, pageSize: 1 }, options)
      return true
    } catch {
      return false
    }
  }

  async function enrich(dataset: Dataset, options?: RequestOptions): Promise<CatalogDatasetRow> {
    const layerDefinitions: LayerDefinition[] = []
    for (const layerId of dataset.layerIds) {
      const layer = await getLayerCached(layerId, options)
      if (layer !== null) layerDefinitions.push(layer)
    }

    if (layerDefinitions.length === 0) {
      return {
        dataset,
        fileState: 'noLayers',
        previewState: 'notApplicable',
        layerCount: dataset.layerIds.length,
        note: '该数据集未登记关联图层，文件与预览状态不适用。',
      }
    }

    const allGeojson = layerDefinitions.every((layer) => layer.source.type === 'geojson')
    if (allGeojson) {
      const checks = await Promise.all(
        layerDefinitions.map((layer) => featuresReadable(layer.id, options)),
      )
      const readable = checks.every(Boolean)
      return {
        dataset,
        fileState: readable ? 'verified' : 'metadataOnly',
        previewState: readable ? 'previewable' : 'servicePending',
        layerCount: layerDefinitions.length,
        note: readable ? null : '存在要素文件读取失败的关联图层。',
      }
    }

    // 至少一个关联图层是 unavailable（栅格等）：登记了元数据但无浏览器可用文件。
    const unavailable = layerDefinitions.filter((layer) => layer.source.type === 'unavailable')
    const reason = unavailable
      .map((layer) => (layer.source.type === 'unavailable' ? layer.source.reason : null))
      .find((text): text is string => text !== null)
    return {
      dataset,
      fileState: 'metadataOnly',
      previewState: 'servicePending',
      layerCount: layerDefinitions.length,
      note: reason ?? '栅格服务未接入，界面不读取像元值。',
    }
  }

  async function listDatasets(
    query: CatalogListQuery,
    options?: RequestOptions,
  ): Promise<Page<CatalogDatasetRow>> {
    const envelope = await catalog.listDatasets(
      {
        theme: query.theme,
        dataType: query.dataType,
        keyword: query.keyword,
        page: query.page,
        pageSize: query.pageSize,
      },
      options,
    )
    // 富化只对当前页执行，避免整目录探测；探测结果随行返回。
    const items = await Promise.all(envelope.data.items.map((dataset) => enrich(dataset, options)))
    return { ...envelope.data, items }
  }

  async function getDatasetDetail(
    datasetId: string,
    options?: RequestOptions,
  ): Promise<CatalogDatasetDetail> {
    const datasetEnvelope = await catalog.getDataset(datasetId, options)
    const dataset = datasetEnvelope.data

    // 关联成果：成果目录能力未接入（阶段8B 501 NOT_IMPLEMENTED）时如实降级为
    // 空清单并带说明，不阻塞数据集详情本身，也不伪造「暂无登记」语义。
    let relatedResultsNote: string | null = null
    const [source, relatedLayers, relatedResults] = await Promise.all([
      catalog.getSource(dataset.sourceId, options).then(
        (envelope) => envelope.data,
        () => null, // 来源未登记时详情页显示「未登记」，不阻塞其余内容
      ),
      Promise.all(dataset.layerIds.map((layerId) => getLayerCached(layerId, options))).then(
        (defs) => defs.filter((def): def is LayerDefinition => def !== null),
      ),
      results
        .listResults({ page: 1, pageSize: 100 }, options)
        .catch((error: unknown) => {
          if (isRepositoryError(error) && error.code === 'NOT_IMPLEMENTED') {
            relatedResultsNote =
              '成果目录能力未接入（阶段8B）：关联成果清单暂不可用，不代表没有关联成果。'
            return { data: { items: [] } }
          }
          throw error
        })
        .then((envelope) =>
          Promise.all(
            (envelope.data as Page<ResultSummary>).items.map(async (result) => {
              try {
                const detailEnvelope = await results.getResult(result.id, options)
                return detailEnvelope.data
              } catch {
                // 单个成果详情失败：跳过该成果的关联展示，不阻塞数据集详情。
                return null
              }
            }),
          ),
        )
        .then((details) =>
          details
            .filter((detail): detail is NonNullable<typeof detail> => detail !== null)
            .filter(
              (detail) =>
                detail.layerIds.some((layerId) => dataset.layerIds.includes(layerId)) ||
                detail.inputs.some((input) => input.datasetId === dataset.id),
            )
            .map((detail) => ({
              id: detail.id,
              kind: detail.kind,
              title: detail.title,
              version: detail.version,
              status: detail.status,
              time: detail.time,
              scenarioYear: detail.scenarioYear,
              sourceType: detail.sourceType,
              layerIds: detail.layerIds,
              regionLabel: detail.regionLabel,
              metrics: detail.metrics,
            })),
        ),
    ])

    const precipYears =
      dataset.dataType === 'raster'
        ? dataset.availableTimes
            .filter((time) => time.precision === 'year' && time.value !== null)
            .map((time) => String(time.value))
        : []

    return { dataset, source, relatedLayers, relatedResults, relatedResultsNote, precipYears }
  }

  async function listImports(
    query: { page: number; pageSize: number },
    options?: RequestOptions,
  ): Promise<Page<ImportLog>> {
    const envelope = await catalog.listImports(
      { page: query.page, pageSize: query.pageSize },
      options,
    )
    return envelope.data
  }

  return { listDatasets, getDatasetDetail, listImports }
}

let current: CatalogWorkspaceService | null = null

/** 应用级单例；`setCatalogWorkspaceService(null)` 用于测试替换。 */
export function getCatalogWorkspaceService(): CatalogWorkspaceService {
  if (current === null) current = createCatalogWorkspaceService(getRepositories())
  return current
}

/** 测试替换用；传 null 恢复默认单例。 */
export function setCatalogWorkspaceService(service: CatalogWorkspaceService | null): void {
  current = service
}
