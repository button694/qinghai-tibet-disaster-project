/**
 * 地图生命周期自检计数（阶段2 验收项「无重复地图监听」的可核验证据）。
 *
 * 这不是调试口子：它只统计「当前还活着几个 OpenLayers 实例 / 注册了几个地图事件监听」，
 * 由地图工作台的状态栏直接显示，供人工与浏览器用例核对。
 * 离开页面、切换路由、切换数据模式时计数必须回到 0，否则说明监听或实例泄漏。
 */

interface LifecycleCounts {
  mapInstances: number
  listeners: number
}

const counts: LifecycleCounts = { mapInstances: 0, listeners: 0 }

export function registerMapInstance(): void {
  counts.mapInstances += 1
}

export function unregisterMapInstance(listeners: number): void {
  counts.mapInstances = Math.max(0, counts.mapInstances - 1)
  counts.listeners = Math.max(0, counts.listeners - listeners)
}

export function registerMapListeners(count: number): void {
  counts.listeners += count
}

export function mapLifecycleCounts(): LifecycleCounts {
  return { ...counts }
}

/** 仅供单元测试在用例之间复位，业务代码不得调用。 */
export function resetMapLifecycleCounts(): void {
  counts.mapInstances = 0
  counts.listeners = 0
}
