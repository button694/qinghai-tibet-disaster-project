/**
 * 地图工作台的业务服务（阶段2；阶段8C 扩展为全量加载）。
 *
 * 页面与组件不直接调用 Repository，也不自己拼 GeoJSON 地址：图层的几何一律通过
 * `LayerRepository.listFeatures` 取得（示例模式下它读数据包 manifest 的要素索引）。
 * 这样做的代价是多一次契约调用，收益是「页面 → Repository」这一条铁律不被绕过，
 * 阶段8 换成正式接口时地图代码零改动（01 §6.2、D-013）。
 *
 * 三条失败语义（不许违反）：
 * - 图层声明 `source.type === 'unavailable'` → `status: 'unavailable'`，附数据包给出的原因；
 * - 读取失败 → `status: 'failed'` 并带回 `RepositoryError`，**绝不回退示例数据**（D-015）；
 * - 命中数超过单次渲染上限 → `truncated: true`，界面必须同时显示「已渲染 M / 共 N」。
 *
 * 阶段8C：全量加载不再局限于点图层——线/面图层（道路、救援路线等）同样按同一套
 * 分页循环取全部要素；线/面图层额外请求服务端几何简化（仅用于地图渲染，见
 * `simplifyMetersFor`），点图层不简化。调用方可传 `onProgress` 观察「已加载 N / 共 M」，
 * 并可用 `requestOptions.signal` 取消——取消视为「未完成」而不是「失败」，
 * 界面据此显示「已取消」而不是报错（见 `loadLayer` 的 catch 分支）。
 */
import type {
  Dataset,
  DictionaryItem,
  Envelope,
  FeatureDetail,
  LayerDefinition,
  Legend,
  Region,
  Theme,
} from '@/domain/types'
import { getRepositories } from '@/repositories'
import type { Repositories, RequestOptions } from '@/repositories/types'
import { isRepositoryError, toRepositoryError, type RepositoryError } from '@/repositories/types'

/** 单次 HTTP 页大小；地图会对可控图层自动合并多个页面凑出全量。 */
// 阶段8C：服务端 listFeatures 单页上限为 2000（见后端 app/config.py）；
// 地图使用该值作为单页大小，并继续循环分页取完全部记录。
export const DEFAULT_MAX_FEATURES = 2000
/**
 * 全量地图加载不按要素数量截断；分页大小、并发数、AbortSignal 和线/面简化
 * 共同承担浏览器保护。保留这个导出名只是兼容旧调用方，不再作为截断阈值。
 */
export const MAX_COMPLETE_FEATURES = Number.POSITIVE_INFINITY
/** @deprecated 点/线/面图层现在共用同一套无截断全量加载逻辑。 */
export const MAX_COMPLETE_POINT_FEATURES = MAX_COMPLETE_FEATURES
const COMPLETE_PAGE_CONCURRENCY = 6

/**
 * 线/面图层全量上图时使用的服务端几何简化容差（米，LCC 投影单位）。
 *
 * 取值依据：研究区跨度约 2500 公里，150 米容差在整图概览尺度下不可感知，
 * 但能显著压缩救援路线一类高密度折线的顶点数（实测见交付报告）。属性表格、
 * 要素详情与导出都不经过这条路径，不受影响（见 services/resultsCenter、
 * services/queryExport 等不传 simplifyMeters 的取数路径）。点图层没有可简化的
 * 折线/多边形几何，不传该参数。
 */
export const MAP_RENDER_SIMPLIFY_METERS = 150

function simplifyMetersFor(layer: LayerDefinition): number | undefined {
  return layer.geometryType === 'LineString' || layer.geometryType === 'Polygon'
    ? MAP_RENDER_SIMPLIFY_METERS
    : undefined
}

export type LayerDataStatus = 'unavailable' | 'ready' | 'failed' | 'cancelled'

export interface LayerDataResult {
  layerId: string
  status: LayerDataStatus
  /** 契约原样返回的要素详情，不做二次建模，避免丢字段。 */
  features: FeatureDetail[]
  /** 服务端 COUNT 返回的全部匹配记录数；永远不以当前数组长度替代。 */
  serverTotal: number
  /** 分页请求实际取回的记录数，包含重复业务对象和无几何记录。 */
  fetchedCount: number
  /** 按业务对象标识去重后的记录数，即传给列表/地图前的对象数。 */
  uniqueCount: number
  /** 实际交给地图渲染的记录数；无几何记录不计入。 */
  renderedCount: number
  /** 是否已成功取回服务端声明的全部分页；缺页/空页时为 false。 */
  complete: boolean
  /** 兼容旧调用方：等同于 serverTotal。 */
  total: number
  /** 兼容旧调用方：等同于 uniqueCount。 */
  matched: number
  /** 服务端记录未完整取回时为 true，界面不得声称已展示全部。 */
  truncated: boolean
  /** 不可用、缺页或部分加载时的说明文案。 */
  note: string | null
  error: RepositoryError | null
  /**
   * 补充（阶段8C）：地图上这批要素的几何是否经过服务端简化（仅用于渲染，
   * 不代表原始精度）。图层树/图例必须据此提示，避免用户把简化几何当作精确几何使用。
   */
  geometrySimplified?: boolean
  /** 实际生效的简化容差（米）；未简化为 null。 */
  simplifyToleranceMeters?: number | null
}

export interface LegendResult {
  legend: Legend | null
  note: string | null
}

export interface DatasetResult {
  dataset: Dataset | null
  note: string | null
}

export interface DictionaryResult {
  /** 以 dictionaryId 为键的条目表；读取失败的字典不会出现在这里。 */
  items: Record<string, DictionaryItem[]>
  /** 逐条读取失败的说明，界面照实显示，不用空标签蒙混。 */
  notes: string[]
}

export interface RegionListResult {
  regions: Region[]
  note: string | null
}

/** 图层字段里声明的全部字典 ID（去重，保持声明顺序）。 */
export function dictionaryIdsOf(layer: LayerDefinition): string[] {
  const ids: string[] = []
  for (const field of layer.fields) {
    if (field.dictionaryId !== undefined && !ids.includes(field.dictionaryId)) {
      ids.push(field.dictionaryId)
    }
  }
  return ids
}

export interface MapLayerService {
  listLayers(
    query?: { theme?: Theme },
    options?: RequestOptions,
  ): Promise<Envelope<LayerDefinition[]>>
  loadLayer(
    layer: LayerDefinition,
    options?: RequestOptions,
    onProgress?: LoadProgressCallback,
  ): Promise<LayerDataResult>
  getLegend(legendId: string, options?: RequestOptions): Promise<LegendResult>
  getDataset(datasetId: string, options?: RequestOptions): Promise<DatasetResult>
  /** 读取图层字段用到的代码字典，用于把 `enum` 原始代码显示成中文标签。 */
  getDictionaries(layer: LayerDefinition, options?: RequestOptions): Promise<DictionaryResult>
  /** `GET /regions`：行政区/流域条目，供阶段3 的「行政区或流域」空间条件使用。 */
  listRegions(options?: RequestOptions): Promise<RegionListResult>
  /** 模式切换时清空缓存，避免沿用上一模式的图层数据（D-014）。 */
  clear(): void
}

function messageOf(error: unknown): RepositoryError {
  return isRepositoryError(error) ? error : toRepositoryError(error, 'UNKNOWN')
}

function dedupeMapFeatures(features: FeatureDetail[]): {
  features: FeatureDetail[]
  removed: number
} {
  const seen = new Set<string>()
  const unique: FeatureDetail[] = []
  for (const feature of features) {
    const key =
      feature.entityKey !== undefined
        ? `${feature.ref.layerId}:entity:${feature.entityKey}`
        : `${feature.ref.layerId}:feature:${feature.ref.id}`
    if (seen.has(key)) continue
    seen.add(key)
    unique.push(feature)
  }
  return { features: unique, removed: features.length - unique.length }
}

/** 全量加载进度回调：`loaded` 已取回记录数（含无几何），`total` 服务端匹配总数。 */
export type LoadProgressCallback = (loaded: number, total: number) => void

function isAbortError(error: unknown): boolean {
  return (
    (error instanceof DOMException && error.name === 'AbortError') ||
    (error instanceof Error && error.name === 'AbortError')
  )
}

/**
 * 逐页取回某图层全部要素（点/线/面通用）。
 *
 * 只要服务端 total 大于首页条数就继续分页，直到全部记录取回；不会因为总量
 * 超过某个静态阈值而静默返回第一页。浏览器保护由较小单页、有限并发、取消信号
 * 和线/面服务端几何简化共同完成。线/面图层的每一页都使用同一套简化参数。
 */
async function loadCompleteFeatures(
  repositories: Repositories,
  layer: LayerDefinition,
  first: { items: FeatureDetail[]; total: number; pageSize: number },
  requestOptions: RequestOptions | undefined,
  onProgress: LoadProgressCallback | undefined,
): Promise<{
  features: FeatureDetail[]
  serverTotal: number
  fetchedCount: number
  uniqueCount: number
  renderedCount: number
  complete: boolean
  note: string | null
}> {
  const serverTotal = first.total
  const pageSize = Math.max(1, first.pageSize)
  const all: FeatureDetail[] = []
  const seenSourceIds = new Set<string>()
  const duplicateSourceIds = new Set<string>()
  let complete = first.items.length >= Math.min(pageSize, serverTotal)

  // 只把同一页或跨页重复的原始 ref 视为分页异常；同一业务对象在不同源记录中的
  // entityKey 关联仍由 dedupeMapFeatures 正常处理，不能误判为分页缺页。
  function appendSourcePage(items: FeatureDetail[]): void {
    const pageSourceIds = new Set<string>()
    for (const feature of items) {
      const sourceId = `${feature.ref.layerId}:${feature.ref.id}`
      if (seenSourceIds.has(sourceId) || pageSourceIds.has(sourceId)) {
        duplicateSourceIds.add(sourceId)
      }
      pageSourceIds.add(sourceId)
      all.push(feature)
    }
    for (const sourceId of pageSourceIds) seenSourceIds.add(sourceId)
  }

  appendSourcePage(first.items)
  onProgress?.(all.length, serverTotal)

  // 非正式 API（示例包/快照）保留单页保护，但仍然返回真实 total 与部分状态，
  // 不把 items.length 冒充成全量；正式 API 则继续向后分页。
  if (repositories.mode === 'api' && serverTotal > pageSize) {
    const simplifyMeters = simplifyMetersFor(layer)
    const pageCount = Math.ceil(serverTotal / pageSize)
    for (let start = 2; start <= pageCount; start += COMPLETE_PAGE_CONCURRENCY) {
      const pageNumbers = Array.from(
        { length: Math.min(COMPLETE_PAGE_CONCURRENCY, pageCount - start + 1) },
        (_, index) => start + index,
      )
      const pages = await Promise.all(
        pageNumbers.map((page) =>
          repositories.layers.listFeatures(
            layer.id,
            { page, pageSize, simplifyMeters },
            requestOptions,
          ),
        ),
      )
      for (let index = 0; index < pages.length; index += 1) {
        const pageNumber = pageNumbers[index]!
        const page = pages[index]!
        const expected = Math.min(pageSize, Math.max(0, serverTotal - (pageNumber - 1) * pageSize))
        if (page.data.items.length < expected) complete = false
        appendSourcePage(page.data.items)
      }
      onProgress?.(all.length, serverTotal)
    }
  }

  // 不能只看 pageCount：服务端可能返回空页/缺页，或跨页重复同一源 ref。
  // 即便 fetchedCount 恰好等于 serverTotal，源记录重复也不能写入完整缓存。
  if (all.length < serverTotal || duplicateSourceIds.size > 0) complete = false
  const deduped = dedupeMapFeatures(all)
  const uniqueCount = deduped.features.length
  const renderedCount = deduped.features.filter((feature) => feature.geometry !== null).length
  const fetchedCount = all.length
  const note = complete
    ? deduped.removed > 0
      ? `地图已取回全部 ${serverTotal} 条服务端记录，按业务对象去重后显示 ${uniqueCount} 个对象；列表仍可分页查看明细。`
      : `地图已取回全部 ${serverTotal} 个对象；列表仍可分页查看明细。`
    : duplicateSourceIds.size > 0
      ? `服务端分页发现 ${duplicateSourceIds.size} 个重复源记录（同页或跨页），仅取回 ${fetchedCount} / ${serverTotal} 条；本次结果不完整，未写入完整缓存。`
      : `地图仅取回 ${fetchedCount} / ${serverTotal} 条服务端记录，按业务对象去重后显示 ${uniqueCount} 个对象；本次结果不完整，未写入完整缓存。`
  return {
    features: deduped.features,
    serverTotal,
    fetchedCount,
    uniqueCount,
    renderedCount,
    complete,
    note,
  }
}

export function createMapLayerService(
  repositories: Repositories,
  options: { maxFeatures?: number } = {},
): MapLayerService {
  const maxFeatures = options.maxFeatures ?? DEFAULT_MAX_FEATURES
  const cache = new Map<string, LayerDataResult>()

  return {
    async listLayers(query, requestOptions) {
      return repositories.layers.listLayers(query, requestOptions)
    },

    async loadLayer(layer, requestOptions, onProgress) {
      const cached = cache.get(layer.id)
      if (cached) return cached

      if (layer.source.type === 'unavailable') {
        const unavailable: LayerDataResult = {
          layerId: layer.id,
          status: 'unavailable',
          features: [],
          serverTotal: 0,
          fetchedCount: 0,
          uniqueCount: 0,
          renderedCount: 0,
          complete: false,
          total: 0,
          matched: 0,
          truncated: false,
          note: layer.source.reason,
          error: null,
          geometrySimplified: false,
          simplifyToleranceMeters: null,
        }
        return unavailable
      }

      try {
        const simplifyMeters = simplifyMetersFor(layer)
        const envelope = await repositories.layers.listFeatures(
          layer.id,
          { page: 1, pageSize: maxFeatures, simplifyMeters },
          requestOptions,
        )
        const page = envelope.data
        const complete = await loadCompleteFeatures(
          repositories,
          layer,
          page,
          requestOptions,
          onProgress,
        )
        const result: LayerDataResult = {
          layerId: layer.id,
          status: 'ready',
          features: complete.features,
          serverTotal: complete.serverTotal,
          fetchedCount: complete.fetchedCount,
          uniqueCount: complete.uniqueCount,
          renderedCount: complete.renderedCount,
          complete: complete.complete,
          total: complete.serverTotal,
          matched: complete.uniqueCount,
          truncated: !complete.complete,
          note: complete.note,
          error: null,
          // 全量加载失败/截断时页面已单独用 note 说明；这里只标注「本次实际使用的几何」
          // 是否被服务端简化，供图层树/图例明确提示，不让用户误以为是原始精度。
          geometrySimplified: page.geometrySimplified ?? false,
          simplifyToleranceMeters: page.simplifyToleranceMeters ?? null,
        }
        // 只有真正取回全部服务端分页才进入完整缓存；缺页结果可用于本次显示，
        // 但必须让下一次重试重新请求，避免把部分结果当成完整地图。
        if (result.complete) cache.set(layer.id, result)
        return result
      } catch (error) {
        // 取消是「用户主动中止」，不是失败：不进缓存，界面据 status==='cancelled' 显示「已取消」而非报错。
        if (isAbortError(error)) {
          const cancelled: LayerDataResult = {
            layerId: layer.id,
            status: 'cancelled',
            features: [],
            serverTotal: 0,
            fetchedCount: 0,
            uniqueCount: 0,
            renderedCount: 0,
            complete: false,
            total: 0,
            matched: 0,
            truncated: false,
            note: '已取消加载；可重新点击「重试」继续加载该图层。',
            error: null,
            geometrySimplified: false,
            simplifyToleranceMeters: null,
          }
          return cancelled
        }
        // 失败即失败：不返回任何示例要素，也不把上一次成功的结果留在缓存里。
        cache.delete(layer.id)
        const failure: LayerDataResult = {
          layerId: layer.id,
          status: 'failed',
          features: [],
          serverTotal: 0,
          fetchedCount: 0,
          uniqueCount: 0,
          renderedCount: 0,
          complete: false,
          total: 0,
          matched: 0,
          truncated: false,
          note: null,
          error: messageOf(error),
          geometrySimplified: false,
          simplifyToleranceMeters: null,
        }
        return failure
      }
    },

    async getLegend(legendId, requestOptions) {
      try {
        const envelope = await repositories.layers.getLegend(legendId, requestOptions)
        return { legend: envelope.data, note: null }
      } catch (error) {
        return { legend: null, note: `图例读取失败：${messageOf(error).userMessage}` }
      }
    },

    async getDataset(datasetId, requestOptions) {
      try {
        const envelope = await repositories.catalog.getDataset(datasetId, requestOptions)
        return { dataset: envelope.data, note: null }
      } catch (error) {
        return { dataset: null, note: `数据集元数据读取失败：${messageOf(error).userMessage}` }
      }
    },

    async getDictionaries(layer, requestOptions) {
      const ids = dictionaryIdsOf(layer)
      const items: Record<string, DictionaryItem[]> = {}
      const notes: string[] = []
      const results = await Promise.all(
        ids.map(async (id) => {
          try {
            const envelope = await repositories.catalog.getDictionary(id, requestOptions)
            return { id, items: envelope.data.items }
          } catch (error) {
            notes.push(`代码字典 ${id} 读取失败：${messageOf(error).userMessage}`)
            return null
          }
        }),
      )
      for (const result of results) {
        if (result !== null) items[result.id] = result.items
      }
      return { items, notes }
    },

    async listRegions(requestOptions) {
      try {
        const envelope = await repositories.catalog.listRegions(undefined, requestOptions)
        return { regions: envelope.data, note: null }
      } catch (error) {
        return { regions: [], note: `行政区/流域列表读取失败：${messageOf(error).userMessage}` }
      }
    },

    clear() {
      cache.clear()
    },
  }
}

let current: MapLayerService | null = null

/** 应用级单例；`setMapLayerService(null)` 用于切换数据模式或测试替换。 */
export function getMapLayerService(): MapLayerService {
  if (current === null) current = createMapLayerService(getRepositories())
  return current
}

export function setMapLayerService(service: MapLayerService | null): void {
  current = service
}

/**
 * 轻量级全量取数：不需要完整 `LayerDefinition`（因此也不做几何简化/缓存/去重），
 * 只按 `total` 循环翻页直到取完，供只需要「全部要素」而不需要地图渲染优化的
 * 调用方使用（如总览背景边界、影响范围底图等本身量级有限的图层）。
 * 数据量大、要上主地图渲染的图层请用 `MapLayerService.loadLayer`。
 */
export async function fetchAllLayerFeatures(
  repositories: Pick<Repositories, 'layers'>,
  layerId: string,
  options: { pageSize?: number; requestOptions?: RequestOptions } = {},
): Promise<{ features: FeatureDetail[]; total: number; complete: boolean }> {
  // 后端对单页有明确硬上限（当前 2000）；不能把“完整加载上限”
  // 误当成 HTTP pageSize，否则默认请求会被 422 拒绝。超过上限时仍由下面
  // 的循环分页取完全部记录。
  const pageSize = Math.min(
    DEFAULT_MAX_FEATURES,
    Math.max(1, Math.floor(options.pageSize ?? DEFAULT_MAX_FEATURES)),
  )
  const first = await repositories.layers.listFeatures(
    layerId,
    { page: 1, pageSize },
    options.requestOptions,
  )
  const total = first.data.total
  const items = [...first.data.items]
  const pageCount = Math.ceil(total / pageSize)
  for (let page = 2; page <= pageCount && items.length < total; page += 1) {
    const next = await repositories.layers.listFeatures(
      layerId,
      { page, pageSize },
      options.requestOptions,
    )
    if (next.data.items.length === 0) break
    items.push(...next.data.items)
  }
  return { features: items, total, complete: items.length >= total }
}
