/**
 * 阶段5：应急保障工作台服务。
 *
 * 只读**已存**路线与资源（03 §8-4）：
 * - 显示起点、终点、距离、时间、网络版本、阻断条件与风险路段；
 * - `routeRecompute` 能力未接入时全部只读，不重算路径；
 * - 距离与时间的来源说明随成果返回，前端不按固定速度编造耗时；
 * - 无可达路径时几何为 null，禁止用直线冒充路线。
 */
import { getRepositories } from '@/repositories'
import type {
  FeatureDetail,
  FeatureRef,
  Page,
  ResultDetail,
  ResultSummary,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import type { Repositories, RequestOptions } from '@/repositories/types'

export interface EmergencyWorkspaceService {
  /** 应急类成果清单。 */
  listEmergencyResults(options?: RequestOptions): Promise<ResultSummary[]>
  /** 成果详情（方法、假设、输入）。 */
  getResult(resultId: string, options?: RequestOptions): Promise<ResultDetail>
  /** 某成果下的已存路线摘要（方案 A/B/C…）。 */
  listRoutes(
    resultId: string,
    options?: RequestOptions,
    hazardPointId?: string | null,
    page?: { page: number; pageSize: number },
  ): Promise<RouteSummary[]>
  /** 所有路线目录的服务端分页，不按危险源分组三条。 */
  listAllRoutesPage(
    resultId: string,
    query: { page: number; pageSize: number },
    options?: RequestOptions,
  ): Promise<Page<RouteSummary>>
  /** 单条路线详情（几何、起终点、风险段、资源）。 */
  getRoute(routeId: string, options?: RequestOptions): Promise<RouteDetail>
  /** 单个要素：用于风险段 / 阻断点引用的要素定位（真实关联取数）。 */
  getFeature(ref: FeatureRef, options?: RequestOptions): Promise<FeatureDetail>
}

export function createEmergencyWorkspaceService(
  repositories: Repositories,
): EmergencyWorkspaceService {
  const { results, layers } = repositories

  async function listEmergencyResults(options?: RequestOptions): Promise<ResultSummary[]> {
    const envelope = await results.listResults(
      { kind: 'emergency', page: 1, pageSize: 50 },
      options,
    )
    return envelope.data.items
  }

  async function getResult(resultId: string, options?: RequestOptions): Promise<ResultDetail> {
    const envelope = await results.getResult(resultId, options)
    return envelope.data
  }

  async function listRoutes(
    resultId: string,
    options?: RequestOptions,
    hazardPointId?: string | null,
    page?: { page: number; pageSize: number },
  ): Promise<RouteSummary[]> {
    if (page !== undefined) {
      const response = await results.listRoutes(resultId, { ...page }, options)
      return response.data.items
    }
    if (hazardPointId) {
      const grouped = await results.listRoutes(
        resultId,
        { page: 1, pageSize: 20, hazardPointId },
        options,
      )
      return grouped.data.items
    }
    // 真实演示修正（B3）：方案必须按同一危险源/情景分组。
    // 先取第一页（3 条）确定库内登记的分组键 HAZARD_POINT_ID，再精确取该危险源的全部
    // 方案（库内每组恰好 3 条：医院/消防站/救援站）；不同危险源的前 N 条不得混称 A/B/C。
    // 分组键未登记（旧数据/mock 未提供）时退化为第 1 页，并保留分页上限，不整包下载。
    const first = await results.listRoutes(resultId, { page: 1, pageSize: 3 }, options)
    const firstHazardPointId = first.data.items[0]?.hazardPointId ?? null
    if (firstHazardPointId === null) return first.data.items
    const grouped = await results.listRoutes(
      resultId,
      { page: 1, pageSize: 20, hazardPointId: firstHazardPointId },
      options,
    )
    return grouped.data.items
  }

  async function listAllRoutesPage(
    resultId: string,
    query: { page: number; pageSize: number },
    options?: RequestOptions,
  ): Promise<Page<RouteSummary>> {
    const response = await results.listRoutes(resultId, query, options)
    return response.data
  }

  async function getRoute(routeId: string, options?: RequestOptions): Promise<RouteDetail> {
    const envelope = await results.getRoute(routeId, options)
    return envelope.data
  }

  async function getFeature(ref: FeatureRef, options?: RequestOptions): Promise<FeatureDetail> {
    const envelope = await layers.getFeature(ref, options)
    return envelope.data
  }

  return { listEmergencyResults, getResult, listRoutes, listAllRoutesPage, getRoute, getFeature }
}

let current: EmergencyWorkspaceService | null = null

/** 应用级单例；`setEmergencyWorkspaceService(null)` 用于测试替换。 */
export function getEmergencyWorkspaceService(): EmergencyWorkspaceService {
  if (current === null) current = createEmergencyWorkspaceService(getRepositories())
  return current
}

export function setEmergencyWorkspaceService(service: EmergencyWorkspaceService | null): void {
  current = service
}
