/**
 * 查询工作区服务（阶段3：03 §6-6）。
 *
 * 两个必须守住的边界：
 *
 * 1. **旧响应不得覆盖新结果**。每次发起查询都递增序号并 abort 上一次请求
 *    （`AbortController`）；响应回来时先比对序号，序号不是最新的一律丢弃（返回 `null`），
 *    调用方（store）只接受最新结果。这样「快速改条件/快速翻页」不会出现
 *    「后点的查询先回来，界面显示的是旧条件的结果」。
 * 2. **地图范围加载与全范围业务查询是两件事**。地图按图层装载几何走
 *    `LayerRepository.listFeatures`（见 `services/mapLayers.ts`），业务查询走
 *    `QueryRepository`；两者各有独立的取消与序号，本服务不触发也不复用地图装载，
 *    避免「拖动地图触发一次全量业务查询」这类耦合。
 *
 * 请求取消与过期都返回 `null`（不是抛错）：它们是正常流程，不是故障；
 * 真正的读取失败仍然抛 `RepositoryError`，由界面显示错误状态。
 */
import type {
  AttributeFilter,
  Context,
  FeatureDetail,
  Metric,
  QueryInput,
  QueryResult,
  SpatialInput,
} from '@/domain/types'
import { getRepositories } from '@/repositories'
import type { Repositories, RequestOptions } from '@/repositories/types'

export const DEFAULT_PAGE_SIZE = 20
/** 导出「全部」时的最大翻页数：防止接口异常时无限翻页；触顶即如实说明未取到全部。 */
export const MAX_PAGES_FOR_ALL = 200
/**
 * 「全部匹配」导出默认每页条数：与界面当前每页条数（可能只有 5/10 条）脱钩，
 * 固定取服务端单页上限（见后端 app/config.py 的 page_max_size=2000），
 * 使 MAX_PAGES_FOR_ALL × 本值能覆盖当前最大图层（滑坡点 36500 条）而不早停。
 */
export const DEFAULT_EXPORT_PAGE_SIZE = 2000
/** 全量导出的数量保护上限：200 页 × 2000 条；触顶时返回非完整结果并禁止伪称“全部”。 */
export const MAX_EXPORT_RECORDS = MAX_PAGES_FOR_ALL * DEFAULT_EXPORT_PAGE_SIZE
export type AllRowsStopReason =
  'complete' | 'cancelled' | 'empty-page' | 'max-pages' | 'duplicate-source'

export interface QueryRunInput {
  layerId: string
  filters: AttributeFilter[]
  spatial: SpatialInput | null
  sort: { field: string; direction: 'asc' | 'desc' } | null
  page: number
  pageSize: number
}

export interface QueryOutcome {
  queryId: string
  rows: FeatureDetail[]
  page: number
  pageSize: number
  /** 全部匹配数（翻页不改变）。 */
  total: number
  metrics: Metric[]
  /** 最近邻的逐条距离（米）；非最近邻为 null。 */
  nearestDistances: Record<string, number> | null
  context: Context
  requestId: string
  /** 该结果对应的发起序号。 */
  seq: number
}

export interface AllRowsOutcome {
  rows: FeatureDetail[]
  total: number
  /** false 表示没能拿到全部记录，调用方不得把结果标成「全部」。 */
  complete: boolean
  /** 实际成功返回的服务端页数。 */
  pagesFetched: number
  /** 本次调用允许的最大页数。 */
  maxPages: number
  /** 本次保护上限（pageSize × maxPages）。 */
  maxRecords: number
  /** 停止原因，供界面区分取消、空页和保护上限。 */
  stopReason: AllRowsStopReason
  note: string | null
}

export interface QueryWorkspaceService {
  /** 发起一次新查询；返回 null 表示结果已被更新的查询取代或已取消。 */
  run(input: QueryRunInput): Promise<QueryOutcome | null>
  /** 对已有 queryId 按同一份服务端已校验条件翻页；返回 null 同上。 */
  pageTo(queryId: string, page: number, pageSize: number): Promise<QueryOutcome | null>
  /**
   * 逐页受控获取同一份服务端已校验条件的全部记录（02 §7）。
   * `pageSize` 默认取服务端友好的较大值（不跟随界面当前每页条数），避免用户在表格里
   * 选了小页大小时全量导出被迫拆成成百上千次请求；`onProgress(loaded, total)` 供
   * 调用方显示「已获取 N / 全部匹配 M」。
   */
  fetchAll(
    queryId: string,
    pageSize?: number,
    maxPages?: number,
    onProgress?: (loaded: number, total: number) => void,
  ): Promise<AllRowsOutcome>
  /** 取消在途请求并让已发起的结果作废。 */
  cancel(): void
  /** 切换数据模式后调用：作废在途结果，不沿用上一模式的查询。 */
  reset(): void
}

function isAbortError(error: unknown): boolean {
  return error instanceof Error && (error.name === 'AbortError' || error.name === 'CanceledError')
}

function toOutcome(
  data: QueryResult,
  context: Context,
  requestId: string,
  seq: number,
): QueryOutcome {
  return {
    queryId: data.queryId,
    rows: data.rows.items,
    page: data.rows.page,
    pageSize: data.rows.pageSize,
    total: data.rows.total,
    metrics: data.metrics,
    nearestDistances: data.nearestDistances ?? null,
    context,
    requestId,
    seq,
  }
}

export function createQueryWorkspaceService(repositories: Repositories): QueryWorkspaceService {
  let seq = 0
  let controller: AbortController | null = null

  /** 起一次新请求：先取消上一次，再递增序号。 */
  function beginRequest(): { options: RequestOptions; seq: number } {
    controller?.abort()
    controller = typeof AbortController === 'undefined' ? null : new AbortController()
    seq += 1
    return { options: controller === null ? {} : { signal: controller.signal }, seq }
  }

  function isStale(mySeq: number): boolean {
    return mySeq !== seq
  }

  function toQueryInput(input: QueryRunInput): QueryInput {
    const body: QueryInput = {
      layerId: input.layerId,
      filters: input.filters,
      page: input.page,
      pageSize: input.pageSize,
    }
    if (input.spatial !== null) body.spatial = input.spatial
    if (input.sort !== null) body.sort = input.sort
    return body
  }

  return {
    async run(input) {
      const request = beginRequest()
      try {
        const envelope = await repositories.queries.runQuery(toQueryInput(input), request.options)
        if (isStale(request.seq)) return null
        return toOutcome(envelope.data, envelope.meta, envelope.requestId, request.seq)
      } catch (error) {
        // 取消与过期是正常流程：丢弃结果，不抛给界面当故障。
        if (isAbortError(error) || isStale(request.seq)) return null
        throw error
      }
    },

    async pageTo(queryId, page, pageSize) {
      const request = beginRequest()
      try {
        const envelope = await repositories.queries.getQuery(
          queryId,
          { page, pageSize },
          request.options,
        )
        if (isStale(request.seq)) return null
        return toOutcome(envelope.data, envelope.meta, envelope.requestId, request.seq)
      } catch (error) {
        if (isAbortError(error) || isStale(request.seq)) return null
        throw error
      }
    },

    async fetchAll(
      queryId,
      pageSize = DEFAULT_EXPORT_PAGE_SIZE,
      maxPages = MAX_PAGES_FOR_ALL,
      onProgress,
    ) {
      const collected: FeatureDetail[] = []
      const seenSourceIds = new Set<string>()
      const duplicateSourceIds = new Set<string>()
      let total = 0
      let pagesFetched = 0
      let stopReason: AllRowsStopReason = 'max-pages'

      function appendPage(rows: FeatureDetail[]): void {
        const pageSourceIds = new Set<string>()
        for (const row of rows) {
          const sourceId = `${row.ref.layerId}:${row.ref.id}`
          if (seenSourceIds.has(sourceId) || pageSourceIds.has(sourceId))
            duplicateSourceIds.add(sourceId)
          pageSourceIds.add(sourceId)
          collected.push(row)
        }
        for (const sourceId of pageSourceIds) seenSourceIds.add(sourceId)
      }

      for (let page = 1; page <= maxPages; page += 1) {
        const outcome = await this.pageTo(queryId, page, pageSize)
        if (outcome === null) {
          return {
            rows: collected,
            total,
            complete: false,
            pagesFetched,
            maxPages,
            maxRecords: pageSize * maxPages,
            stopReason: 'cancelled',
            note: `全量导出在第 ${page} 页前被取消或查询已过期，已获取 ${collected.length} / ${total} 条；本文件不是全部结果。`,
          }
        }
        pagesFetched = page
        total = outcome.total
        appendPage(outcome.rows)
        onProgress?.(collected.length, total)
        if (duplicateSourceIds.size > 0) {
          stopReason = 'duplicate-source'
          break
        }
        if (collected.length >= total) {
          stopReason = 'complete'
          break
        }
        if (outcome.rows.length === 0) {
          stopReason = 'empty-page'
          break
        }
      }
      const complete =
        stopReason === 'complete' && collected.length >= total && duplicateSourceIds.size === 0
      const maxRecords = pageSize * maxPages
      const note = complete
        ? null
        : stopReason === 'duplicate-source'
          ? `服务端分页发现 ${duplicateSourceIds.size} 个重复源记录（同页或跨页），只取到 ${collected.length} / ${total} 条；为避免重复数据被伪称全量，本文件不是全部结果。`
          : stopReason === 'empty-page'
            ? `服务端第 ${pagesFetched} 页返回空页，只取到 ${collected.length} / ${total} 条；为避免把缺页结果伪称全量，本文件不是全部结果。`
            : `达到全量导出保护上限 ${maxPages} 页（最多 ${maxRecords} 条），只取到 ${collected.length} / ${total} 条；本文件不是全部结果。`
      return {
        rows: collected,
        total,
        complete,
        pagesFetched,
        maxPages,
        maxRecords,
        stopReason,
        note,
      }
    },

    cancel() {
      seq += 1
      controller?.abort()
    },

    reset() {
      seq += 1
      controller?.abort()
      controller = null
    },
  }
}

let current: QueryWorkspaceService | null = null

/** 应用级单例；切换数据模式后调用 `reset()`（D-014）。 */
export function getQueryWorkspaceService(): QueryWorkspaceService {
  if (current === null) current = createQueryWorkspaceService(getRepositories())
  return current
}

export function setQueryWorkspaceService(service: QueryWorkspaceService | null): void {
  current = service
}
