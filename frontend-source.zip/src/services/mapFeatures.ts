/**
 * 契约要素 → OpenLayers 要素的转换（阶段2）。
 *
 * 三条约定：
 * 1. 几何只在**地图显示**时做 EPSG:4326 → EPSG:3857 转换；业务数据仍以 WGS84
 *    `[经度, 纬度]` 传递（02 §2.5、01 §8）。
 * 2. `geometry === null` 的记录（无几何记录）**不上地图**，只进入对象列表；
 *    它们的定位按钮禁用并说明原因（01 §5.1、§5.5）。
 * 3. 要素 ID 使用全局对象键 `layerId + ':' + id`，不同图层的相同 ID 不会互相覆盖（D-019）。
 */
import Feature from 'ol/Feature'
import GeoJSON from 'ol/format/GeoJSON'
import type Geometry from 'ol/geom/Geometry'

import { featureKey } from '@/domain/format'
import type { FeatureDetail, GeometryFamily } from '@/domain/types'

const reader = new GeoJSON()

/** 转换后可在地图上拾取的要素。属性保留原始键，另加三个内部键供高亮与详情使用。 */
export interface MapFeatureProperties {
  __layerId: string
  __featureId: string
  __title: string
  [key: string]: unknown
}

/**
 * 批量转换。无几何与无法解析的几何被跳过并计数，由调用方如实显示
 * 「N 条记录无几何，未上图」，不补造几何。
 */
export interface ConvertResult {
  features: Feature<Geometry>[]
  /** 因无几何或几何不可解析而未上图的记录数。 */
  skipped: number
}

export function toOlFeatures(items: FeatureDetail[]): ConvertResult {
  const features: Feature<Geometry>[] = []
  let skipped = 0
  for (const item of items) {
    if (item.geometry === null) {
      skipped += 1
      continue
    }
    const geometry = reader.readGeometry(item.geometry, {
      dataProjection: 'EPSG:4326',
      featureProjection: 'EPSG:3857',
    })
    if (!geometry) {
      skipped += 1
      continue
    }
    const feature = new Feature<Geometry>({ geometry })
    const properties: MapFeatureProperties = {
      ...item.properties,
      __layerId: item.ref.layerId,
      __featureId: item.ref.id,
      __title: item.title,
    }
    feature.setProperties(properties, true)
    feature.setId(featureKey(item.ref.layerId, item.ref.id))
    features.push(feature)
  }
  return { features, skipped }
}

/** OL 几何类型 → 契约的几何家族。Multi* 归入同一家族，不丢失多部件。 */
export function olGeometryFamily(geometry: Geometry | null | undefined): GeometryFamily | null {
  if (!geometry) return null
  const type = geometry.getType()
  switch (type) {
    case 'Point':
    case 'MultiPoint':
      return 'Point'
    case 'LineString':
    case 'MultiLineString':
      return 'LineString'
    case 'Polygon':
    case 'MultiPolygon':
      return 'Polygon'
    default:
      return null
  }
}

/** 多部件记录在界面上的说明文案；单部件返回 null。 */
export function multiPartNote(geometry: Geometry | null | undefined): string | null {
  if (!geometry) return null
  switch (geometry.getType()) {
    case 'MultiPoint':
      return '多部件点记录（MultiPoint）'
    case 'MultiLineString':
      return '多部件线记录（MultiLineString）'
    case 'MultiPolygon':
      return '多部件面记录（MultiPolygon）'
    default:
      return null
  }
}
