/**
 * 查询结果导出（阶段3：03 §6-7；格式与元数据依据 02 §7）。
 *
 * 四条硬性要求，本文件逐条落实：
 * 1. **范围必须明确**：调用方只能在「当前页」与「全部匹配」之间二选一；
 *    「全部」由 `queryWorkspace.fetchAll()` 逐页受控获取**同一查询快照**后导出，
 *    拿不到全部时 `complete === false`，此时文件内会写明「非全部」，绝不只导出若干条却命名为全部。
 * 2. CSV 用 UTF-8 BOM、字段正确引号转义；对以 `= + - @` 开头的**文本**做公式注入防护，
 *    **数值列按原样写数字，不误伤合法负数**。
 * 3. GeoJSON 输出 EPSG:4326、坐标顺序 `[经度, 纬度]`，**不添加 `crs` 成员**绕过坐标约定；
 *    元数据另出独立 `metadata.json`。
 * 4. 元数据包含：来源模式、查询条件、范围、版本、生成时间、单位、CRS、分类方法与来源、示例标识。
 */
import type { Context, FeatureDetail, FieldDefinition } from '@/domain/types'
import { formatFieldValue, NOT_PROVIDED_TEXT } from '@/domain/format'
import { dictionaryLabels, type DictionaryMap } from '@/domain/queryFields'

/** 导出范围：调用方必须显式给出，没有「默认全部」这种含糊选项。 */
export type ExportScope = 'page' | 'all'

export const EXPORT_SCOPE_LABEL: Record<ExportScope, string> = {
  page: '当前页',
  all: '全部匹配',
}

/** 导出坐标系：与 02 §2.5 一致，GeoJSON 一律 EPSG:4326、`[经度, 纬度]`。 */
export const EXPORT_CRS = 'EPSG:4326'

export interface ExportColumn {
  key: string
  label: string
  field: FieldDefinition | null
  unit: string | null
}

/** 构建导出列：图层登记的全部字段（不是只导出可筛选字段），最近邻额外带距离列。 */
export function buildExportColumns(
  fields: FieldDefinition[],
  options: { withDistance?: boolean } = {},
): ExportColumn[] {
  const columns: ExportColumn[] = fields.map((field) => ({
    key: field.key,
    label: field.label,
    field,
    unit: field.unit,
  }))
  columns.push({ key: '__refId', label: '对象 ID', field: null, unit: null })
  columns.push({ key: '__geometry', label: '几何类型', field: null, unit: null })
  if (options.withDistance) {
    columns.push({ key: '__distance', label: '距离（米）', field: null, unit: 'm' })
  }
  return columns
}

/* ------------------------------------------------------------------ *
 * CSV
 * ------------------------------------------------------------------ */

/**
 * 公式注入防护（02 §7）。
 *
 * 只对**文本**生效：数值一律原样输出，因此合法负数 `-5` 不会被误伤；
 * 以 `=` `+` `-` `@` 开头的文本会被表格软件当公式解释，统一前置单引号，
 * 并在元数据里记录这一保护方式，让使用者知道如何还原。
 */
export const FORMULA_GUARD_NOTE =
  "以 = + - @ 开头的文本前置单引号（'）以防止表格软件按公式解释；数值列不施加该保护，合法负数保持原样。"

function guardText(text: string): string {
  return /^[=+\-@]/.test(text) ? `'${text}` : text
}

/** CSV 字段转义：一律加引号，内部引号翻倍；换行原样保留在引号内。 */
function csvCell(value: string): string {
  return `"${value.replace(/"/g, '""')}"`
}

export interface CsvBuildInput {
  rows: FeatureDetail[]
  columns: ExportColumn[]
  meta: ExportMeta
  /** 代码字典（dictionaryId → 条目数组），与界面显示保持一致。 */
  dictionaries?: DictionaryMap
  /** 最近邻的逐条距离（米），键为全局对象键。 */
  distances?: Record<string, number> | null
}

/**
 * 单元格取值。
 *
 * - 数值字段写**原始数值**（保持为数值列，单位写在元数据里），`null` 写「未提供」而不是 0；
 * - 其余类型写与界面表格一致的显示值（`formatFieldValue`），保证「表格与导出一致」；
 * - 文本再套公式注入防护。
 */
export function csvCellValue(
  row: FeatureDetail,
  column: ExportColumn,
  dictionaries: DictionaryMap,
): string {
  if (column.key === '__refId') return guardText(row.ref.id)
  if (column.key === '__geometry')
    return guardText(row.geometry === null ? '无几何' : row.geometry.type)
  const field = column.field
  if (!field) return ''
  const raw = row.properties[field.key]
  if (field.type === 'number') {
    return typeof raw === 'number' && Number.isFinite(raw) ? String(raw) : NOT_PROVIDED_TEXT
  }
  if (raw === null || raw === undefined || raw === '') return NOT_PROVIDED_TEXT
  const items = field.dictionaryId === undefined ? undefined : dictionaries[field.dictionaryId]
  const text = formatFieldValue(
    field,
    raw,
    items === undefined ? {} : { dictionary: dictionaryLabels(items) },
  )
  return guardText(text)
}

/** 生成 CSV 文本（含 UTF-8 BOM 与 `#` 开头的元数据注释行）。 */
export function buildCsv(input: CsvBuildInput): string {
  const { rows, columns, meta, dictionaries = {}, distances = null } = input
  const lines: string[] = []
  lines.push(...metadataCommentLines(meta))
  lines.push(columns.map((column) => csvCell(column.label)).join(','))
  for (const row of rows) {
    const cells = columns.map((column) => {
      if (column.key === '__distance') {
        const key = `${row.ref.layerId}:${row.ref.id}`
        const value = distances?.[key]
        return value === undefined ? NOT_PROVIDED_TEXT : String(Math.round(value))
      }
      return csvCell(csvCellValue(row, column, dictionaries))
    })
    lines.push(cells.join(','))
  }
  // BOM 必须在最前面：否则 Excel 按本地编码打开，中文列头会乱码。
  return `﻿${lines.join('\r\n')}\r\n`
}

/* ------------------------------------------------------------------ *
 * GeoJSON 与元数据
 * ------------------------------------------------------------------ */

export interface ExportMeta {
  /** 数据来源模式（示例数据 / 成果快照 / 正式接口）。 */
  modeLabel: string
  snapshotId: string
  scopeLabel: string
  boundaryVersion: string
  datasetVersion: string | null
  layerId: string
  layerLabel: string
  /** 属性条件摘要（与界面条件区同一份文案）。 */
  conditions: string[]
  /** 空间条件摘要；无条件为 null。 */
  spatial: string | null
  /** 距离方法与单位说明；无距离为 null。 */
  distanceMethod: string | null
  sort: string | null
  total: number
  exportedCount: number
  scope: ExportScope
  /** 全部导出是否真的拿到了全部；false 时不得称「全部」。 */
  complete: boolean
  generatedAt: string
  sample: boolean
  /** 额外说明（例如区域按范围框参与判定）。 */
  notes: string[]
}

/** 元数据注释行：写在 CSV 顶部，让「条件、来源、示例标识」随文件一起走。 */
export function metadataCommentLines(meta: ExportMeta): string[] {
  const lines = [
    `# 数据来源：${meta.modeLabel}（数据包 ${meta.snapshotId}）${meta.sample ? ' · 示例数据，非真实统计' : ''}`,
    `# 业务图层：${meta.layerLabel}（${meta.layerId}）`,
    `# 业务范围：${meta.scopeLabel} · 边界版本 ${meta.boundaryVersion}`,
    `# 数据版本：${meta.datasetVersion ?? NOT_PROVIDED_TEXT}`,
    `# 导出范围：${EXPORT_SCOPE_LABEL[meta.scope]}${meta.complete ? '' : '（未完成全部获取，本文件不是全部结果）'}`,
    `# 全部匹配数：${meta.total} · 本文件记录数：${meta.exportedCount}`,
    `# 属性条件：${meta.conditions.length === 0 ? '无（未加条件）' : meta.conditions.join('；')}`,
    `# 空间条件：${meta.spatial ?? '无（未加空间条件）'}`,
    `# 导出时间：${meta.generatedAt}`,
    `# 坐标参考：${EXPORT_CRS}，坐标顺序 [经度, 纬度]`,
  ]
  if (meta.distanceMethod) lines.push(`# 距离方法与单位：${meta.distanceMethod}`)
  if (meta.sort) lines.push(`# 排序：${meta.sort}`)
  if (meta.notes.length > 0) lines.push(`# 说明：${meta.notes.join('；')}`)
  lines.push(`# 文本保护：${FORMULA_GUARD_NOTE}`)
  lines.push(`# 空值一律写「${NOT_PROVIDED_TEXT}」，不写 0（null 不等于 0）。`)
  return lines
}

/**
 * GeoJSON 文本。属性保留**原始值**（机器可读，便于再入库），
 * 显示值由 CSV 承担，两者都来自同一批 `FeatureDetail`，不存在两套口径。
 */
export function buildGeoJson(rows: FeatureDetail[]): string {
  const features = rows.map((row) => ({
    type: 'Feature',
    id: row.ref.id,
    geometry: row.geometry,
    properties: {
      ...row.properties,
      __layerId: row.ref.layerId,
      __title: row.title,
    },
  }))
  const collection = {
    type: 'FeatureCollection',
    // 不写 crs 成员：02 §2.5 规定 GeoJSON 坐标顺序为 [经度, 纬度] 且采用 WGS84，
    // 另加 crs 成员属于绕过约定，不做。
    features,
  }
  return JSON.stringify(collection, null, 2)
}

/** 独立的 metadata.json 内容（02 §7 要求 GeoJSON 附带）。 */
export function buildMetadataJson(meta: ExportMeta, crs = EXPORT_CRS): string {
  return JSON.stringify(
    {
      source: {
        mode: meta.modeLabel,
        packageId: meta.snapshotId,
        sample: meta.sample,
        scopeLabel: meta.scopeLabel,
        boundaryVersion: meta.boundaryVersion,
        datasetVersion: meta.datasetVersion,
      },
      query: {
        layerId: meta.layerId,
        layerLabel: meta.layerLabel,
        conditions: meta.conditions,
        spatial: meta.spatial,
        distanceMethod: meta.distanceMethod,
        sort: meta.sort,
        matchedTotal: meta.total,
      },
      export: {
        scope: meta.scope,
        scopeLabel: EXPORT_SCOPE_LABEL[meta.scope],
        complete: meta.complete,
        exportedCount: meta.exportedCount,
        generatedAt: meta.generatedAt,
        crs,
        coordinateOrder: '[经度, 纬度]',
        textGuard: FORMULA_GUARD_NOTE,
        nullRule: `null 写「${NOT_PROVIDED_TEXT}」，不写 0`,
      },
      notes: meta.notes,
    },
    null,
    2,
  )
}

/** 从契约上下文补出导出元数据里与数据包有关的字段。 */
export function datasetVersionOf(context: Context, datasetId: string): string | null {
  return context.datasetVersions[datasetId] ?? null
}

/* ------------------------------------------------------------------ *
 * 下载
 * ------------------------------------------------------------------ */

/** 触发浏览器下载；浏览器环境之外（单元测试）不提供该能力，只测试文本内容。 */
export function downloadText(fileName: string, text: string, mimeType: string): void {
  if (typeof Blob === 'undefined' || typeof URL === 'undefined') return
  const blob = new Blob([text], { type: `${mimeType};charset=utf-8` })
  const url = URL.createObjectURL(blob)
  const anchor = document.createElement('a')
  anchor.href = url
  anchor.download = fileName
  document.body.appendChild(anchor)
  anchor.click()
  anchor.remove()
  // 不能同步回收：Chromium 里立刻 revokeObjectURL 会让还没真正开始的下载被取消，
  // 表现是「点了导出但什么都没发生」。放到下一个宏任务回收，下载已经发起。
  setTimeout(() => URL.revokeObjectURL(url), 0)
}

/** 导出文件名：`阶段3-查询导出-<图层>-<范围>-<时间戳>`，时间戳精确到秒。 */
export function exportFileName(layerId: string, scope: ExportScope, at: Date): string {
  const pad = (value: number): string => String(value).padStart(2, '0')
  const stamp = `${at.getFullYear()}${pad(at.getMonth() + 1)}${pad(at.getDate())}-${pad(at.getHours())}${pad(at.getMinutes())}${pad(at.getSeconds())}`
  return `query-export-${layerId}-${scope}-${stamp}`
}
