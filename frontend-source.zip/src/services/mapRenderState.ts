/**
 * 地图「实际渲染状态」的类型（阶段2）。
 *
 * 这份状态由 `MapCanvas.vue` **从 OpenLayers 对象本身读出来**再回传给界面，
 * 不是把界面意图再抄一遍：因此只要图层树里显示的可见性 / 透明度 / 要素数与之不符，
 * 就说明控件没有真正作用到地图上。浏览器用例也据此断言「图层控制实际生效」。
 */
import type { LayerDefinition } from '@/domain/types'

/** 传给 `MapCanvas` 的单个图层状态：定义来自注册表，其余来自界面状态。 */
export interface CanvasLayerState {
  definition: LayerDefinition
  visible: boolean
  opacity: number
  /** 叠放顺序，值越大越靠上；由图层树的顺序换算，不在组件里做二次判断。 */
  zIndex: number
  /** 是否可渲染（栅格 / 服务未接入为 false，仍显示在树上但不上图）。 */
  renderable: boolean
}

export interface RenderLayerState {
  layerId: string
  /** OL 矢量图层的实际可见性。 */
  visible: boolean
  /** OL 矢量图层的实际透明度。 */
  opacity: number
  /** OL 矢量图层的实际 zIndex。 */
  zIndex: number
  /** OL 矢量源里当前真实存在的要素数。 */
  featureCount: number
}

export interface MapRenderState {
  layers: RenderLayerState[]
  visibleLayerCount: number
  renderedFeatureCount: number
  /** 当前存活的 OpenLayers 实例数（应为 1；离开页面后为 0）。 */
  mapInstances: number
  /** 当前注册的地图事件监听数（固定为注册的那几个，不随重复挂载增长）。 */
  listeners: number
  /** 视图缩放级别。 */
  zoom: number
}
