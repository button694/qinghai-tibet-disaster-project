/**
 * 研究区边界底图（本地真实数据）的统一入口。
 *
 * 这是已登记在 QTP_GEOHAZARD 中的研究区边界，不是在线地图服务，也不是
 * 从点位推出来的外包络。专题图、成果详情、应急路线和打印地图均通过本模块
 * 读取同一份边界，避免各页面各自拼接一套“看起来像底图”的几何。
 */
import Feature from 'ol/Feature'
import type Geometry from 'ol/geom/Geometry'
import VectorLayer from 'ol/layer/Vector'
import VectorSource from 'ol/source/Vector'
import { Fill, Stroke, Style } from 'ol/style'

import type { DataMode, FeatureDetail } from '@/domain/types'
import { getRepositories } from '@/repositories'
import type { RequestOptions } from '@/repositories/types'
import { fetchAllLayerFeatures } from '@/services/mapLayers'

export const RESEARCH_BOUNDARY_LAYER_ID = 'DS_BASE_QTP_BOUNDARY'

/** 研究区边界的业务展示样式：淡填充、清晰边线，保证点/线成果仍处于视觉主层。 */
export function researchBoundaryStyle(): Style {
  return new Style({
    fill: new Fill({ color: 'rgba(105, 178, 198, 0.10)' }),
    stroke: new Stroke({ color: '#75c6d3', width: 1.6, lineDash: [8, 5] }),
  })
}

export type ResearchBoundarySource = VectorSource<Feature<Geometry>>

/** 创建可复用的底图矢量层；zIndex 由调用方按业务图层栈决定。 */
export function createResearchBoundaryLayer(
  source: ResearchBoundarySource,
  zIndex = 1,
): VectorLayer<ResearchBoundarySource> {
  return new VectorLayer<ResearchBoundarySource>({
    source,
    style: researchBoundaryStyle(),
    zIndex,
  })
}

/**
 * 读取已登记研究区边界。
 *
 * API 模式才会调用该函数；mock/snapshot 页面不应额外请求不存在的正式图层。
 * 请求完全遵循 Repository 的 AbortSignal 与错误契约，失败由页面显示“边界暂不可用”。
 */
export async function loadResearchBoundary(
  mode: DataMode,
  options?: RequestOptions,
): Promise<FeatureDetail[]> {
  if (mode !== 'api') return []
  // 全量取数（翻页循环）：边界当前只有 6 个多边形，换成全量取数是为了不再依赖
  // 一个碰巧够用的页大小。
  const result = await fetchAllLayerFeatures(getRepositories(), RESEARCH_BOUNDARY_LAYER_ID, {
    requestOptions: options,
  })
  return result.features
}
