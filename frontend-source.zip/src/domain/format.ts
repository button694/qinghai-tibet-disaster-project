/**
 * 统一格式化（实现 02 §2 统一语义：null、单位、时间精度、等级与米制距离）。
 *
 * 硬性规则（任何页面都不得绕过本文件自行拼接数值）：
 * 1. `null` 不等于 0，也永远不显示成 0 或“暂无”；必须按 status 显示
 *    未提供 / 无数据 / 不适用（02 §2.3）。
 * 2. 单位未确认（`unit === null`）时只显示数值，不自动补单位（02 §2.6）。
 * 3. 时间按精度显示，不补造缺失的年月日（02 §2.4）。
 * 4. 距离、面积只在明确为米制时换算，绝不用经纬度差当米（02 §2.5）。
 * 5. ID 一律按字符串处理，bigint 不做 Number 转换（02 §2.1）。
 */
import type {
  Bbox,
  FieldDefinition,
  FeaturePropertyValue,
  LonLat,
  Metric,
  MetricStatus,
  TimePrecision,
  TimeRole,
  TimeValue,
} from './types'

/* ------------------------------------------------------------------ *
 * 未知值文案
 * ------------------------------------------------------------------ */

export const UNKNOWN_TEXT = '未知'
export const NOT_PROVIDED_TEXT = '未提供'
export const NO_DATA_TEXT = '无数据'
export const NOT_APPLICABLE_TEXT = '不适用'
export const MISSING_VALUE_TEXT = '—'
/** 领域元数据未登记（方法、精度、年份、范围等）。与“未提供”区分：属未登记，而非数据源缺失。 */
export const NOT_REGISTERED_TEXT = '未登记'
export const METRIC_STATUS_TEXT: Record<MetricStatus, string> = {
  known: '',
  noData: NO_DATA_TEXT,
  notProvided: NOT_PROVIDED_TEXT,
  notApplicable: NOT_APPLICABLE_TEXT,
}

export const TIME_PRECISION_TEXT: Record<TimePrecision, string> = {
  year: '精确到年',
  month: '精确到月',
  day: '精确到日',
  datetime: '精确到时分',
  unknown: '精度未登记',
}

export const TIME_ROLE_LABEL: Record<TimeRole, string> = {
  observed: '观测时间',
  event: '事件时间',
  scenario: '情景时间',
  generated: '生成时间',
  imported: '导入时间',
}

/* ------------------------------------------------------------------ *
 * ID 与计数
 * ------------------------------------------------------------------ */

/**
 * ID 规范化：bigint 直接转字符串，绝不经 Number（02 §2.1）。
 * number 输入仅在后端已确认安全整数时使用，超出安全整数范围会在控制台告警。
 */
export function formatId(value: string | number | bigint | null | undefined): string | null {
  if (value === null || value === undefined) return null
  if (typeof value === 'bigint') return value.toString()
  if (typeof value === 'number') {
    if (!Number.isSafeInteger(value)) {
      console.warn(
        '[format] 收到超出安全整数范围的数字 ID，可能已丢失精度，请改用字符串 ID：',
        value,
      )
    }
    return String(value)
  }
  const trimmed = value.trim()
  return trimmed === '' ? null : trimmed
}

/** 全局对象键：`layerId:id`。同一图层内 ID 唯一，跨表同 ID 不视为同一对象（02 §2.2）。 */
export function featureKey(layerId: string, id: string): string {
  return `${layerId}:${id}`
}

/* ------------------------------------------------------------------ *
 * 数值
 * ------------------------------------------------------------------ */

const numberFormatters = new Map<string, Intl.NumberFormat>()

function numberFormatter(maximumFractionDigits: number, minimumFractionDigits: number) {
  const cacheKey = `${maximumFractionDigits}/${minimumFractionDigits}`
  const cached = numberFormatters.get(cacheKey)
  if (cached) return cached
  const formatter = new Intl.NumberFormat('zh-CN', {
    maximumFractionDigits,
    minimumFractionDigits,
    useGrouping: false,
  })
  numberFormatters.set(cacheKey, formatter)
  return formatter
}

export interface NumberFormatOptions {
  maximumFractionDigits?: number
  minimumFractionDigits?: number
}

/** 数值格式化。null → `—`（不是 0）。 */
export function formatNumber(
  value: number | null | undefined,
  options: NumberFormatOptions = {},
): string {
  if (value === null || value === undefined || Number.isNaN(value)) return MISSING_VALUE_TEXT
  const maximumFractionDigits = options.maximumFractionDigits ?? 0
  const minimumFractionDigits = options.minimumFractionDigits ?? 0
  return numberFormatter(maximumFractionDigits, minimumFractionDigits).format(value)
}

/** 带单位的数值；unit 为 null 时只显示数值（单位未确认，不猜）。 */
export function formatValueWithUnit(
  value: number | null | undefined,
  unit: string | null | undefined,
  options: NumberFormatOptions = {},
): string {
  const text = formatNumber(value, options)
  if (text === MISSING_VALUE_TEXT) return text
  return unit ? `${text} ${unit}` : text
}

/** 指标显示值。status 优先于 value：状态为未提供时即使有值也不显示数字。 */
export function formatMetricValue(metric: Metric, options: NumberFormatOptions = {}): string {
  const statusText = METRIC_STATUS_TEXT[metric.status]
  if (statusText) return statusText
  if (metric.value === null) {
    console.warn(`[format] 指标 ${metric.key} 状态为 known 但值为 null，已按未知显示。`)
    return MISSING_VALUE_TEXT
  }
  const digits =
    options.maximumFractionDigits ??
    (metric.unit !== null && metric.unit !== '人' && metric.unit !== '个' ? 2 : 0)
  return formatValueWithUnit(metric.value, metric.unit, {
    ...options,
    maximumFractionDigits: digits,
  })
}

/** 指标的口径说明行：时点 + 口径 + 范围（01 §4.4 要求每项指标可追溯）。 */
export function formatMetricMeta(metric: Metric): string {
  const parts: string[] = []
  if (metric.year !== null && metric.year !== undefined) parts.push(`${metric.year} 年`)
  if (metric.method) parts.push(metric.method)
  if (metric.scopeLabel) parts.push(metric.scopeLabel)
  if (metric.precisionNote) parts.push(metric.precisionNote)
  return parts.join('；')
}

export interface CountFormatOptions {
  unitSuffix?: string
}

/** 对象个数。null 一律显示为 `—`，不显示 0。 */
export function formatCount(
  value: number | null | undefined,
  options: CountFormatOptions = {},
): string {
  if (value === null || value === undefined) return MISSING_VALUE_TEXT
  return `${formatNumber(value)}${options.unitSuffix ?? ''}`
}

/** 指标年份。未知为 null → “未登记”，不用当前年份顶替。 */
export function formatYear(year: number | null | undefined): string {
  if (year === null || year === undefined) return NOT_REGISTERED_TEXT
  return `${formatNumber(year, { maximumFractionDigits: 0 })} 年`
}

export function formatPercent(value: number | null | undefined, maximumFractionDigits = 1): string {
  if (value === null || value === undefined) return MISSING_VALUE_TEXT
  return `${formatNumber(value * 100, { maximumFractionDigits })}%`
}

/**
 * 固定小数位显示（缩放级别、坐标、分箱区间等技术性数值）。
 * 与 formatNumber 的区别：用于坐标/缩放这类非千分位的技术值，不做分组。
 */
export function formatFixed(value: number, digits: number): string {
  return value.toFixed(digits)
}

/* ------------------------------------------------------------------ *
 * 时间
 * ------------------------------------------------------------------ */

const YEAR_PATTERN = /^\d{4}$/
const MONTH_PATTERN = /^\d{4}-\d{2}$/
const DAY_PATTERN = /^\d{4}-\d{2}-\d{2}$/
const DATETIME_PATTERN =
  /^(\d{4}-\d{2}-\d{2})[T ](\d{2}:\d{2})(?::\d{2})?(?:\.\d+)?(Z|[+-]\d{2}:\d{2})?$/

/** 从字符串推断精度。推断不出时为 `unknown`，不假设精度。 */
export function inferTimePrecision(value: string | null | undefined): TimePrecision {
  if (!value) return 'unknown'
  const text = value.trim()
  if (YEAR_PATTERN.test(text)) return 'year'
  if (MONTH_PATTERN.test(text)) return 'month'
  if (DAY_PATTERN.test(text)) return 'day'
  if (DATETIME_PATTERN.test(text)) return 'datetime'
  return 'unknown'
}

/**
 * 判断字符串是否与声明的精度一致。不一致时界面显示“精度待核对”，
 * 既不截断也不补全（例如声明为日但只有年份）。
 */
export function matchesPrecision(value: string, precision: TimePrecision): boolean {
  switch (precision) {
    case 'year':
      return YEAR_PATTERN.test(value)
    case 'month':
      return MONTH_PATTERN.test(value)
    case 'day':
      return DAY_PATTERN.test(value)
    case 'datetime':
      return DATETIME_PATTERN.test(value)
    case 'unknown':
      return true
  }
}

/** 按精度格式化时间值；缺失时为“未提供”，精度未登记时为“未知”。 */
export function formatTimeValue(time: TimeValue | null | undefined): string {
  if (!time || time.value === null) return NOT_PROVIDED_TEXT
  const value = time.value.trim()
  if (value === '') return NOT_PROVIDED_TEXT

  if (!matchesPrecision(value, time.precision)) {
    return `${value}（精度待核对）`
  }

  switch (time.precision) {
    case 'year':
      return `${value} 年`
    case 'month': {
      const [year, month] = value.split('-')
      return `${year} 年 ${month} 月`
    }
    case 'day':
      return value
    case 'datetime': {
      const matched = DATETIME_PATTERN.exec(value)
      if (!matched) return value
      const [, date, timePart, zone] = matched
      if (!zone) return `${date} ${timePart}`
      const offset = zone === 'Z' ? '+00:00' : zone
      return `${date} ${timePart}（UTC${offset}）`
    }
    case 'unknown':
      return `${value}（精度未登记）`
  }
}

/** 时间值 + 语义，例如「2026-09-15 10:00（生成时间）」。 */
export function formatTimeWithRole(time: TimeValue | null | undefined): string {
  if (!time) return NOT_PROVIDED_TEXT
  return `${formatTimeValue(time)}（${TIME_ROLE_LABEL[time.role]}）`
}

/** 年份列表摘要，用于图层时相（例如「2001—2023 年，共 23 个时相」）。 */
export function formatAvailableTimes(times: TimeValue[]): string {
  if (times.length === 0) return '无时相记录'
  const values = times
    .map((item) => item.value)
    .filter((item): item is string => item !== null)
    .sort()
  if (values.length === 0) return '时相未登记'
  const first = values[0] as string
  const last = values[values.length - 1] as string
  if (values.length === 1) return `${formatTimeValue(times[0] as TimeValue)}`
  return `${first} — ${last}，共 ${values.length} 个时相`
}

/* ------------------------------------------------------------------ *
 * 米制距离、面积与时长
 * ------------------------------------------------------------------ */

export interface DistanceFormatOptions {
  /** `auto`：小于 1 千米用米，其余用千米。 */
  unit?: 'auto' | 'm' | 'km'
}

/** 米制距离显示。入参必须是米；未知为 null → “未提供”。 */
export function formatDistance(
  meters: number | null | undefined,
  options: DistanceFormatOptions = {},
): string {
  if (meters === null || meters === undefined) return NOT_PROVIDED_TEXT
  const unit = options.unit ?? 'auto'
  if (unit === 'km' || (unit === 'auto' && Math.abs(meters) >= 1000)) {
    return `${formatNumber(meters / 1000, { maximumFractionDigits: 1 })} 千米`
  }
  return `${formatNumber(meters, { maximumFractionDigits: 0 })} 米`
}

/** 面积显示。入参必须是平方米。 */
export function formatArea(squareMeters: number | null | undefined): string {
  if (squareMeters === null || squareMeters === undefined) return NOT_PROVIDED_TEXT
  if (Math.abs(squareMeters) >= 1_000_000) {
    return `${formatNumber(squareMeters / 1_000_000, { maximumFractionDigits: 2 })} 平方千米`
  }
  return `${formatNumber(squareMeters, { maximumFractionDigits: 0 })} 平方米`
}

/** 时长显示。null → “未提供”，不按 0 秒处理。 */
export function formatDuration(seconds: number | null | undefined): string {
  if (seconds === null || seconds === undefined) return NOT_PROVIDED_TEXT
  if (seconds < 60) return `${formatNumber(seconds, { maximumFractionDigits: 0 })} 秒`
  const totalMinutes = Math.round(seconds / 60)
  const hours = Math.floor(totalMinutes / 60)
  const minutes = totalMinutes % 60
  if (hours === 0) return `${minutes} 分钟`
  if (minutes === 0) return `${hours} 小时`
  return `${hours} 小时 ${minutes} 分钟`
}

/* ------------------------------------------------------------------ *
 * 坐标与范围
 * ------------------------------------------------------------------ */

/**
 * 经纬度显示，固定 `[lon, lat]` 顺序，标注半球与 WGS84。
 * 超出 WGS84 范围时直接报错文本，不静默显示。
 */
export function formatLonLat(lonLat: LonLat | null | undefined): string {
  if (!lonLat) return NOT_PROVIDED_TEXT
  const [lon, lat] = lonLat
  if (lon < -180 || lon > 180 || lat < -90 || lat > 90) {
    return `坐标超出 WGS84 范围（${lon}, ${lat}）`
  }
  const lonText = `${Math.abs(lon).toFixed(6)}°${lon < 0 ? 'W' : 'E'}`
  const latText = `${Math.abs(lat).toFixed(6)}°${lat < 0 ? 'S' : 'N'}`
  return `${lonText}, ${latText}`
}

/** 范围框显示，顺序固定为西、南、东、北（02 §2.10）。 */
export function formatBbox(bbox: Bbox | null | undefined): string {
  if (!bbox) return NOT_PROVIDED_TEXT
  const [west, south, east, north] = bbox
  return `西 ${formatNumber(west, { maximumFractionDigits: 4 })} / 南 ${formatNumber(south, {
    maximumFractionDigits: 4,
  })} / 东 ${formatNumber(east, { maximumFractionDigits: 4 })} / 北 ${formatNumber(north, {
    maximumFractionDigits: 4,
  })}`
}

/* ------------------------------------------------------------------ *
 * 属性值
 * ------------------------------------------------------------------ */

export interface FieldValueContext {
  /** enum 字段的字典标签：code → label。 */
  dictionary?: Record<string, string> | undefined
}

/**
 * 通用字段值显示。null 为“未提供”；boolean 显示是/否；
 * number 带声明单位；date 按声明精度显示。
 */
export function formatFieldValue(
  field: FieldDefinition,
  value: FeaturePropertyValue | undefined,
  context: FieldValueContext = {},
): string {
  if (value === null || value === undefined) return NOT_PROVIDED_TEXT
  switch (field.type) {
    case 'number':
      return typeof value === 'number'
        ? formatValueWithUnit(value, field.unit, { maximumFractionDigits: 2 })
        : String(value)
    case 'boolean':
      return value === true ? '是' : value === false ? '否' : String(value)
    case 'date': {
      const text = String(value)
      const precision = field.precision ?? inferTimePrecision(text)
      return formatTimeValue({ value: text, precision, role: 'event' })
    }
    case 'enum': {
      const code = String(value)
      const label = context.dictionary?.[code]
      return label ? `${label}（${code}）` : code
    }
    case 'string':
      return String(value)
  }
}

/** 指标状态到说明文案，用于 tooltip 与导出。 */
export function metricStatusText(status: MetricStatus): string {
  return METRIC_STATUS_TEXT[status] || '有数据'
}
