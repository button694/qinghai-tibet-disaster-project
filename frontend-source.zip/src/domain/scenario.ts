/**
 * 阶段4：2050/2100 未来情景的领域类型、指标语义与统计口径。
 *
 * 三条铁律（03 §7 与 DeepSeek下一步任务.md）：
 * 1. `hrgi` / `exposure` / `rrgi` 保留源字段原名与原语义，是**连续指数**，
 *    不是发生概率，也不是风险等级；正式语义口径以数据负责人登记为准，
 *    在此之前界面只展示原始字段名、原始数值与方法说明，不引入额外解释。
 * 2. 没有正式阈值：不五等分、不命名「高风险区」；2050 与 2100 共用
 *    `config/mapStyle.ts` 的同一条连续色域（SCENARIO_RAMP），保证两期可比。
 * 3. `null`（源数据缺失）与 `0`（真实测得为零）是两件事：null 显示「未提供」，
 *    0 显示 0；统计里 null 单列，不并入任何数值分箱，更不算低值。
 *
 * 数据来源是 `public/real-preview/` 的只读文件快照（FileGDB 导出），
 * 经 `repositories/realPreview.ts` 适配层读取——页面与组件不直接 fetch JSON。
 */
import { NOT_PROVIDED_TEXT, formatNumber } from './format'

/* ------------------------------------------------------------------ *
 * 年份与指标
 * ------------------------------------------------------------------ */

export const SCENARIO_YEARS = [2050, 2100] as const
export type ScenarioYear = (typeof SCENARIO_YEARS)[number]

export function isScenarioYear(value: unknown): value is ScenarioYear {
  return value === 2050 || value === 2100
}

export const SCENARIO_METRICS = ['hrgi', 'exposure', 'rrgi'] as const
export type ScenarioMetric = (typeof SCENARIO_METRICS)[number]

export function isScenarioMetric(value: unknown): value is ScenarioMetric {
  return value === 'hrgi' || value === 'exposure' || value === 'rrgi'
}

export interface ScenarioMetricMeta {
  key: ScenarioMetric
  /** 界面展示名＝源字段名（保留原语义，不改名）。 */
  label: string
  /** 指数说明：只声明「连续指数、非概率、非等级」，不编造科学含义。 */
  explanation: string
  /** 单位：源数据为无量纲指数；显式写明，不猜单位。 */
  unit: string
}

export const SCENARIO_METRIC_META: Record<ScenarioMetric, ScenarioMetricMeta> = {
  hrgi: {
    key: 'hrgi',
    label: 'hrgi',
    explanation:
      '源字段 hrgi（危险性相关连续指数）：数值越大表示该指数越高；是连续指数，不是发生概率，也不是风险等级。正式口径以数据负责人登记为准。',
    unit: '无量纲指数（0—1）',
  },
  exposure: {
    key: 'exposure',
    label: 'exposure',
    explanation:
      '源字段 exposure（暴露度相关连续指数）：数值越大表示该指数越高；是连续指数，不是受影响人口数。正式口径以数据负责人登记为准。',
    unit: '无量纲指数（0—1）',
  },
  rrgi: {
    key: 'rrgi',
    label: 'rrgi',
    explanation:
      '源字段 rrgi（相对风险相关连续指数）：数值越大表示该指数越高；是连续指数，不是风险等级，未划分等级。正式口径以数据负责人登记为准。',
    unit: '无量纲指数（0—1）',
  },
}

/* ------------------------------------------------------------------ *
 * 记录与数据集
 * ------------------------------------------------------------------ */

export interface ScenarioRecord {
  /** 业务标识：同一 glacier_id 才视为同一对象（203 §7-5）。 */
  glacierId: string
  longitude: number
  latitude: number
  /** 三个指标各自独立取值；源数据缺失为 null，不是 0。 */
  values: Record<ScenarioMetric, number | null>
  region: string | null
  basin: string | null
}

export interface ScenarioDataset {
  year: ScenarioYear
  /** 清单里的源图层名（如 HAZ_SUSCEPTIBILITY_PT_2050），用于来源说明。 */
  sourceLayer: string
  label: string
  sha256: string
  records: ScenarioRecord[]
  /** 文件总条数（清单 count）。 */
  total: number
  /** 因 glacier_id 缺失或坐标非法被跳过的条数；界面如实显示，不静默丢弃。 */
  skippedInvalid: number
}

/** 同对象匹配统计（按 glacier_id 精确匹配，大小写敏感）。 */
export interface ScenarioMatchStats {
  /** 两期都存在的对象数。 */
  matched: number
  /** 仅 2050 存在。 */
  onlyIn2050: number
  /** 仅 2100 存在。 */
  onlyIn2100: number
}

export type MatchStatus = 'both' | 'only-2050' | 'only-2100'

export function computeMatchStats(a: ScenarioDataset, b: ScenarioDataset): ScenarioMatchStats {
  const idsOf = (dataset: ScenarioDataset): Set<string> =>
    new Set(dataset.records.map((record) => record.glacierId))
  const aIds = idsOf(a)
  const bIds = idsOf(b)
  let matched = 0
  for (const id of aIds) if (bIds.has(id)) matched += 1
  return { matched, onlyIn2050: aIds.size - matched, onlyIn2100: bIds.size - matched }
}

/**
 * 判断一个 glacier_id 的匹配身份。两期都装载后才有意义；
 * 只装载一期时返回 null（界面不显示未匹配结论）。
 */
export function matchStatusOf(
  glacierId: string,
  ids2050: Set<string> | null,
  ids2100: Set<string> | null,
): MatchStatus | null {
  if (ids2050 === null || ids2100 === null) return null
  const in2050 = ids2050.has(glacierId)
  const in2100 = ids2100.has(glacierId)
  if (in2050 && in2100) return 'both'
  if (in2050) return 'only-2050'
  return 'only-2100'
}

export const MATCH_STATUS_TEXT: Record<MatchStatus, string> = {
  both: '两期均有',
  'only-2050': '仅 2050',
  'only-2100': '仅 2100',
}

/* ------------------------------------------------------------------ *
 * 归一化：源 GeoJSON → ScenarioRecord
 * ------------------------------------------------------------------ */

function toNullableNumber(value: unknown): number | null {
  if (value === null || value === undefined) return null
  if (typeof value !== 'number' || !Number.isFinite(value)) return null
  return value
}

function toNullableText(value: unknown): string | null {
  if (typeof value !== 'string') return null
  const trimmed = value.trim()
  return trimmed.length === 0 ? null : trimmed
}

/**
 * 把一条源要素归一化为 ScenarioRecord；glacier_id 缺失或坐标非法时返回 null
 * （调用方计入 skippedInvalid，不让坏记录无声消失）。
 */
export function toScenarioRecord(raw: Record<string, unknown>): ScenarioRecord | null {
  const geometry = raw.geometry as { type?: unknown; coordinates?: unknown } | null | undefined
  const properties = (raw.properties ?? {}) as Record<string, unknown>
  const glacierId = toNullableText(properties.glacier_id)
  if (!Array.isArray(geometry?.coordinates) || glacierId === null) return null
  const longitude = toNullableNumber(geometry.coordinates[0])
  const latitude = toNullableNumber(geometry.coordinates[1])
  if (longitude === null || latitude === null) return null
  return {
    glacierId,
    longitude,
    latitude,
    values: {
      hrgi: toNullableNumber(properties.hrgi),
      exposure: toNullableNumber(properties.exposure),
      rrgi: toNullableNumber(properties.rrgi),
    },
    region: toNullableText(properties.region),
    basin: toNullableText(properties.basin),
  }
}

/* ------------------------------------------------------------------ *
 * 显示格式化（组件不得自带规则）
 * ------------------------------------------------------------------ */

/** 指数值显示：null → 「未提供」（不是 0，也不是 —）；0 → 0.000（真实为零）。 */
export function formatScenarioValue(value: number | null): string {
  if (value === null) return NOT_PROVIDED_TEXT
  return formatNumber(value, { minimumFractionDigits: 3, maximumFractionDigits: 3 })
}

/* ------------------------------------------------------------------ *
 * 分布统计：连续分箱（展示用，不是等级）
 * ------------------------------------------------------------------ */

/** 展示用分箱数量；这是「连续指数的分布直方图」，不是风险分级。 */
export const SCENARIO_BIN_COUNT = 10

export interface ScenarioBin {
  /** 区间 [from, to)，最后一箱闭合右端。 */
  from: number
  to: number
  count: number
}

/**
 * 按统一 [0,1] 域把指标值分成 SCENARIO_BIN_COUNT 个等宽区间统计条数。
 * null 不进任何箱（由调用方单独统计并显示），0 属于第一箱（真实为零）。
 */
export function distributionBins(
  records: ScenarioRecord[],
  metric: ScenarioMetric,
): { bins: ScenarioBin[]; nullCount: number } {
  const bins: ScenarioBin[] = Array.from({ length: SCENARIO_BIN_COUNT }, (_, index) => ({
    from: index / SCENARIO_BIN_COUNT,
    to: (index + 1) / SCENARIO_BIN_COUNT,
    count: 0,
  }))
  let nullCount = 0
  for (const record of records) {
    const value = record.values[metric]
    if (value === null) {
      nullCount += 1
      continue
    }
    const clamped = Math.min(1, Math.max(0, value))
    const index = Math.min(SCENARIO_BIN_COUNT - 1, Math.floor(clamped * SCENARIO_BIN_COUNT))
    const bin = bins[index]
    if (bin !== undefined) bin.count += 1
  }
  return { bins, nullCount }
}

/** 判断一个值是否落在直方图点击产生的筛选区间 [from, to] 内（右端闭合）。 */
export function valueInBinRange(value: number | null, range: [number, number] | null): boolean {
  if (range === null) return true
  if (value === null) return false
  return value >= range[0] && value <= range[1]
}
