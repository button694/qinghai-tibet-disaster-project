/**
 * 风险等级元数据（01 §4.2 风险色、§4.5 风险分布图）。
 *
 * 地图、图例、徽标与分布图共用本文件，保证同一等级在任何位置颜色与文案一致。
 * 颜色值与 `src/styles/tokens.css` 中的 `--color-risk-*` 必须一致，
 * 由 `tests/unit/tokens.spec.ts` 直接解析 tokens.css 交叉校验，避免两处漂移。
 */
import type { RiskLevel } from './types'

/** 等级顺序固定：低 → 高，数据不足永远排在最后。 */
export const RISK_LEVELS = ['low', 'lower', 'medium', 'higher', 'high', 'insufficient'] as const

export const GRADED_RISK_LEVELS = ['low', 'lower', 'medium', 'higher', 'high'] as const

export const RISK_LEVEL_LABEL: Record<RiskLevel, string> = {
  low: '低',
  lower: '较低',
  medium: '中',
  higher: '较高',
  high: '高',
  insufficient: '数据不足',
}

/** 分类图例与排序用的序号，同时也作为“不能只靠颜色区分”的文字编号。 */
export const RISK_LEVEL_ORDER: Record<RiskLevel, number> = {
  low: 1,
  lower: 2,
  medium: 3,
  higher: 4,
  high: 5,
  insufficient: 0,
}

export const RISK_LEVEL_COLOR: Record<RiskLevel, string> = {
  low: '#3d8f78',
  lower: '#8bae69',
  medium: '#d8b24c',
  higher: '#de7c3b',
  high: '#bf454b',
  insufficient: '#929eab',
}

/** 白底徽标上使用的深色文字，保证对比度。 */
export const RISK_LEVEL_TEXT_COLOR: Record<RiskLevel, string> = {
  low: '#1f5b4b',
  lower: '#4d6636',
  medium: '#7a5f11',
  higher: '#8a4315',
  high: '#7f2329',
  insufficient: '#4b5763',
}

/** 数据不足的附加纹理要求（01 §4.2）。 */
export const RISK_LEVEL_PATTERN: Record<RiskLevel, 'hatch' | 'none'> = {
  low: 'none',
  lower: 'none',
  medium: 'none',
  higher: 'none',
  high: 'none',
  insufficient: 'hatch',
}

const RISK_LEVEL_SET = new Set<string>(RISK_LEVELS)

export function isRiskLevel(value: string | null | undefined): value is RiskLevel {
  return value != null && RISK_LEVEL_SET.has(value)
}

/** 未知值返回 `insufficient`（数据不足），绝不猜测成中间等级。 */
export function toRiskLevel(value: string | null | undefined): RiskLevel {
  return isRiskLevel(value) ? value : 'insufficient'
}

export function riskLevelLabel(value: string | null | undefined): string {
  return RISK_LEVEL_LABEL[toRiskLevel(value)]
}

/** 按固定等级顺序排序，用于图例、统计表与导出。 */
export function compareRiskLevel(a: RiskLevel, b: RiskLevel): number {
  return RISK_LEVEL_ORDER[a] - RISK_LEVEL_ORDER[b]
}

/** 高风险口径：高与较高（01 §5.2 重点对象筛选）。 */
export const HIGH_RISK_LEVELS: RiskLevel[] = ['higher', 'high']

export function isHighRisk(level: RiskLevel): boolean {
  return HIGH_RISK_LEVELS.includes(level)
}
