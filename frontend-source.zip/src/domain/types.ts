/**
 * 统一数据契约（实现 02《接口契约与数据接入规范》§3、§3.1、§3.2）。
 *
 * 说明：
 * 1. 本文件是**唯一**的业务数据结构来源。页面、mock 适配器与 HTTP 适配器共用同一组类型，
 *    页面不得直接读示例 JSON，也不得出现数据库物理字段名。
 * 2. 所有 ID 一律为字符串（02 §2.1）。SQL bigint 不得先转 JS Number 再转字符串。
 * 3. `null` 表示未知/未提供，**不等于 0**；另有 status 区分 notProvided / noData /
 *    notApplicable（02 §2.3）。
 * 4. 02 中同名的核心模型按原文实现；02 §3.2 只给了字段清单的补充模型在下方展开为严格类型，
 *    凡本文件对 02 的补充或细化都在注释中标出「补充」。
 */
import type { Geometry } from 'geojson'

/* ------------------------------------------------------------------ *
 * 基础枚举
 * ------------------------------------------------------------------ */

/** 数据模式（01 §6.3）。mock＝示例数据，snapshot＝成果快照，api＝正式接口。 */
export type DataMode = 'mock' | 'snapshot' | 'api'

/** 五个业务主题＋系统元数据。系统主题不作为地图图层（01 §5.1）。 */
export type Theme = 'base' | 'tnr' | 'hazard' | 'emg' | 'result' | 'sys'

/** 风险等级：五级＋数据不足（01 §4.2）。 */
export type RiskLevel = 'low' | 'lower' | 'medium' | 'higher' | 'high' | 'insufficient'

export type ResultKind = 'risk' | 'exposure' | 'emergency'

/** 时间精度。不补造具体日期（02 §2.4）。 */
export type TimePrecision = 'year' | 'month' | 'day' | 'datetime' | 'unknown'

/** 时间语义：事件时间、观测时间、情景时间与导入时间必须分开建模（01 §7.2）。 */
export type TimeRole = 'observed' | 'event' | 'scenario' | 'generated' | 'imported'

/** 指标状态。`null` 值必须给出具体状态，页面据此显示不同文案（02 §2.3）。 */
export type MetricStatus = 'known' | 'noData' | 'notProvided' | 'notApplicable'

/** 矢量几何家族。源数据允许是 Multi 几何，不为适配单部件丢弃多部件（02 §3）。 */
export type GeometryFamily = 'Point' | 'LineString' | 'Polygon' | 'Raster' | 'Table'

/** 要素属性值。只允许 JSON 原始类型，不允许嵌套对象（02 §3 FeatureDetail）。 */
export type FeaturePropertyValue = string | number | boolean | null

/** WGS84 经纬度，坐标顺序 `[longitude, latitude]`（02 §2.5）。 */
export type LonLat = [number, number]

/** 范围框，顺序为**西、南、东、北**（02 §2.10）。 */
export type Bbox = [number, number, number, number]

/* ------------------------------------------------------------------ *
 * 02 §3 核心模型
 * ------------------------------------------------------------------ */

/** 统一对象引用。全局对象键为 `layerId + ':' + id`（01 §7.2）。 */
export interface FeatureRef {
  layerId: string
  id: string
}

export interface TimeValue {
  value: string | null
  precision: TimePrecision
  role: TimeRole
}

export interface Metric {
  key: string
  label: string
  /** 未知一律为 null，不得写 0。 */
  value: number | null
  /** 未确认单位时为 null，界面不自动推测（02 §2.6）。 */
  unit: string | null
  status: MetricStatus
  /** 统计口径/方法说明。 */
  method?: string
  /** 指标对应年份（如人口年份）。 */
  year?: number
  /** 精度补充说明，例如“仅统计示例样区内”。 */
  precisionNote?: string
  /** 补充：统计范围标签，01 §4.4 要求每项指标显示统计范围。 */
  scopeLabel?: string
}

/** 数据上下文。列表、统计与导出必须携带同一份上下文（02 §2.7、§2.8）。 */
export interface Context {
  mode: DataMode
  snapshotId: string
  queryId?: string
  /** 完整时间必须带时区。 */
  generatedAt: string
  scopeLabel: string
  boundaryVersion: string
  datasetVersions: Record<string, string>
}

/** 所有数据接口的统一外层结构（下载内容除外）。 */
export interface Envelope<T> {
  data: T
  meta: Context
  requestId: string
}

export interface Page<T> {
  items: T[]
  /** 全部匹配总数，不是本页条数（02 §4.1）。 */
  total: number
  page: number
  pageSize: number
}

/**
 * 补充（阶段8C）：`LayerRepository.listFeatures` 专用的分页返回形态。
 *
 * 比通用 `Page<T>` 多了几何简化标注：`geometrySimplified` 为 true 时，
 * `items[].geometry` 是服务端按 `simplifyToleranceMeters` 简化过的渲染用几何，
 * 不是原始精度——界面（图层树/图例说明）必须据此提示，调用方不得把它当原始几何
 * 用于导出或精确空间判定。
 */
export interface FeaturePage extends Page<FeatureDetail> {
  geometrySimplified?: boolean
  simplifyToleranceMeters?: number | null
}

export type FieldType = 'string' | 'number' | 'date' | 'enum' | 'boolean'

export interface FieldDefinition {
  key: string
  label: string
  type: FieldType
  unit: string | null
  nullable: boolean
  filterable: boolean
  sortable: boolean
  dictionaryId?: string
  /** 补充：日期字段的声明精度，用于按精度显示而非补造日期。 */
  precision?: TimePrecision
  /** 补充：原始物理字段名，只用于 API_MAPPING 追溯，页面不显示（02 §3）。 */
  originalField?: string
}

/** 地图数据来源。没有可用服务时必须用 `unavailable` 明确声明，而不是留空 URL。 */
export type MapSource =
  | { type: 'geojson'; url: string; outputCrs: 'EPSG:4326' }
  | { type: 'xyz'; url: string; projection: string; minZoom?: number; maxZoom?: number }
  | { type: 'wmts'; capabilitiesUrl: string; layer: string; matrixSet: string }
  | { type: 'wms'; url: string; layer: string; version: '1.1.1' | '1.3.0'; projection: string }
  | { type: 'cog'; url: string; projection: string; noData: number | null }
  | { type: 'unavailable'; reason: string }

export interface LayerDefinition {
  id: string
  label: string
  theme: Theme
  datasetId: string
  geometryType: GeometryFamily
  source: MapSource
  fields: FieldDefinition[]
  defaultVisible: boolean
  defaultOpacity: number
  minZoom?: number
  availableTimes: TimeValue[]
  legendId: string
  queryable: boolean
  exportFormats: string[]
  sourceCrs: string
  sourceWkt?: string
}

export interface FeatureDetail {
  ref: FeatureRef
  /** 跨点面表达的同一业务对象标识，须有真实映射来源（02 §2.2）。 */
  entityKey?: string
  title: string
  datasetId: string
  /** 无几何记录为 null：属性可查，定位不可用（01 §5.1）。 */
  geometry: Geometry | null
  properties: Record<string, FeaturePropertyValue>
  relatedResultIds: string[]
}

export type ResultStatus = 'published' | 'draft' | 'archived'

/** 项目自身分析成果与外部来源情景必须分开标识（01 §5.2）。 */
export type ResultSourceType = 'projectAnalysis' | 'externalScenario'

export interface ResultSummary {
  id: string
  kind: ResultKind
  title: string
  version: string
  status: ResultStatus
  time: TimeValue
  scenarioYear?: number
  sourceType: ResultSourceType
  layerIds: string[]
  regionLabel: string
  metrics: Metric[]
}

export interface ResultClassification {
  method: string
  unit: string | null
  classes: Array<{ code: RiskLevel; label: string; min: number | null; max: number | null }>
  boundaryRule: string
}

export interface ResultFile {
  id: string
  label: string
  format: string
  /** 文件不可访问时保留元数据，只把可用性标为 false（01 §5.5）。 */
  available: boolean
  /** 补充：不可用原因。 */
  unavailableReason?: string
  /**
   * 补充（阶段6）：浏览器可访问的相对地址（数据包内路径）。
   * 只有服务明确登记且文件真实存在时才有值；没有 url 的 available 文件
   * 界面同样不给下载入口，避免伪造。
   */
  url?: string
}

export interface ResultDetail extends ResultSummary {
  taskId: string | null
  method: string | null
  parameters: Record<string, unknown>
  inputs: Array<{ datasetId: string; version: string | null; role: string }>
  /** 未提供分级阈值时为 null：界面只显示连续指数，不擅自五等分（01 §5.2）。 */
  classification: ResultClassification | null
  qualityNotes: string[]
  files: ResultFile[]
}

/* ------------------------------------------------------------------ *
 * 02 §3.1 查询模型
 * ------------------------------------------------------------------ */

export type FilterOperator = 'eq' | 'in' | 'containsText' | 'gte' | 'lte' | 'between' | 'isNull'

export interface AttributeFilter {
  field: string
  operator: FilterOperator
  value?: string | number | boolean | Array<string | number>
}

export type SpatialPredicate = 'intersects' | 'within' | 'bufferIntersects' | 'nearest'

export interface SpatialInput {
  predicate: SpatialPredicate
  /** `geometry` / `sourceFeature` / `regionId` 恰选一个，由接口校验。 */
  geometry?: Geometry
  sourceFeature?: FeatureRef
  regionId?: string
  /** 单位米。缓冲与最近邻都必须给出米制距离，禁止把经纬度差当米。 */
  distanceMeters?: number
  limit?: number
}

export interface QueryInput {
  layerId: string
  /** 第一版统一 AND 语义。 */
  filters: AttributeFilter[]
  spatial?: SpatialInput
  scenarioYear?: number
  datasetVersion?: string
  page: number
  pageSize: number
  sort?: { field: string; direction: 'asc' | 'desc' }
  /**
   * 补充（阶段8C）：仅用于地图渲染的服务端几何简化容差（米，LCC 投影单位）。
   * 只对线/面几何生效，且不能与 spatial 同时使用（服务端会拒绝）；
   * 属性表格/要素详情/导出一律不传本字段，保持原始精度几何。
   */
  simplifyMeters?: number
}

export interface QueryMapSelection {
  featureRefs?: FeatureRef[]
  overlayUrl?: string
  /** 全部匹配数。地图可能概化或聚合，不能用可见点数推导（01 §5.1）。 */
  matchedTotal: number
  renderedCount: number
  truncated: boolean
}

export interface QueryResult {
  rows: Page<FeatureDetail>
  queryId: string
  metrics: Metric[]
  mapSelection: QueryMapSelection
  /**
   * 补充（本工程）：最近邻查询的逐条距离（米），键为全局对象键 `layerId:id`。
   * 02 §3.1 要求最近邻「返回距离单位 m 以及采用的距离方法」，契约原型里没有承载逐条距离的字段，
   * 因此在此补充一个可空字段；非最近邻查询为 `null`，不写 0 也不省略单位。
   */
  nearestDistances?: Record<string, number> | null
  /**
   * 补充（阶段8C）：本响应里的要素几何是否经过服务端简化（仅用于地图渲染）。
   * 未请求 simplifyMeters、或图层几何不支持简化（点/无重投影几何）时为 false。
   */
  geometrySimplified?: boolean
  /** 实际生效的简化容差（米）；未简化为 null。 */
  simplifyToleranceMeters?: number | null
}

/* ------------------------------------------------------------------ *
 * 02 §3.2 元数据与补充模型
 * ------------------------------------------------------------------ */

export type DatasetType = 'vector' | 'raster' | 'table'
export type DatasetStatus = 'registered' | 'published' | 'archived'
export type AccessLevel = 'public' | 'internal' | 'restricted'

export interface Dataset {
  id: string
  name: string
  theme: Theme
  sourceId: string
  dataType: DatasetType
  version: string
  availableTimes: TimeValue[]
  sourceCrs: string
  sourceWkt?: string
  /** 范围框为西、南、东、北；未登记为 null，不填 (0,0,0,0)。 */
  extent: Bbox | null
  resolution: string | null
  quality: string | null
  accessLevel: AccessLevel
  status: DatasetStatus
  /** 补充：栅格“已登记”不等于“服务可用”（01 §5.6），两者分开显示。 */
  serviceAvailable: boolean
  /** 补充：服务状态说明，不可用时必填。 */
  serviceNote: string | null
  /** 已接入真实栅格浏览时对应的受控资产编号；不会暴露服务器或磁盘路径。 */
  rasterPreviewId?: string | null
  /** 多年份栅格资产（如年度降水 2001—2023）的年份→资产编号映射；单一年份数据集为空。 */
  rasterPreviewYears?: Record<string, string> | null
  /** 补充：时相说明，例如“2001—2023 年降水”。 */
  temporalCoverage?: string | null
  fields: FieldDefinition[]
  layerIds: string[]
}

export interface DataSource {
  id: string
  name: string
  organization: string | null
  sourceUrl: string | null
  acquiredDate: TimeValue | null
  licenseDescription: string | null
}

export type LegendKind = 'classified' | 'continuous' | 'categorical'

export interface LegendItem {
  code: string
  label: string
  color: string
  min: number | null
  max: number | null
}

export interface Legend {
  id: string
  kind: LegendKind
  unit: string | null
  items: LegendItem[]
  range: { min: number | null; max: number | null } | null
  /** 数据不足必须有文字或纹理，不能只靠颜色（01 §4.2）。 */
  noDataStyle: { color: string; label: string; pattern: 'hatch' | 'none' }
  classificationVersion: string | null
}

/** 承灾体影响统计。人口密度栅格不得直接求和当人数（01 §5.3）。 */
export interface ExposureSummary {
  resultId: string
  hazardRef: FeatureRef | null
  impactLayerId: string
  metrics: Metric[]
  /** 点面重复对象的去重规则说明，必须写明依据的业务标识。 */
  deduplicationRule: string | null
  populationYear: number | null
  scopeMethod: string | null
  /** 补充：参与统计的记录数与去重后的对象数，两者分开显示。 */
  matchedRecordCount: number
  uniqueEntityCount: number
  /** 补充（本工程）：受影响对象按类别的计数，用于阶段5 的分类筛选；02 §3.2 只要求「受影响对象分页入口」。 */
  affectedCategories: Array<{ key: string; label: string; layerId: string; count: number }>
  /** 补充（本工程）：派生过程的口径提醒，02 未列；无提醒时为 null。 */
  note: string | null
}

export type RouteStatus = 'reachable' | 'unreachable'
/**
 * 路线角色：primary（ROUTE_RANK=1）/ alternative（其余非空登记值）/
 * unregistered（ROUTE_RANK 为 NULL，库内未登记角色语义——不得推定为主方案或备选）。
 */
export type RouteRole = 'primary' | 'alternative' | 'unregistered'

export interface RouteEndpoint {
  ref: FeatureRef | null
  label: string
  lonLat: LonLat | null
}

export interface RouteRiskSegment {
  ref: FeatureRef | null
  kind: 'blocked' | 'risk'
  label: string
  note: string | null
}

export interface RouteResourceRef {
  ref: FeatureRef
  label: string
  kind: 'hospital' | 'rescue' | 'firestation' | 'airport'
  /** 与路线的距离；未知为 null，不补造。 */
  distanceFromRouteMeters: number | null
}

export interface RouteSummary {
  id: string
  resultId: string
  /** 补充（本工程）：02 §3.2 的 RouteDetail 有 origin/destination 名称，摘要层用单一 label 承载路线名称。 */
  label: string
  /** 补充（本工程）：02 只在方案 A/B 场景中间接提到角色，此处显式建模为 primary/alternative/unregistered。 */
  role: RouteRole
  status: RouteStatus
  /** 无可达路径时几何为 null，禁止用直线冒充路线。 */
  distanceMeters: number | null
  /** 无预计时间时为 null（02 §5.1）。 */
  durationSeconds: number | null
  networkVersion: string
  blockedFeatureRefs: FeatureRef[]
  assumptions: string[]
  generatedAt: string
  /**
   * 补充（真实演示）：同组方案分组键——库内 HAZARD_POINT_ID。
   * 不同危险源的路线不得混称为同一组 A/B/C 方案；未登记时为 null。
   */
  hazardPointId: string | null
  /** 补充（真实演示）：终点设施类型（医院/消防站/救援站等，取库内 FACILITY_TYPE_NAME）。 */
  facilityType: string | null
}

export interface RouteDetail extends RouteSummary {
  origin: RouteEndpoint | null
  destination: RouteEndpoint | null
  geometry: Geometry | null
  riskSegments: RouteRiskSegment[]
  resources: RouteResourceRef[]
  /** 补充：距离来源说明，区分“已存成果记录”与“前端估算”。 */
  distanceSource: string
  /** 补充：通行时间来源说明；时间为 null 时说明原因。 */
  durationSource: string | null
}

/** 行政区/流域条目，用于空间查询范围选择。 */
export type RegionLevel = 'country' | 'province' | 'city' | 'county' | 'basin'

export interface Region {
  id: string
  name: string
  level: RegionLevel
  parentId: string | null
  extent: Bbox | null
}

export interface DictionaryItem {
  code: string
  label: string
}

/** 代码与标签字典。GB/CODE 只作分类，不是主键（01 §7.2）。 */
export interface Dictionary {
  id: string
  label: string
  items: DictionaryItem[]
}

/** 已登记的导入批次日志（01 §5.7）。不是完整用户操作审计表。 */
export interface ImportLog {
  id: string
  datasetId: string
  layerId: string | null
  batchLabel: string
  sourceCount: number | null
  targetCount: number | null
  status: 'succeeded' | 'failed' | 'running' | 'unknown'
  startedAt: string | null
  finishedAt: string | null
}

/** 能力开关。未声明的写能力默认关闭（02 §3.2）。 */
export type CapabilityKey =
  | 'readLayers'
  | 'attributeQuery'
  | 'spatialQuery'
  | 'readResults'
  | 'exportFormats'
  | 'authEnabled'
  | 'routeRecompute'
  | 'analysisSubmit'
  | 'dataEdit'
  | 'backupExecute'

export interface Capabilities {
  readLayers: boolean
  attributeQuery: boolean
  spatialQuery: boolean
  readResults: boolean
  /** 服务明确支持的导出格式；支持某格式不代表每个成果都有该文件。 */
  exportFormats: string[]
  authEnabled: boolean
  routeRecompute: boolean
  analysisSubmit: boolean
  dataEdit: boolean
  backupExecute: boolean
  /** 补充：能力被关闭的原因，用于界面上解释“为什么按钮不可用”。 */
  reasons: Partial<Record<CapabilityKey, string>>
  /** 补充（本工程）：实际生效的运行模式。示例包声明可能与运行模式不一致，界面按本字段标注来源。 */
  mode: DataMode
  /** 补充（本工程）：数据包标识（mock/snapshot）或快照标识，用于来源追溯。 */
  snapshotId: string
}

/** 成果分级/分类统计。count 为对象数，一律由样本或成果记录派生。 */
export interface CategoryStatistics {
  key: string
  label: string
  count: number
  unit: string | null
  color: string | null
}

export interface ResultStatistics {
  resultId: string
  unit: string | null
  method: string | null
  distribution: CategoryStatistics[]
  metrics: Metric[]
  /** 样本不足时的文字说明，替代图形（01 §4.5）。 */
  sampleNote: string | null
}

export interface OverviewKeyFeature {
  ref: FeatureRef
  title: string
  layerLabel: string
  level: RiskLevel | null
  metric: Metric | null
}

/** 总览数据（`GET /overview`）。最多四项指标，每项带口径与时点（01 §4.4）。 */
export interface OverviewData {
  regionLabel: string
  /** 数据快照时间；不显示虚假“实时监测中”。 */
  snapshotTime: TimeValue | null
  metrics: Metric[]
  riskDistribution: CategoryStatistics[]
  keyFeatures: OverviewKeyFeature[]
  currentResults: ResultSummary[]
  notes: string[]
}
