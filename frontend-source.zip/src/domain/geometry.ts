/**
 * 几何工具（02 §2.5 坐标与单位规则）。
 *
 * 用途限定，必须在文档与界面中保持诚实：
 * 1. 这里的长度/面积是**球面近似或局部平面近似**，只用于示例数据自检、地图交互容差
 *    与屏幕提示。正式统计一律读取已存成果或服务端计算值（02 §4）。
 * 2. 所有入参出参都是 WGS84 `[lon, lat]` 度。距离换算统一走米制公式，
 *    **绝不把经纬度差当米**（02 §2.5）。
 * 3. 裁剪函数只对**凸多边形**精确（示例影响范围均为凸多边形）；
 *    遇到凹多边形会在文档与测试中明确标出适用范围。**任意多边形（含凹面）的相交、
 *    覆盖与米制距离判定不在本文件**，见 `spatialRelations.ts`（阶段3）。
 */
import type { Geometry, Position } from 'geojson'

import type { Bbox, GeometryFamily, LonLat } from './types'

/** WGS84 平均地球半径（米）。 */
export const EARTH_RADIUS_METERS = 6371008.8

/** 1 度纬度约等于的米数（用于局部投影，非正式统计）。 */
const METERS_PER_DEGREE_LAT = 111132

/** 1 度经度在给定纬度上约等于的米数。 */
export function metersPerDegreeLon(latitude: number): number {
  return 111320 * Math.cos((latitude * Math.PI) / 180)
}

function toRadians(degrees: number): number {
  return (degrees * Math.PI) / 180
}

/** 球面两点距离（haversine），单位米。 */
export function haversineMeters(a: LonLat, b: LonLat): number {
  const [lon1, lat1] = a
  const [lon2, lat2] = b
  const phi1 = toRadians(lat1)
  const phi2 = toRadians(lat2)
  const dPhi = toRadians(lat2 - lat1)
  const dLambda = toRadians(lon2 - lon1)
  const sinPhi = Math.sin(dPhi / 2)
  const sinLambda = Math.sin(dLambda / 2)
  const h = sinPhi * sinPhi + Math.cos(phi1) * Math.cos(phi2) * sinLambda * sinLambda
  return 2 * EARTH_RADIUS_METERS * Math.asin(Math.min(1, Math.sqrt(h)))
}

/** 折线长度（米），逐段 haversine 求和。 */
export function polylineLengthMeters(coords: LonLat[]): number {
  let total = 0
  for (let index = 1; index < coords.length; index += 1) {
    total += haversineMeters(coords[index - 1] as LonLat, coords[index] as LonLat)
  }
  return total
}

/**
 * 球面多边形面积（米²）——球面盈余近似公式，仅用于示例自检，
 * 不作为成果面积；成果面积以服务端或成果文件为准。
 */
export function ringAreaSquareMeters(ring: LonLat[]): number {
  if (ring.length < 3) return 0
  let sum = 0
  for (let index = 0; index < ring.length; index += 1) {
    const current = ring[index] as LonLat
    const next = ring[(index + 1) % ring.length] as LonLat
    sum +=
      toRadians(next[0] - current[0]) *
      (2 + Math.sin(toRadians(current[1])) + Math.sin(toRadians(next[1])))
  }
  return Math.abs((sum * EARTH_RADIUS_METERS * EARTH_RADIUS_METERS) / 2)
}

/* ------------------------------------------------------------------ *
 * 局部平面投影（小范围近似）
 * ------------------------------------------------------------------ */

export interface LocalProjection {
  toLocal: (point: LonLat) => [number, number]
  toLonLat: (x: number, y: number) => LonLat
}

/**
 * 以某点为原点建立局部平面（米）。**只用于判断“最近点落在哪里”，
 * 真正的距离数值仍由 `haversineMeters` 在球面上算**（见 spatialRelations.ts）。
 */
export function createLocalProjection(origin: LonLat): LocalProjection {
  const [originLon, originLat] = origin
  const lonScale = metersPerDegreeLon(originLat)
  return {
    toLocal: ([lon, lat]) => [
      (lon - originLon) * lonScale,
      (lat - originLat) * METERS_PER_DEGREE_LAT,
    ],
    toLonLat: (x, y) => [originLon + x / lonScale, originLat + y / METERS_PER_DEGREE_LAT],
  }
}

/* ------------------------------------------------------------------ *
 * 坐标读取
 * ------------------------------------------------------------------ */

function isPosition(value: unknown): value is Position {
  return (
    Array.isArray(value) &&
    value.length >= 2 &&
    typeof value[0] === 'number' &&
    typeof value[1] === 'number'
  )
}

function asLonLat(position: Position): LonLat {
  return [position[0] as number, position[1] as number]
}

/** 取几何的代表点坐标（点本身；线/面的首个坐标），无几何时返回 null。 */
export function representativeLonLat(geometry: Geometry | null | undefined): LonLat | null {
  if (!geometry) return null
  switch (geometry.type) {
    case 'Point':
      return isPosition(geometry.coordinates) ? asLonLat(geometry.coordinates) : null
    case 'MultiPoint':
    case 'LineString': {
      const first = geometry.coordinates[0]
      return isPosition(first) ? asLonLat(first) : null
    }
    case 'MultiLineString':
    case 'Polygon': {
      const firstRing = geometry.coordinates[0]
      const first = firstRing?.[0]
      return isPosition(first) ? asLonLat(first) : null
    }
    case 'MultiPolygon': {
      const first = geometry.coordinates[0]?.[0]?.[0]
      return isPosition(first) ? asLonLat(first) : null
    }
    case 'GeometryCollection': {
      for (const item of geometry.geometries) {
        const found = representativeLonLat(item)
        if (found) return found
      }
      return null
    }
  }
}

/** 全部坐标点（面取外环+内环）。用于范围框与自检。 */
export function allCoordinates(geometry: Geometry | null | undefined): LonLat[] {
  if (!geometry) return []
  const result: LonLat[] = []
  const pushRing = (ring: Position[]) => {
    for (const position of ring) {
      if (isPosition(position)) result.push(asLonLat(position))
    }
  }
  switch (geometry.type) {
    case 'Point':
      if (isPosition(geometry.coordinates)) result.push(asLonLat(geometry.coordinates))
      break
    case 'MultiPoint':
    case 'LineString':
      pushRing(geometry.coordinates)
      break
    case 'MultiLineString':
    case 'Polygon':
      for (const ring of geometry.coordinates) pushRing(ring)
      break
    case 'MultiPolygon':
      for (const polygon of geometry.coordinates) {
        for (const ring of polygon) pushRing(ring)
      }
      break
    case 'GeometryCollection':
      for (const item of geometry.geometries) result.push(...allCoordinates(item))
      break
  }
  return result
}

/** 几何家族。返回 null 表示几何缺失（属性可查但无法定位）。 */
export function geometryFamilyOf(geometry: Geometry | null | undefined): GeometryFamily | null {
  if (!geometry) return null
  switch (geometry.type) {
    case 'Point':
    case 'MultiPoint':
      return 'Point'
    case 'LineString':
    case 'MultiLineString':
      return 'LineString'
    case 'Polygon':
    case 'MultiPolygon':
      return 'Polygon'
    case 'GeometryCollection':
      return null
  }
}

/** 范围框（西、南、东、北）。无坐标时返回 null，不返回 (0,0,0,0)。 */
export function bboxOfGeometry(geometry: Geometry | null | undefined): Bbox | null {
  const coords = allCoordinates(geometry)
  if (coords.length === 0) return null
  let west = Infinity
  let south = Infinity
  let east = -Infinity
  let north = -Infinity
  for (const [lon, lat] of coords) {
    if (lon < west) west = lon
    if (lon > east) east = lon
    if (lat < south) south = lat
    if (lat > north) north = lat
  }
  return [west, south, east, north]
}

/** 面几何的近似中心（外环经纬度平均），用于地图标注；不是权威质心。 */
export function approximateCentroid(geometry: Geometry | null | undefined): LonLat | null {
  if (!geometry) return null
  let outer: Position[] | null = null
  if (geometry.type === 'Polygon') outer = geometry.coordinates[0] ?? null
  else if (geometry.type === 'MultiPolygon') outer = geometry.coordinates[0]?.[0] ?? null
  if (!outer || outer.length === 0) return representativeLonLat(geometry)
  let sumLon = 0
  let sumLat = 0
  let count = 0
  for (const position of outer) {
    if (!isPosition(position)) continue
    sumLon += position[0] as number
    sumLat += position[1] as number
    count += 1
  }
  if (count === 0) return representativeLonLat(geometry)
  return [sumLon / count, sumLat / count]
}

/* ------------------------------------------------------------------ *
 * 点与面关系
 * ------------------------------------------------------------------ */

export type PointLocation = 'inside' | 'outside' | 'boundary'

/**
 * 点与环的关系。射线法判断内外，用局部平面距离判断是否落在边界上
 * （容差为米，默认 1 米）。
 */
export function classifyPointInRing(
  point: LonLat,
  ring: LonLat[],
  toleranceMeters = 1,
): PointLocation {
  if (ring.length < 3) return 'outside'
  const projection = createLocalProjection(point)
  const localPoint = projection.toLocal(point)
  const localRing = ring.map((item) => projection.toLocal(item))

  for (let index = 0; index < localRing.length; index += 1) {
    const a = localRing[index] as [number, number]
    const b = localRing[(index + 1) % localRing.length] as [number, number]
    if (distancePointToSegment(localPoint, a, b) <= toleranceMeters) return 'boundary'
  }

  let inside = false
  for (let index = 0, j = ring.length - 1; index < ring.length; j = index, index += 1) {
    const [xi, yi] = ring[index] as LonLat
    const [xj, yj] = ring[j] as LonLat
    const intersects = yi > point[1] !== yj > point[1]
    if (intersects) {
      const xIntersection = ((xj - xi) * (point[1] - yi)) / (yj - yi) + xi
      if (point[0] < xIntersection) inside = !inside
    }
  }
  return inside ? 'inside' : 'outside'
}

function distancePointToSegment(
  point: [number, number],
  a: [number, number],
  b: [number, number],
): number {
  const dx = b[0] - a[0]
  const dy = b[1] - a[1]
  const lengthSquared = dx * dx + dy * dy
  if (lengthSquared === 0) return Math.hypot(point[0] - a[0], point[1] - a[1])
  let t = ((point[0] - a[0]) * dx + (point[1] - a[1]) * dy) / lengthSquared
  t = Math.max(0, Math.min(1, t))
  return Math.hypot(point[0] - (a[0] + t * dx), point[1] - (a[1] + t * dy))
}

/** 点与多边形（含内环）的关系：内环内视为 outside。 */
export function classifyPointInPolygon(
  point: LonLat,
  polygon: LonLat[][],
  toleranceMeters = 1,
): PointLocation {
  const outer = polygon[0]
  if (!outer) return 'outside'
  const outerLocation = classifyPointInRing(point, outer, toleranceMeters)
  if (outerLocation !== 'inside') return outerLocation
  for (let index = 1; index < polygon.length; index += 1) {
    const hole = polygon[index]
    if (!hole) continue
    const holeLocation = classifyPointInRing(point, hole, toleranceMeters)
    if (holeLocation === 'inside') return 'outside'
    if (holeLocation === 'boundary') return 'boundary'
  }
  return 'inside'
}

/** 点与几何的关系（点、面、多面）。线几何返回是否落在线附近。 */
export function classifyPointInGeometry(
  point: LonLat,
  geometry: Geometry | null | undefined,
  toleranceMeters = 1,
): PointLocation {
  if (!geometry) return 'outside'
  switch (geometry.type) {
    case 'Point':
      return isPosition(geometry.coordinates) &&
        haversineMeters(point, asLonLat(geometry.coordinates)) <= toleranceMeters
        ? 'inside'
        : 'outside'
    case 'MultiPoint':
      return geometry.coordinates.some(
        (item) => isPosition(item) && haversineMeters(point, asLonLat(item)) <= toleranceMeters,
      )
        ? 'inside'
        : 'outside'
    case 'LineString':
      return isPointOnPolyline(point, geometry.coordinates.map(asLonLat), toleranceMeters)
        ? 'boundary'
        : 'outside'
    case 'MultiLineString':
      return geometry.coordinates.some((line) =>
        isPointOnPolyline(point, line.map(asLonLat), toleranceMeters),
      )
        ? 'boundary'
        : 'outside'
    case 'Polygon':
      return classifyPointInPolygon(
        point,
        geometry.coordinates.map((ring) => ring.map(asLonLat)),
        toleranceMeters,
      )
    case 'MultiPolygon': {
      let result: PointLocation = 'outside'
      for (const polygon of geometry.coordinates) {
        const location = classifyPointInPolygon(
          point,
          polygon.map((ring) => ring.map(asLonLat)),
          toleranceMeters,
        )
        if (location === 'inside') return 'inside'
        if (location === 'boundary') result = 'boundary'
      }
      return result
    }
    case 'GeometryCollection': {
      let result: PointLocation = 'outside'
      for (const item of geometry.geometries) {
        const location = classifyPointInGeometry(point, item, toleranceMeters)
        if (location === 'inside') return 'inside'
        if (location === 'boundary') result = 'boundary'
      }
      return result
    }
  }
}

/** 点是否落在折线上（容差为米）。用于校验路线是否沿已登记道路。 */
export function isPointOnPolyline(point: LonLat, coords: LonLat[], toleranceMeters = 5): boolean {
  if (coords.length < 2) return false
  const projection = createLocalProjection(point)
  const localPoint = projection.toLocal(point)
  for (let index = 1; index < coords.length; index += 1) {
    const a = projection.toLocal(coords[index - 1] as LonLat)
    const b = projection.toLocal(coords[index] as LonLat)
    if (distancePointToSegment(localPoint, a, b) <= toleranceMeters) return true
  }
  return false
}

/* ------------------------------------------------------------------ *
 * 裁剪（凸多边形精确）
 * ------------------------------------------------------------------ */

/** 环的平面有向面积符号，用于确定内法线方向。 */
function signedArea(ring: LonLat[]): number {
  const origin = ring[0] as LonLat
  const projection = createLocalProjection(origin)
  const local = ring.map((item) => projection.toLocal(item))
  let sum = 0
  for (let index = 0; index < local.length; index += 1) {
    const [x1, y1] = local[index] as [number, number]
    const [x2, y2] = local[(index + 1) % local.length] as [number, number]
    sum += x1 * y2 - x2 * y1
  }
  return sum / 2
}

/**
 * 线段与**凸多边形**求交（Cyrus–Beck）。
 * 返回裁剪后的线段或 null（完全在外部）。凹多边形结果不可靠，调用方需自行保证。
 */
export function clipSegmentToConvexPolygon(
  a: LonLat,
  b: LonLat,
  ring: LonLat[],
): [LonLat, LonLat] | null {
  if (ring.length < 3) return null
  const projection = createLocalProjection(ring[0] as LonLat)
  const localRing = ring.map((item) => projection.toLocal(item))
  const localA = projection.toLocal(a)
  const localB = projection.toLocal(b)
  const counterClockwise = signedArea(ring) >= 0

  let t0 = 0
  let t1 = 1

  for (let index = 0; index < localRing.length; index += 1) {
    const p1 = localRing[index] as [number, number]
    const p2 = localRing[(index + 1) % localRing.length] as [number, number]
    const dx = p2[0] - p1[0]
    const dy = p2[1] - p1[1]
    const normal: [number, number] = counterClockwise ? [-dy, dx] : [dy, -dx]
    const fa = normal[0] * (localA[0] - p1[0]) + normal[1] * (localA[1] - p1[1])
    const fb = normal[0] * (localB[0] - p1[0]) + normal[1] * (localB[1] - p1[1])
    const delta = fb - fa
    if (delta === 0) {
      if (fa < 0) return null
      continue
    }
    const t = -fa / delta
    if (delta > 0) {
      if (t > t0) t0 = t
    } else if (t < t1) {
      t1 = t
    }
    if (t0 > t1) return null
  }

  const start: [number, number] = [
    localA[0] + t0 * (localB[0] - localA[0]),
    localA[1] + t0 * (localB[1] - localA[1]),
  ]
  const end: [number, number] = [
    localA[0] + t1 * (localB[0] - localA[0]),
    localA[1] + t1 * (localB[1] - localA[1]),
  ]
  return [projection.toLonLat(start[0], start[1]), projection.toLonLat(end[0], end[1])]
}

/** 折线被凸多边形裁剪后的若干段。 */
export function clipPolylineToConvexPolygon(coords: LonLat[], ring: LonLat[]): LonLat[][] {
  const parts: LonLat[][] = []
  let current: LonLat[] = []
  for (let index = 1; index < coords.length; index += 1) {
    const clipped = clipSegmentToConvexPolygon(
      coords[index - 1] as LonLat,
      coords[index] as LonLat,
      ring,
    )
    if (!clipped) {
      if (current.length > 1) parts.push(current)
      current = []
      continue
    }
    const [start, end] = clipped
    const last = current[current.length - 1]
    if (!last || haversineMeters(last, start) > 1) {
      if (current.length > 1) parts.push(current)
      current = [start, end]
    } else {
      current.push(end)
    }
  }
  if (current.length > 1) parts.push(current)
  return parts
}

/**
 * 折线落在若干**互不重叠**的凸多边形内的长度之和（米）。
 * 多边形重叠时会重复计数，调用方须保证不重叠——示例影响范围已按此约束设计，
 * 并由 `tests/unit/demo-package.spec.ts` 校验。
 */
export function clippedLengthMeters(coords: LonLat[], rings: LonLat[][]): number {
  let total = 0
  for (const ring of rings) {
    for (const part of clipPolylineToConvexPolygon(coords, ring)) {
      total += polylineLengthMeters(part)
    }
  }
  return total
}

/** 折线是否整体落在若干多边形之外（用于“不相交/空结果”示例自检）。 */
export function isPolylineOutsidePolygons(coords: LonLat[], rings: LonLat[][]): boolean {
  for (const ring of rings) {
    if (clipPolylineToConvexPolygon(coords, ring).length > 0) return false
  }
  return true
}
