/**
 * 空间关系判定（阶段3：03 §6-3、§6-4；语义依据 02 §3.1）。
 *
 * 三条口径必须在界面、测试、导出与文档里始终一致：
 *
 * 1. **`within` 是覆盖语义**（02 §3.1）：目标的所有点位于范围内部或边界，不允许任何部分在外。
 *    它与 `intersects` 是两套判定、分别测试——「部分重叠」只算相交，**不算覆盖**。
 *    已有服务若用「严格内部」语义，必须转换后使用，不得直接顶替本函数。
 * 2. **一切距离都是米**：点对点用 WGS84 球面 haversine；点到线段、线段到线段先用局部平面
 *    （米）确定「最近点落在哪里」，再用 haversine 取球面距离。**绝不把经纬度差当米**（02 §2.5）。
 * 3. 判定对**任意多边形（含凹面与内环）**成立，不复用 `geometry.ts` 里「只对凸面精确」的裁切函数；
 *    后者的适用范围写在该文件头，两者不混用。
 *
 * 精度声明（必须随结果一同展示）：定位最近点时用的局部平面在样区尺度（约 250 km）内与球面
 * 差异远小于示例数据本身的坐标精度；最终距离值一律是球面 haversine。
 */
import type { Geometry, Position } from 'geojson'

import {
  bboxOfGeometry,
  classifyPointInGeometry,
  createLocalProjection,
  haversineMeters,
} from './geometry'
import type { Bbox, LonLat } from './types'

/** 边界容差（米）：落在范围边界上按「内部或边界」处理（02 §3.1）。 */
export const BOUNDARY_TOLERANCE_METERS = 1

/**
 * 距离方法与单位的固定说明文案。
 * 02 §3.1 要求「最近邻必须说明限制半径和数量，返回距离单位 m 以及采用的距离方法」，
 * 界面、指标与导出元数据共用同一句话，避免三处写法不一致。
 */
export const DISTANCE_METHOD_TEXT =
  '距离单位米（m）：点对点取 WGS84 球面 haversine；点到线段、线段到线段先用局部平面（米）确定最近点位置，' +
  '再取球面 haversine 距离。不使用经纬度差充当米。'

/** 空间关系判定的统一谓词文案（与 02 §3.1 的四个取值一一对应）。 */
export const SPATIAL_PREDICATE_TEXT = {
  intersects: '相交：目标与范围有任一公共部分（含边界相触）',
  within: '覆盖：目标的所有点位于范围内部或边界，不允许任何部分在外',
  bufferIntersects: '对象缓冲：以选定对象为中心按半径做等距缓冲，落在缓冲内即命中',
  nearest: '最近邻：在限制半径内按距离升序取前 N 条，超出半径不返回',
} as const

/* ------------------------------------------------------------------ *
 * 几何拆解
 * ------------------------------------------------------------------ */

function isPosition(value: unknown): value is Position {
  return (
    Array.isArray(value) &&
    value.length >= 2 &&
    typeof value[0] === 'number' &&
    typeof value[1] === 'number'
  )
}

function asLonLat(position: Position): LonLat {
  return [position[0] as number, position[1] as number]
}

/** 面的全部环（外环 + 内环）；非面几何返回空数组。 */
export function ringsOf(geometry: Geometry | null): LonLat[][] {
  if (!geometry) return []
  switch (geometry.type) {
    case 'Polygon':
      return geometry.coordinates.map((ring) => ring.filter(isPosition).map(asLonLat))
    case 'MultiPolygon':
      return geometry.coordinates.flatMap((polygon) =>
        polygon.map((ring) => ring.filter(isPosition).map(asLonLat)),
      )
    case 'GeometryCollection':
      return geometry.geometries.flatMap((item) => ringsOf(item))
    default:
      return []
  }
}

/** 全部顶点坐标（点、线、面、多部件、集合）。 */
export function verticesOf(geometry: Geometry | null): LonLat[] {
  if (!geometry) return []
  switch (geometry.type) {
    case 'Point':
      return isPosition(geometry.coordinates) ? [asLonLat(geometry.coordinates)] : []
    case 'MultiPoint':
    case 'LineString':
      return geometry.coordinates.filter(isPosition).map(asLonLat)
    case 'MultiLineString':
    case 'Polygon':
      return geometry.coordinates.flatMap((ring) => ring.filter(isPosition).map(asLonLat))
    case 'MultiPolygon':
      return geometry.coordinates.flatMap((polygon) =>
        polygon.flatMap((ring) => ring.filter(isPosition).map(asLonLat)),
      )
    case 'GeometryCollection':
      return geometry.geometries.flatMap((item) => verticesOf(item))
  }
}

/** 仅点几何的顶点（Point / MultiPoint）：它们没有线段，距离要单独按点对点算。 */
function pointVerticesOf(geometry: Geometry | null): LonLat[] {
  if (!geometry) return []
  switch (geometry.type) {
    case 'Point':
      return isPosition(geometry.coordinates) ? [asLonLat(geometry.coordinates)] : []
    case 'MultiPoint':
      return geometry.coordinates.filter(isPosition).map(asLonLat)
    case 'GeometryCollection':
      return geometry.geometries.flatMap((item) => pointVerticesOf(item))
    default:
      return []
  }
}

/** 全部线段；点几何返回空数组（点没有线段可拆）。 */
export function segmentsOf(geometry: Geometry | null): Array<[LonLat, LonLat]> {
  if (!geometry) return []
  const result: Array<[LonLat, LonLat]> = []
  const pushRing = (positions: Position[]): void => {
    const ring = positions.filter(isPosition).map(asLonLat)
    for (let index = 1; index < ring.length; index += 1) {
      result.push([ring[index - 1] as LonLat, ring[index] as LonLat])
    }
    if (ring.length >= 3) result.push([ring[ring.length - 1] as LonLat, ring[0] as LonLat])
  }
  switch (geometry.type) {
    case 'LineString':
      pushRing(geometry.coordinates)
      break
    case 'MultiLineString':
    case 'Polygon':
      for (const ring of geometry.coordinates) pushRing(ring)
      break
    case 'MultiPolygon':
      for (const polygon of geometry.coordinates) for (const ring of polygon) pushRing(ring)
      break
    case 'GeometryCollection':
      return geometry.geometries.flatMap((item) => segmentsOf(item))
    default:
      break
  }
  return result
}

/* ------------------------------------------------------------------ *
 * 平面判定
 * ------------------------------------------------------------------ */

type LocalPoint = [number, number]

function projectorFor(a: Bbox | null, b: Bbox | null) {
  const west = Math.min(a?.[0] ?? 0, b?.[0] ?? 0)
  const south = Math.min(a?.[1] ?? 0, b?.[1] ?? 0)
  const east = Math.max(a?.[2] ?? 0, b?.[2] ?? 0)
  const north = Math.max(a?.[3] ?? 0, b?.[3] ?? 0)
  return createLocalProjection([(west + east) / 2, (south + north) / 2])
}

/** 叉积符号：判断 c 相对有向线段 a→b 的左右。 */
function cross(a: LocalPoint, b: LocalPoint, c: LocalPoint): number {
  return (b[0] - a[0]) * (c[1] - a[1]) - (b[1] - a[1]) * (c[0] - a[0])
}

function onSegment(p: LocalPoint, a: LocalPoint, b: LocalPoint): boolean {
  const EPSILON = 1e-9
  if (Math.abs(cross(a, b, p)) > EPSILON) return false
  return (
    p[0] >= Math.min(a[0], b[0]) - EPSILON &&
    p[0] <= Math.max(a[0], b[0]) + EPSILON &&
    p[1] >= Math.min(a[1], b[1]) - EPSILON &&
    p[1] <= Math.max(a[1], b[1]) + EPSILON
  )
}

/**
 * 两线段是否相交。
 * - `strict = false`：接触（端点落在另一段上、共线重叠）也算相交，用于 `intersects`；
 * - `strict = true`：只认严格穿越（两侧严格异号），用于 `within`——
 *   目标若有一段跑到范围外，必然**严格穿越**边界；仅仅贴着边界不算越界。
 */
function segmentsIntersect(
  p1: LonLat,
  p2: LonLat,
  p3: LonLat,
  p4: LonLat,
  project: ReturnType<typeof createLocalProjection>,
  strict: boolean,
): boolean {
  const a = project.toLocal(p1)
  const b = project.toLocal(p2)
  const c = project.toLocal(p3)
  const d = project.toLocal(p4)
  const d1 = cross(c, d, a)
  const d2 = cross(c, d, b)
  const d3 = cross(a, b, c)
  const d4 = cross(a, b, d)
  if (strict) return d1 * d2 < 0 && d3 * d4 < 0
  if (d1 * d2 < 0 && d3 * d4 < 0) return true
  return onSegment(a, c, d) || onSegment(b, c, d) || onSegment(c, a, b) || onSegment(d, a, b)
}

function edgesIntersect(a: Geometry, b: Geometry, strict: boolean): boolean {
  const segmentsA = segmentsOf(a)
  const segmentsB = segmentsOf(b)
  if (segmentsA.length === 0 || segmentsB.length === 0) return false
  const project = projectorFor(bboxOfGeometry(a), bboxOfGeometry(b))
  for (const [p1, p2] of segmentsA) {
    for (const [p3, p4] of segmentsB) {
      if (segmentsIntersect(p1, p2, p3, p4, project, strict)) return true
    }
  }
  return false
}

/** 范围框是否重叠。`toleranceDeg` 为度，用于把边界容差折算进来，避免误杀。 */
function boxesOverlap(a: Bbox | null, b: Bbox | null, toleranceDeg: number): boolean {
  if (!a || !b) return false
  return !(
    a[2] + toleranceDeg < b[0] ||
    b[2] + toleranceDeg < a[0] ||
    a[3] + toleranceDeg < b[1] ||
    b[3] + toleranceDeg < a[1]
  )
}

/* ------------------------------------------------------------------ *
 * 关系判定
 * ------------------------------------------------------------------ */

/**
 * 相交：目标与范围有任一公共部分（含边界相触）。
 *
 * 三种情形任一成立即为相交：①目标的顶点落在范围内部或边界；②范围的顶点落在目标内部或边界；
 * ③两者的边相交（线与面、面与面可能只靠穿越相交，没有任何顶点落在对方内部）。
 */
export function geometryIntersects(target: Geometry, range: Geometry): boolean {
  if (!boxesOverlap(bboxOfGeometry(target), bboxOfGeometry(range), 0.001)) return false
  for (const point of verticesOf(target)) {
    if (classifyPointInGeometry(point, range, BOUNDARY_TOLERANCE_METERS) !== 'outside') return true
  }
  for (const point of verticesOf(range)) {
    if (classifyPointInGeometry(point, target, BOUNDARY_TOLERANCE_METERS) !== 'outside') return true
  }
  return edgesIntersect(target, range, false)
}

/**
 * 覆盖（`within`，02 §3.1）：目标的所有点位于范围内部或边界，不允许任何部分在外。
 *
 * 判定 = 全部顶点在内部或边界 **且** 没有任何边严格穿越范围边界。
 * 后者不可省：凹多边形范围内的折线可能所有顶点都在内部、中间却从缺口穿出去了。
 */
export function geometryWithin(target: Geometry, range: Geometry): boolean {
  const vertices = verticesOf(target)
  if (vertices.length === 0) return false
  for (const point of vertices) {
    if (classifyPointInGeometry(point, range, BOUNDARY_TOLERANCE_METERS) === 'outside') return false
  }
  return !edgesIntersect(target, range, true)
}

/* ------------------------------------------------------------------ *
 * 米制距离
 * ------------------------------------------------------------------ */

/**
 * 点到线段的最短距离（米）。
 * 最近点的位置由局部平面（米）确定，距离值由 haversine 在球面上取。
 */
export function pointToSegmentMeters(point: LonLat, a: LonLat, b: LonLat): number {
  const project = createLocalProjection(point)
  const localPoint = project.toLocal(point)
  const localA = project.toLocal(a)
  const localB = project.toLocal(b)
  const dx = localB[0] - localA[0]
  const dy = localB[1] - localA[1]
  const lengthSquared = dx * dx + dy * dy
  let t = 0
  if (lengthSquared > 0) {
    t = ((localPoint[0] - localA[0]) * dx + (localPoint[1] - localA[1]) * dy) / lengthSquared
    t = Math.min(1, Math.max(0, t))
  }
  const foot = project.toLonLat(localA[0] + t * dx, localA[1] + t * dy)
  return haversineMeters(point, foot)
}

/**
 * 两个几何之间的最短距离（米）。相交（含边界相触）时为 0。
 *
 * 线段到线段不需要逐点逼近：两段若不交，最短距离必在某一端点处取得，
 * 因此取四个「端点到另一段」的距离即可，与遍历采样结果一致且稳定。
 */
export function distanceMeters(target: Geometry, range: Geometry): number {
  if (geometryIntersects(target, range)) return 0
  const pointsA = pointVerticesOf(target)
  const pointsB = pointVerticesOf(range)
  const segmentsA = segmentsOf(target)
  const segmentsB = segmentsOf(range)
  let best = Number.POSITIVE_INFINITY

  for (const a of pointsA) {
    for (const b of pointsB) best = Math.min(best, haversineMeters(a, b))
    for (const [start, end] of segmentsB) {
      best = Math.min(best, pointToSegmentMeters(a, start, end))
    }
  }
  for (const b of pointsB) {
    for (const [start, end] of segmentsA) {
      best = Math.min(best, pointToSegmentMeters(b, start, end))
    }
  }
  for (const [a1, a2] of segmentsA) {
    for (const [b1, b2] of segmentsB) {
      best = Math.min(best, pointToSegmentMeters(a1, b1, b2), pointToSegmentMeters(a2, b1, b2))
    }
  }
  return best
}

/**
 * 对象缓冲相交：以 `center` 为中心、`radiusMeters` 为半径做等距缓冲，目标落在其内即命中。
 * 半径为 0 时退化为相交判定（02 §3.1 的 `bufferIntersects`）。
 */
export function bufferIntersects(
  target: Geometry,
  center: Geometry,
  radiusMeters: number,
): boolean {
  if (!Number.isFinite(radiusMeters) || radiusMeters < 0) return false
  return distanceMeters(target, center) <= radiusMeters
}

/** 最近邻结果：距离单位米，按距离升序；已排除无几何记录（无几何无从计算距离）。 */
export interface NearestMatch<T> {
  item: T
  distanceMeters: number
}

/**
 * 最近邻：在 `radiusMeters` 限制半径内取距离最近的 `limit` 条。
 *
 * 02 §3.1 要求「限制半径和数量」必须说明，因此两个参数都是**必填且必须为正**；
 * 调用方（仓储层）负责校验，本函数只做计算。超出半径的记录不返回——
 * 这与「返回最近的 N 条」不同：没有半径限制的「最近 N 条」会在无邻近对象时
 * 悄悄返回很远的对象，那不是最近邻。
 */
export function nearestByDistance<T>(
  items: T[],
  distanceOf: (item: T) => number | null,
  radiusMeters: number,
  limit: number,
): NearestMatch<T>[] {
  const matched: NearestMatch<T>[] = []
  for (const item of items) {
    const distance = distanceOf(item)
    if (distance === null || !Number.isFinite(distance)) continue
    if (distance > radiusMeters) continue
    matched.push({ item, distanceMeters: distance })
  }
  matched.sort((a, b) => a.distanceMeters - b.distanceMeters)
  return matched.slice(0, Math.max(0, Math.floor(limit)))
}
