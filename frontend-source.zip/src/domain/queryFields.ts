/**
 * 查询条件生成（阶段3：03 §6-1「根据 fields 生成文本、分类、数值、日期和空值条件，
 * 隐藏不可查询字段」）。
 *
 * 三条约束：
 * 1. **条件入口完全由注册表的 `FieldDefinition` 驱动**：只有 `filterable === true` 的字段
 *    才会出现条件入口，其余字段在界面上被隐藏并把隐藏条数写在页面上，
 *    不允许前端凭字段名猜条件，也不允许把不可查询字段悄悄放进去。
 * 2. 排序入口同理只用 `sortable === true` 的字段。
 * 3. 每个条件都能变成一句中文摘要（`describeCondition`），界面、导出元数据与测试
 *    共用同一份文案，避免「界面这么写、导出那么写」。
 */
import type {
  AttributeFilter,
  DictionaryItem,
  FieldDefinition,
  FilterOperator,
  LayerDefinition,
} from './types'
import { NOT_PROVIDED_TEXT } from './format'

/** 数值条件的比较方式。 */
export type NumberOperator = 'eq' | 'gte' | 'lte' | 'between'

/**
 * 一条界面条件。按字段类型区分形态，而不是用一个「万能值 + 运算符」——
 * 这样数值区间、枚举多选、空值判定各自的取值都有确定的位置，不会拼出畸形条件。
 */
export type FieldCondition =
  | { field: string; kind: 'text'; text: string }
  | { field: string; kind: 'enum'; codes: string[] }
  | { field: string; kind: 'number'; operator: NumberOperator; min: string; max: string }
  | { field: string; kind: 'date'; from: string; to: string }
  | { field: string; kind: 'boolean'; value: boolean }
  | { field: string; kind: 'isNull' }

export const NUMBER_OPERATOR_LABEL: Record<NumberOperator, string> = {
  eq: '等于',
  gte: '大于等于',
  lte: '小于等于',
  between: '介于',
}

export const FILTER_OPERATOR_LABEL: Record<FilterOperator, string> = {
  eq: '等于',
  in: '属于',
  containsText: '包含',
  gte: '大于等于',
  lte: '小于等于',
  between: '介于',
  isNull: '为空',
}

/* ------------------------------------------------------------------ *
 * 字段可用性
 * ------------------------------------------------------------------ */

/** 可以生成条件入口的字段（注册表声明 `filterable`）。 */
export function filterableFields(layer: LayerDefinition | null): FieldDefinition[] {
  if (!layer) return []
  return layer.fields.filter((field) => field.filterable)
}

/** 可以排序的字段（注册表声明 `sortable`）。 */
export function sortableFields(layer: LayerDefinition | null): FieldDefinition[] {
  if (!layer) return []
  return layer.fields.filter((field) => field.sortable)
}

/**
 * 被隐藏的字段说明。不可查询字段不是「前端不支持」，而是**数据包未声明其可查询**，
 * 因此这里如实说明条数与原因，不提供入口也不假装能查。
 */
export function hiddenFieldNote(layer: LayerDefinition | null): string | null {
  if (!layer) return null
  const hidden = layer.fields.length - filterableFields(layer).length
  if (hidden <= 0) return null
  return `另有 ${hidden} 个字段未在数据包中声明可查询，本页不提供其条件入口（01 §5.1：能力由数据包声明，不由前端推测）。`
}

/** 该字段的形态，用于选择条件控件。 */
export function conditionKindOf(field: FieldDefinition): FieldCondition['kind'] {
  if (field.type === 'enum') return 'enum'
  if (field.type === 'number') return 'number'
  if (field.type === 'date') return 'date'
  if (field.type === 'boolean') return 'boolean'
  return 'text'
}

/** 按字段类型新建一个空条件。 */
export function emptyCondition(field: FieldDefinition): FieldCondition {
  switch (field.type) {
    case 'enum':
      return { field: field.key, kind: 'enum', codes: [] }
    case 'number':
      return { field: field.key, kind: 'number', operator: 'gte', min: '', max: '' }
    case 'date':
      return { field: field.key, kind: 'date', from: '', to: '' }
    case 'boolean':
      return { field: field.key, kind: 'boolean', value: true }
    default:
      return { field: field.key, kind: 'text', text: '' }
  }
}

/** 该字段支持的比较方式（数值与日期支持区间，其余不支持）。 */
export function numberOperatorsOf(field: FieldDefinition): NumberOperator[] {
  if (field.type !== 'number') return []
  return ['gte', 'lte', 'between', 'eq']
}

/* ------------------------------------------------------------------ *
 * 条件 → 契约 / 条件 → 文案
 * ------------------------------------------------------------------ */

function toNumber(text: string): number | null {
  const trimmed = text.trim()
  if (trimmed === '') return null
  const value = Number(trimmed)
  return Number.isFinite(value) ? value : null
}

/**
 * 界面条件 → 契约 `AttributeFilter`。
 *
 * 条件不完整（空文本、非法数值、未选枚举）时返回 `null`，由调用方剔除；
 * 绝不把半截条件发给接口，也**不把空字符串当成 0**（02 §2.3）。
 */
export function toAttributeFilter(condition: FieldCondition): AttributeFilter | null {
  switch (condition.kind) {
    case 'text': {
      const text = condition.text.trim()
      return text === '' ? null : { field: condition.field, operator: 'containsText', value: text }
    }
    case 'enum':
      return condition.codes.length === 0
        ? null
        : { field: condition.field, operator: 'in', value: [...condition.codes] }
    case 'number': {
      const min = toNumber(condition.min)
      const max = toNumber(condition.max)
      if (condition.operator === 'between') {
        if (min === null || max === null) return null
        return { field: condition.field, operator: 'between', value: [min, max] }
      }
      if (min === null) return null
      return { field: condition.field, operator: condition.operator, value: min }
    }
    case 'date': {
      const from = condition.from.trim()
      const to = condition.to.trim()
      if (from !== '' && to !== '') {
        return { field: condition.field, operator: 'between', value: [from, to] }
      }
      if (from !== '') return { field: condition.field, operator: 'gte', value: from }
      if (to !== '') return { field: condition.field, operator: 'lte', value: to }
      return null
    }
    case 'boolean':
      return { field: condition.field, operator: 'eq', value: condition.value }
    case 'isNull':
      return { field: condition.field, operator: 'isNull' }
  }
}

/** 批量转换并剔除不完整条件。 */
export function toAttributeFilters(conditions: FieldCondition[]): AttributeFilter[] {
  const result: AttributeFilter[] = []
  for (const condition of conditions) {
    const filter = toAttributeFilter(condition)
    if (filter !== null) result.push(filter)
  }
  return result
}

/** 条件是否「填了一半」：用于在运行前提示用户，而不是静默忽略。 */
export function isPartialCondition(condition: FieldCondition): boolean {
  if (condition.kind === 'number' && condition.operator === 'between') {
    const min = condition.min.trim()
    const max = condition.max.trim()
    return (min === '') !== (max === '')
  }
  return false
}

/**
 * 代码字典：以 dictionaryId 为键、值为该字典的条目数组。
 * 与 `FeatureDetailPanel` 等组件使用的形状一致，避免同一份字典在页面里有两套结构。
 */
export type DictionaryMap = Record<string, DictionaryItem[]>

/** 字典条目数组 → code → label 映射；供需要「标签表」的格式化函数使用。 */
export function dictionaryLabels(items: DictionaryItem[]): Record<string, string> {
  const result: Record<string, string> = {}
  for (const item of items) result[item.code] = item.label
  return result
}

function labelOfCode(items: DictionaryItem[] | undefined, code: string): string | undefined {
  return items?.find((item) => item.code === code)?.label
}

function unitSuffix(field: FieldDefinition): string {
  return field.unit === null ? '' : ` ${field.unit}`
}

/**
 * 条件的中文摘要。`dictionaries` 以 dictionaryId 为键，值为 code → label。
 * 与导出元数据共用，保证「界面看到的」就是「导出里写的」。
 */
export function describeCondition(
  condition: FieldCondition,
  field: FieldDefinition,
  dictionaries: DictionaryMap = {},
): string {
  const items = field.dictionaryId === undefined ? undefined : dictionaries[field.dictionaryId]
  const name = field.label
  switch (condition.kind) {
    case 'text':
      return `${name} 包含「${condition.text.trim()}」`
    case 'enum': {
      const text = condition.codes
        .map((code) => {
          const label = labelOfCode(items, code)
          return label === undefined ? code : `${label}（${code}）`
        })
        .join('、')
      return `${name} 属于 ${text}`
    }
    case 'number': {
      const unit = unitSuffix(field)
      const min = condition.min.trim()
      const max = condition.max.trim()
      if (condition.operator === 'between') return `${name} 介于 ${min} — ${max}${unit}`
      return `${name} ${NUMBER_OPERATOR_LABEL[condition.operator]} ${min}${unit}`
    }
    case 'date': {
      const from = condition.from.trim()
      const to = condition.to.trim()
      if (from !== '' && to !== '') return `${name} 介于 ${from} — ${to}`
      if (from !== '') return `${name} 不早于 ${from}`
      if (to !== '') return `${name} 不晚于 ${to}`
      return `${name} 未填区间`
    }
    case 'boolean':
      return `${name} 为${condition.value ? '是' : '否'}`
    case 'isNull':
      return `${name} 为空（${NOT_PROVIDED_TEXT}）`
  }
}

/** 一组条件的摘要；空数组时给出「无条件」的明确说法。 */
export function describeConditions(
  conditions: FieldCondition[],
  layer: LayerDefinition | null,
  dictionaries: DictionaryMap = {},
): string[] {
  if (!layer) return []
  const result: string[] = []
  for (const condition of conditions) {
    const field = layer.fields.find((item) => item.key === condition.field)
    if (!field) continue
    const filter = toAttributeFilter(condition)
    if (filter === null) continue
    result.push(describeCondition(condition, field, dictionaries))
  }
  return result
}
