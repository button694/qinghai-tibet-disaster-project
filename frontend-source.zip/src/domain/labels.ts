/**
 * 枚举到中文标签的唯一映射。
 *
 * 页面与导出都从这里取标签，避免同一枚举在不同文件出现不同说法
 * （例如 `api` 时而叫“正式接口”时而叫“生产数据”）。
 */
import type {
  AccessLevel,
  DatasetStatus,
  DataMode,
  GeometryFamily,
  ImportLog,
  LegendKind,
  RegionLevel,
  ResultKind,
  ResultSourceType,
  RouteRole,
  RouteStatus,
  Theme,
} from './types'

export const DATA_MODE_LABEL: Record<DataMode, string> = {
  mock: '示例数据',
  snapshot: '已发布成果',
  api: '数据已同步',
}

export const DATA_MODE_DESCRIPTION: Record<DataMode, string> = {
  mock: '当前展示演示数据，用于了解平台功能，不作为实际结论。',
  snapshot: '当前展示已发布的成果数据。',
  api: '当前展示项目已发布的成果数据。',
}

export const THEME_LABEL: Record<Theme, string> = {
  base: '基础地理',
  tnr: '地形与冰冻圈',
  hazard: '灾害与情景',
  emg: '承灾体与应急',
  result: '风险成果',
  sys: '系统元数据',
}

export const RESULT_KIND_LABEL: Record<ResultKind, string> = {
  risk: '风险评估成果',
  exposure: '承灾体暴露成果',
  emergency: '应急路线成果',
}

export const RESULT_SOURCE_TYPE_LABEL: Record<ResultSourceType, string> = {
  projectAnalysis: '本项目分析成果',
  externalScenario: '外部来源情景',
}

export const DATASET_STATUS_LABEL: Record<DatasetStatus, string> = {
  registered: '已登记',
  published: '已发布',
  archived: '已归档',
}

export const ACCESS_LEVEL_LABEL: Record<AccessLevel, string> = {
  public: '公开',
  internal: '内部',
  restricted: '受限',
}

export const ROUTE_ROLE_LABEL: Record<RouteRole, string> = {
  primary: '主方案',
  alternative: '备选',
  unregistered: '角色未登记',
}

export const ROUTE_STATUS_LABEL: Record<RouteStatus, string> = {
  reachable: '可达',
  unreachable: '无可达路径',
}

export const REGION_LEVEL_LABEL: Record<RegionLevel, string> = {
  country: '国家',
  province: '省级',
  city: '市级',
  county: '县级',
  basin: '流域',
}

export const IMPORT_STATUS_LABEL: Record<ImportLog['status'], string> = {
  succeeded: '成功',
  failed: '失败',
  running: '进行中',
  unknown: '状态未知',
}

export const GEOMETRY_FAMILY_LABEL: Record<GeometryFamily, string> = {
  Point: '点',
  LineString: '线',
  Polygon: '面',
  Raster: '栅格',
  Table: '表',
}

/** 图例种类（阶段2 地图图例使用）。 */
export const LEGEND_KIND_LABEL: Record<LegendKind, string> = {
  classified: '分级图例',
  continuous: '连续图例',
  categorical: '分类图例',
}
