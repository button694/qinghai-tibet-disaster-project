/**
 * 阶段6：成果中心状态（Pinia）。
 *
 * - 列表：类型/状态筛选 + 分页；筛选变化页码回 1。
 * - 详情：按 resultId 装载（深链接刷新安全），含已存要素与范围框。
 *
 * 竞态防护与失败处理同 exposure store；失败清空旧结果，不回退示例数据。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import type { ResultKind, ResultStatus } from '@/domain/types'
import {
  getResultsCenterService,
  type ResultCenterDetail,
  type ResultsCenterService,
} from '@/services/resultsCenter'
import type { ResultSummary } from '@/domain/types'
import { toRepositoryError, type RepositoryError } from '@/repositories/types'

export type ResultsStatus = 'idle' | 'loading' | 'ready' | 'failed'

export const useResultsStore = defineStore('results', () => {
  /* ------------------------------ 列表 ------------------------------ */
  const rows = ref<ResultSummary[]>([])
  const total = ref(0)
  const page = ref(1)
  const pageSize = ref(20)
  const kindFilter = ref<ResultKind | null>(null)
  const statusFilter = ref<ResultStatus | null>(null)

  const listStatus = ref<ResultsStatus>('idle')
  const listError = ref<RepositoryError | null>(null)

  /* ------------------------------ 详情 ------------------------------ */
  const detail = ref<ResultCenterDetail | null>(null)
  const detailStatus = ref<ResultsStatus>('idle')
  const detailError = ref<RepositoryError | null>(null)

  let listToken = 0
  let detailToken = 0

  const service = (): ResultsCenterService => getResultsCenterService()

  const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize.value)))
  const hasActiveFilters = computed(() => kindFilter.value !== null || statusFilter.value !== null)

  function reset(): void {
    rows.value = []
    total.value = 0
    page.value = 1
    kindFilter.value = null
    statusFilter.value = null
    listStatus.value = 'idle'
    listError.value = null
    detail.value = null
    detailStatus.value = 'idle'
    detailError.value = null
  }

  async function loadList(targetPage?: number): Promise<void> {
    if (targetPage !== undefined) page.value = targetPage
    const token = ++listToken
    listStatus.value = 'loading'
    listError.value = null
    try {
      const items = await service().listResults({
        kind: kindFilter.value ?? undefined,
        status: statusFilter.value ?? undefined,
        page: page.value,
        pageSize: pageSize.value,
      })
      if (token !== listToken) return
      rows.value = items
      total.value = items.length
      listStatus.value = 'ready'
    } catch (error) {
      if (token !== listToken) return
      listStatus.value = 'failed'
      listError.value = toRepositoryError(error)
      rows.value = []
      total.value = 0
    }
  }

  function setKind(kind: ResultKind | null): void {
    kindFilter.value = kind
    void loadList(1)
  }

  function setStatus(status: ResultStatus | null): void {
    statusFilter.value = status
    void loadList(1)
  }

  function clearFilters(): void {
    kindFilter.value = null
    statusFilter.value = null
    void loadList(1)
  }

  function goToPage(target: number): void {
    if (target < 1 || target > totalPages.value || target === page.value) return
    void loadList(target)
  }

  /** 详情：resultId 由路由参数给出；深链接刷新时同样调用。 */
  async function loadDetail(resultId: string): Promise<void> {
    const token = ++detailToken
    detailStatus.value = 'loading'
    detailError.value = null
    detail.value = null
    try {
      const next = await service().getResultDetail(resultId)
      if (token !== detailToken) return
      detail.value = next
      detailStatus.value = 'ready'
    } catch (error) {
      if (token !== detailToken) return
      detailStatus.value = 'failed'
      detailError.value = toRepositoryError(error)
      detail.value = null
    }
  }

  return {
    rows,
    total,
    page,
    pageSize,
    kindFilter,
    statusFilter,
    listStatus,
    listError,
    detail,
    detailStatus,
    detailError,
    totalPages,
    hasActiveFilters,
    reset,
    loadList,
    setKind,
    setStatus,
    clearFilters,
    goToPage,
    loadDetail,
  }
})
