/**
 * 阶段5：应急保障工作台状态（Pinia）。
 *
 * 上下文链路：`?resultId=...`（从暴露页「查看应急方案」或成果入口进入）；
 * 未带 resultId 时取应急类成果清单第一个。
 *
 * 方案切换纪律（03 §8-4、§8-5）：
 * - 切换 A/B/C 时**先清空旧详情与旧选中**再装载，地图与指标不残留上一方案的状态；
 * - `routeRecompute` 未接入：blockedFeatureRefs 只作为既有方案的条件说明展示，
 *   条件输入一律只读；本页不提供「按新条件重算」的入口，也就不存在冒用旧结果的问题。
 *
 * 失败处理：路线清单/详情失败显示错误与重试，不回退示例数据；失败清空旧结果。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import type {
  FeatureDetail,
  FeatureRef,
  ResultDetail,
  ResultSummary,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import {
  getEmergencyWorkspaceService,
  type EmergencyWorkspaceService,
} from '@/services/emergencyWorkspace'
import { RepositoryError, toRepositoryError } from '@/repositories/types'

export type EmergencyStatus = 'idle' | 'loading' | 'ready' | 'failed'

export interface EmergencyQuery {
  resultId?: string | null
  routeId?: string | null
}

export const useEmergencyStore = defineStore('emergency', () => {
  const results = ref<ResultSummary[]>([])
  const resultId = ref<string | null>(null)
  const result = ref<ResultDetail | null>(null)

  const routes = ref<RouteSummary[]>([])
  const allRoutes = ref<RouteSummary[]>([])
  const allRoutesTotal = ref(0)
  const allRoutesPage = ref(1)
  const allRoutesPageSize = 20
  const allRoutesStatus = ref<EmergencyStatus>('idle')
  const allRoutesError = ref<RepositoryError | null>(null)
  const selectedRouteId = ref<string | null>(null)
  const routeDetail = ref<RouteDetail | null>(null)

  /**
   * 当前方案风险段 / 阻断点引用的要素（真实关联取数，供地图标记）。
   * 与路线详情同生命周期：切换方案时一并清空。
   */
  const markedFeatures = ref<FeatureDetail[]>([])

  const listStatus = ref<EmergencyStatus>('idle')
  const routesStatus = ref<EmergencyStatus>('idle')
  const detailStatus = ref<EmergencyStatus>('idle')
  const listError = ref<RepositoryError | null>(null)
  const routesError = ref<RepositoryError | null>(null)
  const detailError = ref<RepositoryError | null>(null)

  /** 深链接指定的路线及其库内危险源分组键；重试时必须保留，不能静默回到默认方案。 */
  const requestedRouteId = ref<string | null>(null)
  const requestedHazardPointId = ref<string | null>(null)

  let listToken = 0
  let routesToken = 0
  let allRoutesToken = 0
  let detailToken = 0

  const service = (): EmergencyWorkspaceService => getEmergencyWorkspaceService()

  /* ------------------------------ 派生 ------------------------------ */

  const selectedRoute = computed<RouteSummary | null>(
    () => routes.value.find((route) => route.id === selectedRouteId.value) ?? null,
  )

  /** 主方案（primary）与备选方案（alternative），用于方案切换的展示顺序。 */
  const primaryRoutes = computed(() => routes.value.filter((route) => route.role === 'primary'))
  const alternativeRoutes = computed(() =>
    routes.value.filter((route) => route.role === 'alternative'),
  )

  const routeCount = computed(() => routes.value.length)
  const allRoutesTotalPages = computed(() =>
    Math.max(1, Math.ceil(allRoutesTotal.value / allRoutesPageSize)),
  )
  const unreachableCount = computed(
    () => routes.value.filter((route) => route.status === 'unreachable').length,
  )

  /* ------------------------------ 动作 ------------------------------ */

  function reset(): void {
    ++listToken
    ++routesToken
    ++allRoutesToken
    ++detailToken
    results.value = []
    resultId.value = null
    result.value = null
    routes.value = []
    allRoutes.value = []
    allRoutesTotal.value = 0
    allRoutesPage.value = 1
    allRoutesStatus.value = 'idle'
    allRoutesError.value = null
    selectedRouteId.value = null
    routeDetail.value = null
    markedFeatures.value = []
    listStatus.value = 'idle'
    routesStatus.value = 'idle'
    detailStatus.value = 'idle'
    listError.value = null
    routesError.value = null
    detailError.value = null
    requestedRouteId.value = null
    requestedHazardPointId.value = null
  }

  /** 从路由查询进入；深链接可直接携带 routeId 选中方案。 */
  async function initFromQuery(query: EmergencyQuery): Promise<void> {
    reset()

    // 先按深链接中的 routeId 读取真实详情，拿到同一危险源的 HAZARD_POINT_ID；
    // 不得先取默认组再把指定 routeId 静默替换成第一页方案。
    let requestedRoute: RouteDetail | null = null
    if (query.routeId !== null && query.routeId !== undefined && query.routeId !== '') {
      requestedRouteId.value = query.routeId
      try {
        requestedRoute = await service().getRoute(query.routeId)
        requestedHazardPointId.value = requestedRoute.hazardPointId
      } catch (error) {
        listStatus.value = 'failed'
        listError.value = toRepositoryError(error)
        return
      }
    }

    await loadResultList()
    // 清单请求失败时必须停在真实错误态；不能把失败的空结果继续解释成“清单为空”，
    // 否则 HTTP 501 会被覆盖成 NOT_FOUND。
    if (listStatus.value === 'failed') return
    const wanted =
      query.resultId !== null && query.resultId !== undefined && query.resultId !== ''
        ? query.resultId
        : (requestedRoute?.resultId ?? results.value[0]?.id ?? null)
    if (wanted === null) {
      listStatus.value = 'failed'
      listError.value = new RepositoryError({
        code: 'NOT_FOUND',
        message: '应急类成果清单为空。',
        userMessage: '没有可用的应急类成果（清单为空）。',
      })
      return
    }
    if (requestedRoute !== null && requestedRoute.resultId !== wanted) {
      listStatus.value = 'failed'
      listError.value = new RepositoryError({
        code: 'NOT_FOUND',
        message: `指定路线 ${requestedRoute.id} 不属于成果 ${wanted}。`,
        userMessage: '指定路线与成果不匹配，未静默切换到其它路线。',
        details: { routeId: requestedRoute.id, resultId: wanted },
      })
      return
    }
    resultId.value = wanted
    await loadRoutes()
    // 深链接指定路线必须出现在同一 HAZARD_POINT_ID 分组中；缺失时显示 NOT_FOUND，
    // 不能把其它危险源的第一条路线当成指定路线。
    if (
      requestedRouteId.value !== null &&
      !routes.value.some((item) => item.id === requestedRouteId.value)
    ) {
      routesStatus.value = 'failed'
      routesError.value = new RepositoryError({
        code: 'NOT_FOUND',
        message: `指定路线 ${requestedRouteId.value} 不在当前危险源方案组中。`,
        userMessage: '未找到指定路线的同组方案，未静默切换到其它危险源。',
        details: {
          routeId: requestedRouteId.value,
          resultId: wanted,
          hazardPointId: requestedHazardPointId.value,
        },
      })
      routes.value = []
      return
    }
    const initial = requestedRouteId.value ?? routes.value[0]?.id ?? null
    if (initial !== null) await selectRoute(initial)
  }

  async function loadResultList(): Promise<void> {
    const token = ++listToken
    listStatus.value = 'loading'
    listError.value = null
    try {
      const items = await service().listEmergencyResults()
      if (token !== listToken) return
      results.value = items
      listStatus.value = 'ready'
    } catch (error) {
      if (token !== listToken) return
      listStatus.value = 'failed'
      listError.value = toRepositoryError(error)
    }
  }

  async function selectResult(nextResultId: string): Promise<void> {
    if (nextResultId === resultId.value) return
    await initFromQuery({ resultId: nextResultId, routeId: null })
  }

  async function loadRoutes(): Promise<void> {
    const id = resultId.value
    if (id === null) return
    const token = ++routesToken
    routesStatus.value = 'loading'
    routesError.value = null
    try {
      const [items, detail] = await Promise.all([
        service().listRoutes(id, undefined, requestedHazardPointId.value),
        service()
          .getResult(id)
          .catch(() => null),
      ])
      if (token !== routesToken || resultId.value !== id) return
      routes.value = items
      await loadAllRoutesPage(1)
      if (token !== routesToken || resultId.value !== id) return
      if (detail !== null) result.value = detail
      routesStatus.value = 'ready'
    } catch (error) {
      if (token !== routesToken || resultId.value !== id) return
      routesStatus.value = 'failed'
      routesError.value = toRepositoryError(error)
      routes.value = []
    }
  }

  async function loadAllRoutesPage(page: number): Promise<void> {
    const id = resultId.value
    if (id === null || page < 1) return
    const token = ++allRoutesToken
    allRoutesStatus.value = 'loading'
    allRoutesError.value = null
    try {
      const response = await service().listAllRoutesPage(id, { page, pageSize: allRoutesPageSize })
      if (resultId.value !== id || token !== allRoutesToken) return
      allRoutes.value = response.items
      allRoutesTotal.value = response.total
      allRoutesPage.value = response.page
      allRoutesStatus.value = 'ready'
    } catch (error) {
      if (resultId.value !== id || token !== allRoutesToken) return
      allRoutes.value = []
      allRoutesTotal.value = 0
      allRoutesStatus.value = 'failed'
      allRoutesError.value = toRepositoryError(error)
    }
  }

  /**
   * 选择方案：**先清空旧详情**再装载（03 §8-4「切换同步清空旧状态」）。
   * 同一方案重复点击不重复请求。
   */
  async function selectRoute(routeId: string): Promise<void> {
    if (selectedRouteId.value === routeId && routeDetail.value !== null) return
    selectedRouteId.value = routeId
    // 同步清空旧状态：地图与信息面板立即回到「装载中」，不显示上一方案的路线。
    routeDetail.value = null
    detailError.value = null
    const token = ++detailToken
    detailStatus.value = 'loading'
    try {
      const detail = await service().getRoute(routeId)
      if (detail.hazardPointId !== null && !routes.value.some((item) => item.id === routeId)) {
        const grouped = await service().listRoutes(resultId.value!, undefined, detail.hazardPointId)
        if (token !== detailToken || selectedRouteId.value !== routeId) return
        routes.value = grouped
      }
      if (token !== detailToken || selectedRouteId.value !== routeId) return
      routeDetail.value = detail
      detailStatus.value = 'ready'
      // 风险段/阻断点标记是路线展示的一部分：装载完成前方案不算就绪，
      // 避免「详情已出、地图标记还在飞」的中间态。
      await loadMarkedFeatures(detail)
    } catch (error) {
      if (token !== detailToken || selectedRouteId.value !== routeId) return
      detailStatus.value = 'failed'
      detailError.value = toRepositoryError(error)
      routeDetail.value = null
    }
  }

  /** 读取风险段 / 阻断点引用的要素；单个失败不阻塞其它标记，只少画一个点。 */
  async function loadMarkedFeatures(detail: RouteDetail): Promise<void> {
    const refs: FeatureRef[] = []
    for (const segment of detail.riskSegments) {
      if (segment.ref !== null) refs.push(segment.ref)
    }
    for (const ref of detail.blockedFeatureRefs) refs.push(ref)
    const token = detailToken
    const loaded = await Promise.all(
      refs.map(async (ref) => {
        try {
          return await service().getFeature(ref)
        } catch {
          return null
        }
      }),
    )
    if (token !== detailToken || selectedRouteId.value !== detail.id) return
    markedFeatures.value = loaded.filter((item): item is FeatureDetail => item !== null)
  }

  function retry(): void {
    if (listStatus.value === 'failed' || routesStatus.value === 'failed') {
      void initFromQuery({ resultId: resultId.value, routeId: requestedRouteId.value })
      return
    }
    if (detailStatus.value === 'failed' && selectedRouteId.value !== null) {
      void selectRoute(selectedRouteId.value)
    }
  }

  return {
    results,
    resultId,
    result,
    routes,
    allRoutes,
    allRoutesTotal,
    allRoutesPage,
    allRoutesPageSize,
    allRoutesTotalPages,
    allRoutesStatus,
    allRoutesError,
    selectedRouteId,
    routeDetail,
    markedFeatures,
    listStatus,
    routesStatus,
    detailStatus,
    listError,
    routesError,
    detailError,
    selectedRoute,
    primaryRoutes,
    alternativeRoutes,
    routeCount,
    unreachableCount,
    initFromQuery,
    selectResult,
    selectRoute,
    retry,
    loadAllRoutesPage,
  }
})
