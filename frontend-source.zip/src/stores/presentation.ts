/**
 * 演示模式（阶段7，01 §4.2「投影演示模式正文提升到 16px」）。
 *
 * 进入后给 <html> 加 data-presentation='true'，tokens.css 据此放大正文与说明字号；
 * 组件只精简次要列，不隐藏来源、时间、单位、缺失值与示例身份。
 * 状态仅存于会话内（不持久化），页面刷新即退出——避免「忘记自己在演示模式」。
 */
import { defineStore } from 'pinia'
import { ref } from 'vue'

export const usePresentationStore = defineStore('presentation', () => {
  const active = ref(false)

  function enter(): void {
    active.value = true
    document.documentElement.dataset.presentation = 'true'
  }

  function exit(): void {
    active.value = false
    delete document.documentElement.dataset.presentation
  }

  function toggle(): void {
    if (active.value) exit()
    else enter()
  }

  /** 刷新 / 意外残留时清理（AppShell 卸载时也会调用）。 */
  function reset(): void {
    active.value = false
    delete document.documentElement.dataset.presentation
  }

  return { active, enter, exit, toggle, reset }
})
