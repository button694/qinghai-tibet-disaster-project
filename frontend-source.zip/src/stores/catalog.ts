/**
 * 阶段6：数据目录状态（Pinia）。
 *
 * - 列表：主题/类型/关键词筛选 + 分页；筛选与清除后页码回 1，结果与计数一致。
 * - 详情：按 datasetId 装载（深链接刷新安全）；来源/关联图层/关联成果/降水年份。
 * - 降水年份切换是纯展示状态（availableTimes 派生），不触发请求。
 *
 * 竞态防护与失败处理同 exposure store：递增令牌丢弃旧响应；失败清空旧结果，不回退。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import type { DatasetType, ImportLog, Page, Theme } from '@/domain/types'
import {
  getCatalogWorkspaceService,
  type CatalogDatasetDetail,
  type CatalogDatasetRow,
  type CatalogWorkspaceService,
} from '@/services/catalogWorkspace'

export type CatalogStatus = 'idle' | 'loading' | 'ready' | 'failed'

export interface CatalogListFilters {
  theme: Theme | null
  dataType: DatasetType | null
  keyword: string
}

export const useCatalogStore = defineStore('catalog', () => {
  /* ------------------------------ 列表 ------------------------------ */
  const rows = ref<CatalogDatasetRow[]>([])
  const total = ref(0)
  const page = ref(1)
  const pageSize = ref(20)
  const filters = ref<CatalogListFilters>({ theme: null, dataType: null, keyword: '' })

  const listStatus = ref<CatalogStatus>('idle')
  const listError = ref<string | null>(null)

  /* ------------------------------ 详情 ------------------------------ */
  const detail = ref<CatalogDatasetDetail | null>(null)
  const detailStatus = ref<CatalogStatus>('idle')
  const detailError = ref<string | null>(null)

  /** 降水分册当前年份（详情装载后默认第一个登记年份）。 */
  const selectedPrecipYear = ref<string | null>(null)

  /** 导入登记日志（只读展示，不是完整审计日志）。 */
  const imports = ref<Page<ImportLog> | null>(null)
  const importsStatus = ref<CatalogStatus>('idle')
  const importsError = ref<string | null>(null)

  let listToken = 0
  let detailToken = 0
  let importsToken = 0

  const service = (): CatalogWorkspaceService => getCatalogWorkspaceService()

  const totalPages = computed(() => Math.max(1, Math.ceil(total.value / pageSize.value)))
  const hasActiveFilters = computed(
    () =>
      filters.value.theme !== null ||
      filters.value.dataType !== null ||
      filters.value.keyword.trim() !== '',
  )

  function reset(): void {
    rows.value = []
    total.value = 0
    page.value = 1
    filters.value = { theme: null, dataType: null, keyword: '' }
    listStatus.value = 'idle'
    listError.value = null
    detail.value = null
    detailStatus.value = 'idle'
    detailError.value = null
    selectedPrecipYear.value = null
  }

  async function loadList(targetPage?: number): Promise<void> {
    if (targetPage !== undefined) page.value = targetPage
    const token = ++listToken
    listStatus.value = 'loading'
    listError.value = null
    try {
      const next = await service().listDatasets({
        theme: filters.value.theme ?? undefined,
        dataType: filters.value.dataType ?? undefined,
        keyword: filters.value.keyword.trim() !== '' ? filters.value.keyword.trim() : undefined,
        page: page.value,
        pageSize: pageSize.value,
      })
      if (token !== listToken) return
      rows.value = next.items
      total.value = next.total
      listStatus.value = 'ready'
    } catch (error) {
      if (token !== listToken) return
      listStatus.value = 'failed'
      listError.value = error instanceof Error ? error.message : String(error)
      rows.value = []
      total.value = 0
    }
  }

  function setFilter(patch: Partial<CatalogListFilters>): void {
    filters.value = { ...filters.value, ...patch }
    void loadList(1)
  }

  function clearFilters(): void {
    filters.value = { theme: null, dataType: null, keyword: '' }
    void loadList(1)
  }

  function goToPage(target: number): void {
    if (target < 1 || target > totalPages.value || target === page.value) return
    void loadList(target)
  }

  /** 详情：datasetId 由路由参数给出；深链接刷新时同样调用。 */
  async function loadDetail(datasetId: string): Promise<void> {
    const token = ++detailToken
    detailStatus.value = 'loading'
    detailError.value = null
    detail.value = null
    selectedPrecipYear.value = null
    try {
      const next = await service().getDatasetDetail(datasetId)
      if (token !== detailToken) return
      detail.value = next
      selectedPrecipYear.value = next.precipYears[0] ?? null
      detailStatus.value = 'ready'
    } catch (error) {
      if (token !== detailToken) return
      detailStatus.value = 'failed'
      detailError.value = error instanceof Error ? error.message : String(error)
      detail.value = null
    }
  }

  function selectPrecipYear(year: string): void {
    if (detail.value === null) return
    if (!detail.value.precipYears.includes(year)) return
    selectedPrecipYear.value = year
  }

  async function loadImports(pageNumber = 1): Promise<void> {
    const token = ++importsToken
    importsStatus.value = 'loading'
    importsError.value = null
    try {
      const next = await service().listImports({ page: pageNumber, pageSize: 50 })
      if (token !== importsToken) return
      imports.value = next
      importsStatus.value = 'ready'
    } catch (error) {
      if (token !== importsToken) return
      importsStatus.value = 'failed'
      importsError.value = error instanceof Error ? error.message : String(error)
      imports.value = null
    }
  }

  return {
    rows,
    total,
    page,
    pageSize,
    filters,
    listStatus,
    listError,
    detail,
    detailStatus,
    detailError,
    selectedPrecipYear,
    imports,
    importsStatus,
    importsError,
    totalPages,
    hasActiveFilters,
    reset,
    loadList,
    setFilter,
    clearFilters,
    goToPage,
    loadDetail,
    selectPrecipYear,
    loadImports,
  }
})
