/**
 * 阶段5：暴露度工作台状态（Pinia）。
 *
 * 上下文链路（03 §8-1、§8-7）：
 * - 支持深链接进入：`?resultId=...&hazard=<layerId>:<id>`；
 *   未带 resultId 时取暴露类成果清单的第一个（示例包只有一个，行为可预期）；
 * - `hazard` 查询参数是「从地图危险源点进来」的来源上下文，只用于展示与定位，
 *   危险源与影响范围的真实关联以影响范围记录的 `hazardRefId` 属性为准（摘要的 hazardRef），
 *   不做空间接近猜测。
 *
 * 竞态防护与失败处理同 risk store：递增令牌丢弃旧响应；失败清空旧结果，不回退。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import { featureKey } from '@/domain/format'
import type {
  ExposureSummary,
  FeatureDetail,
  FeatureRef,
  Page,
  ResultDetail,
  ResultSummary,
} from '@/domain/types'
import {
  getExposureWorkspaceService,
  type ExposureWorkspaceService,
} from '@/services/exposureWorkspace'
import { RepositoryError, toRepositoryError } from '@/repositories/types'

export type ExposureStatus = 'idle' | 'loading' | 'ready' | 'failed'

export interface ExposureQuery {
  resultId?: string | null
  hazard?: string | null
}

function parseHazardRef(raw: string | null | undefined): FeatureRef | null {
  if (raw === null || raw === undefined) return null
  const [layerId = '', id = ''] = raw.split(':')
  if (layerId.trim() === '' || id.trim() === '') return null
  return { layerId: layerId.trim(), id: id.trim() }
}

function parseHazardRaw(ref: FeatureRef | null): string | null {
  return ref === null ? null : `${ref.layerId}:${ref.id}`
}

export const useExposureStore = defineStore('exposure', () => {
  /* ------------------------------ 状态 ------------------------------ */
  const results = ref<ResultSummary[]>([])
  const resultId = ref<string | null>(null)
  const result = ref<ResultDetail | null>(null)
  const summary = ref<ExposureSummary | null>(null)

  /** 来源上下文：从地图危险源进入时携带的 FeatureRef（仅展示与定位）。 */
  const entryHazardRef = ref<FeatureRef | null>(null)
  const entryHazardDetail = ref<FeatureDetail | null>(null)

  const category = ref<string | null>(null)
  const page = ref(1)
  const pageSize = ref(20)
  const affectedPage = ref<Page<FeatureDetail> | null>(null)

  /** 已上图的影响范围要素（与统计同一成果）。 */
  const impactAreas = ref<FeatureDetail[]>([])

  /** 从受影响清单/地图选中的对象（含定位）。 */
  const selectedRef = ref<FeatureRef | null>(null)

  const listStatus = ref<ExposureStatus>('idle')
  const summaryStatus = ref<ExposureStatus>('idle')
  const affectedStatus = ref<ExposureStatus>('idle')
  const areasStatus = ref<ExposureStatus>('idle')
  const listError = ref<RepositoryError | null>(null)
  const summaryError = ref<RepositoryError | null>(null)
  const affectedError = ref<RepositoryError | null>(null)
  const areasError = ref<RepositoryError | null>(null)

  let listToken = 0
  let resultToken = 0
  let summaryToken = 0
  let affectedToken = 0
  let areasToken = 0

  const service = (): ExposureWorkspaceService => getExposureWorkspaceService()

  /* ------------------------------ 派生 ------------------------------ */

  const isReady = computed(() => summaryStatus.value === 'ready' && summary.value !== null)
  const hasAnyFailure = computed(
    () =>
      listStatus.value === 'failed' ||
      summaryStatus.value === 'failed' ||
      affectedStatus.value === 'failed' ||
      areasStatus.value === 'failed',
  )
  /** 类别筛选生效后的受影响对象（当前页），与地图同一份。 */
  const affectedRows = computed(() => affectedPage.value?.items ?? [])
  const affectedTotal = computed(() => affectedPage.value?.total ?? 0)
  const categories = computed(() => summary.value?.affectedCategories ?? [])
  const metrics = computed(() => summary.value?.metrics ?? [])
  const hazardRef = computed(() => summary.value?.hazardRef ?? null)

  /** 类别筛选是否生效（与 summary.affectedCategories 的 key 对齐）。 */
  function isCategoryActive(key: string): boolean {
    return category.value === key
  }

  function selectedKey(): string | null {
    const ref = selectedRef.value
    return ref === null ? null : featureKey(ref.layerId, ref.id)
  }

  /* ------------------------------ 动作 ------------------------------ */

  function reset(): void {
    results.value = []
    resultId.value = null
    result.value = null
    summary.value = null
    entryHazardRef.value = null
    entryHazardDetail.value = null
    category.value = null
    page.value = 1
    affectedPage.value = null
    impactAreas.value = []
    selectedRef.value = null
    listStatus.value = 'idle'
    summaryStatus.value = 'idle'
    affectedStatus.value = 'idle'
    areasStatus.value = 'idle'
    listError.value = null
    summaryError.value = null
    affectedError.value = null
    areasError.value = null
  }

  /** 从路由查询进入；深链接测试直接调用本方法。 */
  async function initFromQuery(query: ExposureQuery): Promise<void> {
    reset()
    entryHazardRef.value = parseHazardRef(query.hazard)
    await loadResults()
    // 清单请求失败时必须停在真实错误态；不能把失败的空结果继续解释成“清单为空”，
    // 否则 HTTP 501 会被覆盖成 NOT_FOUND。
    if (listStatus.value === 'failed') return
    // 结果选择优先级：URL 显式指定 > 成果清单第一个。
    const wanted =
      query.resultId !== null && query.resultId !== undefined && query.resultId !== ''
        ? query.resultId
        : (results.value[0]?.id ?? null)
    if (wanted === null) {
      listStatus.value = 'failed'
      listError.value = new RepositoryError({
        code: 'NOT_FOUND',
        message: '暴露类成果清单为空。',
        userMessage: '没有可用的暴露类成果（清单为空）。',
      })
      return
    }
    resultId.value = wanted
    // 影响范围上图的图层 ID 来自摘要/成果详情，因此这两个先完成再上图。
    await Promise.all([loadResult(), loadSummary(), loadAffected(1)])
    await Promise.all([loadImpactAreas(), loadEntryHazard()])
  }

  async function loadResults(): Promise<void> {
    const token = ++listToken
    listStatus.value = 'loading'
    listError.value = null
    try {
      const items = await service().listExposureResults()
      if (token !== listToken) return
      results.value = items
      listStatus.value = 'ready'
    } catch (error) {
      if (token !== listToken) return
      listStatus.value = 'failed'
      listError.value = toRepositoryError(error)
    }
  }

  async function loadResult(): Promise<void> {
    const id = resultId.value
    if (id === null) return
    const token = ++resultToken
    try {
      const detail = await service().getResult(id)
      if (token !== resultToken || resultId.value !== id) return
      result.value = detail
    } catch {
      // 成果详情失败不阻塞统计展示；来源面板会显示缺口。
    }
  }

  async function loadSummary(): Promise<void> {
    const id = resultId.value
    if (id === null) return
    const token = ++summaryToken
    summaryStatus.value = 'loading'
    summaryError.value = null
    try {
      const next = await service().getExposureSummary(id)
      if (token !== summaryToken || resultId.value !== id) return
      summary.value = next
      summaryStatus.value = 'ready'
    } catch (error) {
      if (token !== summaryToken || resultId.value !== id) return
      summaryStatus.value = 'failed'
      summaryError.value = toRepositoryError(error)
      summary.value = null
    }
  }

  async function loadImpactAreas(): Promise<void> {
    const id = resultId.value
    if (id === null) return
    const token = ++areasToken
    areasStatus.value = 'loading'
    areasError.value = null
    try {
      // 影响范围图层 ID 由摘要给出；摘要未就绪时用成果登记的第一个图层。
      const layerId = summary.value?.impactLayerId ?? result.value?.layerIds[0] ?? null
      if (layerId === null) {
        areasStatus.value = 'failed'
        areasError.value = new RepositoryError({
          code: 'INVALID_RESPONSE',
          message: '影响范围图层未登记。',
          userMessage: '影响范围图层未登记，无法上图。',
        })
        return
      }
      const items = await service().listImpactAreas(layerId)
      if (token !== areasToken || resultId.value !== id) return
      impactAreas.value = items
      areasStatus.value = 'ready'
    } catch (error) {
      if (token !== areasToken || resultId.value !== id) return
      areasStatus.value = 'failed'
      areasError.value = toRepositoryError(error)
      impactAreas.value = []
    }
  }

  /** 受影响对象分页；类别筛选变化时页码回 1（与查询页一致）。 */
  async function loadAffected(targetPage?: number): Promise<void> {
    const id = resultId.value
    if (id === null) return
    const token = ++affectedToken
    if (targetPage !== undefined) page.value = targetPage
    affectedStatus.value = 'loading'
    affectedError.value = null
    try {
      const next = await service().listAffectedFeatures(id, {
        category: category.value ?? undefined,
        page: page.value,
        pageSize: pageSize.value,
      })
      if (token !== affectedToken || resultId.value !== id) return
      affectedPage.value = next
      affectedStatus.value = 'ready'
    } catch (error) {
      if (token !== affectedToken || resultId.value !== id) return
      affectedStatus.value = 'failed'
      affectedError.value = toRepositoryError(error)
      affectedPage.value = null
    }
  }

  function setCategory(key: string | null): void {
    if (category.value === key) return
    category.value = key
    void loadAffected(1)
  }

  function clearFilters(): void {
    category.value = null
    selectedRef.value = null
    void loadAffected(1)
  }

  function goToPage(target: number): void {
    void loadAffected(target)
  }

  function select(ref: FeatureRef | null): void {
    selectedRef.value = ref
  }

  /** 重试：只重试失败的部分，成功的部分不清。 */
  function retry(): void {
    if (listStatus.value === 'failed')
      void initFromQuery({ hazard: parseHazardRaw(entryHazardRef.value) })
    if (summaryStatus.value === 'failed') void loadSummary()
    if (areasStatus.value === 'failed') void loadImpactAreas()
    if (affectedStatus.value === 'failed') void loadAffected()
  }

  /** 读取来源危险源对象详情（失败不阻塞主流程）。 */
  async function loadEntryHazard(): Promise<void> {
    const ref = entryHazardRef.value
    if (ref === null) return
    try {
      entryHazardDetail.value = await service().getFeature(ref)
    } catch {
      entryHazardDetail.value = null
    }
  }

  return {
    // 状态
    results,
    resultId,
    result,
    summary,
    entryHazardRef,
    entryHazardDetail,
    category,
    page,
    pageSize,
    affectedPage,
    impactAreas,
    selectedRef,
    listStatus,
    summaryStatus,
    affectedStatus,
    areasStatus,
    listError,
    summaryError,
    affectedError,
    areasError,
    // 派生
    isReady,
    hasAnyFailure,
    affectedRows,
    affectedTotal,
    categories,
    metrics,
    hazardRef,
    // 动作
    initFromQuery,
    setCategory,
    clearFilters,
    goToPage,
    select,
    selectedKey,
    retry,
    isCategoryActive,
    loadAffected,
  }
})
