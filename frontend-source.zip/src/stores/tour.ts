/**
 * 答辩演示导览（阶段7，04 §7 八分钟答辩脚本、03 §10-6）。
 *
 * 固定五步：总览 → 风险 → 应急 → 来源/成果 → 导出。
 * 每步只做页面跳转与讲解要点展示：不随机播放、不修改数据、不含任何写操作。
 * 上一步 / 下一步按固定顺序移动，第一步禁用上一步，最后一步的下一步即「完成并退出」。
 */
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'
import { useRouter, type Router } from 'vue-router'

import type { DataMode } from '@/domain/types'
import { useSessionStore } from '@/stores/session'

export interface TourStep {
  /** 步骤名（面板标题）。 */
  title: string
  /** 一句话讲解要点（不修改页面数据）。 */
  note: string
  /** 目标路由（固定深链接，保证可复现）。 */
  route: { path: string; query?: Record<string, string> }
}

export const TOUR_STEPS: TourStep[] = [
  {
    title: '总览',
    note: '青藏高原范围、四项口径指标与风险分布；数字可在数据目录与成果明细中逐级对账。',
    route: { path: '/overview' },
  },
  {
    title: '风险研判',
    note: '真实 2050/2100 文件快照的同对象对比与统一连续色域；未来情景，不是实时预警。',
    route: { path: '/analysis/risk' },
  },
  {
    title: '应急保障',
    note: '已存方案 A/B/C 切换先清空旧状态；无可达路径专用状态，路线只读不可重算。',
    route: {
      path: '/analysis/emergency',
      query: { resultId: 'result.demo.route', routeId: 'DEMO-ROUTE-B' },
    },
  },
  {
    title: '来源与成果',
    note: '成果的方法、输入数据集与文件可用性；来源可回溯到数据目录。',
    route: { path: '/results/result.demo.risk' },
  },
  {
    title: '导出',
    note: '一张图属性/空间查询结果可导出 CSV/GeoJSON；风险与应急专题图提供打印视图（浏览器打印 PDF）；暴露分析本版未交付。',
    route: { path: '/map' },
  },
]

/**
 * 正式 API 的答辩路径：只引用已经登记并由生产页实际读取的成果。
 *
 * mock/snapshot 继续使用上面的固定示例脚本；API 模式不能把示例 resultId
 * 或 DEMO-ROUTE 带进导览，否则用户会在正式页看到错误或误把示例当真数据。
 */
export const API_TOUR_STEPS: TourStep[] = [
  {
    title: '总览',
    note: '正式 API 总览：研究区边界与已登记口径指标来自 QTP_GEOHAZARD，只读展示。',
    route: { path: '/overview' },
  },
  {
    title: '正式易发性成果',
    note: '正式 API 读取已登记的 1582 个易发性成果点，展示数据库 HAZ_LEVEL / SCORE；当前页可翻页。',
    route: { path: '/analysis/risk', query: { source: 'projectAnalysis' } },
  },
  {
    title: '综合救援路线',
    note: '读取正式 API 已登记的综合救援路线；路线和终点设施只读，按数据库真实结果展示。',
    route: { path: '/analysis/emergency', query: { resultId: 'result.route.combined' } },
  },
  {
    title: '来源与成果',
    note: '打开正式易发性成果详情，核对 1582 点、方法与数据库登记字段；不以示例成果替代。',
    route: { path: '/results/result.susceptibility.combined' },
  },
  {
    title: '导出（当前页 / 全部匹配）',
    note: '回到正式易发性成果页：“当前页导出”下载表格当前页（每页最多 2000 点）；“全部匹配导出”下载地图已装载的全部 1582 点 CSV/GeoJSON 与元数据，文件内会写明是否为全量。',
    route: { path: '/analysis/risk', query: { source: 'projectAnalysis' } },
  },
]

/** 导览脚本只随运行模式切换；正式 API 与示例脚本不可混用。 */
export function tourStepsForMode(mode: DataMode): TourStep[] {
  return mode === 'api' ? API_TOUR_STEPS : TOUR_STEPS
}

/**
 * 路由桥：应用内由 AppShell 的 setup 上下文注入（useRouter），
 * 单元测试可注入假路由以断言导航目标。与 services 的注入模式一致。
 */
type RouterBridge = Pick<Router, 'push'>
let routerBridge: RouterBridge | null = null

/** 测试替换用；传 null 恢复为「在组件上下文中自动获取」。 */
export function setTourRouterBridge(bridge: RouterBridge | null): void {
  routerBridge = bridge
}

/** 组件上下文内安全获取 router；store 在非组件环境（单测）创建时返回 null。 */
function resolveRouter(): RouterBridge | null {
  if (routerBridge !== null) return routerBridge
  try {
    return useRouter()
  } catch {
    return null
  }
}

export const useTourStore = defineStore('tour', () => {
  /** null = 未开始。 */
  const stepIndex = ref<number | null>(null)
  const session = useSessionStore()
  const steps = computed(() => tourStepsForMode(session.mode))

  function navigate(target: TourStep['route']): void {
    const router = resolveRouter()
    if (router !== null) void router.push(target)
  }

  const active = computed(() => stepIndex.value !== null)
  const step = computed<TourStep | null>(() =>
    stepIndex.value === null ? null : (steps.value[stepIndex.value] ?? null),
  )
  const isFirst = computed(() => stepIndex.value === 0)
  const isLast = computed(() => stepIndex.value === steps.value.length - 1)
  /** 面板进度文字，如「2 / 6」。 */
  const progressLabel = computed(() =>
    stepIndex.value === null ? '' : `${stepIndex.value + 1} / ${steps.value.length}`,
  )

  /** 从第一步开始（已在导览中则回到第一步）。 */
  function start(): void {
    const first = steps.value[0]
    if (first === undefined) return
    stepIndex.value = 0
    navigate(first.route)
  }

  function next(): void {
    if (stepIndex.value === null) return
    if (stepIndex.value >= steps.value.length - 1) {
      exit()
      return
    }
    stepIndex.value += 1
    const target = steps.value[stepIndex.value]
    if (target === undefined) {
      exit()
      return
    }
    navigate(target.route)
  }

  function prev(): void {
    if (stepIndex.value === null || stepIndex.value === 0) return
    stepIndex.value -= 1
    const target = steps.value[stepIndex.value]
    if (target === undefined) {
      exit()
      return
    }
    navigate(target.route)
  }

  function exit(): void {
    stepIndex.value = null
  }

  return { stepIndex, steps, active, step, isFirst, isLast, progressLabel, start, next, prev, exit }
})
