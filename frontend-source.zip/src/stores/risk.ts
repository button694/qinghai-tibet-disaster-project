/**
 * 阶段4：风险研判页状态（Pinia）。
 *
 * 可序列化守卫与地图 store 一致：state 只存普通对象/数组/原始值，
 * 不存 OpenLayers 实例或服务对象；服务经 `services/riskScenarios.ts` 单例获取。
 *
 * 竞态防护：装载用递增令牌，await 之后令牌不一致的结果一律丢弃
 * （阶段3 同款策略，防止先发后到的旧响应覆盖新结果）。
 */
import { computed, ref } from 'vue'
import { defineStore } from 'pinia'
import {
  computeMatchStats,
  distributionBins,
  isScenarioMetric,
  isScenarioYear,
  matchStatusOf,
  valueInBinRange,
  type MatchStatus,
  type ScenarioDataset,
  type ScenarioMatchStats,
  type ScenarioMetric,
  type ScenarioRecord,
  type ScenarioYear,
} from '@/domain/scenario'
import type { PreviewManifest } from '@/repositories/realPreview'
import { getRiskScenarioService } from '@/services/riskScenarios'

export type RiskSourceKind = 'projectAnalysis' | 'externalScenario'
export type RiskYearMode = 'single' | 'compare'
export type RiskYearStatus = 'idle' | 'loading' | 'ready' | 'failed'

function emptyYearRecord(): Record<ScenarioYear, RiskYearStatus> {
  return { 2050: 'idle', 2100: 'idle' }
}

export const useRiskStore = defineStore('risk', () => {
  /* ------------------------------ 状态 ------------------------------ */
  const sourceKind = ref<RiskSourceKind>('externalScenario')
  const yearMode = ref<RiskYearMode>('single')
  const activeYear = ref<ScenarioYear>(2050)
  const metric = ref<ScenarioMetric>('hrgi')

  const regionFilter = ref<string | null>(null)
  const basinFilter = ref<string | null>(null)
  /** 直方图点击产生的连续区间筛选（[from, to]，右端闭合）。 */
  const binRange = ref<[number, number] | null>(null)
  const selectedId = ref<string | null>(null)

  const statusByYear = ref(emptyYearRecord())
  const errorByYear = ref<Record<ScenarioYear, string | null>>({ 2050: null, 2100: null })
  const datasets = ref<Record<ScenarioYear, ScenarioDataset | null>>({ 2050: null, 2100: null })

  const manifest = ref<PreviewManifest | null>(null)
  const manifestStatus = ref<RiskYearStatus>('idle')
  const manifestError = ref<string | null>(null)

  let manifestToken = 0
  /** 每年各自独立的装载令牌：并发装载 2050 与 2100 时互不误伤。 */
  const yearTokens: Record<ScenarioYear, number> = { 2050: 0, 2100: 0 }

  /* ------------------------------ 装载 ------------------------------ */

  async function loadManifest(force = false): Promise<void> {
    if (manifestStatus.value === 'ready' && !force) return
    const token = ++manifestToken
    manifestStatus.value = 'loading'
    manifestError.value = null
    try {
      const next = await getRiskScenarioService().manifest()
      if (token !== manifestToken) return
      manifest.value = next
      manifestStatus.value = 'ready'
    } catch (error) {
      if (token !== manifestToken) return
      manifestStatus.value = 'failed'
      manifestError.value = error instanceof Error ? error.message : String(error)
    }
  }

  async function loadYear(year: ScenarioYear, force = false): Promise<void> {
    if (statusByYear.value[year] === 'ready' && !force) return
    const token = ++yearTokens[year]
    statusByYear.value[year] = 'loading'
    errorByYear.value[year] = null
    try {
      const dataset = await getRiskScenarioService().loadScenario(year)
      if (token !== yearTokens[year]) return // 旧响应：丢弃，不覆盖新状态
      datasets.value[year] = dataset
      statusByYear.value[year] = 'ready'
    } catch (error) {
      if (token !== yearTokens[year]) return
      statusByYear.value[year] = 'failed'
      errorByYear.value[year] = error instanceof Error ? error.message : String(error)
      datasets.value[year] = null // 失败不保留旧结果（02 §4.2）
    }
  }

  /** 装载清单 + 当前需要的年份（单图一年，对比两年）。 */
  async function load(force = false): Promise<void> {
    await Promise.all([loadManifest(force), ...neededYears().map((year) => loadYear(year, force))])
  }

  function neededYears(): ScenarioYear[] {
    return yearMode.value === 'compare' ? [2050, 2100] : [activeYear.value]
  }

  /* ------------------------------ 派生 ------------------------------ */

  const isCompare = computed(() => yearMode.value === 'compare')

  const visibleYears = computed<ScenarioYear[]>(() =>
    yearMode.value === 'compare' ? [2050, 2100] : [activeYear.value],
  )

  function datasetOf(year: ScenarioYear): ScenarioDataset | null {
    return datasets.value[year]
  }

  /** 区域/流域选项：来自已装载数据的原始值（不翻译不改写），排除 null 并排序。 */
  const regionOptions = computed<string[]>(() => collectOptions((record) => record.region))
  const basinOptions = computed<string[]>(() => collectOptions((record) => record.basin))

  function collectOptions(pick: (record: ScenarioRecord) => string | null): string[] {
    const values = new Set<string>()
    for (const year of visibleYears.value) {
      const dataset = datasets.value[year]
      if (!dataset) continue
      for (const record of dataset.records) {
        const value = pick(record)
        if (value !== null) values.add(value)
      }
    }
    return [...values].sort((a, b) => a.localeCompare(b))
  }

  /** 是否命中区域/流域筛选（null 记录在任一筛选激活时被排除，如实不出现在地图上）。 */
  function matchesAttributeFilter(record: ScenarioRecord): boolean {
    if (regionFilter.value !== null && record.region !== regionFilter.value) return false
    if (basinFilter.value !== null && record.basin !== basinFilter.value) return false
    return true
  }

  /** 当前筛选后的记录（地图、统计、重点对象共用同一份，保证口径一致）。 */
  function filteredRecords(year: ScenarioYear): ScenarioRecord[] {
    const dataset = datasets.value[year]
    if (!dataset) return []
    return dataset.records.filter(
      (record) =>
        matchesAttributeFilter(record) &&
        valueInBinRange(record.values[metric.value], binRange.value),
    )
  }

  const filteredCount = computed(() =>
    visibleYears.value.reduce((sum, year) => sum + filteredRecords(year).length, 0),
  )

  /** 未匹配统计：永远基于**全量**数据计算，不随筛选变化（筛选后数量单独显示）。 */
  const matchStats = computed<ScenarioMatchStats | null>(() => {
    const a = datasets.value[2050]
    const b = datasets.value[2100]
    if (!a || !b) return null
    return computeMatchStats(a, b)
  })

  const ids2050 = computed<Set<string> | null>(() => setOfIds(2050))
  const ids2100 = computed<Set<string> | null>(() => setOfIds(2100))

  function setOfIds(year: ScenarioYear): Set<string> | null {
    const dataset = datasets.value[year]
    return dataset ? new Set(dataset.records.map((record) => record.glacierId)) : null
  }

  function matchStatusOfId(glacierId: string): MatchStatus | null {
    return matchStatusOf(glacierId, ids2050.value, ids2100.value)
  }

  /** 当前筛选下的指标分布（直方图数据；null 单独返回，不进箱）。 */
  const distribution = computed(() => {
    const records =
      yearMode.value === 'compare'
        ? [...filteredRecords(2050), ...filteredRecords(2100)]
        : filteredRecords(activeYear.value)
    return distributionBins(records, metric.value)
  })

  const selectedRecord = computed<ScenarioRecord | null>(() => {
    if (selectedId.value === null) return null
    for (const year of [2050, 2100] as const) {
      const dataset = datasets.value[year]
      const found = dataset?.records.find((record) => record.glacierId === selectedId.value)
      if (found) return found
    }
    return null
  })

  /* ------------------------------ 动作 ------------------------------ */

  function setSourceKind(kind: RiskSourceKind): void {
    sourceKind.value = kind
  }

  function setYearMode(mode: RiskYearMode): void {
    if (yearMode.value === mode) return
    yearMode.value = mode
    void load()
  }

  function setActiveYear(year: ScenarioYear): void {
    if (!isScenarioYear(year)) return
    activeYear.value = year
    yearMode.value = 'single'
    void load()
  }

  function setMetric(next: unknown): void {
    if (!isScenarioMetric(next)) return
    if (metric.value === next) return
    metric.value = next
    // 分箱区间是「某一指标」上的区间，换指标后旧区间语义失效，必须清掉。
    binRange.value = null
  }

  function setRegion(value: string | null): void {
    regionFilter.value = value
  }

  function setBasin(value: string | null): void {
    basinFilter.value = value
  }

  function setBinRange(range: [number, number] | null): void {
    binRange.value = range
  }

  /** 清除全部筛选（区域、流域、直方图区间）；选中对象保留。 */
  function clearFilters(): void {
    regionFilter.value = null
    basinFilter.value = null
    binRange.value = null
  }

  function select(glacierId: string | null): void {
    selectedId.value = glacierId
  }

  /** 失败重试：只重拉失败的部分，成功的缓存不丢。 */
  async function retry(): Promise<void> {
    const tasks: Promise<void>[] = []
    if (manifestStatus.value === 'failed') tasks.push(loadManifest(true))
    for (const year of neededYears()) {
      if (statusByYear.value[year] === 'failed') tasks.push(loadYear(year, true))
    }
    await Promise.all(tasks)
  }

  return {
    // 状态
    sourceKind,
    yearMode,
    activeYear,
    metric,
    regionFilter,
    basinFilter,
    binRange,
    selectedId,
    statusByYear,
    errorByYear,
    datasets,
    manifest,
    manifestStatus,
    manifestError,
    // 派生
    isCompare,
    visibleYears,
    regionOptions,
    basinOptions,
    filteredCount,
    matchStats,
    distribution,
    selectedRecord,
    // 方法
    datasetOf,
    filteredRecords,
    matchStatusOfId,
    load,
    loadYear,
    setSourceKind,
    setYearMode,
    setActiveYear,
    setMetric,
    setRegion,
    setBasin,
    setBinRange,
    clearFilters,
    select,
    retry,
  }
})
