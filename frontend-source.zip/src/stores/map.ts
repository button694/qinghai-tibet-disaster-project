/**
 * 地图工作台状态（阶段2）。
 *
 * 硬性约束（03 §5-1）：**OpenLayers 实例不进 Pinia**。本 store 只保存可序列化状态——
 * 图层注册表、可见性、透明度、叠放顺序、搜索词、选中引用、面板开合与各图层的数据状态；
 * 地图实例、矢量源、要素几何一律由 `MapCanvas.vue` 在组件生命周期内用非响应式变量持有。
 * `tests/unit/map-store.spec.ts` 用「状态可 JSON 往返」守住这条约束。
 *
 * 叠放顺序约定：`order[0]` 是图层树的**最上面一行**，也是地图上**最上层**的图层；
 * 上下移动即调整该数组。地图侧由 zIndex 体现，不从数组下标直接推断。
 */
import { defineStore } from 'pinia'
import { computed, ref, shallowRef } from 'vue'

import {
  groupLayersByTheme,
  initialDrawOrder,
  isMapTheme,
  type ThemeGroup,
} from '@/config/mapLayers'
import type { FeatureDetail, LayerDefinition } from '@/domain/types'
import {
  getMapLayerService,
  type LayerDataResult,
  type LayerDataStatus,
} from '@/services/mapLayers'
import type { MapRenderState } from '@/services/mapRenderState'

export type RegistryStatus = 'idle' | 'loading' | 'ready' | 'failed'

export interface LayerDataSummary {
  status: 'idle' | 'loading' | LayerDataStatus
  /** 服务端声明的全部匹配记录数。 */
  serverTotal: number
  /** 分页实际取回的记录数（重复业务对象也计入）。 */
  fetchedCount: number
  /** 按业务对象去重后的记录数。 */
  uniqueCount: number
  /** 实际传给地图渲染的记录数。 */
  renderedCount: number
  /** 是否完整取回服务端全部分页。 */
  complete: boolean
  /** 兼容旧调用方：等同于 serverTotal。 */
  total: number
  /** 兼容旧调用方：等同于 uniqueCount。 */
  matched: number
  /** 服务端记录未完整取回时为 true。 */
  truncated: boolean
  /** 无几何记录数：属性可查，定位不可用。 */
  skippedNoGeometry: number
  note: string | null
  errorCode: string | null
  errorText: string | null
  /** 加载中的实时进度：已加载 / 全部匹配数；非加载中状态为 null。 */
  progress: { loaded: number; total: number } | null
  /** 当前地图使用的几何是否被服务端简化（仅用于渲染，见 services/mapLayers）。 */
  geometrySimplified: boolean
  /** 实际生效的简化容差（米）；未简化为 null。 */
  simplifyToleranceMeters: number | null
}

export function emptySummary(): LayerDataSummary {
  return {
    status: 'idle',
    serverTotal: 0,
    fetchedCount: 0,
    uniqueCount: 0,
    renderedCount: 0,
    complete: false,
    total: 0,
    matched: 0,
    truncated: false,
    skippedNoGeometry: 0,
    note: null,
    errorCode: null,
    errorText: null,
    progress: null,
    geometrySimplified: false,
    simplifyToleranceMeters: null,
  }
}

/** 把服务层的加载结果映射为界面用的图层数据状态（唯一的映射处）。 */
export function toDataSummary(
  result: LayerDataResult,
  skippedNoGeometry: number,
  renderedCount = result.renderedCount,
): LayerDataSummary {
  return {
    status: result.status,
    serverTotal: result.serverTotal,
    fetchedCount: result.fetchedCount,
    uniqueCount: result.uniqueCount,
    renderedCount,
    complete: result.complete,
    total: result.total,
    matched: result.matched,
    truncated: result.truncated,
    skippedNoGeometry,
    note: result.note,
    errorCode: result.error?.code ?? null,
    errorText: result.error?.userMessage ?? null,
    progress: null,
    geometrySimplified: result.geometrySimplified ?? false,
    simplifyToleranceMeters: result.simplifyToleranceMeters ?? null,
  }
}

export const useMapStore = defineStore('map', () => {
  const status = ref<RegistryStatus>('idle')
  const errorCode = ref<string | null>(null)
  const errorText = ref<string | null>(null)
  /** 图层注册表（来自 Repository，不写死图层 ID）。 */
  const layers = ref<LayerDefinition[]>([])
  /** 叠放顺序：index 0 在最上层。 */
  const order = ref<string[]>([])
  const visible = ref<Record<string, boolean>>({})
  const opacity = ref<Record<string, number>>({})
  const dataSummary = ref<Record<string, LayerDataSummary>>({})
  const search = ref('')
  const activeLayerId = ref<string | null>(null)
  const selected = ref<FeatureDetail | null>(null)
  /** 地图侧回传的「实际渲染状态」，只读展示，用于核对控件是否真的生效。 */
  const renderState = shallowRef<MapRenderState | null>(null)
  /** 背景：示例研究区边界（本地文件，非在线底图）。 */
  const backgroundVisible = ref(true)
  const detailOpen = ref(false)
  const objectListOpen = ref(false)
  const legendOpen = ref(false)
  /** 窄屏时图层面板以抽屉呈现，一次只开一个。 */
  const layerDrawerOpen = ref(false)

  const orderedLayers = computed(() => {
    const byId = new Map(layers.value.map((layer) => [layer.id, layer]))
    const ordered = order.value
      .map((id) => byId.get(id))
      .filter((layer): layer is LayerDefinition => layer !== undefined)
    // 注册表里出现、但尚未进入 order 的图层（模式切换或注册表更新）补齐到末尾。
    for (const layer of layers.value) {
      if (!order.value.includes(layer.id)) ordered.push(layer)
    }
    return ordered
  })

  const groups = computed<ThemeGroup[]>(() => groupLayersByTheme(orderedLayers.value, search.value))

  const selectedCount = computed(() => groups.value.reduce((sum, g) => sum + g.layers.length, 0))

  const visibleLayerIds = computed(() =>
    orderedLayers.value.filter((layer) => isVisible(layer.id)).map((layer) => layer.id),
  )

  const activeLayer = computed(
    () => orderedLayers.value.find((layer) => layer.id === activeLayerId.value) ?? null,
  )

  function isVisible(layerId: string): boolean {
    return visible.value[layerId] ?? false
  }

  function opacityOf(layerId: string): number {
    return opacity.value[layerId] ?? 1
  }

  function summaryOf(layerId: string): LayerDataSummary {
    return dataSummary.value[layerId] ?? emptySummary()
  }

  /** 用注册表默认值初始化每层的可见性与透明度（默认值来自数据包，不由前端另行决定）。 */
  function applyRegistry(next: LayerDefinition[]): void {
    layers.value = next.filter((layer) => isMapTheme(layer.theme))
    order.value = initialDrawOrder(layers.value)
    const nextVisible: Record<string, boolean> = {}
    const nextOpacity: Record<string, number> = {}
    const nextSummary: Record<string, LayerDataSummary> = {}
    for (const layer of layers.value) {
      nextVisible[layer.id] = layer.defaultVisible
      nextOpacity[layer.id] = layer.defaultOpacity
      nextSummary[layer.id] = emptySummary()
    }
    visible.value = nextVisible
    opacity.value = nextOpacity
    dataSummary.value = nextSummary
    selected.value = null
    detailOpen.value = false
    activeLayerId.value = null
  }

  async function loadRegistry(options: { force?: boolean } = {}): Promise<void> {
    if (status.value === 'loading') return
    if (!options.force && status.value === 'ready') return
    status.value = 'loading'
    errorCode.value = null
    errorText.value = null
    try {
      const envelope = await getMapLayerService().listLayers()
      applyRegistry(envelope.data)
      status.value = 'ready'
    } catch (error) {
      // 失败即失败：不保留任何图层，也不用示例图层顶替。
      layers.value = []
      order.value = []
      status.value = 'failed'
      const repositoryError = error as { code?: string; userMessage?: string; message?: string }
      errorCode.value = repositoryError.code ?? 'UNKNOWN'
      errorText.value =
        repositoryError.userMessage ?? repositoryError.message ?? '图层注册表读取失败。'
    }
  }

  function setVisible(layerId: string, next: boolean): void {
    visible.value = { ...visible.value, [layerId]: next }
  }

  function toggleVisible(layerId: string): void {
    setVisible(layerId, !isVisible(layerId))
  }

  function setOpacity(layerId: string, next: number): void {
    const clamped = Math.min(1, Math.max(0, next))
    opacity.value = { ...opacity.value, [layerId]: clamped }
  }

  /** 图层树里向上/向下移动；`order[0]` 为最上层。 */
  function moveLayer(layerId: string, direction: 'up' | 'down'): boolean {
    const index = order.value.indexOf(layerId)
    if (index < 0) return false
    const target = direction === 'up' ? index - 1 : index + 1
    if (target < 0 || target >= order.value.length) return false
    const next = [...order.value]
    const moved = next[index]
    const replaced = next[target]
    if (moved === undefined || replaced === undefined) return false
    next[index] = replaced
    next[target] = moved
    order.value = next
    return true
  }

  function resetOrder(): void {
    order.value = initialDrawOrder(layers.value)
    const nextOpacity: Record<string, number> = {}
    const nextVisible: Record<string, boolean> = {}
    for (const layer of layers.value) {
      nextOpacity[layer.id] = layer.defaultOpacity
      nextVisible[layer.id] = layer.defaultVisible
    }
    opacity.value = nextOpacity
    visible.value = nextVisible
  }

  function setSearch(value: string): void {
    search.value = value
  }

  function setActiveLayer(layerId: string | null): void {
    activeLayerId.value = layerId
  }

  function select(detail: FeatureDetail | null): void {
    selected.value = detail
    detailOpen.value = detail !== null
  }

  function clearSelection(): void {
    selected.value = null
    detailOpen.value = false
  }

  function setDataSummary(layerId: string, summary: LayerDataSummary): void {
    dataSummary.value = { ...dataSummary.value, [layerId]: summary }
  }

  function markLoading(layerId: string): void {
    setDataSummary(layerId, { ...summaryOf(layerId), status: 'loading', progress: null })
  }

  /** 全量加载过程中的实时进度（已加载 / 全部匹配数），供图层树显示「已加载 N / 共 M」。 */
  function setLoadProgress(layerId: string, loaded: number, total: number): void {
    const current = summaryOf(layerId)
    if (current.status !== 'loading') return
    setDataSummary(layerId, { ...current, progress: { loaded, total } })
  }

  function setRenderState(next: MapRenderState | null): void {
    renderState.value = next
  }

  function toggleDetail(): void {
    detailOpen.value = !detailOpen.value
  }

  function toggleLegend(): void {
    legendOpen.value = !legendOpen.value
  }

  function toggleObjectList(): void {
    objectListOpen.value = !objectListOpen.value
  }

  function toggleLayerDrawer(): void {
    layerDrawerOpen.value = !layerDrawerOpen.value
  }

  function closeDrawers(): void {
    layerDrawerOpen.value = false
  }

  /** 离开页面或切换数据模式时复位；不缓存上一模式的图层与选中状态（D-014）。 */
  function reset(): void {
    status.value = 'idle'
    errorCode.value = null
    errorText.value = null
    layers.value = []
    order.value = []
    visible.value = {}
    opacity.value = {}
    dataSummary.value = {}
    search.value = ''
    activeLayerId.value = null
    selected.value = null
    renderState.value = null
    detailOpen.value = false
    objectListOpen.value = false
    legendOpen.value = false
    layerDrawerOpen.value = false
  }

  return {
    status,
    errorCode,
    errorText,
    layers,
    order,
    visible,
    opacity,
    dataSummary,
    search,
    activeLayerId,
    selected,
    renderState,
    backgroundVisible,
    detailOpen,
    objectListOpen,
    legendOpen,
    layerDrawerOpen,
    orderedLayers,
    groups,
    selectedCount,
    visibleLayerIds,
    activeLayer,
    isVisible,
    opacityOf,
    summaryOf,
    loadRegistry,
    applyRegistry,
    setVisible,
    toggleVisible,
    setOpacity,
    moveLayer,
    resetOrder,
    setSearch,
    setActiveLayer,
    select,
    clearSelection,
    setDataSummary,
    markLoading,
    setLoadProgress,
    setRenderState,
    toggleDetail,
    toggleLegend,
    toggleObjectList,
    toggleLayerDrawer,
    closeDrawers,
    reset,
  }
})
