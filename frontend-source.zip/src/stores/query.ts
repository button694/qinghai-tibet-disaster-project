/**
 * 查询工作区状态（阶段3）。
 *
 * 与地图 store 同样的硬约束：**只保存可序列化状态**。绘制几何是普通 GeoJSON，
 * 源对象只保存 `FeatureRef`，OpenLayers 对象一律不进 Pinia。
 *
 * 三条行为约定（03 §6-2、§6-5、§6-6）：
 * 1. **改条件页码回 1**：任何会改变结果集合的操作（换图层、加删改条件、改空间条件、改排序）
 *    都把页码重置为 1；只有「翻页」本身才改变页码。
 * 2. **旧响应不覆盖新结果**：查询由 `services/queryWorkspace` 统一加序号与 abort，
 *    本 store 只接受非 `null` 的最新结果。
 * 3. **空结果与失败分开**：空结果是有结果（0 条），失败是没拿到结果——
 *    两者在 `status` 上是两个值，界面不得混为一谈。
 */
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import type { Geometry } from 'geojson'
import type {
  Context,
  FeatureDetail,
  FeatureRef,
  LayerDefinition,
  Metric,
  SpatialInput,
  SpatialPredicate,
} from '@/domain/types'
import {
  describeConditions,
  filterableFields,
  hiddenFieldNote,
  sortableFields,
  toAttributeFilters,
  type DictionaryMap,
  type FieldCondition,
} from '@/domain/queryFields'
import { isRepositoryError, toRepositoryError, type RepositoryError } from '@/repositories/types'
import {
  getQueryWorkspaceService,
  DEFAULT_PAGE_SIZE,
  type QueryOutcome,
} from '@/services/queryWorkspace'
import { useMapStore } from '@/stores/map'

/** 空间条件的来源形态。与谓词共同决定真正发给接口的空间输入。 */
export type SpatialSourceKind = 'draw' | 'region' | 'feature'

export interface SpatialDraft {
  predicate: SpatialPredicate
  source: SpatialSourceKind
  /** 绘制范围（EPSG:4326 多边形）；框选与多边形写入这里。 */
  geometry: Geometry | null
  regionId: string | null
  /** 对象缓冲 / 最近邻的源对象。 */
  sourceFeature: FeatureRef | null
  sourceLabel: string | null
  /** 缓冲半径或最近邻限制半径（米）。 */
  distanceMeters: number | null
  /** 最近邻返回数量。 */
  limit: number | null
}

export type QueryStatus = 'idle' | 'loading' | 'ready' | 'failed'

export function emptySpatialDraft(): SpatialDraft {
  return {
    predicate: 'intersects',
    source: 'draw',
    geometry: null,
    regionId: null,
    sourceFeature: null,
    sourceLabel: null,
    distanceMeters: null,
    limit: null,
  }
}

/**
 * 界面空间条件 → 契约 `SpatialInput`。
 *
 * `geometry / sourceFeature / regionId` 恰选一个（02 §3.1），这里按 `source` 决定给哪一个，
 * 其余两个不填；条件不完整（选了方式但没画范围、没选对象、半径为空）时返回 `null`，
 * 由调用方提示用户，绝不把半截条件发给接口。
 */
export function toSpatialInput(draft: SpatialDraft | null): SpatialInput | null {
  if (draft === null) return null
  const base: SpatialInput = { predicate: draft.predicate }
  if (draft.source === 'draw') {
    if (draft.geometry === null) return null
    base.geometry = draft.geometry
    return base
  }
  if (draft.source === 'region') {
    if (draft.regionId === null) return null
    base.regionId = draft.regionId
    return base
  }
  if (draft.sourceFeature === null) return null
  base.sourceFeature = draft.sourceFeature
  if (draft.predicate === 'bufferIntersects' || draft.predicate === 'nearest') {
    if (draft.distanceMeters === null || draft.distanceMeters <= 0) return null
    base.distanceMeters = draft.distanceMeters
  }
  if (draft.predicate === 'nearest') {
    if (draft.limit === null || draft.limit < 1) return null
    base.limit = draft.limit
  }
  return base
}

export const useQueryStore = defineStore('query', () => {
  const mapStore = useMapStore()

  const open = ref(false)
  const layerId = ref<string | null>(null)
  const conditions = ref<FieldCondition[]>([])
  const spatial = ref<SpatialDraft | null>(null)
  const sort = ref<{ field: string; direction: 'asc' | 'desc' } | null>(null)
  const page = ref(1)
  const pageSize = ref(DEFAULT_PAGE_SIZE)

  const status = ref<QueryStatus>('idle')
  const queryId = ref<string | null>(null)
  const rows = ref<FeatureDetail[]>([])
  const total = ref(0)
  const metrics = ref<Metric[]>([])
  const nearestDistances = ref<Record<string, number> | null>(null)
  const context = ref<Context | null>(null)
  const error = ref<RepositoryError | null>(null)
  /** 条件填了一半的提示：不阻断查询，但要说清楚哪些条件实际没生效。 */
  const partialNote = ref<string | null>(null)

  const layer = computed<LayerDefinition | null>(
    () => mapStore.layers.find((item) => item.id === layerId.value) ?? null,
  )

  /** 可作条件的字段（注册表声明可查询）。 */
  const availableFields = computed(() => filterableFields(layer.value))

  /** 还可添加的字段：同一个字段只允许一条条件（AND 语义下重复无意义）。 */
  const addableFields = computed(() =>
    availableFields.value.filter((field) => !conditions.value.some((c) => c.field === field.key)),
  )

  const hiddenNote = computed(() => hiddenFieldNote(layer.value))

  const sortFields = computed(() => sortableFields(layer.value))

  const pageCount = computed(() =>
    total.value === 0 ? 1 : Math.max(1, Math.ceil(total.value / pageSize.value)),
  )

  const hasResult = computed(() => status.value === 'ready')

  /** 本页命中（用于在地图上高亮）：行数受分页限制，不与总数混淆。 */
  const pageRefs = computed(() => rows.value.map((row) => row.ref))

  function resetPage(): void {
    page.value = 1
  }

  function clearResult(): void {
    status.value = 'idle'
    queryId.value = null
    rows.value = []
    total.value = 0
    metrics.value = []
    nearestDistances.value = null
    context.value = null
    error.value = null
  }

  function setLayer(next: string | null): void {
    layerId.value = next
    conditions.value = []
    spatial.value = null
    sort.value = null
    partialNote.value = null
    resetPage()
    clearResult()
  }

  function addCondition(condition: FieldCondition): void {
    conditions.value = [...conditions.value, condition]
    resetPage()
  }

  function removeCondition(field: string): void {
    conditions.value = conditions.value.filter((item) => item.field !== field)
    resetPage()
  }

  function updateCondition(field: string, next: FieldCondition): void {
    conditions.value = conditions.value.map((item) => (item.field === field ? next : item))
    resetPage()
  }

  function clearConditions(): void {
    conditions.value = []
    resetPage()
  }

  function setSpatial(next: SpatialDraft | null): void {
    spatial.value = next
    resetPage()
  }

  function updateSpatial(patch: Partial<SpatialDraft>): void {
    if (spatial.value === null) return
    spatial.value = { ...spatial.value, ...patch }
    resetPage()
  }

  function setSort(field: string | null): void {
    if (field === null) {
      sort.value = null
    } else {
      const previous = sort.value
      sort.value =
        previous?.field === field
          ? { field, direction: previous.direction === 'asc' ? 'desc' : 'asc' }
          : { field, direction: 'asc' }
    }
    resetPage()
  }

  function setPageSize(next: number): void {
    pageSize.value = Math.max(1, Math.floor(next))
    resetPage()
  }

  const activeFilters = computed(() => toAttributeFilters(conditions.value))
  const spatialInput = computed(() => toSpatialInput(spatial.value))

  /**
   * 空间条件填了一半的说明。
   *
   * 不阻断用户操作，但在运行前如实告诉用户「这个条件实际不会生效」——
   * 否则用户会以为自己加了空间条件，结果却是全表查询。
   */
  const spatialIncompleteReason = computed<string | null>(() => {
    const draft = spatial.value
    if (draft === null) return null
    if (draft.source === 'draw' && draft.geometry === null) {
      return '还没有绘制范围：请在地图上框选或画多边形。'
    }
    if (draft.source === 'region' && draft.regionId === null) {
      return '还没有选择行政区或流域。'
    }
    if (draft.source === 'feature') {
      if (draft.sourceFeature === null) {
        return '还没有选择源对象：请先点选一个对象，再点「用当前选中对象」。'
      }
      if (
        (draft.predicate === 'bufferIntersects' || draft.predicate === 'nearest') &&
        (draft.distanceMeters === null || draft.distanceMeters <= 0)
      ) {
        return '还没有填写有效的半径（米）。'
      }
      if (draft.predicate === 'nearest' && (draft.limit === null || draft.limit < 1)) {
        return '还没有填写返回数量。'
      }
    }
    return null
  })

  /** 条件摘要（界面与导出共用同一份文案）。 */
  function conditionsText(dictionaries: DictionaryMap = {}): string[] {
    return describeConditions(conditions.value, layer.value, dictionaries)
  }

  /* ------------------------------------------------------------------ *
   * 执行
   * ------------------------------------------------------------------ */

  async function run(): Promise<void> {
    if (layerId.value === null) return
    status.value = 'loading'
    error.value = null
    partialNote.value = null
    try {
      const outcome = await getQueryWorkspaceService().run({
        layerId: layerId.value,
        filters: activeFilters.value,
        spatial: spatialInput.value,
        sort: sort.value,
        page: page.value,
        pageSize: pageSize.value,
      })
      // null 表示结果已被更新的查询取代或已取消：保留 loading，等待最新一次返回。
      if (outcome === null) return
      applyOutcome(outcome)
    } catch (unknownError) {
      const repositoryError = isRepositoryError(unknownError)
        ? unknownError
        : toRepositoryError(unknownError, 'UNKNOWN')
      status.value = 'failed'
      error.value = repositoryError
      rows.value = []
      total.value = 0
      queryId.value = null
    }
  }

  /** 仅翻页：复用同一 queryId，条件不变。 */
  async function goToPage(next: number): Promise<void> {
    if (queryId.value === null) return
    const target = Math.min(Math.max(1, next), pageCount.value)
    page.value = target
    status.value = 'loading'
    error.value = null
    try {
      const outcome = await getQueryWorkspaceService().pageTo(queryId.value, target, pageSize.value)
      if (outcome === null) return
      applyOutcome(outcome)
    } catch (unknownError) {
      const repositoryError = isRepositoryError(unknownError)
        ? unknownError
        : toRepositoryError(unknownError, 'UNKNOWN')
      status.value = 'failed'
      error.value = repositoryError
      rows.value = []
    }
  }

  function applyOutcome(outcome: QueryOutcome): void {
    queryId.value = outcome.queryId
    rows.value = outcome.rows
    total.value = outcome.total
    page.value = outcome.page
    pageSize.value = outcome.pageSize
    metrics.value = outcome.metrics
    nearestDistances.value = outcome.nearestDistances
    context.value = outcome.context
    status.value = 'ready'
    error.value = null
  }

  function cancel(): void {
    getQueryWorkspaceService().cancel()
    if (status.value === 'loading') status.value = 'idle'
  }

  function toggleOpen(): void {
    open.value = !open.value
  }

  function setOpen(next: boolean): void {
    open.value = next
  }

  /** 离开页面或切换数据模式时复位（D-014）。 */
  function reset(): void {
    getQueryWorkspaceService().reset()
    open.value = false
    layerId.value = null
    conditions.value = []
    spatial.value = null
    sort.value = null
    page.value = 1
    pageSize.value = DEFAULT_PAGE_SIZE
    partialNote.value = null
    clearResult()
  }

  return {
    open,
    layerId,
    conditions,
    spatial,
    sort,
    page,
    pageSize,
    status,
    queryId,
    rows,
    total,
    metrics,
    nearestDistances,
    context,
    error,
    partialNote,
    layer,
    availableFields,
    addableFields,
    hiddenNote,
    sortFields,
    pageCount,
    hasResult,
    pageRefs,
    activeFilters,
    spatialInput,
    spatialIncompleteReason,
    setLayer,
    addCondition,
    removeCondition,
    updateCondition,
    clearConditions,
    setSpatial,
    updateSpatial,
    setSort,
    setPageSize,
    conditionsText,
    run,
    goToPage,
    cancel,
    toggleOpen,
    setOpen,
    reset,
  }
})
