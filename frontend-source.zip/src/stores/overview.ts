/**
 * 阶段6：总览状态（Pinia）。
 *
 * 数据全部来自 OverviewRepository（`GET /overview` 契约）；风险区要素经
 * LayerRepository 装载用于主地图。总览数字必须能在数据目录或成果明细中
 * 找到对应依据，页面不自造任何统计。
 *
 * 竞态防护与失败处理同 exposure store；失败清空旧结果，不回退示例数据。
 */
import { ref } from 'vue'
import { defineStore } from 'pinia'
import type { FeatureDetail, OverviewData } from '@/domain/types'
import { getRepositories } from '@/repositories'
import { toRepositoryError, type RepositoryError } from '@/repositories/types'
import { fetchAllLayerFeatures } from '@/services/mapLayers'
import { useSessionStore } from '@/stores/session'

export type OverviewStatus = 'idle' | 'loading' | 'ready' | 'failed'

/** 总览主地图图层：mock 模式用示例风险区成果；API 模式用真实正式边界（SYS_DATASET 登记）。 */
export const OVERVIEW_RISK_LAYER_ID = 'result.demo.risk'
export const OVERVIEW_API_BOUNDARY_LAYER_ID = 'DS_BASE_QTP_BOUNDARY'

export const useOverviewStore = defineStore('overview', () => {
  const data = ref<OverviewData | null>(null)
  const zones = ref<FeatureDetail[]>([])
  const status = ref<OverviewStatus>('idle')
  const error = ref<RepositoryError | null>(null)
  /** 指标成功但风险区要素上图失败时的非阻断警告。 */
  const zoneWarning = ref<string | null>(null)

  let token = 0

  async function load(): Promise<void> {
    const current = ++token
    status.value = 'loading'
    error.value = null
    zoneWarning.value = null
    try {
      const { overview, layers } = getRepositories()
      const envelope = await overview.getOverview()
      // 真实演示修正：API 模式下总览地图加载**真实正式边界图层**（6 个多边形），
      // 不再请求 mock 专属的 result.demo.risk（HTTP 下 404 造成 console error）。
      const session = useSessionStore()
      const zoneLayerId =
        session.mode === 'api' ? OVERVIEW_API_BOUNDARY_LAYER_ID : OVERVIEW_RISK_LAYER_ID
      // 风险区要素失败不应拖垮指标面板，但主地图要有明确状态；
      // 这里两者一起成功才算 ready，要素失败单独降级为空并记录。
      let zoneItems: FeatureDetail[] = []
      let zoneFailure: string | null = null
      try {
        // 全量取数（翻页循环）而不是只取首个服务页：边界图层当前只有 6 个多边形，
        // 换成全量取数是为了不再依赖一个碰巧够用的页大小，未来边界图层变大也不会截断。
        const zoneResult = await fetchAllLayerFeatures({ layers }, zoneLayerId)
        zoneItems = zoneResult.features
      } catch (zoneError) {
        zoneFailure = zoneError instanceof Error ? zoneError.message : String(zoneError)
      }
      if (current !== token) return
      data.value = envelope.data
      zones.value = zoneItems
      status.value = 'ready'
      if (zoneFailure !== null) {
        zoneWarning.value = `${session.mode === 'api' ? '研究区边界' : '风险区要素'}上图失败：${zoneFailure}`
      }
    } catch (err) {
      if (current !== token) return
      status.value = 'failed'
      error.value = toRepositoryError(err)
      data.value = null
      zones.value = []
    }
  }

  function reset(): void {
    data.value = null
    zones.value = []
    status.value = 'idle'
    error.value = null
    zoneWarning.value = null
  }

  return { data, zones, status, error, zoneWarning, load, reset }
})
