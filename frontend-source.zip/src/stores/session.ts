/**
 * 会话状态：数据模式、能力清单与来源上下文（阶段1）。
 *
 * 这是“模式只改配置”在界面上的唯一出处：
 * 页面从本 store 取模式标签、快照标识、能力开关，而不是各自读环境变量。
 *
 * 三条硬性规则：
 * 1. 能力清单来自 Repository（示例模式下来自数据包的 `capabilities.json`），
 *    页面不得自行假定某项能力可用。
 * 2. 能力读取失败时保持“失败”状态并保留错误码，**不降级成示例能力**。
 * 3. 能力未知时一律按“不可用”处理（保守只读），避免出现假按钮。
 */
import { defineStore } from 'pinia'
import { computed, ref } from 'vue'

import { appEnv } from '@/config/env'
import { DATA_MODE_DESCRIPTION, DATA_MODE_LABEL } from '@/domain/labels'
import type { Capabilities, Context, DataMode } from '@/domain/types'
import { dataSourceUrl, getRepositories } from '@/repositories'
import { isRepositoryError, toRepositoryError, type RepositoryError } from '@/repositories/types'

export type SessionStatus = 'idle' | 'loading' | 'ready' | 'failed'

export const useSessionStore = defineStore('session', () => {
  const mode = ref<DataMode>(appEnv.dataMode)
  const status = ref<SessionStatus>('idle')
  /** 已解析出的错误对象；失败时页面直接展示它，不做任何兜底。 */
  const error = ref<RepositoryError | null>(null)
  const capabilities = ref<Capabilities | null>(null)
  const context = ref<Context | null>(null)
  const failedAt = ref<string | null>(null)

  const modeLabel = computed(() => import.meta.env.VITE_PUBLISHED_SNAPSHOT === 'true' ? '真实成果快照' : DATA_MODE_LABEL[mode.value])
  const modeDescription = computed(() => DATA_MODE_DESCRIPTION[mode.value])
  const sourceUrl = computed(() => {
    const value = dataSourceUrl(mode.value)
    return value === '' ? '(未配置)' : value
  })

  /** 示例数据身份：界面必须持续标识，且关闭全部写能力。 */
  const isSample = computed(() => mode.value === 'mock')
  const isLoading = computed(() => status.value === 'loading')
  const isFailed = computed(() => status.value === 'failed')
  const isReady = computed(() => status.value === 'ready')

  const snapshotId = computed(
    () => capabilities.value?.snapshotId ?? context.value?.snapshotId ?? null,
  )
  // 统计范围与快照信息只来自信封 meta（Context），能力清单本身不携带范围字段。
  const scopeLabel = computed(() => context.value?.scopeLabel ?? null)
  const generatedAt = computed(() => context.value?.generatedAt ?? null)
  const boundaryVersion = computed(() => context.value?.boundaryVersion ?? null)

  const readOnly = computed(() => capabilities.value?.dataEdit !== true)
  const canSpatialQuery = computed(() => capabilities.value?.spatialQuery === true)
  const canAttributeQuery = computed(() => capabilities.value?.attributeQuery === true)
  const canReadResults = computed(() => capabilities.value?.readResults === true)
  const canRecomputeRoute = computed(() => capabilities.value?.routeRecompute === true)
  const canSubmitAnalysis = computed(() => capabilities.value?.analysisSubmit === true)
  const canBackup = computed(() => capabilities.value?.backupExecute === true)
  const exportFormats = computed(() => capabilities.value?.exportFormats ?? [])

  /** 能力原因说明：能力不可用时必须能说清原因，而不是给一个灰按钮。 */
  const reasons = computed<Record<string, string>>(() => capabilities.value?.reasons ?? {})

  function reasonFor(key: keyof Capabilities | string): string | null {
    const value = reasons.value[key as string]
    return typeof value === 'string' && value.trim() !== '' ? value : null
  }

  function errorCode(): string | null {
    return error.value === null ? null : error.value.code
  }

  /**
   * 读取能力清单。失败时保留错误，不回退示例能力，也不假装成功。
   * @param force 为 true 时忽略已有结果强制重读（“重试”按钮使用）。
   */
  async function loadCapabilities(force = false): Promise<void> {
    if (status.value === 'loading') return
    if (!force && status.value === 'ready') return
    status.value = 'loading'
    error.value = null
    failedAt.value = null
    try {
      const envelope = await getRepositories().capabilities.getCapabilities()
      capabilities.value = envelope.data
      context.value = envelope.meta
      mode.value = envelope.meta.mode
      status.value = 'ready'
    } catch (unknownError) {
      capabilities.value = null
      context.value = null
      status.value = 'failed'
      failedAt.value = new Date().toISOString()
      error.value = isRepositoryError(unknownError)
        ? unknownError
        : toRepositoryError(unknownError, 'UNKNOWN')
    }
  }

  function reset(): void {
    status.value = 'idle'
    capabilities.value = null
    context.value = null
    error.value = null
    failedAt.value = null
  }

  return {
    mode,
    status,
    error,
    capabilities,
    context,
    failedAt,
    modeLabel,
    modeDescription,
    sourceUrl,
    isSample,
    isLoading,
    isFailed,
    isReady,
    snapshotId,
    scopeLabel,
    generatedAt,
    boundaryVersion,
    readOnly,
    canSpatialQuery,
    canAttributeQuery,
    canReadResults,
    canRecomputeRoute,
    canSubmitAnalysis,
    canBackup,
    exportFormats,
    reasons,
    reasonFor,
    errorCode,
    loadCapabilities,
    reset,
  }
})
