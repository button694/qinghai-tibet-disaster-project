/**
 * 正式接口（api 模式）适配器骨架。
 *
 * 路径与查询参数严格按 02 §4「拟定接口」实现，统一前缀 `/api/v1`。
 *
 * 三条硬性约束：
 * 1. **绝不回退示例数据**：任何失败都抛 `RepositoryError`，由页面显示失败状态。
 * 2. 响应必须是 `{ data, meta, requestId }` 信封；缺字段即报 `INVALID_RESPONSE`，不做“猜测式解析”。
 * 3. 只读浏览类接口用 GET；查询用 `POST /queries` 后按 `queryId` 继续分页，不在前端重算。
 */
import type {
  Capabilities,
  Dataset,
  DataSource,
  Dictionary,
  Envelope,
  ExposureSummary,
  FeatureDetail,
  FeaturePage,
  FeatureRef,
  ImportLog,
  LayerDefinition,
  Legend,
  OverviewData,
  Page,
  QueryInput,
  QueryResult,
  Region,
  ResultDetail,
  ResultStatistics,
  ResultSummary,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import { RepositoryError, type Repositories } from '@/repositories/types'
import { buildUrl, responseError } from '@/repositories/errors'

export interface HttpRepositoryOptions {
  /** 接口前缀，例如 `/api/v1`。 */
  baseUrl: string
  /** 可注入的 fetch，便于单测与联调替换。 */
  fetcher?: typeof fetch
  /** 附加请求头（如鉴权令牌）。 */
  headers?: Record<string, string>
  /** 默认分页大小，缺省与契约示例保持一致。 */
  defaultPageSize?: number
}

type QueryValue = string | number | boolean | undefined | null

interface RequestSpec {
  method?: 'GET' | 'POST'
  path: string
  query?: Record<string, QueryValue>
  body?: unknown
  signal?: AbortSignal
}

export function createHttpRepositories(options: HttpRepositoryOptions): Repositories {
  const baseUrl = options.baseUrl
  const rawFetch = options.fetcher ?? globalThis.fetch
  const defaultPageSize = options.defaultPageSize ?? 20
  const extraHeaders = options.headers ?? {}

  /** 发送请求并校验信封结构；失败一律抛 RepositoryError。 */
  async function request<T>(spec: RequestSpec): Promise<Envelope<T>> {
    if (typeof rawFetch !== 'function') {
      throw new RepositoryError({
        code: 'NOT_IMPLEMENTED',
        message: '当前运行环境不支持 fetch，无法访问正式接口。',
      })
    }
    const url = buildUrl(baseUrl, spec.path, spec.query)
    const headers: Record<string, string> = { Accept: 'application/json', ...extraHeaders }
    const init: RequestInit = { method: spec.method ?? 'GET', headers }
    if (spec.signal) init.signal = spec.signal
    if (spec.body !== undefined) {
      headers['Content-Type'] = 'application/json'
      init.body = JSON.stringify(spec.body)
    }

    let response: Response
    try {
      response = await rawFetch(url, init)
    } catch (error) {
      if (error instanceof DOMException && error.name === 'AbortError') throw error
      throw new RepositoryError({
        code: 'NETWORK_ERROR',
        message: `无法连接正式接口：${url}`,
        retryable: true,
        cause: error,
      })
    }
    if (!response.ok) throw await responseError(response, url)
    if (response.status === 204) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: `${url} 返回空响应；契约要求返回 data/meta 信封。`,
        httpStatus: 204,
      })
    }

    let body: unknown
    try {
      body = (await response.json()) as unknown
    } catch (error) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: `正式接口返回的不是合法 JSON：${url}`,
        httpStatus: response.status,
        cause: error,
      })
    }
    return requireEnvelope<T>(body, url)
  }

  function pageQuery(page?: number, pageSize?: number): Record<string, QueryValue> {
    return { page: page ?? 1, pageSize: pageSize ?? defaultPageSize }
  }

  const layers: Repositories['layers'] = {
    async listLayers(query, requestOptions) {
      const spec: RequestSpec = { path: '/layers' }
      if (query?.theme) spec.query = { theme: query.theme }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<LayerDefinition[]>(spec)
    },

    /**
     * 02 §4 未单独定义 `GET /layers/:id`：这里读取图层列表后按 id 取用，
     * 保证行为与 mock 一致，待后端补充单条接口后替换（见 docs/API_MAPPING.md）。
     */
    async getLayer(layerId, requestOptions) {
      const envelope = await layers.listLayers(undefined, requestOptions)
      const layer = envelope.data.find((item) => item.id === layerId)
      if (!layer) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到图层 ${layerId}。`,
          details: { layerId },
        })
      }
      return { ...envelope, data: layer }
    },

    /**
     * 02 §4 未定义要素列表接口：借用 `POST /queries`（空筛选条件）获取分页要素，
     * 这样分页总数由服务端给出，不使用 `items.length` 冒充总数。
     */
    async listFeatures(layerId, query, requestOptions) {
      const input: QueryInput = {
        layerId,
        filters: [],
        page: query?.page ?? 1,
        pageSize: query?.pageSize ?? defaultPageSize,
      }
      if (query?.datasetVersion) input.datasetVersion = query.datasetVersion
      if (query?.sort) input.sort = query.sort
      if (query?.simplifyMeters !== undefined) input.simplifyMeters = query.simplifyMeters
      const spec: RequestSpec = { method: 'POST', path: '/queries', body: input }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      const envelope = await request<QueryResult>(spec)
      const page: FeaturePage = {
        ...envelope.data.rows,
        geometrySimplified: envelope.data.geometrySimplified,
        simplifyToleranceMeters: envelope.data.simplifyToleranceMeters,
      }
      return { data: page, meta: envelope.meta, requestId: envelope.requestId }
    },

    async getFeature(ref: FeatureRef, requestOptions) {
      const spec: RequestSpec = {
        path: `/layers/${encodeURIComponent(ref.layerId)}/features/${encodeURIComponent(ref.id)}`,
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<FeatureDetail>(spec)
    },

    async getLegend(legendId: string, requestOptions) {
      const spec: RequestSpec = { path: `/legends/${encodeURIComponent(legendId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Legend>(spec)
    },
  }

  const queries: Repositories['queries'] = {
    async runQuery(input: QueryInput, requestOptions) {
      const spec: RequestSpec = { method: 'POST', path: '/queries', body: input }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<QueryResult>(spec)
    },

    async getQuery(queryId: string, page, requestOptions) {
      const spec: RequestSpec = {
        path: `/queries/${encodeURIComponent(queryId)}`,
        query: pageQuery(page.page, page.pageSize),
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<QueryResult>(spec)
    },
  }

  const results: Repositories['results'] = {
    async listResults(query, requestOptions) {
      const spec: RequestSpec = {
        path: '/results',
        query: {
          ...pageQuery(query?.page, query?.pageSize),
          kind: query?.kind,
          status: query?.status,
          scenarioYear: query?.scenarioYear,
        },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Page<ResultSummary>>(spec)
    },

    async getResult(resultId: string, requestOptions) {
      const spec: RequestSpec = { path: `/results/${encodeURIComponent(resultId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<ResultDetail>(spec)
    },

    async getStatistics(resultId: string, requestOptions) {
      const spec: RequestSpec = {
        path: `/results/${encodeURIComponent(resultId)}/statistics`,
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<ResultStatistics>(spec)
    },

    async listAffectedFeatures(resultId: string, query, requestOptions) {
      const spec: RequestSpec = {
        path: `/results/${encodeURIComponent(resultId)}/affected-features`,
        query: { ...pageQuery(query?.page, query?.pageSize), category: query?.category },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Page<FeatureDetail>>(spec)
    },

    /**
     * 02 §4 未定义暴露统计接口：本工程拟定 `GET /results/:id/exposure-summary`（D-031）。
     * 后端未提供时返回 404，界面显示「未接入」而不是自行拼凑统计。
     */
    async getExposureSummary(resultId: string, requestOptions) {
      const spec: RequestSpec = {
        path: `/results/${encodeURIComponent(resultId)}/exposure-summary`,
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<ExposureSummary>(spec)
    },

    async listRoutes(resultId: string, query, requestOptions) {
      const spec: RequestSpec = {
        path: `/results/${encodeURIComponent(resultId)}/routes`,
        query: {
          ...pageQuery(query?.page, query?.pageSize),
          ...(query?.hazardPointId ? { hazardPointId: query.hazardPointId } : {}),
        },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Page<RouteSummary>>(spec)
    },

    async getRoute(routeId: string, requestOptions) {
      const spec: RequestSpec = { path: `/routes/${encodeURIComponent(routeId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<RouteDetail>(spec)
    },
  }

  const catalog: Repositories['catalog'] = {
    async listDatasets(query, requestOptions) {
      const spec: RequestSpec = {
        path: '/datasets',
        query: {
          ...pageQuery(query?.page, query?.pageSize),
          theme: query?.theme,
          type: query?.dataType,
          keyword: query?.keyword,
        },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Page<Dataset>>(spec)
    },

    async getDataset(datasetId: string, requestOptions) {
      const spec: RequestSpec = { path: `/datasets/${encodeURIComponent(datasetId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Dataset>(spec)
    },

    async getSource(sourceId: string, requestOptions) {
      const spec: RequestSpec = { path: `/sources/${encodeURIComponent(sourceId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<DataSource>(spec)
    },

    async getDictionary(dictionaryId: string, requestOptions) {
      const spec: RequestSpec = { path: `/dictionaries/${encodeURIComponent(dictionaryId)}` }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Dictionary>(spec)
    },

    async listRegions(query, requestOptions) {
      const spec: RequestSpec = { path: '/regions' }
      const regionQuery: Record<string, QueryValue> = {}
      if (query?.parentId) regionQuery.parentId = query.parentId
      if (query?.level) regionQuery.level = query.level
      if (Object.keys(regionQuery).length > 0) spec.query = regionQuery
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Region[]>(spec)
    },

    async listImports(query, requestOptions) {
      const spec: RequestSpec = {
        path: '/imports',
        query: { ...pageQuery(query?.page, query?.pageSize), datasetId: query?.datasetId },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Page<ImportLog>>(spec)
    },
  }

  const overview: Repositories['overview'] = {
    async getOverview(query, requestOptions) {
      const spec: RequestSpec = {
        path: '/overview',
        query: {
          regionId: query?.regionId,
          resultId: query?.resultId,
          scenarioYear: query?.scenarioYear,
        },
      }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<OverviewData>(spec)
    },
  }

  const capabilities: Repositories['capabilities'] = {
    async getCapabilities(requestOptions) {
      const spec: RequestSpec = { path: '/capabilities' }
      if (requestOptions?.signal) spec.signal = requestOptions.signal
      return request<Capabilities>(spec)
    },
  }

  return { mode: 'api', layers, queries, results, catalog, overview, capabilities }
}

/* ------------------------------------------------------------------ *
 * 信封校验
 * ------------------------------------------------------------------ */

const REQUIRED_META_KEYS = [
  'mode',
  'snapshotId',
  'generatedAt',
  'scopeLabel',
  'boundaryVersion',
  'datasetVersions',
] as const

/**
 * 严格校验 `{ data, meta, requestId }` 信封（02 §4）。
 * 缺少 `meta` 关键字段时停止解析：宁可报错，也不给页面一个来源不明的数字。
 */
export function requireEnvelope<T>(body: unknown, url: string): Envelope<T> {
  if (body === null || typeof body !== 'object') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `正式接口响应不是对象：${url}`,
      details: { url },
    })
  }
  const record = body as Record<string, unknown>
  if (!('data' in record)) {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `正式接口响应缺少 data 字段：${url}`,
      details: { url },
    })
  }
  const meta = record.meta
  if (meta === null || typeof meta !== 'object') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `正式接口响应缺少 meta 上下文（模式、快照、范围），已停止解析：${url}`,
      details: { url },
    })
  }
  const missing = REQUIRED_META_KEYS.filter((key) => {
    const value = (meta as Record<string, unknown>)[key]
    return value === undefined || value === null
  })
  if (missing.length > 0) {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `正式接口响应 meta 缺少字段：${missing.join('、')}（${url}）`,
      details: { url, missing },
    })
  }
  const requestId = record.requestId
  if (typeof requestId !== 'string' || requestId === '') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `正式接口响应缺少 requestId，无法追溯来源：${url}`,
      details: { url },
    })
  }
  return body as Envelope<T>
}
