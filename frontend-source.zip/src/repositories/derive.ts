/**
 * 派生计算（纯函数）：所有统计、图表与指标都从同一份要素现场算出。
 *
 * 规则（01 §6.3、02 §2.9）：
 * 1. 示例包内不存计数；`results.json` 只登记成果元数据与口径说明。
 * 2. 统计与图表必须由同一个函数产生，避免界面与导出口径不一致。
 * 3. `null` 永远不等于 0：缺指标的对象记为“数据不足”，不并入低风险。
 * 4. 无几何的记录不参与任何空间统计，但会计入“未定位记录数”，避免静默丢失。
 */
import type { Geometry } from 'geojson'
import type {
  CategoryStatistics,
  FeaturePropertyValue,
  FeatureRef,
  LonLat,
  Metric,
  RiskLevel,
} from '@/domain/types'
import { RISK_LEVEL_COLOR, RISK_LEVEL_LABEL, RISK_LEVEL_ORDER, toRiskLevel } from '@/domain/risk'
import {
  classifyPointInGeometry,
  clippedLengthMeters,
  geometryFamilyOf,
  polylineLengthMeters,
  representativeLonLat,
} from '@/domain/geometry'

/* ------------------------------------------------------------------ *
 * 几何辅助
 * ------------------------------------------------------------------ */

/** 取出 Polygon / MultiPolygon 的外环；其他几何返回空数组。 */
export function outerRingsOf(geometry: Geometry | null | undefined): LonLat[][] {
  if (!geometry) return []
  if (geometry.type === 'Polygon') {
    const ring = geometry.coordinates[0]
    return ring && ring.length >= 3 ? [ring as LonLat[]] : []
  }
  if (geometry.type === 'MultiPolygon') {
    return geometry.coordinates
      .map((polygon) => polygon[0] as LonLat[] | undefined)
      .filter((ring): ring is LonLat[] => Boolean(ring && ring.length >= 3))
  }
  return []
}

/** 判断外环是否为凸多边形（决定能否使用精确裁剪）。 */
export function isConvexRing(ring: LonLat[]): boolean {
  if (ring.length < 4) return false
  const points = ring.slice(0, -1)
  let sign = 0
  for (let index = 0; index < points.length; index += 1) {
    const a = points[index] as LonLat
    const b = points[(index + 1) % points.length] as LonLat
    const c = points[(index + 2) % points.length] as LonLat
    const cross = (b[0] - a[0]) * (c[1] - b[1]) - (b[1] - a[1]) * (c[0] - b[0])
    if (Math.abs(cross) < 1e-12) continue
    const current = cross > 0 ? 1 : -1
    if (sign === 0) sign = current
    else if (sign !== current) return false
  }
  return sign !== 0
}

/* ------------------------------------------------------------------ *
 * 受影响对象（空间关系派生）
 * ------------------------------------------------------------------ */

export interface ImpactAreaInput {
  ref: FeatureRef
  label: string
  geometry: Geometry | null
}

export interface CandidateInput {
  ref: FeatureRef
  layerLabel: string
  title: string
  entityKey: string | null
  geometry: Geometry | null
  properties: Record<string, FeaturePropertyValue>
}

export interface AffectedRecord {
  ref: FeatureRef
  layerLabel: string
  title: string
  entityKey: string | null
  areaRef: FeatureRef
  areaLabel: string
  /** 判定方法，导出与说明中如实标注，避免把近似判定说成精算。 */
  matchMethod: 'point-in-polygon' | 'representative-point-in-polygon'
}

export interface AffectedDerivation {
  records: AffectedRecord[]
  /** 去重后的对象标识（无 entityKey 时退化为 `layerId:id`）。 */
  entityKeys: string[]
  recordCount: number
  entityCount: number
  /** 无几何、无法参与空间统计的记录数（单独计数，不并入受影响对象）。 */
  unlocatedCount: number
  /** 无法参与判定的范围（非面几何）。 */
  unsupportedAreaRefs: FeatureRef[]
  /** 使用了代表点近似判定的记录数。 */
  approximateCount: number
  notes: string[]
}

function entityKeyOf(feature: CandidateInput): string {
  return feature.entityKey && feature.entityKey.trim() !== ''
    ? `entity:${feature.entityKey}`
    : `ref:${feature.ref.layerId}:${feature.ref.id}`
}

/**
 * 逐范围判定受影响对象。
 * 点要素用点在面内判定；面要素用代表点判定并计入 `approximateCount`（如实标注为近似）。
 */
export function deriveAffectedRecords(
  areas: ImpactAreaInput[],
  candidates: CandidateInput[],
): AffectedDerivation {
  const records: AffectedRecord[] = []
  const unsupportedAreaRefs: FeatureRef[] = []
  let unlocatedCount = 0
  let approximateCount = 0
  let polygonAreaCount = 0

  for (const area of areas) {
    const rings = outerRingsOf(area.geometry)
    if (rings.length === 0) {
      unsupportedAreaRefs.push(area.ref)
      continue
    }
    polygonAreaCount += 1
    for (const candidate of candidates) {
      const family = geometryFamilyOf(candidate.geometry)
      if (!candidate.geometry) {
        unlocatedCount += 1
        continue
      }
      if (family !== 'Point' && family !== 'Polygon') continue
      const point =
        family === 'Point'
          ? (representativeLonLat(candidate.geometry) as LonLat | null)
          : representativeLonLat(candidate.geometry)
      if (!point) continue
      if (classifyPointInGeometry(point, area.geometry) !== 'inside') continue
      if (family === 'Polygon') approximateCount += 1
      records.push({
        ref: candidate.ref,
        layerLabel: candidate.layerLabel,
        title: candidate.title,
        entityKey: candidate.entityKey,
        areaRef: area.ref,
        areaLabel: area.label,
        matchMethod: family === 'Point' ? 'point-in-polygon' : 'representative-point-in-polygon',
      })
    }
  }

  // 同一对象被多个范围覆盖时只保留一条记录（示例范围互不重叠，这里仍做防御性去重）
  const deduped: AffectedRecord[] = []
  const seen = new Set<string>()
  for (const record of records) {
    const key = `${entityKeyOf({
      ref: record.ref,
      layerLabel: record.layerLabel,
      title: record.title,
      entityKey: record.entityKey,
      geometry: null,
      properties: {},
    })}|${record.areaRef.layerId}:${record.areaRef.id}`
    if (seen.has(key)) continue
    seen.add(key)
    deduped.push(record)
  }

  const entityKeys = [
    ...new Set(
      deduped.map((record) =>
        entityKeyOf({
          ref: record.ref,
          layerLabel: record.layerLabel,
          title: record.title,
          entityKey: record.entityKey,
          geometry: null,
          properties: {},
        }),
      ),
    ),
  ]

  const notes: string[] = []
  if (approximateCount > 0) {
    notes.push(
      `有面状记录按代表点参与范围判定（近似口径，共 ${approximateCount} 条），导出时标注判定方法。`,
    )
  }
  if (unlocatedCount > 0) {
    notes.push(`有记录未登记位置信息，不参与空间统计，单独计数。`)
  }
  if (unsupportedAreaRefs.length > 0) {
    notes.push(`有影响范围未登记面几何，未参与判定。`)
  }
  void polygonAreaCount

  return {
    records: deduped,
    entityKeys,
    recordCount: deduped.length,
    entityCount: entityKeys.length,
    unlocatedCount,
    unsupportedAreaRefs,
    approximateCount,
    notes,
  }
}

/* ------------------------------------------------------------------ *
 * 受影响道路长度（裁剪派生，不用直线近似）
 * ------------------------------------------------------------------ */

export interface RoadInput {
  ref: FeatureRef
  label: string
  coords: LonLat[]
}

export interface ClippedLengthDerivation {
  totalMeters: number
  byArea: Array<{ areaRef: FeatureRef; areaLabel: string; meters: number; exact: boolean }>
  /** 存在非凸范围时退回采样口径。 */
  approximate: boolean
  notes: string[]
}

/** 逐范围裁剪道路折线并累加长度；范围互不重叠时不会重复计数。 */
export function deriveClippedRoadLength(
  areas: ImpactAreaInput[],
  roads: RoadInput[],
): ClippedLengthDerivation {
  const byArea: ClippedLengthDerivation['byArea'] = []
  const notes: string[] = []
  let approximate = false
  let total = 0

  for (const area of areas) {
    const rings = outerRingsOf(area.geometry)
    if (rings.length === 0) continue
    const convex = rings.every((ring) => isConvexRing(ring))
    if (!convex) approximate = true
    let meters = 0
    for (const road of roads) {
      meters += clippedLengthMeters(road.coords, rings)
    }
    total += meters
    byArea.push({ areaRef: area.ref, areaLabel: area.label, meters, exact: convex })
  }

  if (approximate) {
    notes.push('有影响范围为非凸多边形，长度按多边形裁剪口径计算，可能存在边界近似。')
  }
  notes.push('受影响道路长度按道路折线在影响范围内的裁剪长度累加，不使用直线距离。')

  return { totalMeters: total, byArea, approximate, notes }
}

/** 路线里程与几何长度的一致性核对（不一致时如实报告，不篡改数值）。 */
export function verifyRouteDistance(
  coords: LonLat[] | null,
  distanceMeters: number | null,
): { computedMeters: number | null; consistent: boolean | null } {
  if (!coords || coords.length < 2 || distanceMeters === null) {
    return { computedMeters: null, consistent: null }
  }
  const computedMeters = polylineLengthMeters(coords)
  const consistent =
    Math.abs(computedMeters - distanceMeters) <= Math.max(1, distanceMeters * 0.005)
  return { computedMeters, consistent }
}

/* ------------------------------------------------------------------ *
 * 统计
 * ------------------------------------------------------------------ */

/** 按固定等级顺序统计风险分布；缺指标记为“数据不足”，不并入低风险。 */
export function deriveRiskDistribution(
  zones: Array<{ riskLevel: string | null }>,
  unit: string | null,
): CategoryStatistics[] {
  const counts = new Map<RiskLevel, number>()
  for (const zone of zones) {
    const level = toRiskLevel(zone.riskLevel)
    counts.set(level, (counts.get(level) ?? 0) + 1)
  }
  return [...counts.entries()]
    .sort((a, b) => RISK_LEVEL_ORDER[a[0]] - RISK_LEVEL_ORDER[b[0]])
    .map(([level, count]) => ({
      key: level,
      label: RISK_LEVEL_LABEL[level],
      count,
      unit,
      color: RISK_LEVEL_COLOR[level],
    }))
}

/** 按任意取值计数，保持首次出现顺序，用于“按类别统计”。 */
export function deriveCategoryCounts(
  items: Array<{ key: string | null; label: string | null; color?: string | null }>,
  unit: string | null,
): CategoryStatistics[] {
  const counts = new Map<string, CategoryStatistics>()
  for (const item of items) {
    const key = item.key ?? 'unknown'
    const existing = counts.get(key)
    if (existing) existing.count += 1
    else
      counts.set(key, {
        key,
        label: item.label ?? '未登记',
        count: 1,
        unit,
        color: item.color ?? null,
      })
  }
  return [...counts.values()]
}

/* ------------------------------------------------------------------ *
 * 指标
 * ------------------------------------------------------------------ */

export interface PopulationInput {
  /** 人口数据集是否有可用服务：不可用时指标记为“未提供”，绝不补零。 */
  serviceAvailable: boolean
  value: number | null
  year: number | null
  unit: string | null
  note?: string
}

export function deriveExposureMetrics(input: {
  scopeLabel: string
  matchedRecordCount: number
  uniqueEntityCount: number
  unlocatedCount: number
  affectedRoadMeters: number | null
  population: PopulationInput
  method: string
}): Metric[] {
  const population: Metric = input.population.serviceAvailable
    ? {
        key: 'population',
        label: '受影响常住人口',
        value: input.population.value,
        unit: input.population.unit,
        status: input.population.value === null ? 'notProvided' : 'known',
        year: input.population.year ?? undefined,
        scopeLabel: input.scopeLabel,
        precisionNote: input.population.note,
      }
    : {
        key: 'population',
        label: '受影响常住人口',
        value: null,
        unit: input.population.unit,
        status: 'notProvided',
        scopeLabel: input.scopeLabel,
        precisionNote:
          input.population.note ?? '人口数据集当前无可用服务，未做人口统计，界面不显示估算值。',
      }

  const road: Metric = {
    key: 'affectedRoadLength',
    label: '受影响道路长度',
    value: input.affectedRoadMeters,
    unit: '米',
    status: input.affectedRoadMeters === null ? 'noData' : 'known',
    method: '按道路折线在影响范围内的裁剪长度累加（球面长度），不使用直线距离。',
    scopeLabel: input.scopeLabel,
  }

  return [
    {
      key: 'matchedRecords',
      label: '受影响记录数',
      value: input.matchedRecordCount,
      unit: '条',
      status: 'known',
      method: input.method,
      scopeLabel: input.scopeLabel,
    },
    {
      key: 'uniqueEntities',
      label: '受影响对象数（按对象标识去重）',
      value: input.uniqueEntityCount,
      unit: '个',
      status: 'known',
      method: '同一对象的点、面记录按对象标识去重，只计一次。',
      scopeLabel: input.scopeLabel,
    },
    road,
    population,
    {
      key: 'unlocatedRecords',
      label: '未登记位置的记录数',
      value: input.unlocatedCount,
      unit: '条',
      status: 'known',
      method: '无位置信息的记录不参与空间统计，单独计数。',
      scopeLabel: input.scopeLabel,
    },
  ]
}

export function deriveRouteMetrics(
  routes: Array<{ id: string; label: string; status: string; distanceMeters: number | null }>,
  scopeLabel: string,
): Metric[] {
  const reachable = routes.filter((route) => route.status === 'reachable')
  const unreachable = routes.filter((route) => route.status !== 'reachable')
  const withDistance = reachable.filter((route) => route.distanceMeters !== null)
  const shortest = withDistance.reduce<number | null>((min, route) => {
    const value = route.distanceMeters as number
    return min === null || value < min ? value : min
  }, null)

  return [
    {
      key: 'routeCount',
      label: '已存路线数',
      value: routes.length,
      unit: '条',
      status: 'known',
      method: '读取已存路线成果，不在前端重算路径。',
      scopeLabel,
    },
    {
      key: 'reachableCount',
      label: '可达路线数',
      value: reachable.length,
      unit: '条',
      status: 'known',
      scopeLabel,
    },
    {
      key: 'unreachableCount',
      label: '不可达路线数',
      value: unreachable.length,
      unit: '条',
      status: reachable.length + unreachable.length === 0 ? 'noData' : 'known',
      precisionNote:
        unreachable.length > 0 ? '已存成果标记为不可达，界面不提供路径几何与通行时间。' : undefined,
      scopeLabel,
    },
    {
      key: 'shortestDistance',
      label: '可达路线最短里程',
      value: shortest,
      unit: '米',
      status: shortest === null ? 'notProvided' : 'known',
      method: '按已存成果中的里程字段展示，并与几何长度核对一致性。',
      scopeLabel,
    },
  ]
}

export function deriveOverviewMetrics(input: {
  scopeLabel: string
  zoneCount: number
  gradedZoneCount: number
  insufficientZoneCount: number
  highRiskCount: number
  affectedEntityCount: number | null
  snapshotNote: string
}): Metric[] {
  return [
    {
      key: 'riskZoneCount',
      label: '已登记风险区对象数',
      value: input.zoneCount,
      unit: '个',
      status: 'known',
      scopeLabel: input.scopeLabel,
      precisionNote: input.snapshotNote,
    },
    {
      key: 'gradedZoneCount',
      label: '已完成分级的风险区数',
      value: input.gradedZoneCount,
      unit: '个',
      status: 'known',
      method: '只有指标完整的对象才计入分级；缺指标的记为“数据不足”，不并入低风险。',
      scopeLabel: input.scopeLabel,
    },
    {
      key: 'insufficientZoneCount',
      label: '数据不足的风险区数',
      value: input.insufficientZoneCount,
      unit: '个',
      status: input.zoneCount === 0 ? 'noData' : 'known',
      scopeLabel: input.scopeLabel,
    },
    {
      key: 'highRiskCount',
      label: '高与较高风险区数',
      value: input.highRiskCount,
      unit: '个',
      status: input.gradedZoneCount === 0 ? 'noData' : 'known',
      method: '高风险口径为“高”与“较高”两级。',
      scopeLabel: input.scopeLabel,
    },
    {
      key: 'affectedEntityCount',
      label: '受影响对象数（按对象标识去重）',
      value: input.affectedEntityCount,
      unit: '个',
      status: input.affectedEntityCount === null ? 'noData' : 'known',
      method: '由已存影响范围与承灾体要素现场派生，点面双表达按对象标识去重。',
      scopeLabel: input.scopeLabel,
    },
  ]
}
