/**
 * HTTP 状态与错误体到 `RepositoryError` 的统一映射。
 *
 * mock/snapshot 的 JSON 包加载与正式 HTTP 适配器共用本文件，
 * 保证同一个 503 在任何模式下都得到同一个错误码与同一句中文说明。
 */
import { RepositoryError, type RepositoryErrorCode } from '@/repositories/types'

/** 已知错误码集合，用于判断服务端返回的 code 是否可透传。 */
const KNOWN_CODES = new Set<string>([
  'SERVICE_UNAVAILABLE',
  'NOT_FOUND',
  'UNAUTHORIZED',
  'FORBIDDEN',
  'QUERY_EXPIRED',
  'INVALID_PARAMETER',
  'NO_ROUTE',
  'NOT_IMPLEMENTED',
  'INVALID_RESPONSE',
  'SNAPSHOT_MISSING',
])

export function isKnownErrorCode(code: string): code is RepositoryErrorCode {
  return KNOWN_CODES.has(code)
}

/** 按 HTTP 状态码给出默认错误码。503 与 5xx 一律视为服务不可用且可重试。 */
export function mapHttpStatus(status: number): { code: RepositoryErrorCode; retryable: boolean } {
  if (status === 404) return { code: 'NOT_FOUND', retryable: false }
  if (status === 401) return { code: 'UNAUTHORIZED', retryable: false }
  if (status === 403) return { code: 'FORBIDDEN', retryable: false }
  if (status === 400 || status === 422) return { code: 'INVALID_PARAMETER', retryable: false }
  // 02 §4.2：查询过期/快照变化为 409 或 410，两种状态码语义一致。
  if (status === 409 || status === 410) return { code: 'QUERY_EXPIRED', retryable: false }
  if (status === 501) return { code: 'NOT_IMPLEMENTED', retryable: false }
  if (status >= 500) return { code: 'SERVICE_UNAVAILABLE', retryable: true }
  return { code: 'UNKNOWN', retryable: false }
}

export function httpStatusError(status: number, url?: string): RepositoryError {
  const { code, retryable } = mapHttpStatus(status)
  return new RepositoryError({
    code,
    message: url ? `数据服务返回 HTTP ${status}：${url}` : `数据服务返回 HTTP ${status}。`,
    retryable,
    httpStatus: status,
  })
}

/**
 * 解析服务端错误体（02 §4.2：`{ error: { code, message, requestId } }`）。
 * 无法解析时退回状态码映射，绝不吞掉错误。
 */
export async function responseError(response: Response, url?: string): Promise<RepositoryError> {
  const fallback = httpStatusError(response.status, url)
  try {
    const body = (await response.json()) as unknown
    if (body !== null && typeof body === 'object') {
      const envelope = body as { error?: unknown; requestId?: unknown }
      const error = envelope.error
      if (error !== null && typeof error === 'object') {
        const raw = error as {
          code?: unknown
          message?: unknown
          retryable?: unknown
          details?: unknown
          requestId?: unknown
        }
        const code = typeof raw.code === 'string' ? raw.code : fallback.code
        const message = typeof raw.message === 'string' ? raw.message : fallback.message
        return new RepositoryError({
          code,
          message,
          retryable: typeof raw.retryable === 'boolean' ? raw.retryable : fallback.retryable,
          httpStatus: response.status,
          requestId:
            typeof envelope.requestId === 'string'
              ? envelope.requestId
              : typeof raw.requestId === 'string'
                ? raw.requestId
                : undefined,
          details:
            raw.details !== null && typeof raw.details === 'object' && !Array.isArray(raw.details)
              ? (raw.details as Record<string, unknown>)
              : undefined,
        })
      }
    }
  } catch {
    // 错误体不是 JSON：使用状态码映射结果。
  }
  return fallback
}

/** 生成稳定的请求地址：保留 base 的子路径，避免出现 `//`。 */
export function buildUrl(
  baseUrl: string,
  path: string,
  query?: Record<string, string | number | boolean | undefined | null>,
): string {
  const base = baseUrl.endsWith('/') ? baseUrl.slice(0, -1) : baseUrl
  const suffix = path.startsWith('/') ? path : `/${path}`
  const search = new URLSearchParams()
  for (const [key, value] of Object.entries(query ?? {})) {
    if (value === undefined || value === null || value === '') continue
    search.append(key, String(value))
  }
  const queryString = search.toString()
  return queryString === '' ? `${base}${suffix}` : `${base}${suffix}?${queryString}`
}
