/**
 * 数据层入口：按运行模式组装 Repository（01 §6.3、03 §4）。
 *
 * 页面只 import 本文件拿到的 `Repositories`，不关心背后是 JSON 数据包还是正式接口。
 * “模式只改配置”在这里落地：`VITE_DATA_MODE` 一变，实现整体切换，页面代码零改动。
 *
 * 模式与实现的对应关系：
 * - `mock`     → JSON 数据包（`public/demo/`），界面持续标识“示例数据”，全部写能力关闭
 * - `snapshot` → JSON 数据包（成果快照目录），包缺失或缺文件时报 `SNAPSHOT_MISSING`
 * - `api`      → HTTP 正式接口（`/api/v1`），失败即失败，**不回退示例数据**
 */
import { appEnv, type AppEnv } from '@/config/env'
import type { DataMode } from '@/domain/types'
import type { JsonFetcher } from '@/repositories/json/loader'
import { createJsonPackageRepository } from '@/repositories/json/packageRepository'
import { createHttpRepositories } from '@/repositories/http/httpRepository'
import type { Repositories } from '@/repositories/types'

export interface RepositoryOverrides {
  /** 注入 JSON 包加载器（单测从磁盘读取示例包）。 */
  jsonFetcher?: JsonFetcher
  /** 注入 HTTP 实现（联调或单测模拟失败）。 */
  httpFetcher?: typeof fetch
}

/** 当前模式下实际使用的数据来源地址，用于界面“数据来源”说明。 */
export function dataSourceUrl(mode: DataMode, env: AppEnv = appEnv): string {
  if (mode === 'api') return env.apiBaseUrl
  if (mode === 'snapshot') return env.snapshotBaseUrl
  return env.demoBaseUrl
}

/** 该模式是否属于“示例数据”（用于强制只读身份与持续标识）。 */
export function isSampleMode(mode: DataMode): boolean {
  return mode === 'mock'
}

export function createRepositories(
  env: AppEnv = appEnv,
  overrides: RepositoryOverrides = {},
): Repositories {
  switch (env.dataMode) {
    case 'api':
      return createHttpRepositories({ baseUrl: env.apiBaseUrl, fetcher: overrides.httpFetcher })
    case 'snapshot':
      return createJsonPackageRepository({
        mode: 'snapshot',
        baseUrl: env.snapshotBaseUrl,
        // 快照模式要求数据包声明为非示例包：拿到示例包直接报 SNAPSHOT_MISSING。
        requireNonSamplePackage: true,
        ...(overrides.jsonFetcher ? { fetcher: overrides.jsonFetcher } : {}),
      })
    case 'mock':
    default:
      return createJsonPackageRepository({
        mode: 'mock',
        baseUrl: env.demoBaseUrl,
        ...(overrides.jsonFetcher ? { fetcher: overrides.jsonFetcher } : {}),
      })
  }
}

let current: Repositories | null = null

/** 应用级单例：同一模式只创建一次，避免重复请求数据包。 */
export function getRepositories(): Repositories {
  if (current === null) current = createRepositories()
  return current
}

/** 允许应用启动或测试替换实现（切换模式时使用）。 */
export function setRepositories(repositories: Repositories | null): void {
  current = repositories
}

export type { Repositories }
