/** Static transport for the real, dated export. It never contacts SQL Server. */
import type { FeatureDetail, QueryInput } from '@/domain/types'

type Json = Record<string, any>
const enabled = import.meta.env.VITE_PUBLISHED_SNAPSHOT === 'true'
const assetBase = import.meta.env.BASE_URL
const nativeFetch = globalThis.fetch.bind(globalThis)
const cached = new Map<string, Promise<any>>()
function asset(name: string): Promise<any> {
  if (!cached.has(name)) cached.set(name, nativeFetch(`${assetBase}published-snapshot/${name}`).then(r => {
    if (!r.ok) throw new Error(`成果文件读取失败：${name}`)
    return r.json()
  }))
  return cached.get(name)!
}
function page(items: any[], query: URLSearchParams) {
  const n = Math.max(1, Number(query.get('page') ?? 1))
  const size = Math.max(1, Number(query.get('pageSize') ?? 20))
  return {items: items.slice((n - 1) * size, n * size), total: items.length, page: n, pageSize: size}
}
function json(data: unknown, status = 200) {
  return new Response(JSON.stringify(data), {status, headers: {'Content-Type': 'application/json'}})
}
function failure(message: string, status = 501) {
  return json({error: {code: status === 404 ? 'NOT_FOUND' : 'NOT_IMPLEMENTED', message}}, status)
}
function compare(f: FeatureDetail, filter: Json): boolean {
  const v = f.properties[filter.field], expected = filter.value
  switch (filter.operator) {
    case 'eq': return String(v) === String(expected)
    case 'in': return Array.isArray(expected) && expected.some(x => String(x) === String(v))
    case 'containsText': return String(v ?? '').toLowerCase().includes(String(expected).toLowerCase())
    case 'gte': return v !== null && v !== undefined && Number(v) >= Number(expected)
    case 'lte': return v !== null && v !== undefined && Number(v) <= Number(expected)
    case 'between': return v !== null && Array.isArray(expected) && Number(v) >= Number(expected[0]) && Number(v) <= Number(expected[1])
    case 'isNull': return v === null || v === undefined
    default: throw new Error('此筛选条件未在静态版中提供。')
  }
}
const queries = new Map<string, QueryInput>()
let queryCounter = 0
async function runQuery(input: QueryInput, q: URLSearchParams, b: Json, envelope: (data: any) => Response): Promise<Response> {
  if (input.spatial) return failure('在线成果快照不提供精确空间查询，请使用原数据库版本。线面几何已按 200 米容差简化，仅供浏览。')
  if (input.scenarioYear !== undefined || input.datasetVersion !== undefined) return failure('请通过专题页选择情景或成果版本。')
  if (!b.layerExports[input.layerId]?.included) return failure('该图层仅保留目录信息，未随在线展示版分发。')
  const layer = await asset(`layers/${input.layerId}.json`)
  let rows: FeatureDetail[] = layer.items.filter((f: FeatureDetail) => input.filters.every(filter => compare(f, filter)))
  if (input.sort) {
    const {field, direction} = input.sort
    rows = [...rows].sort((a, c) => {
      const x = a.properties[field], y = c.properties[field]
      const order = typeof x === 'number' && typeof y === 'number' ? x-y : String(x ?? '').localeCompare(String(y ?? ''), 'zh-CN', {numeric:true})
      return direction === 'desc' ? -order : order
    })
  }
  const token = `snapshot-q-${++queryCounter}`
  queries.set(token, input)
  q.set('page', String(input.page)); q.set('pageSize', String(input.pageSize))
  const result = page(rows, q)
  return envelope({rows:result, queryId:token, metrics:[], mapSelection:{featureRefs:result.items.map(f => f.ref),matchedTotal:result.total,renderedCount:result.items.length,truncated:result.total>result.page*result.pageSize},nearestDistances:null,geometrySimplified:layer.geometrySimplified,simplifyToleranceMeters:layer.simplifyToleranceMeters})
}

export function installPublishedSnapshot(): void {
  if (!enabled) return
  globalThis.fetch = async (resource, options) => {
    const raw = typeof resource === 'string' ? resource : resource instanceof URL ? resource.href : resource.url
    const url = new URL(raw, location.href)
    const marker = url.pathname.indexOf('/api/v1')
    if (marker === -1) {
      if (url.origin === location.origin && url.pathname.startsWith('/real-preview/')) return nativeFetch(`${assetBase}${url.pathname.slice(1)}`,options)
      return nativeFetch(resource, options)
    }
    try {
      if (options?.signal?.aborted) throw new DOMException('Aborted','AbortError')
      const path = decodeURIComponent(url.pathname.slice(marker + 7)) || '/'
      const q = url.searchParams
      const b = await asset('bootstrap.json')
      const envelope = (data: any) => json({data,meta:{...b.meta,mode:'api',snapshotId:`published-${b.exportedAt}`,generatedAt:b.exportedAt,scopeLabel:'青藏高原研究区（真实成果静态快照）'},requestId:'published-snapshot'})
      if (path === '/health') return json({status:'ok',database:'not-required',version:'static-snapshot'})
      if (path === '/layers') return envelope(b.layers.data.filter((l: Json) => !q.get('theme') || l.theme === q.get('theme')).map((l: Json) => {
        const exportInfo=b.layerExports[l.id]
        return exportInfo?.included ? {...l,exportFormats:l.geometryType === 'Point' ? l.exportFormats : ['csv']} : {...l,defaultVisible:false,queryable:false,exportFormats:[],source:{type:'unavailable',reason:exportInfo?.reason || l.source.reason || '本展示版未包含此图层。'}}
      }))
      if (path === '/capabilities') return envelope({...b.capabilities.data,spatialQuery:false,reasons:{...b.capabilities.data.reasons,spatialQuery:'静态成果展示不提供精确空间查询；几何按 200 米容差概化。'},snapshotId:`published-${b.exportedAt}`})
      if (path === '/overview') return envelope(b.overview.data)
      if (path === '/dataset-versions') return envelope(b['dataset-versions'].data)
      if (path === '/regions') return envelope(b.regions.data.filter((r: Json) => (!q.get('parentId') || r.parentId === q.get('parentId')) && (!q.get('level') || r.level === q.get('level'))))
      if (path === '/datasets') return envelope(page(b.datasets.data.items.filter((d: Json) => (!q.get('theme') || d.theme===q.get('theme')) && (!q.get('type') || d.dataType===q.get('type')) && (!q.get('keyword') || `${d.name} ${d.id}`.toLowerCase().includes(q.get('keyword')!.toLowerCase()))),q))
      if (path === '/results') return envelope(page([...b.results.data.items].sort((a: Json,c: Json) => Number(c.id.endsWith('combined'))-Number(a.id.endsWith('combined'))).filter((r: Json) => (!q.get('kind')||r.kind===q.get('kind'))&&(!q.get('status')||r.status===q.get('status'))),q))
      if (path === '/queries' && options?.method==='POST') return runQuery(JSON.parse(String(options.body)),q,b,envelope)
      const continued=path.match(/^\/queries\/(.+)$/)
      if (continued) {
        const old=queries.get(continued[1]!)
        if (!old) return failure('查询已失效，请重新查询。',404)
        return runQuery({...old,page:Number(q.get('page')||1),pageSize:Number(q.get('pageSize')||20)},q,b,envelope)
      }
      const feature=path.match(/^\/layers\/([^/]+)\/features(?:\/([^/]+))?$/)
      if(feature) {
        if(!b.layerExports[feature[1]!]?.included) return failure('该图层未随静态展示版分发。')
        const layer=await asset(`layers/${feature[1]}.json`)
        if(feature[2]) {
          const found=layer.items.find((f: FeatureDetail)=>f.ref.id===feature[2]); return found?envelope(found):failure('未找到对象。',404)
        }
        return envelope({...page(layer.items,q),geometrySimplified:layer.geometrySimplified,simplifyToleranceMeters:layer.simplifyToleranceMeters})
      }
      const routes=path.match(/^\/results\/([^/]+)\/routes$/)
      if(routes) {
        const items=await asset(`route-lists/${routes[1]}.json`)
        return envelope(page(items.filter((r:Json)=>!q.get('hazardPointId')||r.hazardPointId===q.get('hazardPointId')),q))
      }
      const route=path.match(/^\/routes\/(.+)$/)
      if(route) {
        const [rid,code]=route[1]!.split(':')
        const result=b.results.data.items.find((r:Json)=>r.id===rid)
        if(!result) return failure('未找到路线成果。',404)
        const list=await asset(`route-lists/${rid}.json`), summary=list.find((r:Json)=>r.id===route[1])
        const features=await asset(`layers/${result.layerIds[0]}.json`)
        const f=features.items.find((f:FeatureDetail)=>f.properties.routeCode===code)
        if(!summary||!f) return failure('未找到路线。',404)
        const geometry=f.geometry, coords=geometry?.type==='LineString'?geometry.coordinates:[]
        const scope=rid!.split('.').at(-1)
        const associations=await asset(`route-links/${scope}.json`)
        const link=associations.find((l:Json)=>l.routeCode===code)
        let facility: FeatureDetail | undefined
        if(link?.facilityLayer&&link.facilityPk) {
          const facilities=await asset(`layers/${link.facilityLayer}.json`)
          facility=facilities.items.find((p:FeatureDetail)=>p.ref.id===link.facilityPk)
        }
        const lonLat=facility?.geometry?.type==='Point'?facility.geometry.coordinates:null
        const kind=link?.facilityLayer?.includes('HOSPITAL')?'hospital':link?.facilityLayer?.includes('FIRE')?'firestation':'rescue'
        return envelope({...summary,geometry:summary.status==='reachable'?geometry:null,origin:{ref:null,label:'路线几何起点',lonLat:coords[0]??null},destination:{ref:facility?.ref??null,label:summary.label,lonLat},resources:facility?[{ref:facility.ref,label:summary.label,kind,distanceFromRouteMeters:null}]:[],riskSegments:[],distanceSource:'原数据库 NETWORK_DISTANCE_KM；几何按 200 米容差简化，仅供展示。',durationSource:null,assumptions:[...summary.assumptions,'终点设施按数据库来源图层和编号关联；不提供实时路况或重新规划。']})
      }
      if(path==='/rasters') return envelope(b.rasters.data)
      const response=b.responses[path]
      if(response?.imageFile) return nativeFetch(`${assetBase}published-snapshot/${response.imageFile}`,options)
      if(response) return envelope(response.data)
      return failure('静态成果展示版未提供此能力。')
    } catch(error) {
      if(error instanceof DOMException && error.name==='AbortError') throw error
      return failure(error instanceof Error?error.message:String(error))
    }
  }
}
