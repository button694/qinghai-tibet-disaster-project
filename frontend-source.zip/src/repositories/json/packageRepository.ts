/**
 * JSON 数据包适配器：**mock（示例数据）与 snapshot（成果快照）共用同一实现**。
 *
 * 两者差异只在配置（数据包地址、是否要求 manifest 明确为非示例包），代码路径完全一致，
 * 因此“模式只改配置”是结构性的，而不是靠 if 分支模拟（01 §6.3）。
 *
 * 硬性约束：
 * 1. 所有计数、统计、指标一律由 `derive.ts` 现场派生，包内不存数字，避免两份口径。
 * 2. 任何文件缺失或结构不符都抛 `RepositoryError`，绝不返回示例数据顶替。
 * 3. 示例模式强制关闭全部写能力（“示例只读”身份）。
 */
import type { Geometry, Feature as GeoJsonFeature } from 'geojson'
import type {
  AttributeFilter,
  Capabilities,
  CategoryStatistics,
  Context,
  Dataset,
  DataMode,
  DataSource,
  Dictionary,
  Envelope,
  ExposureSummary,
  FeatureDetail,
  FeaturePropertyValue,
  FeatureRef,
  ImportLog,
  LayerDefinition,
  Legend,
  Metric,
  OverviewData,
  OverviewKeyFeature,
  Page,
  QueryInput,
  QueryResult,
  Region,
  RegionLevel,
  Bbox,
  SpatialInput,
  ResultDetail,
  ResultStatistics,
  ResultSummary,
  RouteDetail,
  RouteSummary,
  Theme,
  TimeValue,
} from '@/domain/types'
import { RISK_LEVEL_ORDER, toRiskLevel } from '@/domain/risk'
import { featureKey, formatDistance, formatId } from '@/domain/format'
import {
  bufferIntersects,
  distanceMeters,
  DISTANCE_METHOD_TEXT,
  geometryIntersects,
  geometryWithin,
  nearestByDistance,
} from '@/domain/spatialRelations'
import {
  RepositoryError,
  type AffectedFeatureQuery,
  type CatalogRepository,
  type DatasetListQuery,
  type FeatureQuery,
  type ImportLogQuery,
  type LayerListQuery,
  type LayerRepository,
  type OverviewQuery,
  type OverviewRepository,
  type PageInput,
  type QueryRepository,
  type Repositories,
  type RequestOptions,
  type ResultListQuery,
  type ResultRepository,
  type SortInput,
} from '@/repositories/types'
import {
  createJsonFetcher,
  joinUrl,
  requireArray,
  requireObject,
  type JsonFetcher,
} from '@/repositories/json/loader'
import {
  deriveAffectedRecords,
  deriveCategoryCounts,
  deriveClippedRoadLength,
  deriveExposureMetrics,
  deriveOverviewMetrics,
  deriveRiskDistribution,
  deriveRouteMetrics,
  verifyRouteDistance,
  type CandidateInput,
  type ImpactAreaInput,
} from '@/repositories/derive'

/* ------------------------------------------------------------------ *
 * 配置与内部结构
 * ------------------------------------------------------------------ */

export interface JsonPackageOptions {
  mode: DataMode
  /** 数据包根地址，例如 `/demo/`。 */
  baseUrl: string
  /** 可注入的加载器；默认走浏览器 fetch。 */
  fetcher?: JsonFetcher
  /**
   * 是否要求数据包明确声明为非示例包。
   * 快照模式为 true：拿到示例包即报 `SNAPSHOT_MISSING`，避免把示例当成果。
   */
  requireNonSamplePackage?: boolean
}

interface RawManifest {
  packageId: string
  label: string
  mode: DataMode
  sample: boolean
  generatedAt: string
  scopeLabel: string
  boundaryVersion: string
  datasetVersions: Record<string, string>
  files: {
    layers: string
    legends: string
    dictionaries: string
    datasets: string
    sources: string
    regions: string
    results: string
    routes: string
    imports: string
    capabilities: string
    features: Record<string, string>
  }
  notes: string[]
}

interface RawResultRecord extends Omit<ResultDetail, 'metrics'> {
  metrics?: Metric[]
}

type RawRouteRecord = RouteDetail

const RISK_LAYER_ID = 'result.demo.risk'
const IMPACT_LAYER_ID = 'result.demo.impact'
const HAZARD_LAYER_ID = 'hazard.landslide'
const ROAD_LAYER_ID = 'emg.road'

/** 参与承灾体统计的图层（道路单独按裁剪长度处理，不参与点面判定）。 */
const EXPOSURE_CANDIDATE_LAYERS = [
  'base.settlement.point',
  'base.settlement.polygon',
  'base.facility.point',
  'emg.hospital',
  'emg.rescue',
]

/* ------------------------------------------------------------------ *
 * 工具
 * ------------------------------------------------------------------ */

function assertNotAborted(options?: RequestOptions): void {
  if (options?.signal?.aborted) {
    throw new DOMException('请求已取消。', 'AbortError')
  }
}

function compareValues(
  a: FeaturePropertyValue | undefined,
  b: FeaturePropertyValue | undefined,
): number {
  const aNull = a === null || a === undefined
  const bNull = b === null || b === undefined
  if (aNull && bNull) return 0
  if (aNull) return 1 // null 永远排在最后，不当作 0
  if (bNull) return -1
  if (typeof a === 'number' && typeof b === 'number') return a - b
  if (typeof a === 'boolean' && typeof b === 'boolean') return Number(a) - Number(b)
  return String(a).localeCompare(String(b), 'zh-CN')
}

function sortItems<T>(
  items: T[],
  sort: SortInput | undefined,
  valueOf: (item: T) => FeaturePropertyValue | undefined,
): T[] {
  if (!sort) return items
  const direction = sort.direction === 'desc' ? -1 : 1
  return [...items].sort((a, b) => direction * compareValues(valueOf(a), valueOf(b)))
}

function paginate<T>(items: T[], page: number, pageSize: number): Page<T> {
  const safePage = Number.isFinite(page) && page >= 1 ? Math.floor(page) : 1
  const safeSize = Number.isFinite(pageSize) && pageSize >= 1 ? Math.floor(pageSize) : 20
  const start = (safePage - 1) * safeSize
  return {
    items: items.slice(start, start + safeSize),
    total: items.length,
    page: safePage,
    pageSize: safeSize,
  }
}

/**
 * 可比较值的排序比较（阶段3 补充：日期区间条件）。
 *
 * - 数值：直接比较；
 * - 字符串：按字典序比较。ISO 8601 时间字符串（`2024-05-01`）的字典序与时间序一致，
 *   因此日期区间可以复用 `between / gte / lte`，不必另造一套日期运算符；
 * - 其余组合（数值 vs 字符串、null、布尔）视为不可比较，返回 `null`，调用方按「不匹配」处理，
 *   **不把 null 当 0 参与比较**（02 §2.3）。
 */
function compareOrderable(value: FeaturePropertyValue | undefined, other: unknown): number | null {
  if (typeof value === 'number' && typeof other === 'number') {
    return value === other ? 0 : value > other ? 1 : -1
  }
  if (typeof value === 'string' && typeof other === 'string') {
    return value.localeCompare(other, 'zh-CN')
  }
  return null
}

function matchesFilter(
  properties: Record<string, FeaturePropertyValue>,
  filter: AttributeFilter,
): boolean {
  const value = properties[filter.field]
  switch (filter.operator) {
    case 'isNull':
      return value === null || value === undefined
    case 'eq':
      return value === filter.value
    case 'in':
      return Array.isArray(filter.value) ? filter.value.includes(value as string | number) : false
    case 'containsText':
      return typeof value === 'string' && typeof filter.value === 'string'
        ? value.includes(filter.value)
        : false
    case 'gte': {
      const compared = compareOrderable(value, filter.value)
      return compared !== null && compared >= 0
    }
    case 'lte': {
      const compared = compareOrderable(value, filter.value)
      return compared !== null && compared <= 0
    }
    case 'between': {
      if (!Array.isArray(filter.value) || filter.value.length !== 2) return false
      const [min, max] = filter.value as [unknown, unknown]
      const lower = compareOrderable(value, min)
      const upper = compareOrderable(value, max)
      return lower !== null && upper !== null && lower >= 0 && upper <= 0
    }
    default:
      return false
  }
}

function toPrimitiveProperties(raw: unknown): Record<string, FeaturePropertyValue> {
  if (raw === null || typeof raw !== 'object') return {}
  const result: Record<string, FeaturePropertyValue> = {}
  for (const [key, value] of Object.entries(raw as Record<string, unknown>)) {
    if (value === null) result[key] = null
    else if (typeof value === 'string' || typeof value === 'number' || typeof value === 'boolean') {
      result[key] = value
    }
    // 嵌套对象不进属性表：属性面板只展示扁平字段（02 §3 FeatureDetail）。
  }
  return result
}

/* ------------------------------------------------------------------ *
 * 适配器
 * ------------------------------------------------------------------ */

export function createJsonPackageRepository(options: JsonPackageOptions): Repositories {
  const baseUrl = options.baseUrl
  const mode = options.mode
  const fetchJson = options.fetcher ?? createJsonFetcher({ baseUrl })
  const fileCache = new Map<string, Promise<unknown>>()
  const queryCache = new Map<
    string,
    {
      input: QueryInput
      rows: FeatureDetail[]
      metrics: Metric[]
      /** 最近邻的逐条距离（米）；非最近邻查询为 null。 */
      distances: Record<string, number> | null
    }
  >()
  let queryCounter = 0
  let requestCounter = 0

  function loadFile<T>(filePath: string): Promise<T> {
    const cached = fileCache.get(filePath)
    if (cached) return cached as Promise<T>
    const promise = fetchJson(filePath).catch((error: unknown) => {
      const repositoryError =
        error instanceof RepositoryError
          ? error
          : new RepositoryError({
              code: 'UNKNOWN',
              message: `读取 ${filePath} 失败。`,
              cause: error,
            })
      // 快照模式下任何文件缺失都视为“快照包缺失”，不再尝试其它来源。
      if (options.requireNonSamplePackage && repositoryError.code === 'NOT_FOUND') {
        throw new RepositoryError({
          code: 'SNAPSHOT_MISSING',
          message: `成果快照缺少文件 ${filePath}。`,
          details: { filePath },
          cause: repositoryError,
        })
      }
      throw repositoryError
    })
    fileCache.set(filePath, promise)
    // 失败不缓存：允许用户重试
    promise.catch(() => fileCache.delete(filePath))
    return promise as Promise<T>
  }

  async function loadManifest(): Promise<RawManifest> {
    const manifest = await loadFile<RawManifest>('manifest.json')
    if (
      manifest === null ||
      typeof manifest !== 'object' ||
      typeof manifest.packageId !== 'string'
    ) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: '数据包 manifest 结构不符合契约。',
      })
    }
    if (options.requireNonSamplePackage && manifest.sample === true) {
      throw new RepositoryError({
        code: 'SNAPSHOT_MISSING',
        message: '请求成果快照模式，但数据包声明为示例包；已停止加载，不使用示例数据。',
        details: { packageId: manifest.packageId },
      })
    }
    return manifest
  }

  async function envelope<T>(data: T, extra: { queryId?: string } = {}): Promise<Envelope<T>> {
    const manifest = await loadManifest()
    requestCounter += 1
    const meta: Context = {
      mode,
      snapshotId: manifest.packageId,
      generatedAt: manifest.generatedAt,
      scopeLabel: manifest.scopeLabel,
      boundaryVersion: manifest.boundaryVersion,
      datasetVersions: manifest.datasetVersions,
    }
    if (extra.queryId) meta.queryId = extra.queryId
    return {
      data,
      meta,
      requestId: `req-${mode}-${String(requestCounter).padStart(4, '0')}`,
    }
  }

  async function loadLayers(): Promise<LayerDefinition[]> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.layers)
    return requireArray<LayerDefinition>(raw, 'layers', manifest.files.layers)
  }

  async function findLayer(layerId: string): Promise<LayerDefinition> {
    const layers = await loadLayers()
    const layer = layers.find((item) => item.id === layerId)
    if (!layer) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `未找到图层 ${layerId}。`,
        details: { layerId },
      })
    }
    return layer
  }

  async function loadLayerFeatures(layerId: string): Promise<FeatureDetail[]> {
    const manifest = await loadManifest()
    const layer = await findLayer(layerId)
    const filePath = manifest.files.features[layerId]
    if (!filePath) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `数据包未登记图层 ${layerId} 的要素文件。`,
        details: { layerId },
      })
    }
    const raw = await loadFile<{ features?: GeoJsonFeature[] }>(filePath)
    const features = Array.isArray(raw?.features) ? raw.features : null
    if (!features) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: `${filePath} 不是合法的 GeoJSON FeatureCollection。`,
        details: { filePath },
      })
    }
    return features.map((feature) => toFeatureDetail(feature, layer, filePath))
  }

  const relatedResultsPromise = () =>
    loadResults().then((results) =>
      results.map((result) => ({ id: result.id, layerIds: result.layerIds })),
    )

  function toFeatureDetail(
    feature: GeoJsonFeature,
    layer: LayerDefinition,
    filePath: string,
  ): FeatureDetail {
    const properties = toPrimitiveProperties(feature.properties)
    const id = formatId((feature.id ?? properties.id) as string | number | null)
    if (!id) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: `${filePath} 中有要素缺少稳定 ID。`,
        details: { filePath, layerId: layer.id },
      })
    }
    const title =
      typeof properties.name === 'string' && properties.name.trim() !== ''
        ? properties.name
        : `${layer.label} ${id}`
    const entityKey = typeof properties.entityKey === 'string' ? properties.entityKey : undefined
    const detail: FeatureDetail = {
      ref: { layerId: layer.id, id },
      title,
      datasetId: layer.datasetId,
      geometry: (feature.geometry ?? null) as Geometry | null,
      properties,
      relatedResultIds: [],
    }
    if (entityKey !== undefined) detail.entityKey = entityKey
    return detail
  }

  async function withRelatedResults(details: FeatureDetail[]): Promise<FeatureDetail[]> {
    const results = await relatedResultsPromise()
    return details.map((detail) => ({
      ...detail,
      relatedResultIds: results
        .filter((result) => result.layerIds.includes(detail.ref.layerId))
        .map((result) => result.id),
    }))
  }

  async function loadResults(): Promise<RawResultRecord[]> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.results)
    return requireArray<RawResultRecord>(raw, 'results', manifest.files.results)
  }

  async function findResult(resultId: string): Promise<RawResultRecord> {
    const results = await loadResults()
    const result = results.find((item) => item.id === resultId)
    if (!result) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `未找到成果 ${resultId}。`,
        details: { resultId },
      })
    }
    return result
  }

  async function loadRoutes(): Promise<RawRouteRecord[]> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.routes)
    return requireArray<RawRouteRecord>(raw, 'routes', manifest.files.routes)
  }

  async function loadCapabilitiesFile(): Promise<Capabilities> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.capabilities)
    return requireObject<Capabilities>(raw, 'capabilities', manifest.files.capabilities)
  }

  /** 示例模式：强制关闭全部写能力，并把原因写清楚（01 §6.4、02 §3.2）。 */
  async function capabilitiesWithReadOnly(
    mode: DataMode,
    snapshotId: string,
  ): Promise<Capabilities> {
    const fromFile = await loadCapabilitiesFile()
    const reasons = { ...(fromFile.reasons ?? {}) }
    const capabilities: Capabilities = { ...fromFile, reasons, mode, snapshotId }
    if (fromFile.mode !== mode) {
      reasons.readLayers = '数据包声明的模式与当前运行模式不一致，界面按当前运行模式标注来源。'
    }
    if (mode === 'mock') {
      const readOnlyReason = '示例数据只读：不允许新增、修改、删除或提交分析任务。'
      capabilities.dataEdit = false
      capabilities.backupExecute = false
      capabilities.analysisSubmit = false
      capabilities.routeRecompute = false
      capabilities.authEnabled = false
      reasons.dataEdit = reasons.dataEdit ?? readOnlyReason
      reasons.backupExecute = reasons.backupExecute ?? readOnlyReason
      reasons.analysisSubmit = reasons.analysisSubmit ?? readOnlyReason
      reasons.routeRecompute = reasons.routeRecompute ?? readOnlyReason
    }
    return capabilities
  }

  /* -------------------------- 空间关系（示例包内派生） -------------------------- */

  async function impactAreas(): Promise<ImpactAreaInput[]> {
    const details = await loadLayerFeatures(IMPACT_LAYER_ID)
    return details.map((detail) => ({
      ref: detail.ref,
      label: detail.title,
      geometry: detail.geometry,
    }))
  }

  async function exposureCandidates(): Promise<CandidateInput[]> {
    const layers = await loadLayers()
    const result: CandidateInput[] = []
    for (const layerId of EXPOSURE_CANDIDATE_LAYERS) {
      const layer = layers.find((item) => item.id === layerId)
      if (!layer) continue
      const details = await loadLayerFeatures(layerId)
      for (const detail of details) {
        result.push({
          ref: detail.ref,
          layerLabel: layer.label,
          title: detail.title,
          entityKey: detail.entityKey ?? null,
          geometry: detail.geometry,
          properties: detail.properties,
        })
      }
    }
    return result
  }

  async function roadInputs() {
    const roads = await loadLayerFeatures(ROAD_LAYER_ID)
    return roads
      .map((road) => ({
        ref: road.ref,
        label: road.title,
        coords: outerCoordinateList(road.geometry),
      }))
      .filter((road) => road.coords.length >= 2)
  }

  function outerCoordinateList(geometry: Geometry | null): Array<[number, number]> {
    if (!geometry) return []
    if (geometry.type === 'LineString') return geometry.coordinates as Array<[number, number]>
    if (geometry.type === 'MultiLineString')
      return (geometry.coordinates as Array<Array<[number, number]>>).flat()
    return []
  }

  async function affectedDerivation() {
    const [areas, candidates, roads] = await Promise.all([
      impactAreas(),
      exposureCandidates(),
      roadInputs(),
    ])
    const affected = deriveAffectedRecords(areas, candidates)
    const clipped = deriveClippedRoadLength(areas, roads)
    return { areas, candidates, roads, affected, clipped }
  }

  /* -------------------------------- 图层仓库 -------------------------------- */

  const layers: LayerRepository = {
    async listLayers(query?: LayerListQuery, options?: RequestOptions) {
      assertNotAborted(options)
      const all = await loadLayers()
      const filtered = query?.theme ? all.filter((layer) => layer.theme === query.theme) : all
      return envelope(sortLayers(filtered))
    },

    async getLayer(layerId: string, options?: RequestOptions) {
      assertNotAborted(options)
      return envelope(await findLayer(layerId))
    },

    async listFeatures(layerId: string, query?: FeatureQuery, options?: RequestOptions) {
      assertNotAborted(options)
      const details = await withRelatedResults(await loadLayerFeatures(layerId))
      const sorted = sortItems(
        details,
        query?.sort,
        (detail) => detail.properties[query?.sort?.field ?? ''],
      )
      const page = paginate(sorted, query?.page ?? 1, query?.pageSize ?? 50)
      return envelope(page)
    },

    async getFeature(ref: FeatureRef, options?: RequestOptions) {
      assertNotAborted(options)
      const details = await loadLayerFeatures(ref.layerId)
      const detail = details.find((item) => item.ref.id === ref.id)
      if (!detail) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到对象 ${ref.layerId}:${ref.id}。`,
          details: { ref },
        })
      }
      const [withResults] = await withRelatedResults([detail])
      return envelope(withResults as FeatureDetail)
    },

    async getLegend(legendId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.legends)
      const legends = requireArray<Legend>(raw, 'legends', manifest.files.legends)
      const legend = legends.find((item) => item.id === legendId)
      if (!legend) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到图例 ${legendId}。`,
          details: { legendId },
        })
      }
      return envelope(legend)
    },
  }

  function sortLayers(input: LayerDefinition[]): LayerDefinition[] {
    const themeOrder: Theme[] = ['base', 'tnr', 'hazard', 'emg', 'result', 'sys']
    return [...input].sort((a, b) => {
      const byTheme = themeOrder.indexOf(a.theme) - themeOrder.indexOf(b.theme)
      if (byTheme !== 0) return byTheme
      return a.label.localeCompare(b.label, 'zh-CN')
    })
  }

  /* -------------------- 空间条件（阶段3：在完整小样本上真正执行） -------------------- */

  async function loadRegions(): Promise<Region[]> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.regions)
    return requireArray<Region>(raw, 'regions', manifest.files.regions)
  }

  async function findRegion(regionId: string): Promise<Region> {
    const regions = await loadRegions()
    const region = regions.find((item) => item.id === regionId)
    if (!region) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `未找到统计范围 ${regionId}。`,
        details: { regionId },
      })
    }
    return region
  }

  /**
   * 范围框 → 多边形（西、南、东、北）。
   * 行政区/流域在本数据包里**只登记范围框**，因此区域条件只能按范围框参与判定；
   * 界面必须写明这一点，不得声称按行政边界裁切。
   */
  function bboxToPolygon(bbox: Bbox): Geometry {
    const [west, south, east, north] = bbox
    return {
      type: 'Polygon',
      coordinates: [
        [
          [west, south],
          [east, south],
          [east, north],
          [west, north],
          [west, south],
        ],
      ],
    }
  }

  async function findFeatureByRef(ref: FeatureRef): Promise<FeatureDetail | null> {
    const details = await loadLayerFeatures(ref.layerId)
    return details.find((item) => item.ref.id === ref.id) ?? null
  }

  interface ResolvedSpatial {
    geometry: Geometry
    /** 参与判定的范围名称，写进指标口径（界面与导出都要能追溯）。 */
    label: string
    note: string | null
  }

  /**
   * 解析空间输入（02 §3.1：`geometry` / `sourceFeature` / `regionId` 恰选一个）。
   * 多选或全不选都直接报错，不挑一个「看起来像的」继续算。
   */
  async function resolveSpatialGeometry(spatial: SpatialInput): Promise<ResolvedSpatial> {
    const provided = [
      spatial.geometry === undefined ? null : 'geometry',
      spatial.sourceFeature === undefined ? null : 'sourceFeature',
      spatial.regionId === undefined ? null : 'regionId',
    ].filter((item): item is string => item !== null)
    if (provided.length !== 1) {
      throw new RepositoryError({
        code: 'INVALID_PARAMETER',
        message: '空间条件必须在 geometry / sourceFeature / regionId 中恰选一个（02 §3.1）。',
        details: { provided },
      })
    }
    if (spatial.geometry) return { geometry: spatial.geometry, label: '绘制范围', note: null }
    if (spatial.sourceFeature) {
      const detail = await findFeatureByRef(spatial.sourceFeature)
      if (detail === null || detail.geometry === null) {
        throw new RepositoryError({
          code: 'INVALID_PARAMETER',
          message: '空间条件的源对象没有几何：无法参与空间判定，也不为其补造坐标。',
          details: { ref: spatial.sourceFeature },
        })
      }
      return { geometry: detail.geometry, label: detail.title, note: null }
    }
    const region = await findRegion(spatial.regionId as string)
    if (region.extent === null) {
      throw new RepositoryError({
        code: 'NOT_FOUND',
        message: `统计范围 ${region.id} 未登记范围框，无法参与空间判定。`,
        details: { regionId: region.id },
      })
    }
    return {
      geometry: bboxToPolygon(region.extent),
      label: region.name,
      note: `${region.name}：本数据包只登记范围框，按范围框参与判定，不声称按行政边界裁切。`,
    }
  }

  interface SpatialOutcome {
    rows: FeatureDetail[]
    /** 因无几何而未参与空间判定的条数：不静默丢弃，要在界面说明。 */
    excludedNoGeometry: number
    /** 最近邻的逐条距离（米），键为全局对象键；非最近邻查询为 null。 */
    distances: Record<string, number> | null
    metrics: Metric[]
  }

  /**
   * 执行空间谓词（阶段3 §6-4「mock 对完整小样本真正执行空间关系」）。
   *
   * - `intersects` / `within` 是两套判定：`within` 为覆盖语义（02 §3.1），与相交分别测试；
   * - `bufferIntersects` 按「到源对象的最短距离 ≤ 半径」判定，半径必须为正；
   * - `nearest` 必须同时给出限制半径与数量，超出半径不返回——没有半径的「最近 N 条」
   *   会在邻近无对象时悄悄返回很远的对象，那不是最近邻。
   */
  function applySpatialPredicate(
    details: FeatureDetail[],
    spatial: SpatialInput,
    resolved: ResolvedSpatial,
  ): SpatialOutcome {
    const candidates: FeatureDetail[] = []
    let excludedNoGeometry = 0
    for (const detail of details) {
      if (detail.geometry === null) excludedNoGeometry += 1
      else candidates.push(detail)
    }

    const metrics: Metric[] = []
    if (excludedNoGeometry > 0) {
      metrics.push({
        key: 'spatialExcludedNoGeometry',
        label: '因无几何未参与空间判定的记录数',
        value: excludedNoGeometry,
        unit: '条',
        status: 'known',
        method:
          '无几何记录没有坐标，不能参与相交、覆盖、缓冲与最近邻判定；其属性仍可查询，定位不可用。',
      })
    }

    if (spatial.predicate === 'nearest') {
      const radius = spatial.distanceMeters ?? 0
      const limit = spatial.limit ?? 0
      if (!Number.isFinite(radius) || radius <= 0 || !Number.isFinite(limit) || limit < 1) {
        throw new RepositoryError({
          code: 'INVALID_PARAMETER',
          message: '最近邻必须同时给出限制半径（米）与返回数量，否则无法说明结果边界（02 §3.1）。',
          details: { distanceMeters: spatial.distanceMeters, limit: spatial.limit },
        })
      }
      const matched = nearestByDistance(
        candidates,
        (detail) => distanceMeters(detail.geometry as Geometry, resolved.geometry),
        radius,
        limit,
      )
      const distances: Record<string, number> = {}
      for (const item of matched) {
        distances[featureKey(item.item.ref.layerId, item.item.ref.id)] = item.distanceMeters
      }
      const farthest =
        matched.length === 0 ? null : (matched[matched.length - 1]?.distanceMeters ?? null)
      metrics.push(
        {
          key: 'nearestRadiusMeters',
          label: '最近邻限制半径',
          value: radius,
          unit: 'm',
          status: 'known',
          method: DISTANCE_METHOD_TEXT,
        },
        {
          key: 'nearestLimit',
          label: '最近邻返回数量上限',
          value: limit,
          unit: '条',
          status: 'known',
          method: `在限制半径内按距离升序截取；范围：${resolved.label}。`,
        },
        {
          key: 'nearestFarthestMeters',
          label: '本次结果中最远一条的距离',
          value: farthest,
          unit: 'm',
          status: farthest === null ? 'notApplicable' : 'known',
          method: DISTANCE_METHOD_TEXT,
        },
      )
      return { rows: matched.map((item) => item.item), excludedNoGeometry, distances, metrics }
    }

    if (spatial.predicate === 'bufferIntersects') {
      const radius = spatial.distanceMeters ?? 0
      if (!Number.isFinite(radius) || radius <= 0) {
        throw new RepositoryError({
          code: 'INVALID_PARAMETER',
          message: '缓冲查询必须给出半径（米）；半径为 0 时请改用相交判定（02 §3.1）。',
          details: { distanceMeters: spatial.distanceMeters },
        })
      }
      const rows = candidates.filter((detail) =>
        bufferIntersects(detail.geometry as Geometry, resolved.geometry, radius),
      )
      metrics.push({
        key: 'bufferRadiusMeters',
        label: '缓冲半径',
        value: radius,
        unit: 'm',
        status: 'known',
        method: `${DISTANCE_METHOD_TEXT}命中判定为「到源对象的最短距离 ≤ 半径」；源对象：${resolved.label}。`,
      })
      return { rows, excludedNoGeometry, distances: null, metrics }
    }

    const within = spatial.predicate === 'within'
    const rows = candidates.filter((detail) => {
      const geometry = detail.geometry as Geometry
      return within
        ? geometryWithin(geometry, resolved.geometry)
        : geometryIntersects(geometry, resolved.geometry)
    })
    metrics.push({
      key: 'spatialMatched',
      label: within ? '覆盖命中的记录数' : '相交命中的记录数',
      value: rows.length,
      unit: '条',
      status: 'known',
      method: within
        ? `覆盖语义：目标所有点位于范围内部或边界，不允许任何部分在外（02 §3.1）；范围：${resolved.label}。`
        : `相交语义：目标与范围有任一公共部分，含边界相触（02 §3.1）；范围：${resolved.label}。`,
    })
    return { rows, excludedNoGeometry, distances: null, metrics }
  }

  /* -------------------------------- 查询仓库 -------------------------------- */

  const queries: QueryRepository = {
    async runQuery(input: QueryInput, options?: RequestOptions) {
      assertNotAborted(options)
      const capabilities = await capabilitiesWithReadOnly(mode, (await loadManifest()).packageId)
      if (input.spatial && !capabilities.spatialQuery) {
        throw new RepositoryError({
          code: 'NOT_IMPLEMENTED',
          message:
            capabilities.reasons.spatialQuery ??
            '空间查询需要后端空间数据库支持，当前数据源未接入，界面不返回占位结果。',
        })
      }
      const all = await withRelatedResults(await loadLayerFeatures(input.layerId))
      const attributeMatched = all.filter((detail) =>
        input.filters.every((filter) => matchesFilter(detail.properties, filter)),
      )

      // 空间条件在属性条件之后执行：先按属性收敛，再在结果上做空间判定。
      // 无几何记录没有坐标，不参与空间判定，但会以指标的形式如实报告条数。
      let rows = attributeMatched
      let distances: Record<string, number> | null = null
      const spatialMetrics: Metric[] = []
      if (input.spatial) {
        const resolved = await resolveSpatialGeometry(input.spatial)
        const outcome = applySpatialPredicate(attributeMatched, input.spatial, resolved)
        rows = outcome.rows
        distances = outcome.distances
        spatialMetrics.push(...outcome.metrics)
      }

      const sortField = input.sort?.field
      // 最近邻已有确定的排序语义（距离升序）；用户没有额外指定排序时不覆盖它。
      const sorted =
        input.spatial?.predicate === 'nearest' && !sortField
          ? rows
          : sortItems(rows, input.sort, (detail) =>
              sortField ? detail.properties[sortField] : undefined,
            )
      queryCounter += 1
      const queryId = `demo-query-${String(queryCounter).padStart(4, '0')}`
      const unlocatedCount = sorted.filter((detail) => detail.geometry === null).length
      const metrics: Metric[] = [
        {
          key: 'matchedTotal',
          label: '匹配对象总数',
          value: sorted.length,
          unit: '条',
          status: 'known',
          method: '由当前筛选条件在该图层全部记录上派生；翻页不改变该数值。',
        },
        {
          key: 'unlocatedRecords',
          label: '匹配结果中未登记位置的记录数',
          value: unlocatedCount,
          unit: '条',
          status: 'known',
          method: '无几何记录可查属性，但定位不可用。',
        },
        ...spatialMetrics,
      ]
      queryCache.set(queryId, { input, rows: sorted, metrics, distances })
      const page = paginate(sorted, input.page, input.pageSize)
      const result: QueryResult = {
        rows: page,
        queryId,
        metrics,
        mapSelection: {
          featureRefs: page.items.map((item) => item.ref),
          matchedTotal: sorted.length,
          renderedCount: page.items.length,
          truncated: page.items.length < sorted.length,
        },
      }
      if (distances !== null) result.nearestDistances = distances
      return envelope(result, { queryId })
    },

    async getQuery(queryId: string, page: PageInput, options?: RequestOptions) {
      assertNotAborted(options)
      const cached = queryCache.get(queryId)
      if (!cached) {
        throw new RepositoryError({
          code: 'QUERY_EXPIRED',
          message: '查询结果已过期或不存在，请重新发起查询。',
          details: { queryId },
        })
      }
      const result: QueryResult = {
        rows: paginate(cached.rows, page.page, page.pageSize),
        queryId,
        metrics: cached.metrics,
        mapSelection: {
          featureRefs: cached.rows
            .slice((page.page - 1) * page.pageSize, page.page * page.pageSize)
            .map((item) => item.ref),
          matchedTotal: cached.rows.length,
          renderedCount: Math.min(
            page.pageSize,
            Math.max(0, cached.rows.length - (page.page - 1) * page.pageSize),
          ),
          truncated: cached.rows.length > page.pageSize,
        },
      }
      if (cached.distances !== null) result.nearestDistances = cached.distances
      return envelope(result, { queryId })
    },
  }

  /* -------------------------------- 成果仓库 -------------------------------- */

  const results: ResultRepository = {
    async listResults(query?: Partial<ResultListQuery>, options?: RequestOptions) {
      assertNotAborted(options)
      const all = await loadResults()
      const filtered = all.filter((item) => {
        if (query?.kind && item.kind !== query.kind) return false
        if (query?.status && item.status !== query.status) return false
        if (query?.scenarioYear && item.scenarioYear !== query.scenarioYear) return false
        return true
      })
      const summaries = filtered.map((item) => toResultSummary(item))
      return envelope(paginate(summaries, query?.page ?? 1, query?.pageSize ?? 20))
    },

    async getResult(resultId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const result = await findResult(resultId)
      return envelope(toResultDetail(result))
    },

    async getStatistics(resultId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const result = await findResult(resultId)
      return envelope(await buildStatistics(result))
    },

    async listAffectedFeatures(
      resultId: string,
      query?: Partial<AffectedFeatureQuery>,
      options?: RequestOptions,
    ) {
      assertNotAborted(options)
      await findResult(resultId)
      const { affected } = await affectedDerivation()
      const wanted = query?.category
        ? affected.records.filter((record) => record.ref.layerId === query.category)
        : affected.records
      const layerCache = new Map<string, FeatureDetail[]>()
      const detailsOf = async (layerId: string): Promise<FeatureDetail[]> => {
        const cached = layerCache.get(layerId)
        if (cached) return cached
        const loaded = await withRelatedResults(await loadLayerFeatures(layerId))
        layerCache.set(layerId, loaded)
        return loaded
      }
      const rows: FeatureDetail[] = []
      for (const record of wanted) {
        const detail = (await detailsOf(record.ref.layerId)).find(
          (item) => item.ref.id === record.ref.id,
        )
        if (detail) rows.push(detail)
      }
      const sortField = query?.sort?.field
      const sorted = sortItems(rows, query?.sort, (detail) =>
        sortField ? detail.properties[sortField] : detail.title,
      )
      return envelope(paginate(sorted, query?.page ?? 1, query?.pageSize ?? 50))
    },

    async getExposureSummary(resultId: string, options?: RequestOptions) {
      assertNotAborted(options)
      await findResult(resultId)
      const manifest = await loadManifest()
      const { areas, affected, clipped } = await affectedDerivation()

      // 影响范围记录里登记了对应灾害对象编号；多个灾害对象时不合并成单一编号。
      const impactDetails = await loadLayerFeatures(IMPACT_LAYER_ID)
      const hazardRefIds = new Set<string>()
      for (const area of areas) {
        const detail = impactDetails.find((item) => item.ref.id === area.ref.id)
        const raw = detail?.properties.hazardRefId
        if (typeof raw === 'string' && raw.trim() !== '') hazardRefIds.add(raw)
      }
      const hazardRef: FeatureRef | null =
        hazardRefIds.size === 1
          ? { layerId: HAZARD_LAYER_ID, id: [...hazardRefIds][0] as string }
          : null

      const categories = deriveCategoryCounts(
        affected.records.map((record) => ({
          key: record.ref.layerId,
          label: record.layerLabel,
          color: null,
        })),
        '条',
      ).map((category) => ({
        key: category.key,
        label: category.label,
        layerId: category.key,
        count: category.count,
      }))

      const populationValues = await populationOfAffected(affected.records)
      const metrics = deriveExposureMetrics({
        scopeLabel: manifest.scopeLabel,
        matchedRecordCount: affected.recordCount,
        uniqueEntityCount: affected.entityCount,
        unlocatedCount: affected.unlocatedCount,
        affectedRoadMeters: clipped.totalMeters,
        population: {
          serviceAvailable: await isDatasetServiceAvailable('demo-ds-population'),
          value: populationValues.value,
          year: populationValues.year,
          unit: '人',
        },
        method: '按已存影响范围边界与承灾体要素做点面判定后派生，不重跑模型、不使用直线距离近似。',
      })

      const notes = [...affected.notes, ...clipped.notes]
      if (hazardRef === null) {
        notes.push('影响范围对应多个灾害对象，摘要中不合并为单一灾害编号。')
      }

      const summary: ExposureSummary = {
        resultId,
        hazardRef,
        impactLayerId: IMPACT_LAYER_ID,
        metrics,
        deduplicationRule:
          '同一居民地对象的点位与建成区面按 entityKey（业务对象标识）去重，只计一次。',
        populationYear: populationValues.year,
        scopeMethod:
          '统计范围＝已存影响范围成果的并集；统计方法＝范围内承灾体要素计数与道路裁剪长度累加。',
        matchedRecordCount: affected.recordCount,
        uniqueEntityCount: affected.entityCount,
        affectedCategories: categories,
        note: notes.length > 0 ? notes.join(' ') : null,
      }
      return envelope(summary)
    },

    async listRoutes(resultId: string, query, options?: RequestOptions) {
      assertNotAborted(options)
      await findResult(resultId)
      // hazardPointId 过滤（同一危险源 A/B/C 方案分组）：示例数据未登记分组键时
      // 保持清单不变（示例成果本身即单危险源方案组），与 HTTP 语义一致不伪造。
      const hazardFilter = query?.hazardPointId
      const routes = (await loadRoutes()).filter(
        (route) =>
          route.resultId === resultId &&
          (!hazardFilter ||
            (route as { hazardPointId?: string | null }).hazardPointId === hazardFilter),
      )
      // 阶段8B返工：与 HTTP 同契约返回 Page；示例数据量小，分页在前端 slice，
      // 但 total 仍是该成果的真实总数（不由当前页条数冒充）。
      const page = query?.page ?? 1
      const pageSize = query?.pageSize ?? 20
      const summaries = routes.map((route) => toRouteSummary(route))
      return envelope({
        items: summaries.slice((page - 1) * pageSize, page * pageSize),
        total: summaries.length,
        page,
        pageSize,
      })
    },

    async getRoute(routeId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const route = (await loadRoutes()).find((item) => item.id === routeId)
      if (!route) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到路线 ${routeId}。`,
          details: { routeId },
        })
      }
      return envelope(withDistanceCheck(route))
    },
  }

  /** 路线里程与几何长度复核：不一致时如实记录在来源说明里，不修改数值。 */
  function withDistanceCheck(route: RawRouteRecord): RawRouteRecord {
    const coords = outerCoordinateList(route.geometry)
    const check = verifyRouteDistance(coords.length >= 2 ? coords : null, route.distanceMeters)
    if (check.consistent === null || check.consistent) return route
    return {
      ...route,
      distanceSource: `${route.distanceSource}（前端复核：几何长度 ${formatDistance(
        check.computedMeters,
        { unit: 'm' },
      )}，与登记里程不一致，界面仍显示登记值并保留此说明。）`,
    }
  }

  function toResultSummary(result: RawResultRecord): ResultSummary {
    const summary: ResultSummary = {
      id: result.id,
      kind: result.kind,
      title: result.title,
      version: result.version,
      status: result.status,
      time: result.time,
      sourceType: result.sourceType,
      layerIds: result.layerIds,
      regionLabel: result.regionLabel,
      metrics: result.metrics ?? [],
    }
    if (result.scenarioYear !== undefined) summary.scenarioYear = result.scenarioYear
    return summary
  }

  function toResultDetail(result: RawResultRecord): ResultDetail {
    return {
      ...toResultSummary(result),
      taskId: result.taskId,
      method: result.method,
      parameters: result.parameters ?? {},
      inputs: result.inputs ?? [],
      classification: result.classification ?? null,
      qualityNotes: result.qualityNotes ?? [],
      files: (result.files ?? []).map((file) => ({
        ...file,
        ...(file.url === undefined ? {} : { url: resolvePackageFileUrl(file.url) }),
      })),
    }
  }

  /**
   * JSON 数据包内的相对成果文件地址必须相对数据包根目录解析。
   * 否则在 `/results/:id` 深链接中，浏览器会把 `files/a.csv` 错解为
   * `/results/files/a.csv`，最终命中 SPA 回退页而不是真实成果文件。
   */
  function resolvePackageFileUrl(url: string): string {
    if (/^(?:[a-z][a-z\d+.-]*:|\/\/|\/)/i.test(url)) return url
    return joinUrl(baseUrl, url)
  }

  async function isDatasetServiceAvailable(datasetId: string): Promise<boolean> {
    const manifest = await loadManifest()
    const raw = await loadFile<unknown>(manifest.files.datasets)
    const datasets = requireArray<Dataset>(raw, 'datasets', manifest.files.datasets)
    return datasets.find((dataset) => dataset.id === datasetId)?.serviceAvailable ?? false
  }

  /**
   * 受影响居民地人口：先按业务对象标识去重，再汇总人口属性值。
   *
   * `null` 语义：人口数据集服务不可用、任一对象缺人口值、或参与统计的对象时点不唯一时，
   * 数值与人口时点都返回 `null`（未提供），绝不把示例属性当作人口统计结果，
   * 也不给出一个“看起来有数值”的年份。
   */
  async function populationOfAffected(
    records: Array<{ ref: FeatureRef }>,
  ): Promise<{ value: number | null; year: number | null }> {
    const entities = new Map<string, { population: number | null; year: number | null }>()
    for (const record of records) {
      if (
        record.ref.layerId !== 'base.settlement.point' &&
        record.ref.layerId !== 'base.settlement.polygon'
      ) {
        continue
      }
      const details = await loadLayerFeatures(record.ref.layerId)
      const detail = details.find((item) => item.ref.id === record.ref.id)
      if (!detail) continue
      const key = detail.entityKey ?? `${detail.ref.layerId}:${detail.ref.id}`
      if (entities.has(key)) continue
      const population = detail.properties.population
      const year = detail.properties.populationYear
      entities.set(key, {
        population: typeof population === 'number' ? population : null,
        year: typeof year === 'number' ? year : null,
      })
    }

    // 人口时点只由“确实提供了人口值”的对象决定；时点不唯一时不给单一年份。
    const years = new Set<number>()
    for (const entity of entities.values()) {
      if (entity.population !== null && entity.year !== null) years.add(entity.year)
    }
    const year = years.size === 1 ? ([...years][0] as number) : null

    if (entities.size === 0) return { value: null, year: null }
    if (!(await isDatasetServiceAvailable('demo-ds-population'))) return { value: null, year: null }
    const values = [...entities.values()].map((entity) => entity.population)
    // 只要有对象缺人口值就不汇总：部分求和会被误读为总体人数。
    if (values.some((value) => value === null)) return { value: null, year: null }
    return { value: values.reduce<number>((sum, value) => sum + (value as number), 0), year }
  }

  async function buildStatistics(result: RawResultRecord): Promise<ResultStatistics> {
    const manifest = await loadManifest()
    if (result.kind === 'risk') {
      const zones = await loadLayerFeatures(RISK_LAYER_ID)
      const levels = zones.map((zone) => ({
        riskLevel: zone.properties.riskLevel as string | null,
      }))
      const distribution = deriveRiskDistribution(levels, '个')
      const graded = levels.filter(
        (level) => toRiskLevel(level.riskLevel) !== 'insufficient',
      ).length
      const highRisk = levels.filter((level) =>
        ['higher', 'high'].includes(toRiskLevel(level.riskLevel)),
      ).length
      const metrics: Metric[] = [
        {
          key: 'riskZoneCount',
          label: '风险区对象数',
          value: zones.length,
          unit: '个',
          status: 'known',
          method: `基于数据包 ${manifest.packageId} 的风险区要素现场派生，翻页不改变该数值。`,
          scopeLabel: manifest.scopeLabel,
        },
        {
          key: 'gradedZoneCount',
          label: '已完成分级的风险区数',
          value: graded,
          unit: '个',
          status: 'known',
          method: '只有指标完整、能落入分级区间的对象才计入分级。',
          scopeLabel: manifest.scopeLabel,
        },
        {
          key: 'insufficientZoneCount',
          label: '数据不足的风险区数',
          value: zones.length - graded,
          unit: '个',
          status: zones.length === 0 ? 'noData' : 'known',
          precisionNote: '数据不足的对象不并入低风险，也不参与高风险计数。',
          scopeLabel: manifest.scopeLabel,
        },
        {
          key: 'highRiskCount',
          label: '高与较高风险区数',
          value: highRisk,
          unit: '个',
          status: graded === 0 ? 'noData' : 'known',
          method: '高风险口径为“高”与“较高”两级。',
          scopeLabel: manifest.scopeLabel,
        },
      ]
      return {
        resultId: result.id,
        unit: result.classification?.unit ?? null,
        method: result.classification?.method ?? result.method,
        distribution,
        metrics,
        sampleNote:
          zones.length < 5
            ? '样本量偏小，分布图仅作示例，不构成统计结论。'
            : '数值由示例要素现场派生，分级阈值为示例登记值，不代表正式分级方案。',
      }
    }
    if (result.kind === 'exposure') {
      const { affected, clipped } = await affectedDerivation()
      const distribution: CategoryStatistics[] = deriveCategoryCounts(
        affected.records.map((record) => ({
          key: record.ref.layerId,
          label: record.layerLabel,
          color: null,
        })),
        '条',
      )
      const metrics = deriveExposureMetrics({
        scopeLabel: manifest.scopeLabel,
        matchedRecordCount: affected.recordCount,
        uniqueEntityCount: affected.entityCount,
        unlocatedCount: affected.unlocatedCount,
        affectedRoadMeters: clipped.totalMeters,
        population: {
          serviceAvailable: await isDatasetServiceAvailable('demo-ds-population'),
          value: null,
          year: null,
          unit: '人',
        },
        method: '按已存影响范围与承灾体要素现场派生，不重跑模型。',
      })
      return {
        resultId: result.id,
        unit: '条',
        method: '按影响范围对承灾体逐条判定，点面双表达按 entityKey 去重。',
        distribution,
        metrics,
        sampleNote: '受影响对象清单与统计来自同一批示例要素，翻页不改变统计总数。',
      }
    }
    const routes = (await loadRoutes()).filter((route) => route.resultId === result.id)
    return {
      resultId: result.id,
      unit: '条',
      method: '读取已存路线成果，不在前端重算路径。',
      distribution: deriveCategoryCounts(
        routes.map((route) => ({
          key: route.status,
          label: route.status === 'reachable' ? '可达' : '无可达路径',
          color: null,
        })),
        '条',
      ),
      metrics: deriveRouteMetrics(
        routes.map((route) => ({
          id: route.id,
          label: route.label,
          status: route.status,
          distanceMeters: route.distanceMeters,
        })),
        manifest.scopeLabel,
      ),
      sampleNote: routes.some((route) => route.status === 'unreachable')
        ? '存在不可达路线：界面不提供路径几何与通行时间，避免用直线冒充路线。'
        : null,
    }
  }

  function toRouteSummary(route: RawRouteRecord): RouteSummary {
    return {
      id: route.id,
      resultId: route.resultId,
      label: route.label,
      role: route.role,
      status: route.status,
      distanceMeters: route.distanceMeters,
      durationSeconds: route.durationSeconds,
      networkVersion: route.networkVersion,
      blockedFeatureRefs: route.blockedFeatureRefs ?? [],
      assumptions: route.assumptions ?? [],
      generatedAt: route.generatedAt,
      hazardPointId: (route as { hazardPointId?: string | null }).hazardPointId ?? null,
      facilityType: (route as { facilityType?: string | null }).facilityType ?? null,
    }
  }

  /* -------------------------------- 目录仓库 -------------------------------- */

  const catalog: CatalogRepository = {
    async listDatasets(query?: Partial<DatasetListQuery>, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.datasets)
      const datasets = requireArray<Dataset>(raw, 'datasets', manifest.files.datasets)
      const keyword = query?.keyword?.trim()
      const filtered = datasets.filter((dataset) => {
        if (query?.theme && dataset.theme !== query.theme) return false
        if (query?.dataType && dataset.dataType !== query.dataType) return false
        if (keyword && !dataset.name.includes(keyword)) return false
        return true
      })
      return envelope(paginate(filtered, query?.page ?? 1, query?.pageSize ?? 50))
    },

    async getDataset(datasetId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.datasets)
      const datasets = requireArray<Dataset>(raw, 'datasets', manifest.files.datasets)
      const dataset = datasets.find((item) => item.id === datasetId)
      if (!dataset) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到数据集 ${datasetId}。`,
          details: { datasetId },
        })
      }
      return envelope(dataset)
    },

    async getSource(sourceId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.sources)
      const sources = requireArray<DataSource>(raw, 'sources', manifest.files.sources)
      const source = sources.find((item) => item.id === sourceId)
      if (!source) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到来源 ${sourceId}。`,
          details: { sourceId },
        })
      }
      return envelope(source)
    },

    async getDictionary(dictionaryId: string, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.dictionaries)
      const dictionaries = requireArray<Dictionary>(
        raw,
        'dictionaries',
        manifest.files.dictionaries,
      )
      const dictionary = dictionaries.find((item) => item.id === dictionaryId)
      if (!dictionary) {
        throw new RepositoryError({
          code: 'NOT_FOUND',
          message: `未找到字典 ${dictionaryId}。`,
          details: { dictionaryId },
        })
      }
      return envelope(dictionary)
    },

    async listRegions(
      query?: { parentId?: string; level?: RegionLevel },
      options?: RequestOptions,
    ) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.regions)
      const regions = requireArray<Region>(raw, 'regions', manifest.files.regions)
      const filtered = regions.filter((region) => {
        if (query?.parentId && region.parentId !== query.parentId) return false
        if (query?.level && region.level !== query.level) return false
        return true
      })
      return envelope(filtered)
    },

    async listImports(query?: Partial<ImportLogQuery>, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      const raw = await loadFile<unknown>(manifest.files.imports)
      const logs = requireArray<ImportLog>(raw, 'imports', manifest.files.imports)
      const filtered = logs.filter((log) => {
        if (query?.datasetId && log.datasetId !== query.datasetId) return false
        if (query?.status && log.status !== query.status) return false
        return true
      })
      return envelope(paginate(filtered, query?.page ?? 1, query?.pageSize ?? 50))
    },
  }

  /* -------------------------------- 总览仓库 -------------------------------- */

  const overview: OverviewRepository = {
    async getOverview(query?: OverviewQuery, options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      if (query?.regionId) {
        const raw = await loadFile<unknown>(manifest.files.regions)
        const regions = requireArray<Region>(raw, 'regions', manifest.files.regions)
        if (!regions.some((region) => region.id === query.regionId)) {
          throw new RepositoryError({
            code: 'NOT_FOUND',
            message: `未找到统计范围 ${query.regionId}。`,
            details: { regionId: query.regionId },
          })
        }
      }
      const allResults = await loadResults()
      const zones = await loadLayerFeatures(RISK_LAYER_ID)
      const levels = zones.map((zone) => ({
        riskLevel: zone.properties.riskLevel as string | null,
      }))
      const graded = levels.filter(
        (level) => toRiskLevel(level.riskLevel) !== 'insufficient',
      ).length
      const highRisk = levels.filter((level) =>
        ['higher', 'high'].includes(toRiskLevel(level.riskLevel)),
      ).length
      const { affected, clipped } = await affectedDerivation()

      const snapshotTime: TimeValue = {
        value: manifest.generatedAt,
        precision: 'datetime',
        role: 'generated',
      }

      const keyFeatures: OverviewKeyFeature[] = [...zones]
        .sort((a, b) => {
          const byLevel =
            RISK_LEVEL_ORDER[toRiskLevel(b.properties.riskLevel as string | null)] -
            RISK_LEVEL_ORDER[toRiskLevel(a.properties.riskLevel as string | null)]
          if (byLevel !== 0) return byLevel
          const aValue = typeof a.properties.hrgi === 'number' ? a.properties.hrgi : -1
          const bValue = typeof b.properties.hrgi === 'number' ? b.properties.hrgi : -1
          return bValue - aValue
        })
        .slice(0, 3)
        .map((zone) => {
          const level = toRiskLevel(zone.properties.riskLevel as string | null)
          const hrgi = zone.properties.hrgi
          const metric: Metric = {
            key: 'hrgi',
            label: '综合风险指数',
            value: typeof hrgi === 'number' ? hrgi : null,
            unit: null,
            status: typeof hrgi === 'number' ? 'known' : 'notProvided',
            method: '示例成果登记的无量纲指数，单位未确认，仅显示数值。',
            scopeLabel: manifest.scopeLabel,
          }
          return {
            ref: zone.ref,
            title: zone.title,
            layerLabel: '风险区（示例成果）',
            level,
            metric,
          }
        })

      const data: OverviewData = {
        regionLabel: manifest.scopeLabel,
        snapshotTime,
        metrics: deriveOverviewMetrics({
          scopeLabel: manifest.scopeLabel,
          zoneCount: zones.length,
          gradedZoneCount: graded,
          insufficientZoneCount: zones.length - graded,
          highRiskCount: highRisk,
          affectedEntityCount: affected.entityCount,
          snapshotNote: `快照时间取自数据包生成时间，不是实时监测数据。`,
        }),
        riskDistribution: deriveRiskDistribution(levels, '个'),
        keyFeatures,
        currentResults: allResults
          .filter((result) => result.status === 'published')
          .map((result) => toResultSummary(result)),
        notes: [
          ...manifest.notes,
          `受影响对象数与道路长度由示例要素现场派生：受影响道路长度约 ${formatDistance(
            clipped.totalMeters,
            { unit: 'm' },
          )}（示例值）。`,
          '本页不提供实时监测与预警结论：2050 / 2100 为未来情景，不是实时预报。',
        ],
      }
      return envelope(data)
    },
  }

  const capabilities: Repositories['capabilities'] = {
    async getCapabilities(options?: RequestOptions) {
      assertNotAborted(options)
      const manifest = await loadManifest()
      return envelope(await capabilitiesWithReadOnly(mode, manifest.packageId))
    },
  }

  return {
    mode,
    layers,
    queries,
    results,
    catalog,
    overview,
    capabilities,
  }
}
