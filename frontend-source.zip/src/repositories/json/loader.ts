/**
 * JSON 数据包加载：mock 与 snapshot 两种模式共用同一套加载逻辑。
 *
 * 设计要点（01 §6.3）：
 * 1. 加载器只负责“取到 JSON 对象”，不做业务解释，也不做任何示例数据兜底。
 * 2. 失败一律抛 `RepositoryError`，携带明确错误码，页面据此显示失败状态。
 * 3. `fetchJson` 可注入，便于单测直接从磁盘读取 `public/demo`，不依赖浏览器会话。
 */
import { RepositoryError } from '@/repositories/types'
import { httpStatusError } from '@/repositories/errors'

/** 取一个相对数据包根目录的文件，返回已解析的 JSON。 */
export type JsonFetcher = (filePath: string) => Promise<unknown>

export interface FetchJsonOptions {
  /** 数据包根地址，例如 `/demo/`。 */
  baseUrl: string
  fetcher?: typeof fetch
  /** 统一请求前缀，仅用于 requestId 生成，便于联调定位。 */
  requestIdPrefix?: string
}

function normalizeBase(baseUrl: string): string {
  return baseUrl.endsWith('/') ? baseUrl : `${baseUrl}/`
}

/** 拼接数据包相对地址，保留子路径，避免 `//` 或丢斜杠。 */
export function joinUrl(baseUrl: string, filePath: string): string {
  const base = normalizeBase(baseUrl)
  const relative = filePath.startsWith('/') ? filePath.slice(1) : filePath
  return `${base}${relative}`
}

function httpError(status: number, url?: string): RepositoryError {
  const error = httpStatusError(status, url)
  // 数据包场景下补充更具体的中文说明。
  if (error.code === 'NOT_FOUND') error.message = `数据文件不存在（HTTP 404）：${url ?? ''}`.trim()
  if (error.code === 'SERVICE_UNAVAILABLE') error.message = '数据服务不可用（HTTP 5xx）。'
  return error
}

/**
 * 浏览器 fetch 版本的加载器。
 * 网络错误映射为 `NETWORK_ERROR`（可重试），解析失败映射为 `INVALID_RESPONSE`。
 */
export function createJsonFetcher(options: FetchJsonOptions): JsonFetcher {
  const baseUrl = normalizeBase(options.baseUrl)
  const rawFetch = options.fetcher ?? globalThis.fetch
  return async (filePath: string): Promise<unknown> => {
    if (typeof rawFetch !== 'function') {
      throw new RepositoryError({
        code: 'NOT_IMPLEMENTED',
        message: '当前运行环境不支持 fetch，无法读取数据包。',
      })
    }
    const url = joinUrl(baseUrl, filePath)
    let response: Response
    try {
      response = await rawFetch(url, { headers: { Accept: 'application/json' } })
    } catch (error) {
      // 主动取消不是数据故障，原样抛出交给调用方忽略。
      if (error instanceof DOMException && error.name === 'AbortError') throw error
      throw new RepositoryError({
        code: 'NETWORK_ERROR',
        message: `无法连接数据服务：${url}`,
        retryable: true,
        cause: error,
      })
    }
    if (!response.ok) throw httpError(response.status, url)
    try {
      return (await response.json()) as unknown
    } catch (error) {
      throw new RepositoryError({
        code: 'INVALID_RESPONSE',
        message: `数据文件不是合法 JSON：${url}`,
        httpStatus: response.status,
        cause: error,
      })
    }
  }
}

/** 断言取出根数组字段，缺失或类型不符时报 `INVALID_RESPONSE`。 */
export function requireArray<T>(value: unknown, key: string, filePath: string): T[] {
  if (value === null || typeof value !== 'object') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `${filePath} 顶层结构不是对象。`,
      details: { filePath },
    })
  }
  const list = (value as Record<string, unknown>)[key]
  if (!Array.isArray(list)) {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `${filePath} 缺少数组字段 ${key}。`,
      details: { filePath, key },
    })
  }
  return list as T[]
}

/** 断言取出根对象字段。 */
export function requireObject<T>(value: unknown, key: string, filePath: string): T {
  if (value === null || typeof value !== 'object') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `${filePath} 顶层结构不是对象。`,
      details: { filePath },
    })
  }
  const item = (value as Record<string, unknown>)[key]
  if (item === null || typeof item !== 'object') {
    throw new RepositoryError({
      code: 'INVALID_RESPONSE',
      message: `${filePath} 缺少对象字段 ${key}。`,
      details: { filePath, key },
    })
  }
  return item as T
}
