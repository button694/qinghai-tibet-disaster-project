/**
 * Repository 层契约。
 *
 * 页面与组件只依赖本文件中的接口（01 §6.1、§6.2 分层规则）：
 * 页面 → Repository → mock | snapshot | http。
 * 任何页面都不得直接 import 示例 JSON，也不得在接口失败时改用示例数据（01 §6.3）。
 */
import type {
  Capabilities,
  DataMode,
  Dataset,
  DatasetType,
  DataSource,
  Dictionary,
  Envelope,
  ExposureSummary,
  FeatureDetail,
  FeaturePage,
  FeatureRef,
  ImportLog,
  LayerDefinition,
  Legend,
  OverviewData,
  Page,
  QueryInput,
  QueryResult,
  Region,
  RegionLevel,
  ResultDetail,
  ResultKind,
  ResultStatistics,
  ResultStatus,
  ResultSummary,
  RouteDetail,
  RouteSummary,
  Theme,
} from '@/domain/types'

/* ------------------------------------------------------------------ *
 * 错误
 * ------------------------------------------------------------------ */

/**
 * 已知错误码。与 02 §4.2 错误契约对应：
 * 网络失败或 503 → 服务不可用；无路 → 无可用路线；查询过期 → 需重新查询。
 */
export const KNOWN_REPOSITORY_ERROR_CODES = [
  'SERVICE_UNAVAILABLE',
  'NETWORK_ERROR',
  'NOT_FOUND',
  'UNAUTHORIZED',
  'FORBIDDEN',
  'QUERY_EXPIRED',
  'INVALID_PARAMETER',
  'NO_ROUTE',
  'NOT_IMPLEMENTED',
  'INVALID_RESPONSE',
  'SNAPSHOT_MISSING',
  'UNKNOWN',
] as const

export type RepositoryErrorCode = (typeof KNOWN_REPOSITORY_ERROR_CODES)[number]

export interface RepositoryErrorOptions {
  /** 允许透传服务端返回的其他错误码，便于联调定位。 */
  code: RepositoryErrorCode | string
  message: string
  /** 是否建议用户重试（网络类错误为 true）。 */
  retryable?: boolean
  httpStatus?: number
  requestId?: string
  details?: Record<string, unknown>
  /** 可选的本地化覆盖文案；错误码仍保留用于诊断。 */
  userMessage?: string
  cause?: unknown
}

const ERROR_TEXT: Partial<Record<RepositoryErrorCode, string>> = {
  SERVICE_UNAVAILABLE: '当前内容暂时无法显示，请稍后重试。',
  NETWORK_ERROR: '暂时无法连接数据，请稍后重试。',
  NOT_FOUND: '暂未找到对应内容，请返回后重试。',
  UNAUTHORIZED: '当前登录状态已失效，请重新登录。',
  FORBIDDEN: '当前账号暂时无法查看该内容。',
  QUERY_EXPIRED: '查询结果已过期，请重新查询。',
  INVALID_PARAMETER: '筛选条件有误，请检查后重试。',
  NO_ROUTE: '该条件下无可达路径。',
  NOT_IMPLEMENTED: '该专题数据暂未提供，相关内容正在完善。',
  INVALID_RESPONSE: '数据暂时无法显示，请稍后重试。',
  SNAPSHOT_MISSING: '当前内容暂时无法显示，请稍后重试。',
  UNKNOWN: '数据暂时无法显示，请稍后重试。',
}

export class RepositoryError extends Error {
  readonly code: string
  readonly retryable: boolean
  readonly httpStatus: number | undefined
  readonly requestId: string | undefined
  readonly details: Record<string, unknown> | undefined
  readonly customUserMessage: string | undefined
  /** 原始异常，便于在控制台定位；不参与界面展示。 */
  readonly cause: unknown

  constructor(options: RepositoryErrorOptions) {
    super(options.message)
    this.name = 'RepositoryError'
    this.code = options.code
    this.retryable = options.retryable ?? false
    this.httpStatus = options.httpStatus
    this.requestId = options.requestId
    this.details = options.details
    this.customUserMessage = options.userMessage
    this.cause = options.cause
  }

  /** 面向用户的中文说明。始终说明“未回退示例数据”。 */
  get userMessage(): string {
    if (this.customUserMessage !== undefined) return this.customUserMessage
    const known = ERROR_TEXT[this.code as RepositoryErrorCode]
    return known ?? '数据暂时无法显示，请稍后重试。'
  }
}

export function isRepositoryError(value: unknown): value is RepositoryError {
  return value instanceof RepositoryError
}

/** 未知异常统一收敛为 RepositoryError，避免页面里出现 `unknown` 分叉。 */
export function toRepositoryError(
  error: unknown,
  fallbackCode: RepositoryErrorCode = 'UNKNOWN',
): RepositoryError {
  if (isRepositoryError(error)) return error
  if (error instanceof DOMException && error.name === 'AbortError') {
    return new RepositoryError({ code: fallbackCode, message: '请求已取消。', cause: error })
  }
  const message = error instanceof Error ? error.message : String(error)
  return new RepositoryError({ code: fallbackCode, message, cause: error })
}

/* ------------------------------------------------------------------ *
 * 通用参数
 * ------------------------------------------------------------------ */

export interface RequestOptions {
  signal?: AbortSignal
}

export interface SortInput {
  field: string
  direction: 'asc' | 'desc'
}

export interface PageInput {
  page: number
  pageSize: number
}

/* ------------------------------------------------------------------ *
 * 图层与要素
 * ------------------------------------------------------------------ */

export interface LayerListQuery {
  theme?: Theme
}

export interface FeatureQuery extends PageInput {
  datasetVersion?: string
  sort?: SortInput
  /**
   * 补充（阶段8C）：仅用于地图渲染的服务端几何简化容差（米）；只对线/面几何生效。
   * 属性/导出路径不应传本字段。
   */
  simplifyMeters?: number
}

export interface LayerRepository {
  /** `GET /layers` */
  listLayers(query?: LayerListQuery, options?: RequestOptions): Promise<Envelope<LayerDefinition[]>>
  /** `GET /layers/{layerId}` */
  getLayer(layerId: string, options?: RequestOptions): Promise<Envelope<LayerDefinition>>
  /** `GET /layers/{layerId}/features`（示例包按 manifest 索引读取对应 GeoJSON） */
  listFeatures(
    layerId: string,
    query?: FeatureQuery,
    options?: RequestOptions,
  ): Promise<Envelope<FeaturePage>>
  /** `GET /features/{layerId}/{id}` */
  getFeature(ref: FeatureRef, options?: RequestOptions): Promise<Envelope<FeatureDetail>>
  /** `GET /legends/{legendId}` */
  getLegend(legendId: string, options?: RequestOptions): Promise<Envelope<Legend>>
}

/* ------------------------------------------------------------------ *
 * 查询
 * ------------------------------------------------------------------ */

export interface QueryRepository {
  /** `POST /queries` */
  runQuery(input: QueryInput, options?: RequestOptions): Promise<Envelope<QueryResult>>
  /** `GET /queries/{queryId}?page&pageSize` */
  getQuery(
    queryId: string,
    page: PageInput,
    options?: RequestOptions,
  ): Promise<Envelope<QueryResult>>
}

/* ------------------------------------------------------------------ *
 * 成果
 * ------------------------------------------------------------------ */

export interface ResultListQuery extends PageInput {
  kind?: ResultKind
  status?: ResultStatus
  scenarioYear?: number
}

export interface AffectedFeatureQuery extends PageInput {
  category?: string
  sort?: SortInput
}

export interface ResultRepository {
  /** `GET /results` */
  listResults(
    query?: Partial<ResultListQuery>,
    options?: RequestOptions,
  ): Promise<Envelope<Page<ResultSummary>>>
  /** `GET /results/{resultId}` */
  getResult(resultId: string, options?: RequestOptions): Promise<Envelope<ResultDetail>>
  /** `GET /results/{resultId}/statistics` */
  getStatistics(resultId: string, options?: RequestOptions): Promise<Envelope<ResultStatistics>>
  /** `GET /results/{resultId}/affected-features`（分页不改变统计总数） */
  listAffectedFeatures(
    resultId: string,
    query?: Partial<AffectedFeatureQuery>,
    options?: RequestOptions,
  ): Promise<Envelope<Page<FeatureDetail>>>
  /**
   * `GET /results/{resultId}/exposure-summary`
   *
   * 02 §4 未定义暴露统计接口，本工程自拟该路径（见 DECISIONS D-031）。
   * 后端不提供时返回 404，界面显示「未接入」，不自行拼凑统计。
   */
  getExposureSummary(resultId: string, options?: RequestOptions): Promise<Envelope<ExposureSummary>>
  /**
   * `GET /results/{resultId}/routes?page&pageSize&hazardPointId`
   *
   * 阶段8B返工：服务端分页——total 来自后端 COUNT，items 为当前页；
   * page 缺省 1，pageSize 缺省 20（路线接口上限 100，超限后端 422）。
   * hazardPointId（可选，精确过滤）：同一危险源的 A/B/C 方案分组取数。
   */
  listRoutes(
    resultId: string,
    query?: { page?: number; pageSize?: number; hazardPointId?: string },
    options?: RequestOptions,
  ): Promise<Envelope<Page<RouteSummary>>>
  /** `GET /routes/{routeId}` */
  getRoute(routeId: string, options?: RequestOptions): Promise<Envelope<RouteDetail>>
}

/* ------------------------------------------------------------------ *
 * 数据目录
 * ------------------------------------------------------------------ */

export interface DatasetListQuery extends PageInput {
  theme?: Theme
  dataType?: DatasetType
  keyword?: string
}

export interface ImportLogQuery extends PageInput {
  datasetId?: string
  status?: ImportLog['status']
}

export interface CatalogRepository {
  /** `GET /datasets` */
  listDatasets(
    query?: Partial<DatasetListQuery>,
    options?: RequestOptions,
  ): Promise<Envelope<Page<Dataset>>>
  /** `GET /datasets/{datasetId}` */
  getDataset(datasetId: string, options?: RequestOptions): Promise<Envelope<Dataset>>
  /** `GET /sources/{sourceId}` */
  getSource(sourceId: string, options?: RequestOptions): Promise<Envelope<DataSource>>
  /** `GET /dictionaries/{dictionaryId}` */
  getDictionary(dictionaryId: string, options?: RequestOptions): Promise<Envelope<Dictionary>>
  /** `GET /regions` */
  listRegions(
    query?: { parentId?: string; level?: RegionLevel },
    options?: RequestOptions,
  ): Promise<Envelope<Region[]>>
  /** `GET /imports` */
  listImports(
    query?: Partial<ImportLogQuery>,
    options?: RequestOptions,
  ): Promise<Envelope<Page<ImportLog>>>
}

/* ------------------------------------------------------------------ *
 * 总览与能力
 * ------------------------------------------------------------------ */

export interface OverviewQuery {
  regionId?: string
  resultId?: string
  scenarioYear?: number
}

export interface OverviewRepository {
  /** `GET /overview` */
  getOverview(query?: OverviewQuery, options?: RequestOptions): Promise<Envelope<OverviewData>>
}

export interface CapabilitiesRepository {
  /** `GET /capabilities`：功能能力、数据模式与快照标识 */
  getCapabilities(options?: RequestOptions): Promise<Envelope<Capabilities>>
}

/* ------------------------------------------------------------------ *
 * 工厂返回的完整数据访问集合
 * ------------------------------------------------------------------ */

export interface Repositories {
  /** 当前生效的数据模式，界面的模式标识以此为准。 */
  mode: DataMode
  layers: LayerRepository
  queries: QueryRepository
  results: ResultRepository
  catalog: CatalogRepository
  overview: OverviewRepository
  capabilities: CapabilitiesRepository
}
