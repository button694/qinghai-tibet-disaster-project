import type { FeatureCollection, Geometry } from 'geojson'
import type { ScenarioYear } from '@/domain/scenario'
import { createJsonFetcher } from '@/repositories/json/loader'

export interface PreviewLayer {
  id: string
  label: string
  sourceLayer: string
  file: string
  count: number
  sampled: false
  sha256: string
}
export interface PreviewManifest {
  schemaVersion: 1
  sample: false
  generatedAt: string
  sourceLabel: string
  sourceCrs: string
  displayCrs: 'EPSG:4326'
  sqlServerVerified: false
  vectors: { id: string; count: number; geometry: string; crs: string }[]
  rasters: { id: string; bytes: number; width: number; height: number; crs: string }[]
  exports: PreviewLayer[]
}
export type PreviewFeatures = FeatureCollection<Geometry | null, Record<string, unknown>>

/** Isolated read-only preview repository. Never changes the app's mock/API repository. */
export function createRealPreviewRepository(
  fetcher = createJsonFetcher({ baseUrl: `${import.meta.env.BASE_URL}real-preview/` }),
) {
  return {
    async manifest(): Promise<PreviewManifest> {
      const raw = await fetcher('manifest.json')
      if (!raw || typeof raw !== 'object') throw new Error('真实清单不是对象')
      const m = raw as PreviewManifest
      if (
        m.sample !== false ||
        m.schemaVersion !== 1 ||
        m.displayCrs !== 'EPSG:4326' ||
        !Array.isArray(m.exports) ||
        !Array.isArray(m.vectors) ||
        !Array.isArray(m.rasters)
      ) {
        throw new Error('真实清单格式错误或误用了示例包，已拒绝加载')
      }
      if (
        m.exports.some(
          (l) =>
            !/^[a-zA-Z0-9_-]+\.json$/.test(l.file) || !Number.isInteger(l.count) || l.count < 0,
        )
      ) {
        throw new Error('图层路径或计数无效')
      }
      return m
    },
    async features(layer: PreviewLayer): Promise<PreviewFeatures> {
      if (!/^[a-zA-Z0-9_-]+\.json$/.test(layer.file)) throw new Error('非法图层路径')
      const raw = await fetcher(layer.file)
      const data = raw as PreviewFeatures
      if (
        !data ||
        data.type !== 'FeatureCollection' ||
        !Array.isArray(data.features) ||
        data.features.length !== layer.count
      ) {
        throw new Error(`${layer.label} 几何包无效或数量与清单不一致`)
      }
      return data
    },
    /**
     * 阶段4：按年份读取 2050/2100 未来情景点文件（只读文件快照）。
     * 清单条目必须存在且数量一致，全部要素必须是 Point——情景数据按点渲染，
     * 不是风险面；任何一条不满足都以错误中止，不回退示例数据。
     */
    async scenarioFeatures(
      year: ScenarioYear,
    ): Promise<{ layer: PreviewLayer; features: PreviewFeatures }> {
      const manifest = await this.manifest()
      const layer = manifest.exports.find((item) => item.id === `scenario${year}`)
      if (!layer) throw new Error(`真实清单中没有 ${year} 情景图层，未加载任何数据`)
      const features = await this.features(layer)
      const nonPoint = features.features.filter((item) => item.geometry?.type !== 'Point').length
      if (nonPoint > 0) {
        throw new Error(
          `${layer.label} 含 ${nonPoint} 条非点几何，已中止加载（情景数据只按点渲染）`,
        )
      }
      return { layer, features }
    },
  }
}
