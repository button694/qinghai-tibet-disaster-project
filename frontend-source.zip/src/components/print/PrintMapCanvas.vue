<script setup lang="ts">
/**
 * 打印地图画布（阶段7）。
 *
 * 固定尺寸的 OpenLayers 地图，装载完成后通过 rendercomplete 把画布
 * 快照为 <img>（打印稳定，不依赖浏览器打印 canvas 的时机差异）。
 * - 只画传入的已存要素 / 路线几何，不请求任何在线底图（断网可用）；
 * - 无任何可画内容时发出 map-unavailable，由父级明确提示，禁止输出空白地图；
 * - 比例尺按 Web 墨卡托中心纬度近似换算，并在图面声明「近似」。
 */
import Feature from 'ol/Feature'
import OlMap from 'ol/Map'
import View from 'ol/View'
import { defaults as defaultControls } from 'ol/control'
import type Geometry from 'ol/geom/Geometry'
import LineString from 'ol/geom/LineString'
import Point from 'ol/geom/Point'
import VectorLayer from 'ol/layer/Vector'
import { fromLonLat, toLonLat } from 'ol/proj'
import VectorSource from 'ol/source/Vector'
import type Style from 'ol/style/Style'
import { onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue'

import type { DataMode, FeatureDetail, RouteDetail } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  createResearchBoundaryLayer,
  loadResearchBoundary,
  type ResearchBoundarySource,
} from '@/services/researchBoundary'
import {
  affectedFeatureStyle,
  baseLayerStyle,
  impactAreaStyle,
  MAP_COLORS,
  routeEndpointStyle,
  routeLineStyle,
  routeRiskSegmentStyle,
  riskLevelStyle,
} from '@/config/mapStyle'

type VectorSource3857 = VectorSource<Feature<Geometry>>

const props = defineProps<{
  variant: 'risk' | 'exposure' | 'emergency'
  features: FeatureDetail[]
  route: RouteDetail | null
  /** API 模式下把真实研究区边界放在专题图底层。 */
  mode?: DataMode
  /** 传 null 时使用中性要素样式，不把未经登记的正式字段当作风险等级。 */
  riskLevelField?: string | null
}>()

const emit = defineEmits<{
  /** 画布快照就绪（dataUrl 供打印 <img>；scale 为近似比例尺描述）。 */
  ready: [payload: { dataUrl: string; scaleLabel: string }]
  /** 没有任何可画内容（无几何也不允许猜）。 */
  mapUnavailable: []
}>()

const host = ref<HTMLDivElement | null>(null)
/** 快照完成后的 <img> 数据地址；null 期间显示画布本体。 */
const mapImage = ref<string | null>(null)
const scaleLabel = ref('')

const mapRef = shallowRef<OlMap | null>(null)
const sourceRef = shallowRef<VectorSource3857 | null>(null)
const boundarySourceRef = shallowRef<ResearchBoundarySource | null>(null)
const boundaryStatus = ref<'idle' | 'loading' | 'ready' | 'failed'>('idle')
let boundaryController: AbortController | null = null
let renderDone = false

function featureStyle(detail: FeatureDetail): Style {
  if (props.variant === 'risk') {
    const riskLevelField = props.riskLevelField === undefined ? 'riskLevel' : props.riskLevelField
    if (riskLevelField === null) return baseLayerStyle()
    const level = detail.properties[riskLevelField]
    return riskLevelStyle(typeof level === 'string' ? level : 'insufficient')
  }
  if (props.variant === 'exposure') {
    // 影响范围面（登记在 impact 图层）用风险红；其余受影响对象用数据青。
    const isImpact = detail.ref.layerId.includes('impact')
    return isImpact ? impactAreaStyle() : affectedFeatureStyle(familyOf(detail))
  }
  return routeRiskSegmentStyle()
}

function familyOf(detail: FeatureDetail): 'Point' | 'LineString' | 'Polygon' {
  if (detail.geometry === null) return 'Point'
  if (detail.geometry.type === 'LineString') return 'LineString'
  if (detail.geometry.type === 'Polygon') return 'Polygon'
  return 'Point'
}

/** 已存路线几何为 GeoJSON LineString；这里只取坐标（类型收窄，与 stage5 RouteMapCanvas 同口径）。 */
function routeCoordinates(geometry: { type: string; coordinates: number[][] }): number[][] {
  return geometry.coordinates
}

function rebuild(): void {
  const map = mapRef.value
  const source = sourceRef.value
  if (map === null || source === null) return
  source.clear()
  boundarySourceRef.value?.clear()
  renderDone = false
  mapImage.value = null

  const { features } = toOlFeatures(props.features)
  for (const olFeature of features) {
    const layerId = String(olFeature.get('__layerId') ?? '')
    const featureId = String(olFeature.get('__featureId') ?? '')
    const detail = props.features.find(
      (item) => item.ref.layerId === layerId && item.ref.id === featureId,
    )
    olFeature.setStyle(detail !== undefined ? featureStyle(detail) : riskLevelStyle('insufficient'))
  }
  // 无几何要素不上图（toOlFeatures 已按契约跳过）；父级说明行已如实记录，这里不补造坐标。
  source.addFeatures(features)

  let hasDrawable = features.length > 0
  if (
    props.route !== null &&
    props.route.geometry !== null &&
    props.route.geometry.type === 'LineString'
  ) {
    const coordinates = routeCoordinates(props.route.geometry).map(([lon, lat]) =>
      fromLonLat([lon ?? 0, lat ?? 0]),
    )
    const line = new Feature<Geometry>(new LineString(coordinates))
    line.setStyle(routeLineStyle(props.route.role))
    source.addFeature(line)
    hasDrawable = true
  }
  for (const endpoint of [props.route?.origin, props.route?.destination]) {
    if (endpoint?.lonLat == null) continue
    const marker = new Feature({ geometry: new Point(fromLonLat(endpoint.lonLat)) })
    marker.setStyle(routeEndpointStyle(endpoint === props.route?.origin ? 'origin' : 'destination'))
    source.addFeature(marker)
    hasDrawable = true
  }

  if (!hasDrawable) {
    emit('mapUnavailable')
    return
  }
  const extents = [source.getExtent(), boundarySourceRef.value?.getExtent()].filter(
    (extent): extent is [number, number, number, number] => extent !== undefined,
  )
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  for (const box of extents) {
    extent[0] = Math.min(extent[0], box[0] ?? 0)
    extent[1] = Math.min(extent[1], box[1] ?? 0)
    extent[2] = Math.max(extent[2], box[2] ?? 0)
    extent[3] = Math.max(extent[3], box[3] ?? 0)
  }
  if (!Number.isFinite(extent[0])) {
    // 正式边界正在读取时先等待，不把尚未渲染完成误报为“地图不可用”。
    if (props.mode === 'api' && boundaryStatus.value === 'loading') return
    emit('mapUnavailable')
    return
  }
  map.getView().fit(extent, { padding: [24, 24, 24, 24], maxZoom: 14 })
}

function snapshot(): void {
  const map = mapRef.value
  if (map === null || renderDone) return
  if (props.mode === 'api' && boundaryStatus.value === 'loading') return
  renderDone = true
  const canvas = map.getViewport()?.querySelector('canvas')
  try {
    const dataUrl = canvas instanceof HTMLCanvasElement ? canvas.toDataURL('image/png') : null
    if (dataUrl === null || dataUrl.length < 200) {
      emit('mapUnavailable')
      return
    }
    mapImage.value = dataUrl
    scaleLabel.value = computeScaleLabel(map)
    emit('ready', { dataUrl, scaleLabel: scaleLabel.value })
  } catch {
    // toDataURL 失败（如画布被跨域污染）：明确提示，不输出看似成功的空白地图。
    emit('mapUnavailable')
  }
}

/** 近似比例尺：Web 墨卡托下 resolution 为赤道米/像素，按中心纬度 cos 校正。 */
function computeScaleLabel(map: OlMap): string {
  const view = map.getView()
  const resolution = view.getResolution()
  const center = view.getCenter()
  if (resolution === undefined || center === undefined) return '比例尺：未提供'
  const lonLat = toLonLat(center)
  const centerLat = lonLat[1] ?? 0
  const metersPerPixel = resolution * Math.max(0.1, Math.cos((centerLat * Math.PI) / 180))
  const candidates = [
    100, 200, 500, 1000, 2000, 5000, 10000, 20000, 50000, 100000, 200000, 500000, 1000000,
  ]
  const target = 110 * metersPerPixel
  const chosen = candidates.find((value) => value >= target) ?? 1000000
  const widthPx = Math.round(chosen / metersPerPixel)
  const label = chosen >= 1000 ? `${chosen / 1000} 千米` : `${chosen} 米`
  return `近似比例尺（Web墨卡托中心纬度换算）：${widthPx}px ≈ ${label}`
}

onMounted(() => {
  const source = new VectorSource() as VectorSource3857
  sourceRef.value = source
  const boundarySource = new VectorSource() as ResearchBoundarySource
  boundarySourceRef.value = boundarySource
  const boundaryLayer = createResearchBoundaryLayer(boundarySource, 1)
  const map = new OlMap({
    target: host.value ?? undefined,
    controls: defaultControls({ zoom: false, attribution: false }),
    view: new View({ center: fromLonLat([90, 33]), zoom: 5, minZoom: 3, maxZoom: 16 }),
    layers: [
      boundaryLayer,
      new VectorLayer({
        source,
        style: riskLevelStyle('insufficient'),
        background: MAP_COLORS.background,
      }),
    ],
  })
  mapRef.value = map
  map.on('rendercomplete', () => snapshot())
  boundaryStatus.value = props.mode === 'api' ? 'loading' : 'ready'
  rebuild()

  if (props.mode === 'api') {
    boundaryController = new AbortController()
    void loadResearchBoundary(props.mode, { signal: boundaryController.signal })
      .then((items) => {
        if (boundarySourceRef.value === null) return
        const { features } = toOlFeatures(items)
        boundarySourceRef.value.clear()
        boundarySourceRef.value.addFeatures(features)
        boundaryStatus.value = 'ready'
        rebuild()
      })
      .catch((error: unknown) => {
        if (error instanceof DOMException && error.name === 'AbortError') return
        boundaryStatus.value = 'failed'
        rebuild()
      })
  }
})

onBeforeUnmount(() => {
  boundaryController?.abort()
  boundaryController = null
  mapRef.value?.setTarget(undefined)
  mapRef.value = null
  boundarySourceRef.value = null
})

watch(
  () => [props.features, props.route],
  () => rebuild(),
  { deep: false },
)
</script>

<template>
  <div class="print-map">
    <div v-show="mapImage === null" ref="host" class="print-map-canvas" aria-hidden="true"></div>
    <img
      v-if="mapImage !== null"
      :src="mapImage"
      alt="专题图地图快照"
      class="print-map-image"
      data-testid="print-map-image"
    />
    <span v-if="scaleLabel !== ''" class="print-map-scale" data-testid="print-scale">{{
      scaleLabel
    }}</span>
  </div>
</template>

<style scoped>
.print-map {
  position: relative;
  width: 100%;
  height: 420px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  overflow: hidden;
  background: var(--color-map-bg);
}

.print-map-canvas,
.print-map-image {
  width: 100%;
  height: 100%;
  display: block;
  object-fit: contain;
}

.print-map-scale {
  position: absolute;
  left: var(--space-2);
  bottom: var(--space-2);
  padding: 2px var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font-size: var(--font-size-caption);
}
</style>
