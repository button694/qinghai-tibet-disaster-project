<script setup lang="ts">
/**
 * 加载占位（阶段1，01 §4.4「页面低频切换」）。
 *
 * 用途：数据请求尚未返回时的唯一占位形态。
 * 硬性约束：加载中**不显示任何数值**，避免用 0 或示例统计冒充结果；
 * 骨架条只表达“正在读取”，不表达数量、进度或数值大小。
 */
import { computed } from 'vue'

const props = withDefaults(
  defineProps<{
    /** 加载说明文案 */
    label?: string
    /** 骨架条数量，至少 1 条 */
    lines?: number
  }>(),
  {
    label: '正在加载数据…',
    lines: 3,
  },
)

/** 非法入参（负数、NaN、小数）一律收敛为 1 条，不生成无意义的空骨架 */
const lineCount = computed(() => {
  const value = Math.floor(props.lines)
  return Number.isFinite(value) && value > 0 ? value : 1
})

const lineKeys = computed(() => Array.from({ length: lineCount.value }, (_item, index) => index))
</script>

<template>
  <div
    class="loading-state"
    role="status"
    aria-busy="true"
    data-testid="loading-state"
    :data-line-count="lineCount"
  >
    <p class="loading-label">{{ label }}</p>
    <ul class="loading-lines" aria-hidden="true">
      <li v-for="key in lineKeys" :key="key" class="loading-line" />
    </ul>
  </div>
</template>

<style scoped>
.loading-state {
  display: flex;
  flex-direction: column;
  gap: var(--state-gap);
  padding: var(--state-padding);
  border: var(--state-border-width) solid var(--color-border);
  border-radius: var(--state-radius);
  background: var(--state-surface);
}

.loading-label {
  margin: 0;
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.loading-lines {
  display: flex;
  flex-direction: column;
  gap: var(--skeleton-line-gap);
  margin: 0;
  padding: 0;
  list-style: none;
}

.loading-line {
  width: var(--skeleton-line-width);
  height: var(--skeleton-line-height);
  border-radius: var(--skeleton-radius);
  background: linear-gradient(
    90deg,
    var(--skeleton-base) 25%,
    var(--skeleton-highlight) 37%,
    var(--skeleton-base) 63%
  );
  background-size: 400% 100%;
  animation: loading-shimmer var(--skeleton-duration) ease-in-out infinite;
}

.loading-line:last-child {
  width: var(--skeleton-line-width-last);
}

@keyframes loading-shimmer {
  from {
    background-position: 100% 50%;
  }

  to {
    background-position: 0 50%;
  }
}
</style>
