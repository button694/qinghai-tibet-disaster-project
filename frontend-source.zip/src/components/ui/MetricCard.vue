<script setup lang="ts">
/**
 * 指标卡（阶段1，01 §4.4「每项显示统计范围、时点和口径，未知显示“—”」）。
 *
 * 格式化规则全部来自 `domain/format.ts`，本组件不自行拼接数值、单位或状态文案：
 * - 值：`formatMetricValue`（`notProvided` / `noData` / `notApplicable` 直接输出状态文案）。
 * - 口径：`formatMetricMeta`（年份、方法、范围、精度说明）。
 * - 状态：`metricStatusText`。
 * `null` 永远不显示成 0；单位未确认时不补单位。
 */
import { computed } from 'vue'

import {
  formatMetricMeta,
  formatMetricValue,
  formatYear,
  metricStatusText,
  NOT_REGISTERED_TEXT,
} from '@/domain/format'
import type { Metric } from '@/domain/types'

const props = withDefaults(
  defineProps<{
    /** 指标数据（含 status，null 表示未知） */
    metric: Metric
    /** 视觉权重：`high` 用于总览四项主指标 */
    emphasis?: 'default' | 'high'
  }>(),
  {
    emphasis: 'default',
  },
)

const valueText = computed(() => formatMetricValue(props.metric))

const statusText = computed(() => metricStatusText(props.metric.status))

/** 非 known 状态一律按缺失处理：显示状态文案，不显示数字 */
const isMissing = computed(() => props.metric.status !== 'known')

const metaText = computed(() => formatMetricMeta(props.metric))

/** 有值但单位未登记时给出提示，而不是自动补一个单位（02 §2.6） */
const unitNote = computed(() =>
  !isMissing.value && props.metric.value !== null && props.metric.unit === null
    ? `单位${NOT_REGISTERED_TEXT}`
    : '',
)

const methodText = computed(() => props.metric.method ?? NOT_REGISTERED_TEXT)

const precisionText = computed(() => props.metric.precisionNote ?? NOT_REGISTERED_TEXT)
</script>

<template>
  <article
    class="metric-card"
    :class="`metric-card--${emphasis}`"
    data-testid="metric-card"
    :data-metric-key="metric.key"
    :data-metric-status="metric.status"
  >
    <p class="metric-label">{{ metric.label }}</p>

    <p class="metric-value tabular-nums" :class="{ 'is-missing': isMissing }">{{ valueText }}</p>

    <p v-if="unitNote" class="metric-unit-note">{{ unitNote }}</p>

    <p v-if="isMissing" class="metric-missing-note">
      数据源中该项为空（{{ statusText }}），界面不使用 0 占位。
    </p>

    <p v-if="metaText" class="metric-meta">{{ metaText }}</p>

    <!-- 方法说明入口：默认收起，展开后给出方法、精度与年份（可追溯到 02 的口径字段） -->
    <details class="metric-method">
      <summary class="metric-method-summary">口径与方法</summary>
      <dl class="metric-method-list">
        <dt>统计方法</dt>
        <dd>{{ methodText }}</dd>
        <dt>精度说明</dt>
        <dd>{{ precisionText }}</dd>
        <dt>指标年份</dt>
        <dd>{{ formatYear(metric.year) }}</dd>
        <dt>统计范围</dt>
        <dd>{{ metric.scopeLabel ?? NOT_REGISTERED_TEXT }}</dd>
      </dl>
    </details>

    <div v-if="$slots.source" class="metric-source">
      <slot name="source" />
    </div>
  </article>
</template>

<style scoped>
.metric-card {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  min-width: 0;
  padding: var(--space-4);
  border: var(--state-border-width) solid var(--color-border);
  border-left: var(--space-1) solid var(--color-border);
  border-radius: var(--state-radius);
  background: var(--state-surface);
}

.metric-card--high {
  border-left-color: var(--color-primary);
  box-shadow: var(--shadow-panel);
}

.metric-label {
  margin: 0;
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.metric-value {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-metric);
  font-weight: var(--button-font-weight);
  line-height: var(--line-height-tight);
  font-variant-numeric: tabular-nums;
}

.metric-value.is-missing {
  color: var(--state-text-color);
  font-size: var(--font-size-section-title);
}

.metric-unit-note,
.metric-missing-note,
.metric-meta {
  margin: 0;
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.metric-missing-note {
  color: var(--color-warning-text);
}

.metric-method {
  margin-top: var(--space-2);
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.metric-method-summary {
  cursor: pointer;
  color: var(--color-primary);
}

.metric-method-list {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: var(--space-1) var(--space-2);
  margin: var(--space-2) 0 0;
}

.metric-method-list dt {
  color: var(--state-text-color);
}

.metric-method-list dd {
  margin: 0;
  color: var(--color-text);
}

.metric-source {
  display: flex;
  flex-wrap: wrap;
  gap: var(--badge-gap);
  margin-top: var(--space-2);
}
.metric-card {
  text-align: left;
  box-shadow: 0 2px 8px rgb(16 29 43 / 5%);
}
.metric-meta,
.metric-label,
.metric-value,
.metric-method-list dd {
  overflow-wrap: anywhere;
}
.metric-value {
  font-variant-numeric: tabular-nums;
}
</style>
