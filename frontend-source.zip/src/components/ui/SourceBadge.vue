<script setup lang="ts">
/**
 * 数据来源徽标（阶段1，01 §6.3 三种数据模式）。
 *
 * 规则：
 * 1. 文案只用 `DATA_MODE_LABEL` 映射（示例数据 / 成果快照 / 正式接口），不另起说法。
 * 2. `mock` 模式必须表达「示例数据（非真实数据）」语义，避免把合成示例当结论。
 * 3. `title` 里给出快照标识与统计范围；未提供时明确写“未提供”，不猜不补。
 *    情景年份（2050/2100）属于情景数据，不是实时预警，本组件不做实时性表述。
 */
import { computed } from 'vue'

import { NOT_PROVIDED_TEXT } from '@/domain/format'
import { DATA_MODE_DESCRIPTION, DATA_MODE_LABEL } from '@/domain/labels'
import type { DataMode } from '@/domain/types'

const props = defineProps<{
  /** 当前数据模式 */
  mode: DataMode
  /** 成果快照标识（snapshot 模式必填才有意义） */
  snapshotId?: string
  /** 统计范围说明 */
  scopeLabel?: string
}>()

const modeLabel = computed(() => DATA_MODE_LABEL[props.mode])

/** mock 模式必须带上“非真实数据”的限定语 */
const displayText = computed(() =>
  props.mode === 'mock' ? `${modeLabel.value}（非真实数据）` : modeLabel.value,
)

const badgeTitle = computed(() =>
  [
    DATA_MODE_DESCRIPTION[props.mode],
    props.scopeLabel ? `数据范围：${props.scopeLabel}` : `数据范围：${NOT_PROVIDED_TEXT}`,
  ].join('；'),
)
</script>

<template>
  <span class="source-badge" :data-mode="mode" :title="badgeTitle" data-testid="source-badge">
    <span class="source-badge-text">{{ displayText }}</span>
  </span>
</template>

<style scoped>
.source-badge {
  display: inline-flex;
  align-items: center;
  gap: var(--badge-gap);
  padding: var(--badge-padding-y) var(--badge-padding-x);
  border: var(--badge-border-width) solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--badge-surface);
  color: var(--badge-text);
  font-size: var(--badge-font-size);
  line-height: var(--line-height-tight);
  white-space: nowrap;
}

/* 示例数据用警示底色，避免被误读为真实数据 */
.source-badge[data-mode='mock'] {
  border-color: var(--color-warning);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
}

.source-badge[data-mode='snapshot'] {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
}

.source-badge[data-mode='api'] {
  border-color: var(--color-success);
  background: var(--color-success-surface);
  color: var(--color-success-text);
}

.source-badge-snapshot {
  font-variant-numeric: tabular-nums;
  opacity: 0.85;
}
</style>
