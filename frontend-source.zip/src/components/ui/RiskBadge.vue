<script setup lang="ts">
/**
 * 风险等级徽标（阶段1，01 §4.2）。
 *
 * 规则：
 * 1. 颜色只能来自 `RISK_LEVEL_COLOR` / `RISK_LEVEL_TEXT_COLOR`，组件内不写颜色字面量。
 * 2. 徽标始终带**文字**，且与等级一一对应；数据不足额外叠加斜线纹理，
 *    这样不依赖颜色也能区分等级（对色觉障碍与投影仪都成立）。
 * 3. `null` 或未知等级一律显示「等级未提供」并使用「数据不足」灰蓝色，
 *    **绝不默认成低风险**（低风险是有依据的结论，未知不是）。
 */
import { computed } from 'vue'

import {
  RISK_LEVEL_COLOR,
  RISK_LEVEL_LABEL,
  RISK_LEVEL_PATTERN,
  RISK_LEVEL_TEXT_COLOR,
  isRiskLevel,
  riskLevelLabel,
} from '@/domain/risk'
import type { RiskLevel } from '@/domain/types'

const props = withDefaults(
  defineProps<{
    /** 风险等级；`null` / `undefined` / 非枚举值都按“未提供”处理 */
    level: RiskLevel | string | null | undefined
    /** 是否叠加斜线纹理；数据不足与未知等级始终叠加，不受该开关影响 */
    showPattern?: boolean
  }>(),
  {
    showPattern: true,
  },
)

/** 未知等级统一落到 insufficient 的灰蓝色，绝不下调到 low */
const resolvedLevel = computed<RiskLevel>(() =>
  isRiskLevel(props.level) ? props.level : 'insufficient',
)

const isProvided = computed(() => isRiskLevel(props.level))

const levelText = computed(() =>
  isProvided.value ? RISK_LEVEL_LABEL[resolvedLevel.value] : '等级未提供',
)

const badgeTitle = computed(() =>
  isProvided.value
    ? `风险等级：${riskLevelLabel(resolvedLevel.value)}`
    : '风险等级未提供：按“数据不足”颜色显示，不按低风险处理',
)

const badgeStyle = computed(() => ({
  backgroundColor: RISK_LEVEL_COLOR[resolvedLevel.value],
  color: RISK_LEVEL_TEXT_COLOR[resolvedLevel.value],
}))

const patterned = computed(
  () =>
    RISK_LEVEL_PATTERN[resolvedLevel.value] === 'hatch' && (props.showPattern || !isProvided.value),
)
</script>

<template>
  <span
    class="risk-badge"
    :class="{ 'is-patterned': patterned, 'is-unprovided': !isProvided }"
    :style="badgeStyle"
    :title="badgeTitle"
    data-testid="risk-badge"
    :data-risk-level="resolvedLevel"
    :data-risk-provided="String(isProvided)"
  >
    <span class="risk-badge-text">{{ levelText }}</span>
  </span>
</template>

<style scoped>
.risk-badge {
  position: relative;
  display: inline-flex;
  align-items: center;
  gap: var(--badge-gap);
  overflow: hidden;
  padding: var(--badge-padding-y) var(--badge-padding-x);
  border: var(--badge-border-width) solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  font-size: var(--badge-font-size);
  font-weight: var(--button-font-weight);
  line-height: var(--line-height-tight);
  white-space: nowrap;
  flex-shrink: 0;
  max-width: none;
}

/* 斜线纹理用 currentColor，避免在组件里写颜色值 */
.risk-badge.is-patterned::after {
  content: '';
  position: absolute;
  inset: 0;
  background-image: repeating-linear-gradient(
    45deg,
    currentColor 0,
    currentColor var(--risk-hatch-width),
    transparent var(--risk-hatch-width),
    transparent var(--risk-hatch-size)
  );
  opacity: var(--risk-hatch-opacity);
  pointer-events: none;
}

.risk-badge-text {
  position: relative;
  z-index: 1;
}

.risk-badge.is-unprovided {
  font-style: italic;
}
</style>
