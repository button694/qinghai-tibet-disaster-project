<script setup lang="ts">
/**
 * 空状态（阶段1）。
 *
 * 语义边界：请求**成功**但结果集为空时使用（例如示例包中刻意留空的演示范围）。
 * 请求失败必须使用 ErrorState，不能渲染成空状态或 0；
 * 正在加载必须使用 LoadingState。本组件不显示任何数值。
 */
defineProps<{
  /** 空状态标题，例如「该范围内没有登记对象」 */
  title: string
  /** 补充说明：写清是“确实没有数据”还是“筛选条件过严” */
  description?: string
}>()
</script>

<template>
  <section class="empty-state" role="status" data-testid="empty-state">
    <p class="empty-title">{{ title }}</p>
    <p v-if="description" class="empty-description">{{ description }}</p>
    <div v-if="$slots.default" class="empty-actions">
      <slot />
    </div>
  </section>
</template>

<style scoped>
.empty-state {
  display: flex;
  flex-direction: column;
  gap: var(--state-gap);
  align-items: flex-start;
  padding: var(--state-padding);
  border: var(--state-border-width) dashed var(--color-border);
  border-radius: var(--state-radius);
  background: var(--state-surface);
}

.empty-title {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
  font-weight: var(--button-font-weight);
}

.empty-description {
  margin: 0;
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.empty-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  margin-top: var(--space-2);
}
</style>
