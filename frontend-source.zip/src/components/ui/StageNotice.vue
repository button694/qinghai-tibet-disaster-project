<script setup lang="ts">
/**
 * 阶段占位说明（阶段0 专用）。
 *
 * 用途只有一个：让路由骨架里的页面明确写出“本页业务尚未实现，计划在阶段N实现”，
 * 避免出现“功能开发中”之类冒充实现的气泡，也不允许伪造数据或假按钮。
 * 当某页在对应阶段真正实现后，该页必须删除本组件，而不是长期保留。
 */
defineProps<{
  /** 页面名称 */
  heading: string
  /** 计划实现该页的阶段 */
  stage: string
  /** 该页计划提供的能力（照抄 03 的阶段任务，不额外承诺） */
  planned: string[]
}>()
</script>

<template>
  <section class="stage-notice" data-testid="stage-notice">
    <h1 class="stage-heading">{{ heading }}</h1>

    <p class="stage-line">
      <strong>当前状态：未实现。</strong>
      本页在阶段0 只有路由入口，没有数据、没有查询、没有地图，也不存在任何可点击的假操作。
    </p>

    <p class="stage-line">计划实现阶段：{{ stage }}</p>

    <h2 class="stage-subheading">该页计划提供的能力（来自 03 阶段任务）</h2>
    <ul class="stage-list">
      <li v-for="item in planned" :key="item">{{ item }}</li>
    </ul>

    <p class="stage-footnote">
      数据前提：基础数据与二次分析已完成入库，但数据库、栅格与服务当前不在本机；
      接入真实服务前，全部业务页面按示例数据模式开发和验收。
    </p>
  </section>
</template>

<style scoped>
.stage-notice {
  max-width: 880px;
  padding: var(--space-6);
  border: var(--state-border-width) solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--state-surface);
}

.stage-heading {
  font-size: var(--font-size-page-title);
  margin-bottom: var(--space-4);
}

.stage-subheading {
  font-size: var(--font-size-section-title);
  margin: var(--space-6) 0 var(--space-2);
}

.stage-line {
  margin: 0 0 var(--space-2);
  color: var(--color-text);
}

.stage-list {
  margin: 0;
  padding-left: 1.25em;
  color: var(--state-text-color);
}

.stage-footnote {
  margin: var(--space-6) 0 0;
  padding-top: var(--space-3);
  border-top: var(--state-border-width) solid var(--color-border);
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}
</style>
