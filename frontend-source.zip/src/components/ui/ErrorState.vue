<script setup lang="ts">
/**
 * 失败状态（阶段1，01 §6.3「接口失败不自动改用示例数据」）。
 *
 * 硬性约束：
 * 1. 必须显示**错误码**与 `RepositoryError.userMessage`——该文案本身已写明“未回退示例数据”。
 * 2. 绝不显示任何统计数字或占位数值（不显示 0，不显示示例条数）。
 * 3. 不得把失败渲染成空状态；失败就是失败，由本组件承担。
 */
import { computed } from 'vue'

import { toRepositoryError, type RepositoryError } from '@/repositories/types'

const props = defineProps<{
  /** 原始异常；非 RepositoryError 会被收敛后展示，不做静默吞掉 */
  error: unknown
  /** 标题，缺省为「数据读取失败」 */
  title?: string
  /** 是否显示重试按钮；缺省沿用错误自身的 retryable 标记 */
  retryable?: boolean
}>()

const emit = defineEmits<{
  retry: []
}>()

const repoError = computed<RepositoryError>(() => toRepositoryError(props.error))

const heading = computed(() => props.title ?? '数据读取失败')

/** 未显式传入时沿用错误码的判断：网络类错误才提示重试 */
const canRetry = computed(() => props.retryable ?? repoError.value.retryable)

function onRetry(): void {
  emit('retry')
}
</script>

<template>
  <section
    class="error-state"
    role="alert"
    data-testid="error-state"
    :data-error-code="repoError.code"
  >
    <p class="error-title">{{ heading }}</p>

    <p class="error-message">{{ repoError.userMessage }}</p>

    <p class="error-help">当前内容暂时无法显示，请稍后重试；如果问题持续存在，请联系平台管理员。</p>

    <div class="error-actions">
      <button v-if="canRetry" type="button" class="btn btn--primary" @click="onRetry">重试</button>
      <slot />
    </div>
  </section>
</template>

<style scoped>
.error-state {
  display: flex;
  flex-direction: column;
  gap: var(--state-gap);
  padding: var(--state-padding);
  border: var(--state-border-width) solid var(--error-border-color);
  border-radius: var(--state-radius);
  background: var(--error-surface);
}

.error-title {
  margin: 0;
  color: var(--error-title-color);
  font-size: var(--font-size-body);
  font-weight: var(--button-font-weight);
}

.error-message {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
}

.error-help {
  margin: 0;
  color: var(--state-text-color);
  font-size: var(--font-size-caption);
}

.error-actions {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
  margin-top: var(--space-2);
}

.error-actions:empty {
  display: none;
}
</style>
