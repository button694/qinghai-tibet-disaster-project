<script setup lang="ts">
import { computed } from 'vue'
import { formatCount, formatDistance } from '@/domain/format'
import { ROUTE_ROLE_LABEL } from '@/domain/labels'
import type { RouteSummary } from '@/domain/types'

const props = defineProps<{
  routes: RouteSummary[]
  total: number
  page: number
  pageSize: number
  loading: boolean
  errorText: string | null
}>()
const emit = defineEmits<{
  select: [routeId: string]
  pageChange: [page: number]
}>()
const pageCount = computed(() => Math.max(1, Math.ceil(props.total / props.pageSize)))
const rangeStart = computed(() => (props.total === 0 ? 0 : (props.page - 1) * props.pageSize + 1))
const rangeEnd = computed(() => Math.min(props.total, props.page * props.pageSize))
function distanceText(route: RouteSummary): string {
  return route.distanceMeters === null
    ? '距离未提供'
    : formatDistance(route.distanceMeters, { unit: 'm' })
}
</script>

<template>
  <section class="route-directory" data-testid="route-directory" aria-label="全部路线目录">
    <header class="directory-head">
      <div>
        <h2>全部路线</h2>
        <p>
          当前成果共
          <b data-testid="all-routes-total">{{ formatCount(props.total) }}</b> 条路线；当前显示
          {{ rangeStart }}—{{ rangeEnd }} 条。
        </p>
      </div>
      <span class="directory-note">当前危险源方案仍在右侧单独切换</span>
    </header>
    <p v-if="props.errorText" class="directory-error" role="alert">{{ props.errorText }}</p>
    <p v-else-if="props.loading" class="directory-state" role="status">正在读取路线目录…</p>
    <template v-else>
      <div class="directory-table-wrap">
        <table class="directory-table">
          <caption class="visually-hidden">
            全部路线分页目录
          </caption>
          <thead>
            <tr>
              <th>路线</th>
              <th>危险源</th>
              <th>终点类型</th>
              <th>状态</th>
              <th>距离</th>
              <th>操作</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="route in props.routes"
              :key="route.id"
              :data-testid="'all-route-' + route.id"
            >
              <td>
                <b>{{ route.label }}</b
                ><small>{{ ROUTE_ROLE_LABEL[route.role] }}</small>
              </td>
              <td>{{ route.hazardPointId ?? '未标注' }}</td>
              <td>{{ route.facilityType ?? '未提供' }}</td>
              <td>{{ route.status === 'reachable' ? '可达' : '不可达' }}</td>
              <td>{{ distanceText(route) }}</td>
              <td>
                <button
                  type="button"
                  class="btn btn--small"
                  :data-testid="'all-route-select-' + route.id"
                  @click="emit('select', route.id)"
                >
                  查看路线
                </button>
              </td>
            </tr>
            <tr v-if="props.routes.length === 0">
              <td colspan="6">当前成果没有路线记录。</td>
            </tr>
          </tbody>
        </table>
      </div>
      <nav class="directory-pager" aria-label="全部路线分页">
        <button
          type="button"
          class="btn btn--small"
          :disabled="props.page <= 1"
          @click="emit('pageChange', props.page - 1)"
        >
          上一页
        </button>
        <span>第 {{ props.page }} / {{ pageCount }} 页</span>
        <button
          type="button"
          class="btn btn--small"
          :disabled="props.page >= pageCount"
          @click="emit('pageChange', props.page + 1)"
        >
          下一页
        </button>
      </nav>
    </template>
  </section>
</template>

<style scoped>
.route-directory {
  display: grid;
  gap: var(--space-3);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  min-width: 0;
}
.directory-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-3);
  flex-wrap: wrap;
}
.directory-head h2,
.directory-head p {
  margin: 0;
}
.directory-head h2 {
  font-size: var(--font-size-section-title);
}
.directory-head p,
.directory-note,
.directory-state {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
.directory-head b {
  color: var(--color-text);
  font-variant-numeric: tabular-nums;
}
.directory-table-wrap {
  min-width: 0;
  overflow-x: auto;
}
.directory-table {
  width: 100%;
  min-width: 720px;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}
.directory-table th,
.directory-table td {
  padding: var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  vertical-align: middle;
}
.directory-table th {
  color: var(--color-muted);
  font-weight: 600;
  background: var(--color-surface-sunken);
}
.directory-table td small {
  display: block;
  color: var(--color-muted);
  margin-top: 2px;
}
.directory-error {
  margin: 0;
  color: var(--color-danger-text);
}
.directory-pager {
  display: flex;
  align-items: center;
  justify-content: center;
  gap: var(--space-3);
}
.directory-pager span {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
@media (max-width: 720px) {
  .directory-table {
    min-width: 640px;
  }
}
</style>
