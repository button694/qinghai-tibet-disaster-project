<script setup lang="ts">
/**
 * 应急页路线信息面板：起点、终点、距离、时间、网络版本、阻断条件、风险段与资源。
 *
 * 缺失处理（03 §8-6）：
 * - 时间为 null → 显示「未提供」+ 成果登记的原因（durationSource），不按距离估算；
 * - 无可达路径 → 专用状态块，距离/时间均「未提供」，说明来自成果；
 * - 距离一律带来源说明（已存成果记录，非前端估算）。
 */
import { computed } from 'vue'

import {
  formatCount,
  formatDistance,
  formatDuration,
  formatLonLat,
  NOT_PROVIDED_TEXT,
} from '@/domain/format'
import type { RouteDetail } from '@/domain/types'

const props = defineProps<{
  routeDetail: RouteDetail | null
  status: 'idle' | 'loading' | 'ready' | 'failed'
  errorText: string | null
  /** mock 模式为 true：路线来自示例包，需持续标注示例身份；API 模式为 false。 */
  sampleBadge?: boolean
}>()

const emit = defineEmits<{
  retry: []
}>()

const endpoints = computed(() => {
  const detail = props.routeDetail
  if (detail === null) return []
  const out: Array<{ role: string; label: string; position: string }> = []
  if (detail.origin !== null) {
    out.push({
      role: '起点',
      label: detail.origin.label,
      position: formatLonLat(detail.origin.lonLat) ?? NOT_PROVIDED_TEXT,
    })
  }
  if (detail.destination !== null) {
    out.push({
      role: '终点',
      label: detail.destination.label,
      position: formatLonLat(detail.destination.lonLat) ?? NOT_PROVIDED_TEXT,
    })
  }
  return out
})

const distanceText = computed(() => {
  const detail = props.routeDetail
  if (detail === null) return null
  if (detail.status === 'unreachable' || detail.distanceMeters === null) return NOT_PROVIDED_TEXT
  return formatDistance(detail.distanceMeters, { unit: 'm' })
})

const durationText = computed(() => {
  const detail = props.routeDetail
  if (detail === null) return null
  if (detail.durationSeconds === null) return NOT_PROVIDED_TEXT
  return formatDuration(detail.durationSeconds)
})

const isUnreachable = computed(() => props.routeDetail?.status === 'unreachable')
</script>

<template>
  <section class="info" data-testid="route-info" aria-label="路线信息">
    <p v-if="props.status === 'loading'" class="state" data-testid="route-info-loading">
      路线详情读取中…（上一方案的状态已清空）
    </p>
    <p v-else-if="props.status === 'failed'" class="state error" role="alert">
      {{ props.errorText }}
      <button
        type="button"
        class="btn btn--small"
        data-testid="route-info-retry"
        @click="emit('retry')"
      >
        重试
      </button>
    </p>
    <p v-else-if="props.routeDetail === null" class="state">尚未选择方案。</p>

    <template v-else>
      <header class="info-head">
        <h2 class="info-title">{{ props.routeDetail.label }}</h2>
        <!-- mock 模式才显示示例身份；API 模式路线来自真实库，不再标注合成 -->
        <span v-if="props.sampleBadge" class="sample-badge">示例数据（合成路线）</span>
      </header>

      <!-- 无可达路径：专用状态，不显示任何距离/时间数字 -->
      <p v-if="isUnreachable" class="unreachable" data-testid="route-unreachable">
        <b>无可达路径：</b>已存成果标记该方案不可达（阻断条件见下），因此没有距离与耗时；
        界面不画路线、不按直线或固定速度估算。
      </p>

      <dl class="facts">
        <div class="fact">
          <dt>路线编号</dt>
          <dd data-testid="route-id">{{ props.routeDetail.id }}</dd>
        </div>
        <div v-for="endpoint in endpoints" :key="endpoint.role" class="fact">
          <dt>{{ endpoint.role }}</dt>
          <dd>
            {{ endpoint.label }}
            <span class="fact-sub">{{ endpoint.position }}</span>
          </dd>
        </div>
        <div class="fact">
          <dt>距离</dt>
          <dd>
            <span data-testid="route-distance">{{ distanceText }}</span>
            <span class="fact-sub" data-testid="route-distance-source">{{
              props.routeDetail.distanceSource
            }}</span>
          </dd>
        </div>
        <div class="fact">
          <dt>通行时间</dt>
          <dd>
            <span data-testid="route-duration">{{ durationText }}</span>
            <span
              v-if="props.routeDetail.durationSource"
              class="fact-sub"
              data-testid="route-duration-source"
              >{{ props.routeDetail.durationSource }}</span
            >
          </dd>
        </div>
        <div class="fact">
          <dt>路网版本</dt>
          <dd>{{ props.routeDetail.networkVersion }}</dd>
        </div>
        <div class="fact">
          <dt>生成时间</dt>
          <dd>{{ props.routeDetail.generatedAt }}</dd>
        </div>
      </dl>

      <div class="lists">
        <div class="list-col">
          <h3>阻断条件（路线成果条件）</h3>
          <p v-if="props.routeDetail.blockedFeatureRefs.length === 0" class="list-empty">
            该方案没有登记阻断要素。
          </p>
          <ul v-else class="ref-list">
            <li
              v-for="ref in props.routeDetail.blockedFeatureRefs"
              :key="`${ref.layerId}:${ref.id}`"
            >
              {{ ref.layerId }}/{{ ref.id }}
            </li>
          </ul>
        </div>

        <div class="list-col">
          <h3>风险路段</h3>
          <p v-if="props.routeDetail.riskSegments.length === 0" class="list-empty">
            该方案没有登记风险路段。
          </p>
          <ul v-else class="ref-list">
            <li v-for="segment in props.routeDetail.riskSegments" :key="segment.label">
              {{ segment.label }}
              <span v-if="segment.note" class="fact-sub">{{ segment.note }}</span>
            </li>
          </ul>
        </div>

        <div class="list-col">
          <h3>应急资源（{{ formatCount(props.routeDetail.resources.length) }}）</h3>
          <p v-if="props.routeDetail.resources.length === 0" class="list-empty">
            无可达路径方案未登记资源。
          </p>
          <ul v-else class="ref-list">
            <li
              v-for="resource in props.routeDetail.resources"
              :key="`${resource.ref.layerId}:${resource.ref.id}`"
            >
              {{ resource.label }}
              <span class="fact-sub">
                {{
                  resource.distanceFromRouteMeters === null
                    ? '与路线距离未提供'
                    : `距路线 ${formatDistance(resource.distanceFromRouteMeters, { unit: 'm' })}`
                }}
              </span>
            </li>
          </ul>
        </div>
      </div>

      <details class="assumptions">
        <summary>成果假设（{{ props.routeDetail.assumptions.length }} 条）</summary>
        <ul>
          <li v-for="(item, index) in props.routeDetail.assumptions" :key="index">{{ item }}</li>
        </ul>
      </details>
    </template>
  </section>
</template>

<style scoped>
.info {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.info-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.info-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.sample-badge {
  padding: 1px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.state {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.state.error {
  color: var(--color-danger-text);
}

.unreachable {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-danger);
  border-left-width: 4px;
  border-radius: var(--radius-sm);
  background: var(--color-danger-surface);
  color: var(--color-danger-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.facts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: var(--space-2);
  margin: 0;
}

.fact {
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
}

.fact dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.fact dd {
  margin: var(--space-1) 0 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}

.fact-sub {
  display: block;
  margin-top: 2px;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.lists {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--space-3);
}

.list-col h3 {
  margin: 0 0 var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.ref-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-text);
}

.ref-list li {
  line-height: var(--line-height-body);
  overflow-wrap: anywhere;
}

.list-empty {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.assumptions {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.assumptions summary {
  cursor: pointer;
  color: var(--color-primary);
}

.assumptions ul {
  margin: var(--space-1) 0 0;
  padding-left: var(--space-4);
}
</style>
