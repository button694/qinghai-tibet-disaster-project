<script setup lang="ts">
/**
 * 应急页方案面板：方案 A/B/C 切换、只读条件说明与成果假设。
 *
 * `routeRecompute` 未接入（能力清单 reasons 里有原因说明）：
 * - 阻断条件（blockedFeatureRefs）只作为**既有方案条件**展示，全部只读；
 * - 本页不提供「按新条件重算」的入口，因此也不存在改条件后冒用旧路线的问题。
 */
import { formatDistance } from '@/domain/format'
import { ROUTE_ROLE_LABEL } from '@/domain/labels'
import type { RouteSummary } from '@/domain/types'

const props = defineProps<{
  routes: RouteSummary[]
  selectedRouteId: string | null
  loading: boolean
  errorText: string | null
  recomputeReason: string | null
  emergencyTitle: string | null
  /** mock 模式为 true：路线来自示例包，需持续标注示例身份；API 模式为 false。 */
  sampleBadge?: boolean
}>()

const emit = defineEmits<{
  select: [routeId: string]
  retry: []
}>()

function summaryLine(route: RouteSummary): string {
  if (route.status === 'unreachable') return '不可达（已存成果标记，无距离）'
  const distance =
    route.distanceMeters === null
      ? '距离未提供'
      : formatDistance(route.distanceMeters, { unit: 'm' })
  return distance
}
</script>

<template>
  <section class="plans" data-testid="route-plans" aria-label="当前危险源方案组">
    <header class="plans-head">
      <h2 class="plans-title">当前危险源方案组</h2>
      <span v-if="props.emergencyTitle" class="plans-result-title">{{ props.emergencyTitle }}</span>
      <span v-if="props.sampleBadge" class="sample-badge">示例数据（合成路线）</span>
    </header>
    <p v-if="props.routes[0]?.hazardPointId" class="group-note" data-testid="route-hazard-group">
      当前危险源：{{ props.routes[0].hazardPointId }} ·
      此处显示该危险源的方案切换，全部路线请看下方目录
    </p>

    <p v-if="props.errorText" class="state error" role="alert">
      {{ props.errorText }}
      <button
        type="button"
        class="btn btn--small"
        data-testid="emergency-retry"
        @click="emit('retry')"
      >
        重试
      </button>
    </p>
    <p v-else-if="props.loading" class="state">路线清单读取中…</p>
    <p v-else-if="props.routes.length === 0" class="state">该成果下没有已存路线。</p>

    <div v-else class="plan-list" role="tablist" aria-label="方案切换">
      <button
        v-for="route in props.routes"
        :key="route.id"
        type="button"
        role="tab"
        class="plan"
        :class="{ 'is-active': route.id === props.selectedRouteId }"
        :data-testid="`plan-${route.id}`"
        :aria-selected="route.id === props.selectedRouteId"
        @click="emit('select', route.id)"
      >
        <span class="plan-label">
          方案 {{ route.label }}
          <span class="plan-role">{{ ROUTE_ROLE_LABEL[route.role] }}</span>
        </span>
        <span class="plan-meta">
          <span :class="route.status === 'reachable' ? 'ok' : 'bad'" class="plan-status">
            {{ route.status === 'reachable' ? '可达' : '不可达' }}
          </span>
          <span class="plan-distance">{{ summaryLine(route) }}</span>
          <span class="plan-network">路网 {{ route.networkVersion }}</span>
        </span>
      </button>
    </div>

    <p class="readonly-note" data-testid="route-readonly-note">
      <template v-if="props.recomputeReason"> 路线重新规划暂未提供。 </template>
      <template v-else>当前展示已发布路线。</template>
      阻断条件属于路线成果的一部分；切换方案时地图与指标同步更新。
    </p>
  </section>
</template>

<style scoped>
.plans {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.plans-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.plans-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.plans-result-title {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.group-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.sample-badge {
  padding: 1px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.state {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.state.error {
  color: var(--color-danger-text);
}

.plan-list {
  display: grid;
  gap: var(--space-2);
}

.plan {
  display: grid;
  gap: var(--space-1);
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
  text-align: left;
  cursor: pointer;
}

.plan.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
}

.plan-label {
  color: var(--color-text);
  font-size: var(--font-size-body);
  font-weight: var(--button-font-weight);
}

.plan-role {
  margin-left: var(--space-2);
  padding: 1px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-info-surface);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-weight: 400;
}

.plan-meta {
  display: flex;
  gap: var(--space-2);
  flex-wrap: wrap;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.plan-status.ok {
  color: var(--color-success-text);
}

.plan-status.bad {
  color: var(--color-danger-text);
}

.plan-distance {
  font-variant-numeric: tabular-nums;
}

.readonly-note {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border-left: 3px solid var(--color-warning);
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}
</style>
