<script setup lang="ts">
/**
 * 阶段5：应急路线地图画布。
 *
 * 三条诚实规则：
 * - 只画**已存路线几何**；`status === 'unreachable'`（geometry 为 null）时只画起终点标记
 *   与阻断点，绝不画直线冒充路线；
 * - 起终点、风险段、阻断点都来自成果的真实引用（ref → 要素取数）；
 * - 方案切换时父级会先清空 `routeDetail` / `markedFeatures`，本组件随之清空画面，
 *   不残留上一方案的路线。
 */
import Feature from 'ol/Feature'
import OlMap from 'ol/Map'
import GeoJSON from 'ol/format/GeoJSON'
import View from 'ol/View'
import { defaults as defaultControls, ScaleLine } from 'ol/control'
import type { EventsKey } from 'ol/events'
import Point from 'ol/geom/Point'
import VectorLayer from 'ol/layer/Vector'
import type Geometry from 'ol/geom/Geometry'
import { fromLonLat } from 'ol/proj'
import { unByKey } from 'ol/Observable'
import VectorSource from 'ol/source/Vector'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { formatFixed } from '@/domain/format'
import type { DataMode, FeatureDetail, LonLat, RouteDetail } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  createResearchBoundaryLayer,
  loadResearchBoundary,
  type ResearchBoundarySource,
} from '@/services/researchBoundary'
import { routeEndpointStyle, routeLineStyle, routeRiskSegmentStyle } from '@/config/mapStyle'

const props = defineProps<{
  routeDetail: RouteDetail | null
  /** 风险段 / 阻断点引用的要素（store 经真实关联取回）。 */
  markedFeatures: FeatureDetail[]
  /** 上一方案的要素（用于在详情未就绪时保持画布说明，不画线）。 */
  detailStatus: 'idle' | 'loading' | 'ready' | 'failed'
  /** API 模式下加载真实研究区边界；mock/snapshot 不请求正式边界。 */
  mode?: DataMode
}>()

const host = ref<HTMLDivElement | null>(null)
const zoomText = ref('—')
const lineDrawn = ref(false)
const boundaryCount = ref(0)
const boundaryStatus = ref<'idle' | 'loading' | 'ready' | 'failed'>('idle')

type VectorSource3857 = VectorSource<Feature<Geometry>>

let map: OlMap | null = null
let routeSource: VectorSource3857 | null = null
let markerSource: VectorSource3857 | null = null
let segmentSource: VectorSource3857 | null = null
let boundarySource: ResearchBoundarySource | null = null
let boundaryController: AbortController | null = null
const listenerKeys: EventsKey[] = []
let disposed = false

/** 路线几何的 GeoJSON 读取（EPSG:4326 → EPSG:3857，与 mapFeatures 同一转换口径）。 */
const geoReader = new GeoJSON()

function rebuildRoute(): void {
  if (!routeSource || !markerSource) return
  routeSource.clear()
  markerSource.clear()
  lineDrawn.value = false
  const detail = props.routeDetail
  if (detail === null) return
  if (detail.geometry !== null) {
    // 已存几何：只按成果登记的坐标画线（无几何 → 专用状态，不画直线）。
    const geometry = geoReader.readGeometry(detail.geometry, {
      dataProjection: 'EPSG:4326',
      featureProjection: 'EPSG:3857',
    })
    if (geometry) {
      const feature = new Feature<Geometry>({ geometry })
      feature.set('routeId', detail.id, true)
      feature.setStyle(routeLineStyle(detail.role))
      routeSource.addFeature(feature)
      lineDrawn.value = true
    }
  }
  if (detail.origin?.lonLat) addEndpoint(detail.origin.lonLat, 'origin')
  if (detail.destination?.lonLat) addEndpoint(detail.destination.lonLat, 'destination')
}

function addEndpoint(lonLat: LonLat, kind: 'origin' | 'destination'): void {
  if (!markerSource) return
  const marker = new Feature({ geometry: new Point(fromLonLat(lonLat)) })
  marker.setStyle(routeEndpointStyle(kind))
  markerSource.addFeature(marker)
}

function rebuildSegments(): void {
  if (!segmentSource) return
  segmentSource.clear()
  const { features } = toOlFeatures(props.markedFeatures)
  for (const feature of features) {
    feature.setStyle(routeRiskSegmentStyle())
    segmentSource.addFeature(feature)
  }
}

function fitToRoute(): void {
  if (!map) return
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  const collect = (features: Feature<Geometry>[]): void => {
    for (const feature of features) {
      const box = feature.getGeometry()?.getExtent()
      if (!box || box.length < 4) continue
      extent[0] = Math.min(extent[0], box[0] ?? 0)
      extent[1] = Math.min(extent[1], box[1] ?? 0)
      extent[2] = Math.max(extent[2], box[2] ?? 0)
      extent[3] = Math.max(extent[3], box[3] ?? 0)
    }
  }
  collect(routeSource?.getFeatures() ?? [])
  collect(markerSource?.getFeatures() ?? [])
  collect(segmentSource?.getFeatures() ?? [])
  collect(boundarySource?.getFeatures() ?? [])
  if (!Number.isFinite(extent[0])) return
  map.getView().fit(extent, { padding: [56, 56, 56, 56], maxZoom: 11 })
}

const onMoveEnd = (): void => {
  const zoom = map?.getView().getZoom()
  zoomText.value = zoom === undefined ? '—' : formatFixed(zoom, 1)
}

onMounted(() => {
  if (disposed || !host.value) return
  routeSource = new VectorSource()
  markerSource = new VectorSource()
  segmentSource = new VectorSource()
  boundarySource = new VectorSource()
  const boundaryLayer = createResearchBoundaryLayer(boundarySource, 1)
  const routeLayer = new VectorLayer<VectorSource3857>({ source: routeSource, zIndex: 10 })
  const segmentLayer = new VectorLayer<VectorSource3857>({
    source: segmentSource,
    zIndex: 6,
  })
  const markerLayer = new VectorLayer<VectorSource3857>({ source: markerSource, zIndex: 12 })
  map = new OlMap({
    target: host.value,
    layers: [boundaryLayer, segmentLayer, routeLayer, markerLayer],
    view: new View({ center: fromLonLat([90.8, 30]), zoom: 7, minZoom: 3, maxZoom: 15 }),
    controls: defaultControls({ attribution: false, zoom: false }).extend([new ScaleLine()]),
  })
  listenerKeys.push(map.on('moveend', onMoveEnd))
  rebuildRoute()
  rebuildSegments()
  fitToRoute()

  if (props.mode === 'api') {
    boundaryStatus.value = 'loading'
    boundaryController = new AbortController()
    void loadResearchBoundary(props.mode, { signal: boundaryController.signal })
      .then((items) => {
        if (disposed || !boundarySource) return
        const { features } = toOlFeatures(items)
        boundarySource.clear()
        boundarySource.addFeatures(features)
        boundaryCount.value = features.length
        boundaryStatus.value = 'ready'
        fitToRoute()
      })
      .catch((error: unknown) => {
        if (disposed || (error instanceof DOMException && error.name === 'AbortError')) return
        boundaryStatus.value = 'failed'
      })
  }
})

onBeforeUnmount(() => {
  disposed = true
  for (const key of listenerKeys) unByKey(key)
  listenerKeys.length = 0
  if (map) {
    map.setTarget(undefined)
    map.dispose()
    map = null
  }
  boundaryController?.abort()
  boundaryController = null
  routeSource = null
  markerSource = null
  segmentSource = null
  boundarySource = null
})

watch(
  () => [props.routeDetail, props.detailStatus] as const,
  () => {
    rebuildRoute()
    fitToRoute()
  },
)

watch(
  () => props.markedFeatures,
  () => {
    rebuildSegments()
    fitToRoute()
  },
)

defineExpose({ fitToRoute })
</script>

<template>
  <div class="route-map-wrap">
    <div
      ref="host"
      class="route-map"
      data-testid="route-map"
      :data-line="lineDrawn ? '1' : '0'"
      :data-zoom="zoomText"
      :aria-label="boundaryStatus === 'ready' ? '研究区边界与路线地图' : '已存路线地图'"
    ></div>
    <p class="map-chip">
      <template v-if="boundaryStatus === 'ready'">研究区边界 {{ boundaryCount }} 片 · </template>
      <template v-else-if="boundaryStatus === 'loading'">研究区边界加载中 · </template>
      <template v-else-if="boundaryStatus === 'failed'">研究区边界暂不可用 · </template>
      <template v-if="props.detailStatus === 'loading'">方案装载中…（不显示上一方案路线）</template>
      <template v-else-if="props.routeDetail === null">尚未选择方案</template>
      <template v-else-if="props.routeDetail.geometry === null">
        无可达路径：已存成果标记不可达，地图不绘制路线（不画直线冒充）
      </template>
      <template v-else> 已存路线 · {{ props.routeDetail.label }} · 缩放 {{ zoomText }} </template>
    </p>
  </div>
</template>

<style scoped>
.route-map-wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  height: 100%;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-map-bg);
}

.route-map {
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.map-chip {
  position: absolute;
  top: var(--space-2);
  left: var(--space-2);
  margin: 0;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: rgb(16 29 43 / 78%);
  color: var(--color-shell-muted);
  font-size: var(--font-size-caption);
  pointer-events: none;
  max-width: calc(100% - 16px);
}
</style>
