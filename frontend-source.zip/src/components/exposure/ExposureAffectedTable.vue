<script setup lang="ts">
/**
 * 暴露页受影响对象表：分页 + 选中 + 定位。
 *
 * 三条规则：
 * - 表格数据与地图同一份（store.affectedRows），类别筛选/分页由 store 统一驱动；
 * - 无几何记录照常显示，定位按钮禁用并说明原因（01 §5.5）；
 * - 关键属性按列显示：名称、类别、entityKey（去重依据）、人口（未知显示「未提供」，不显示 0）。
 */
import { computed } from 'vue'

import { formatCount, formatId, NOT_PROVIDED_TEXT } from '@/domain/format'
import type { FeatureDetail } from '@/domain/types'

const props = defineProps<{
  rows: FeatureDetail[]
  total: number
  page: number
  pageSize: number
  loading: boolean
  errorText: string | null
  selectedKey: string | null
}>()

const emit = defineEmits<{
  select: [ref: { layerId: string; id: string } | null]
  locate: [ref: { layerId: string; id: string }]
  page: [target: number]
}>()

const totalPages = computed(() => Math.max(1, Math.ceil(props.total / props.pageSize)))

/** 人口显示：null → 未提供；0 → 0（两者分开，01 §5.3）。 */
function populationText(row: FeatureDetail): string {
  const value = row.properties.population
  if (value === null || value === undefined) return NOT_PROVIDED_TEXT
  if (typeof value === 'number') return `${formatId(value) ?? value} 人`
  return String(value)
}

function canLocate(row: FeatureDetail): boolean {
  return row.geometry !== null
}

function isSelected(row: FeatureDetail): boolean {
  return props.selectedKey === `${row.ref.layerId}:${row.ref.id}`
}
</script>

<template>
  <section class="table-panel" data-testid="exposure-affected-table" aria-label="受影响对象清单">
    <header class="panel-head">
      <h3 class="panel-title">受影响对象清单</h3>
      <span class="panel-total"
        >共 {{ formatCount(props.total) }} 条 · 第 {{ props.page }} / {{ totalPages }} 页</span
      >
    </header>

    <p v-if="props.errorText" class="state error" role="alert">
      {{ props.errorText }}
      <button
        type="button"
        class="btn btn--small"
        data-testid="exposure-retry-affected"
        @click="emit('page', props.page)"
      >
        重试
      </button>
    </p>
    <p v-else-if="props.loading" class="state">受影响对象读取中…</p>
    <p v-else-if="props.rows.length === 0" class="state" data-testid="exposure-empty">
      当前类别下没有受影响对象（结果为 0 条，不是失败）。
    </p>

    <div v-else class="table-wrap">
      <table class="affected-table">
        <thead>
          <tr>
            <th scope="col">名称</th>
            <th scope="col">类别</th>
            <th scope="col">对象标识（去重依据）</th>
            <th scope="col">人口</th>
            <th scope="col">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="row in props.rows"
            :key="`${row.ref.layerId}:${row.ref.id}`"
            :class="{ 'is-selected': isSelected(row) }"
            :data-testid="`affected-row-${row.ref.layerId}:${row.ref.id}`"
            tabindex="0"
            :aria-selected="isSelected(row)"
            @click="emit('select', row.ref)"
            @keydown.enter="emit('select', row.ref)"
            @keydown.space.prevent="emit('select', row.ref)"
          >
            <td data-testid="affected-name">{{ row.title }}</td>
            <td>{{ row.ref.layerId }}</td>
            <td>{{ String(row.properties.entityKey ?? NOT_PROVIDED_TEXT) }}</td>
            <td :data-population="String(row.properties.population ?? 'null')">
              {{ populationText(row) }}
            </td>
            <td>
              <button
                type="button"
                class="btn btn--ghost btn--small"
                :disabled="!canLocate(row)"
                :title="canLocate(row) ? '定位到该对象' : '该记录无几何，定位不可用'"
                @click.stop="canLocate(row) && emit('locate', row.ref)"
              >
                定位
              </button>
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <footer class="pager">
      <button
        type="button"
        class="btn btn--ghost btn--small"
        data-testid="exposure-prev"
        :disabled="props.page <= 1 || props.loading"
        @click="emit('page', props.page - 1)"
      >
        上一页
      </button>
      <button
        type="button"
        class="btn btn--ghost btn--small"
        data-testid="exposure-next"
        :disabled="props.page >= totalPages || props.loading"
        @click="emit('page', props.page + 1)"
      >
        下一页
      </button>
    </footer>
  </section>
</template>

<style scoped>
.table-panel {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.panel-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.panel-title {
  margin: 0;
  font-size: var(--font-size-body);
  color: var(--color-text);
}

.panel-total {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.state {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.state.error {
  color: var(--color-danger-text);
}

.table-wrap {
  overflow-x: auto;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
}

.affected-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.affected-table th,
.affected-table td {
  padding: var(--space-1) var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  white-space: nowrap;
  color: var(--color-text);
}

.affected-table th {
  background: var(--color-surface-sunken);
  color: var(--color-muted);
  font-weight: 600;
}

.affected-table tbody tr {
  cursor: pointer;
}

.affected-table tbody tr:hover {
  background: var(--color-surface-hover);
}

.affected-table tbody tr.is-selected {
  background: var(--color-primary-soft);
}

.pager {
  display: flex;
  gap: var(--space-2);
  justify-content: flex-end;
}
</style>
