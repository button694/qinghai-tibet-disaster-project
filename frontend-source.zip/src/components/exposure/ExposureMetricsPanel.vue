<script setup lang="ts">
/**
 * 暴露页指标面板：分单位展示已存统计（记录数 / 对象数 / 道路长度 / 人口）。
 *
 * 口径诚实规则（03 §8-2、§8-6）：
 * - 人口、道路长度等指标直接复用 MetricCard（null 显示「未提供」，不用 0 占位）；
 * - 人口年份、裁切口径、去重规则、补充说明全部随摘要展示，不自行拼口径。
 */
import MetricCard from '@/components/ui/MetricCard.vue'
import type { ExposureSummary } from '@/domain/types'

const props = defineProps<{
  summary: ExposureSummary
}>()
</script>

<template>
  <section class="metrics" data-testid="exposure-metrics" aria-label="影响统计指标">
    <div class="metric-grid">
      <MetricCard v-for="metric in props.summary.metrics" :key="metric.key" :metric="metric" />
    </div>

    <dl class="caliber">
      <div class="caliber-item">
        <dt>去重规则</dt>
        <dd data-testid="dedup-rule">{{ props.summary.deduplicationRule ?? '未登记' }}</dd>
      </div>
      <div class="caliber-item">
        <dt>统计范围与裁切口径</dt>
        <dd data-testid="scope-method">{{ props.summary.scopeMethod ?? '未登记' }}</dd>
      </div>
      <div class="caliber-item">
        <dt>人口年份</dt>
        <dd data-testid="population-year">
          {{ props.summary.populationYear === null ? '未提供' : props.summary.populationYear }}
        </dd>
      </div>
      <div class="caliber-item">
        <dt>记录数与对象数</dt>
        <dd>
          {{ props.summary.matchedRecordCount }} 条记录 / {{ props.summary.uniqueEntityCount }}
          个去重后对象
        </dd>
      </div>
    </dl>

    <p v-if="props.summary.note" class="summary-note" data-testid="exposure-summary-note">
      {{ props.summary.note }}
    </p>
  </section>
</template>

<style scoped>
.metrics {
  display: grid;
  gap: var(--space-3);
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));
  gap: var(--space-3);
}

.caliber {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(240px, 1fr));
  gap: var(--space-2);
  margin: 0;
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface-sunken);
}

.caliber-item dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.caliber-item dd {
  margin: var(--space-1) 0 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
  overflow-wrap: anywhere;
}

.summary-note {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border-left: 3px solid var(--color-primary);
  border-radius: var(--radius-sm);
  background: var(--color-info-surface);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
  overflow-wrap: anywhere;
}
</style>
