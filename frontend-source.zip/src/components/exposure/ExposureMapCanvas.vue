<script setup lang="ts">
/**
 * 阶段5：暴露度地图画布。
 *
 * 三层数据，全部来自 Repository 取回的已存要素（无几何记录不上图，如实计数）：
 * - 影响范围面（result 图层的已存范围，红色半透明，zIndex 5）；
 * - 受影响对象（按几何家族配色，zIndex 10）；
 * - 选中高亮（蓝白双描边覆盖层，zIndex 9999）与来源危险源标记（上下文标记，橙色）。
 *
 * 命中检测遵守阶段2 的教训（D-038/D-041）：按图层 zIndex 先查受影响对象层，再查范围层，
 * 不依赖 OL 返回顺序。
 */
import Feature from 'ol/Feature'
import type { FeatureLike } from 'ol/Feature'
import OlMap from 'ol/Map'
import type MapBrowserEvent from 'ol/MapBrowserEvent'
import View from 'ol/View'
import { defaults as defaultControls, ScaleLine } from 'ol/control'
import type { EventsKey } from 'ol/events'
import Point from 'ol/geom/Point'
import VectorLayer from 'ol/layer/Vector'
import type Geometry from 'ol/geom/Geometry'
import { fromLonLat } from 'ol/proj'
import { unByKey } from 'ol/Observable'
import VectorSource from 'ol/source/Vector'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { formatFixed } from '@/domain/format'
import type { DataMode, FeatureDetail, LonLat } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  createResearchBoundaryLayer,
  loadResearchBoundary,
  type ResearchBoundarySource,
} from '@/services/researchBoundary'
import {
  affectedFeatureStyle,
  impactAreaStyle,
  routeRiskSegmentStyle,
  selectionStyles,
} from '@/config/mapStyle'

const props = defineProps<{
  /** 已存影响范围要素。 */
  impactAreas: FeatureDetail[]
  /** 受影响对象（当前类别筛选后的完整集合，与统计同口径）。 */
  affected: FeatureDetail[]
  /** 选中对象的全局键 `layerId:id`；null 表示无选中。 */
  selectedKey: string | null
  /** 来源危险源坐标（深链接上下文）；null 表示不是从危险源进入。 */
  hazardLonLat: LonLat | null
  /** API 模式下加载真实研究区边界；mock/snapshot 不请求正式边界。 */
  mode?: DataMode
}>()

const emit = defineEmits<{
  select: [ref: { layerId: string; id: string } | null]
}>()

const host = ref<HTMLDivElement | null>(null)
const zoomText = ref('—')
const drawnCount = ref(0)
const skippedCount = ref(0)
const boundaryCount = ref(0)
const boundaryStatus = ref<'idle' | 'loading' | 'ready' | 'failed'>('idle')

type VectorSource3857 = VectorSource<Feature<Geometry>>

/* ---- OpenLayers 对象：普通变量，非响应式 ---- */
let map: OlMap | null = null
let impactSource: VectorSource3857 | null = null
let affectedSource: VectorSource3857 | null = null
let highlightSource: VectorSource3857 | null = null
let hazardSource: VectorSource3857 | null = null
let boundarySource: ResearchBoundarySource | null = null
let boundaryController: AbortController | null = null
const listenerKeys: EventsKey[] = []
let disposed = false

function rebuildImpact(): void {
  if (!impactSource) return
  const { features, skipped } = toOlFeatures(props.impactAreas)
  impactSource.clear()
  impactSource.addFeatures(features)
  skippedImpact = skipped
  skippedCount.value = skippedImpact + skippedAffected
  syncHighlight()
}

function rebuildAffected(): void {
  if (!affectedSource) return
  const { features, skipped } = toOlFeatures(props.affected)
  affectedSource.clear()
  affectedSource.addFeatures(features)
  skippedAffected = skipped
  skippedCount.value = skippedImpact + skippedAffected
  drawnCount.value = features.length
  syncHighlight()
}

let skippedImpact = 0
let skippedAffected = 0

/** 选中高亮与来源危险源标记画在覆盖层。 */
function syncHighlight(): void {
  if (!highlightSource || !hazardSource) return
  highlightSource.clear()
  if (props.selectedKey !== null) {
    const all = [...(affectedSource?.getFeatures() ?? []), ...(impactSource?.getFeatures() ?? [])]
    const hit = all.find((feature) => feature.getId() === props.selectedKey)
    if (hit !== undefined) {
      const clone = new Feature({ geometry: hit.getGeometry() })
      clone.setStyle(selectionStyles())
      highlightSource.addFeature(clone)
    }
  }
  hazardSource.clear()
  if (props.hazardLonLat !== null) {
    const marker = new Feature({
      geometry: new Point(fromLonLat(props.hazardLonLat)),
    })
    hazardSource.addFeature(marker)
  }
}

function fitAll(): void {
  if (!map) return
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  const collect = (features: Feature<Geometry>[]): void => {
    for (const feature of features) {
      const geometry = feature.getGeometry()
      if (!geometry) continue
      const box = geometry.getExtent()
      if (box.length < 4) continue
      extent[0] = Math.min(extent[0], box[0] ?? 0)
      extent[1] = Math.min(extent[1], box[1] ?? 0)
      extent[2] = Math.max(extent[2], box[2] ?? 0)
      extent[3] = Math.max(extent[3], box[3] ?? 0)
    }
  }
  collect(impactSource?.getFeatures() ?? [])
  collect(affectedSource?.getFeatures() ?? [])
  collect(boundarySource?.getFeatures() ?? [])
  if (!Number.isFinite(extent[0])) return
  map.getView().fit(extent, { padding: [48, 48, 48, 48], maxZoom: 12 })
}

function focusCoordinate(longitude: number, latitude: number): void {
  if (!map) return
  const view = map.getView()
  view.setCenter(fromLonLat([longitude, latitude]))
  view.setZoom(Math.max(view.getZoom() ?? 0, 10))
}

const onSingleClick = (event: MapBrowserEvent): void => {
  if (!map) return
  // 先查受影响对象层（zIndex 更高），再查影响范围层（D-038/D-041）。
  const pickFrom = (source: VectorSource3857 | null): { layerId: string; id: string } | null => {
    if (!source) return null
    const hits = map?.getFeaturesAtPixel(event.pixel, {
      hitTolerance: 6,
      layerFilter: (layer) => layer.getSource() === source,
    })
    for (const feature of hits ?? []) {
      const layerId = feature.get('__layerId')
      const id = feature.get('__featureId')
      if (typeof layerId === 'string' && typeof id === 'string') return { layerId, id }
    }
    return null
  }
  const hit = pickFrom(affectedSource) ?? pickFrom(impactSource)
  emit('select', hit)
}

const onMoveEnd = (): void => {
  const zoom = map?.getView().getZoom()
  zoomText.value = zoom === undefined ? '—' : formatFixed(zoom, 1)
}

onMounted(() => {
  if (disposed || !host.value) return
  impactSource = new VectorSource()
  affectedSource = new VectorSource()
  highlightSource = new VectorSource()
  hazardSource = new VectorSource()
  boundarySource = new VectorSource()
  const boundaryLayer = createResearchBoundaryLayer(boundarySource, 1)
  const impactLayer = new VectorLayer<VectorSource3857>({
    source: impactSource,
    style: impactAreaStyle(),
    zIndex: 5,
  })
  const affectedLayer = new VectorLayer<VectorSource3857>({
    source: affectedSource,
    style: (feature: FeatureLike) => {
      const geometry = feature.getGeometry()
      const type = geometry?.getType()
      if (type === 'LineString' || type === 'MultiLineString')
        return affectedFeatureStyle('LineString')
      if (type === 'Polygon' || type === 'MultiPolygon') return affectedFeatureStyle('Polygon')
      return affectedFeatureStyle('Point')
    },
    zIndex: 10,
  })
  const highlightLayer = new VectorLayer<VectorSource3857>({
    source: highlightSource,
    zIndex: 9999,
  })
  const hazardLayer = new VectorLayer<VectorSource3857>({
    source: hazardSource,
    style: routeRiskSegmentStyle(),
    zIndex: 9998,
  })
  map = new OlMap({
    target: host.value,
    layers: [boundaryLayer, impactLayer, affectedLayer, hazardLayer, highlightLayer],
    view: new View({ center: fromLonLat([90, 30]), zoom: 7, minZoom: 3, maxZoom: 15 }),
    controls: defaultControls({ attribution: false, zoom: false }).extend([new ScaleLine()]),
  })
  listenerKeys.push(map.on('singleclick', onSingleClick), map.on('moveend', onMoveEnd))
  rebuildImpact()
  rebuildAffected()
  fitAll()

  if (props.mode === 'api') {
    boundaryStatus.value = 'loading'
    boundaryController = new AbortController()
    void loadResearchBoundary(props.mode, { signal: boundaryController.signal })
      .then((items) => {
        if (disposed || !boundarySource) return
        const { features } = toOlFeatures(items)
        boundarySource.clear()
        boundarySource.addFeatures(features)
        boundaryCount.value = features.length
        boundaryStatus.value = 'ready'
        fitAll()
      })
      .catch((error: unknown) => {
        if (disposed || (error instanceof DOMException && error.name === 'AbortError')) return
        boundaryStatus.value = 'failed'
      })
  }
})

onBeforeUnmount(() => {
  disposed = true
  for (const key of listenerKeys) unByKey(key)
  listenerKeys.length = 0
  if (map) {
    map.setTarget(undefined)
    map.dispose()
    map = null
  }
  boundaryController?.abort()
  boundaryController = null
  impactSource = null
  affectedSource = null
  highlightSource = null
  hazardSource = null
  boundarySource = null
})

watch(
  () => props.impactAreas,
  () => {
    rebuildImpact()
    fitAll()
  },
)

watch(
  () => props.affected,
  () => {
    rebuildAffected()
    fitAll()
  },
)

watch(
  () => props.selectedKey,
  () => {
    syncHighlight()
  },
)

watch(
  () => props.hazardLonLat,
  () => {
    syncHighlight()
  },
)

defineExpose({ fitAll, focusCoordinate })
</script>

<template>
  <div class="exposure-map-wrap">
    <div
      ref="host"
      class="exposure-map"
      data-testid="exposure-map"
      :data-zoom="zoomText"
      :data-count="drawnCount"
      :aria-label="
        boundaryStatus === 'ready'
          ? '研究区边界、影响范围与受影响对象地图'
          : '影响范围与受影响对象地图'
      "
    ></div>
    <p class="map-chip">
      <template v-if="boundaryStatus === 'ready'">研究区边界 {{ boundaryCount }} 片 · </template>
      <template v-else-if="boundaryStatus === 'loading'">研究区边界加载中 · </template>
      <template v-else-if="boundaryStatus === 'failed'">研究区边界暂不可用 · </template>
      已上图 {{ drawnCount }} 个受影响对象 · {{ impactAreas.length }} 个影响范围<template
        v-if="skippedCount > 0"
      >
        · {{ skippedCount }} 条无几何未上图</template
      >
      · 缩放 {{ zoomText }}
    </p>
  </div>
</template>

<style scoped>
.exposure-map-wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  /* 父级网格行有确定高度；这里必须撑满，否则高度塌缩 OL 不创建 canvas（阶段4 教训）。 */
  height: 100%;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-map-bg);
}

.exposure-map {
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.map-chip {
  position: absolute;
  top: var(--space-2);
  left: var(--space-2);
  margin: 0;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: rgb(16 29 43 / 78%);
  color: var(--color-shell-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  white-space: nowrap;
  max-width: calc(100% - 16px);
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
