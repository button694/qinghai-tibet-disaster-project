<script setup lang="ts">
/**
 * 暴露页来源面板：成果方法、输入数据集、质量说明、文件可用性与上下文链路。
 *
 * 「示例数据」标识持续可见；到应急方案的链接只在成果链存在时提供，
 * 链接携带 resultId / hazard 查询参数（深链接，03 §8-7）。
 */
import { computed } from 'vue'

import type { ResultDetail, ResultSummary } from '@/domain/types'

const props = defineProps<{
  result: ResultDetail | null
  /** 应急类成果清单（用于「查看应急方案」链接；无可用成果时隐藏该步）。 */
  emergencyResults: ResultSummary[]
  /** 深链接查询串（resultId / hazard），跨页保持上下文。 */
  emergencyQuery: string
}>()

const inputs = computed(() => props.result?.inputs ?? [])
const qualityNotes = computed(() => props.result?.qualityNotes ?? [])
const files = computed(() => props.result?.files ?? [])
</script>

<template>
  <section class="source" data-testid="exposure-source" aria-label="来源与口径">
    <header class="source-head">
      <h2 class="source-title">方法、输入与来源</h2>
      <span class="sample-badge">示例数据（合成成果）· 不是真实统计</span>
    </header>

    <template v-if="props.result">
      <p class="method" data-testid="exposure-method">{{ props.result.method }}</p>

      <div class="cols">
        <div class="col">
          <h3>输入数据集</h3>
          <ul class="input-list">
            <li v-for="item in inputs" :key="item.datasetId">
              <span class="input-id">{{ item.datasetId }}</span>
              <span class="input-role">{{ item.role }}</span>
              <span class="input-version">版本 {{ item.version }}</span>
            </li>
          </ul>
        </div>

        <div class="col">
          <h3>质量说明</h3>
          <ul class="note-list">
            <li v-for="(note, index) in qualityNotes" :key="index">{{ note }}</li>
          </ul>
        </div>

        <div class="col">
          <h3>成果文件</h3>
          <ul class="file-list">
            <li v-for="file in files" :key="file.id">
              {{ file.label }} ·
              <b :class="file.available ? 'ok' : 'missing'">{{
                file.available ? '可下载' : '不可用'
              }}</b>
            </li>
          </ul>
        </div>
      </div>

      <nav class="chain" aria-label="上下文链路">
        <span class="chain-step is-current">暴露度</span>
        <span class="chain-arrow" aria-hidden="true">→</span>
        <RouterLink
          v-if="props.emergencyResults.length > 0"
          class="chain-step chain-link"
          data-testid="to-emergency"
          :to="`/analysis/emergency${props.emergencyQuery}`"
        >
          应急方案（{{ props.emergencyResults[0]?.title ?? '' }}）
        </RouterLink>
        <span v-else class="chain-step is-muted">应急方案（正式成果服务待发布）</span>
        <span class="chain-arrow" aria-hidden="true">→</span>
        <span class="chain-step is-muted">来源与导出（阶段6）</span>
      </nav>
    </template>

    <p v-else class="missing">成果详情尚未读取；本面板不会预填任何方法或输入说明。</p>
  </section>
</template>

<style scoped>
.source {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.source-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.source-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.sample-badge {
  padding: 1px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.method {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.cols {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--space-3);
}

.col h3 {
  margin: 0 0 var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.input-list,
.note-list,
.file-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-text);
}

.input-list li {
  display: grid;
  gap: 2px;
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
}

.input-id {
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}

.input-role {
  color: var(--color-muted);
}

.input-version {
  color: var(--color-muted);
}

.note-list li,
.file-list li {
  line-height: var(--line-height-body);
  overflow-wrap: anywhere;
}

.ok {
  color: var(--color-success-text);
}

.missing {
  color: var(--color-danger-text);
}

.chain {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  padding-top: var(--space-2);
  border-top: 1px dashed var(--color-border);
}

.chain-step {
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  font-size: var(--font-size-caption);
}

.chain-step.is-current {
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-weight: var(--button-font-weight);
}

.chain-step.is-muted {
  background: var(--color-disabled-bg);
  color: var(--color-disabled-text);
}

.chain-link {
  border: 1px solid var(--color-border);
  background: var(--color-surface-sunken);
  color: var(--color-primary-strong);
}

.chain-arrow {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
</style>
