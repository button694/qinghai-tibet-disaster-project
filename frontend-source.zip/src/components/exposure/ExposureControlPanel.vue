<script setup lang="ts">
/**
 * 暴露页控制面板：成果信息、来源危险源上下文、类别筛选与清除。
 *
 * 类别筛选来自摘要的 `affectedCategories`（真实派生计数），
 * 不在组件里写死类别清单；清除一键恢复全量并回第 1 页。
 */
import { computed } from 'vue'

import { formatCount } from '@/domain/format'
import type { ExposureSummary, FeatureDetail, FeatureRef, ResultDetail } from '@/domain/types'

const props = defineProps<{
  result: ResultDetail | null
  summary: ExposureSummary | null
  entryHazard: FeatureDetail | null
  entryHazardRef: FeatureRef | null
  /** 摘要派生的危险源关联（hazardRefId 真实关联）。 */
  hazardRef: FeatureRef | null
  activeCategory: string | null
  filteredCount: number
  totalCount: number
}>()

const emit = defineEmits<{
  category: [key: string | null]
  clear: []
}>()

const categories = computed(() => props.summary?.affectedCategories ?? [])
</script>

<template>
  <section class="control" data-testid="exposure-control" aria-label="影响评估控制">
    <div class="control-row">
      <div class="result-info">
        <h2 class="result-title">{{ props.result?.title ?? '影响评估' }}</h2>
        <p v-if="props.result" class="result-meta">
          版本 {{ props.result.version }} ·
          <span class="sample-badge">示例数据（合成成果）</span>
        </p>
      </div>

      <button
        type="button"
        class="btn btn--ghost btn--small"
        data-testid="exposure-clear"
        :disabled="props.activeCategory === null"
        @click="emit('clear')"
      >
        清除筛选
      </button>
    </div>

    <!-- 来源上下文：从地图危险源深链接进入时展示；关联以摘要的 hazardRefId 为准 -->
    <p class="hazard-line" data-testid="exposure-hazard-line">
      <template v-if="props.entryHazardRef !== null">
        来源对象：{{
          props.entryHazard?.title ?? `${props.entryHazardRef.layerId}/${props.entryHazardRef.id}`
        }}
      </template>
      <template v-else-if="props.hazardRef !== null">
        关联危险源：{{ props.hazardRef.layerId }}/{{
          props.hazardRef.id
        }}（影响范围记录的真实关联，非空间推测）
      </template>
      <template v-else>影响范围未登记单一危险源关联；多对象时摘要不合并（见口径说明）。</template>
    </p>

    <div
      v-if="categories.length > 0"
      class="category-row"
      role="group"
      aria-label="受影响对象类别筛选"
    >
      <button
        type="button"
        class="chip"
        :class="{ 'is-active': props.activeCategory === null }"
        data-testid="category-all"
        @click="emit('category', null)"
      >
        全部（{{ formatCount(props.totalCount) }}）
      </button>
      <button
        v-for="item in categories"
        :key="item.key"
        type="button"
        class="chip"
        :class="{ 'is-active': props.activeCategory === item.key }"
        :data-testid="`category-${item.key}`"
        @click="emit('category', item.key)"
      >
        {{ item.label }}（{{ formatCount(item.count) }}）
      </button>
    </div>

    <p class="filter-note">
      筛选后 <b data-testid="exposure-filtered-count">{{ formatCount(props.filteredCount) }}</b>
      条（分页显示）；类别计数来自已存统计，分页不改变总数。
    </p>
  </section>
</template>

<style scoped>
.control {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.control-row {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.result-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.result-meta {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.sample-badge {
  padding: 1px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
}

.hazard-line {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.category-row {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}

.chip {
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  background: var(--color-surface-sunken);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  cursor: pointer;
}

.chip.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-weight: var(--button-font-weight);
}

.filter-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
</style>
