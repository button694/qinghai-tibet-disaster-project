<script setup lang="ts">
/**
 * 答辩演示导览面板（阶段7）。
 *
 * 固定六步的前进/后退/退出控件，固定右下角浮层；Esc 退出；
 * 只切换路由与讲解要点，不修改任何数据。键盘可完整操作（原生 button）。
 */
import { onBeforeUnmount, onMounted } from 'vue'

import { useTourStore } from '@/stores/tour'

const tour = useTourStore()

function onKeydown(event: KeyboardEvent): void {
  if (event.key !== 'Escape') return
  if (!tour.active) return
  tour.exit()
}

onMounted(() => document.addEventListener('keydown', onKeydown))
onBeforeUnmount(() => document.removeEventListener('keydown', onKeydown))
</script>

<template>
  <aside
    v-if="tour.active && tour.step !== null"
    class="tour-panel"
    role="complementary"
    aria-label="答辩演示导览"
    data-testid="tour-panel"
  >
    <div class="tour-head">
      <span class="tour-progress" data-testid="tour-progress">{{ tour.progressLabel }}</span>
      <span class="tour-title" data-testid="tour-title">{{ tour.step.title }}</span>
      <button
        type="button"
        class="btn btn--ghost tour-exit"
        aria-label="退出演示导览"
        title="退出演示导览（Esc）"
        data-testid="tour-exit"
        @click="tour.exit()"
      >
        退出
      </button>
    </div>
    <p class="tour-note" data-testid="tour-note">{{ tour.step.note }}</p>
    <div class="tour-actions">
      <button
        type="button"
        class="btn"
        :disabled="tour.isFirst"
        aria-label="导览上一步"
        data-testid="tour-prev"
        @click="tour.prev()"
      >
        上一步
      </button>
      <button
        type="button"
        class="btn btn--primary"
        :aria-label="tour.isLast ? '完成并退出演示导览' : '导览下一步'"
        :data-testid="tour.isLast ? 'tour-finish' : 'tour-next'"
        @click="tour.next()"
      >
        {{ tour.isLast ? '完成并退出' : '下一步' }}
      </button>
    </div>
  </aside>
</template>

<style scoped>
.tour-panel {
  position: fixed;
  right: var(--space-4);
  bottom: var(--space-4);
  z-index: 60;
  width: min(360px, calc(100vw - var(--space-8)));
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  box-shadow: var(--shadow-panel);
}

.tour-head {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.tour-progress {
  padding: 1px var(--space-2);
  border-radius: var(--badge-radius);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
  font-weight: 600;
  white-space: nowrap;
}

.tour-title {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  font-size: var(--font-size-section-title);
  font-weight: 600;
}

.tour-exit {
  min-height: 28px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}

.tour-note {
  margin: var(--space-2) 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

.tour-actions {
  display: flex;
  justify-content: space-between;
  gap: var(--space-2);
}
</style>
