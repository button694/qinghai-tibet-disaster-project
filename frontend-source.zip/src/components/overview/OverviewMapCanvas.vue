<script setup lang="ts">
/**
 * 阶段6：总览主地图画布。
 *
 * mock 模式画已存风险区成果，API 模式画已登记的研究区边界。
 * API 边界使用统一的底图样式，不把边界片段误着色成风险等级。
 */
import Feature from 'ol/Feature'
import type { FeatureLike } from 'ol/Feature'
import OlMap from 'ol/Map'
import View from 'ol/View'
import { defaults as defaultControls, ScaleLine } from 'ol/control'
import type { EventsKey } from 'ol/events'
import VectorLayer from 'ol/layer/Vector'
import type Geometry from 'ol/geom/Geometry'
import { fromLonLat } from 'ol/proj'
import { unByKey } from 'ol/Observable'
import VectorSource from 'ol/source/Vector'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { formatFixed } from '@/domain/format'
import type { DataMode, FeatureDetail } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import { researchBoundaryStyle } from '@/services/researchBoundary'
import { riskLevelStyle } from '@/config/mapStyle'

const props = defineProps<{
  /** 总览主地图要素；mock 为风险区，api 为正式研究区边界片段。 */
  zones: FeatureDetail[]
  mode?: DataMode
}>()

const host = ref<HTMLDivElement | null>(null)
const zoomText = ref('—')
const drawnCount = ref(0)
const skippedCount = ref(0)

type VectorSource3857 = VectorSource<Feature<Geometry>>

let map: OlMap | null = null
let zoneSource: VectorSource3857 | null = null
const listenerKeys: EventsKey[] = []
let disposed = false

function rebuildZones(): void {
  if (!zoneSource) return
  const { features, skipped } = toOlFeatures(props.zones)
  zoneSource.clear()
  zoneSource.addFeatures(features)
  drawnCount.value = features.length
  skippedCount.value = skipped
  fitAll()
}

function fitAll(): void {
  if (!map) return
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  for (const feature of zoneSource?.getFeatures() ?? []) {
    const geometry = feature.getGeometry()
    if (!geometry) continue
    const box = geometry.getExtent()
    if (box.length < 4) continue
    extent[0] = Math.min(extent[0], box[0] ?? 0)
    extent[1] = Math.min(extent[1], box[1] ?? 0)
    extent[2] = Math.max(extent[2], box[2] ?? 0)
    extent[3] = Math.max(extent[3], box[3] ?? 0)
  }
  if (!Number.isFinite(extent[0])) return
  map.getView().fit(extent, { padding: [36, 36, 36, 36], maxZoom: 11 })
}

const onMoveEnd = (): void => {
  const zoom = map?.getView().getZoom()
  zoomText.value = zoom === undefined ? '—' : formatFixed(zoom, 1)
}

onMounted(() => {
  if (disposed || !host.value) return
  zoneSource = new VectorSource()
  const zoneLayer = new VectorLayer<VectorSource3857>({
    source: zoneSource,
    style: (feature: FeatureLike) =>
      props.mode === 'api'
        ? researchBoundaryStyle()
        : riskLevelStyle(String(feature.get('riskLevel') ?? 'insufficient')),
    zIndex: 5,
  })
  map = new OlMap({
    target: host.value,
    layers: [zoneLayer],
    view: new View({ center: fromLonLat([90, 30]), zoom: 6, minZoom: 3, maxZoom: 15 }),
    controls: defaultControls({ attribution: false, zoom: false }).extend([new ScaleLine()]),
  })
  listenerKeys.push(map.on('moveend', onMoveEnd))
  rebuildZones()
})

onBeforeUnmount(() => {
  disposed = true
  for (const key of listenerKeys) unByKey(key)
  listenerKeys.length = 0
  if (map) {
    map.setTarget(undefined)
    map.dispose()
    map = null
  }
  zoneSource = null
})

watch(
  () => props.zones,
  () => rebuildZones(),
)

defineExpose({ fitAll })
</script>

<template>
  <div class="overview-map-wrap">
    <div
      ref="host"
      class="overview-map"
      data-testid="overview-map"
      :data-count="drawnCount"
      :aria-label="props.mode === 'api' ? '总览研究区边界地图' : '总览风险区地图'"
    ></div>
    <p class="map-chip">
      <template v-if="props.mode === 'api'">已上图 {{ drawnCount }} 个研究区边界片段</template>
      <template v-else>已上图 {{ drawnCount }} 个风险区</template
      ><template v-if="skippedCount > 0"> · {{ skippedCount }} 条无几何未上图</template> · 缩放
      {{ zoomText }}
    </p>
  </div>
</template>

<style scoped>
.overview-map-wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  /* 父级网格行有确定高度；这里必须撑满，否则高度塌缩 OL 不创建 canvas（阶段4 教训）。 */
  height: 100%;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-map-bg);
}

.overview-map {
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.map-chip {
  position: absolute;
  top: var(--space-2);
  left: var(--space-2);
  margin: 0;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: rgb(16 29 43 / 78%);
  color: var(--color-shell-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  white-space: nowrap;
  max-width: calc(100% - 16px);
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
