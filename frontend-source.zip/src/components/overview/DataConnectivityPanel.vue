<script setup lang="ts">
/**
 * 数据接入自检（阶段1 的可见证据）。
 *
 * 这是阶段1 唯一真正“接数据”的界面：它走 `OverviewRepository` + 会话 store，
 * 用同一套示例数据包证明三件事：
 * 1. 共用视觉与数据层：指标卡、来源徽标、状态组件都来自 `components/ui`；
 * 2. 模式只改配置：模式、快照标识、来源地址全部取自 store，页面不读环境变量；
 * 3. 失败即失败：接口未连接时显示错误码与原因，不给任何示例统计数字。
 *
 * 阶段6 会用真正的总览页替换本面板，届时本文件删除。
 */
import { computed, onMounted, ref } from 'vue'

import EmptyState from '@/components/ui/EmptyState.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import MetricCard from '@/components/ui/MetricCard.vue'
import RiskBadge from '@/components/ui/RiskBadge.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import {
  formatCount,
  formatMetricValue,
  formatTimeValue,
  inferTimePrecision,
  NOT_PROVIDED_TEXT,
} from '@/domain/format'
import type { Context, OverviewData, TimeValue } from '@/domain/types'
import { getRepositories } from '@/repositories'
import { isRepositoryError, toRepositoryError, type RepositoryError } from '@/repositories/types'
import { useSessionStore } from '@/stores/session'

type PanelStatus = 'idle' | 'loading' | 'ready' | 'failed'

const session = useSessionStore()

const status = ref<PanelStatus>('idle')
const error = ref<RepositoryError | null>(null)
const overview = ref<OverviewData | null>(null)
const context = ref<Context | null>(null)

/** 只展示前四个指标：超过四个就失去“一眼看懂”的意义（01 §4.3）。 */
const headlineMetrics = computed(() => (overview.value?.metrics ?? []).slice(0, 4))

const distributionRows = computed(() => overview.value?.riskDistribution ?? [])

const distributionTotal = computed(() =>
  distributionRows.value.reduce((sum, row) => sum + row.count, 0),
)

/** 合计单位取自分级条目本身；缺省不猜，标注为“个”以外的单位时照实显示。 */
const distributionUnit = computed(() => distributionRows.value[0]?.unit ?? null)

/** 合计文案：单位未登记时不补单位，只照实说明（02 §2.6）。 */
const distributionTotalText = computed(() =>
  formatCount(distributionTotal.value, {
    unitSuffix:
      distributionUnit.value === null
        ? ` 个（单位${NOT_PROVIDED_TEXT}）`
        : ` ${distributionUnit.value}`,
  }),
)

const provenanceRows = computed(() => {
  const meta = context.value
  if (meta === null) return []
  const versionCount = Object.keys(meta.datasetVersions ?? {}).length
  const snapshotTime: TimeValue = {
    value: meta.generatedAt,
    precision: inferTimePrecision(meta.generatedAt),
    role: 'generated',
  }
  return [
    { key: 'source', label: '数据来源', value: session.modeLabel },
    { key: 'generatedAt', label: '数据更新时间', value: formatTimeValue(snapshotTime) },
    { key: 'scope', label: '统计范围', value: meta.scopeLabel || NOT_PROVIDED_TEXT },
    { key: 'boundary', label: '边界版本', value: meta.boundaryVersion || NOT_PROVIDED_TEXT },
    {
      key: 'datasets',
      label: '登记数据集版本数',
      value: formatCount(versionCount, { unitSuffix: ' 个' }),
    },
  ]
})

async function loadOverview(force = false): Promise<void> {
  if (status.value === 'loading') return
  if (!force && status.value === 'ready') return
  status.value = 'loading'
  error.value = null
  try {
    // 能力清单先就绪：模式与只读身份要以数据源返回的 capabilities 为准。
    await session.loadCapabilities(force)
    if (session.isFailed) {
      throw session.error ?? toRepositoryError(new Error('能力清单读取失败。'))
    }
    const envelope = await getRepositories().overview.getOverview()
    overview.value = envelope.data
    context.value = envelope.meta
    status.value = 'ready'
  } catch (unknownError) {
    overview.value = null
    context.value = null
    status.value = 'failed'
    error.value = isRepositoryError(unknownError)
      ? unknownError
      : toRepositoryError(unknownError, 'UNKNOWN')
  }
}

function retry(): void {
  void loadOverview(true)
}

onMounted(() => {
  void loadOverview()
})
</script>

<template>
  <section class="panel" data-testid="connectivity-panel">
    <header class="panel-head">
      <div>
        <h2 class="panel-title">数据来源与更新</h2>
        <p class="panel-subtitle">当前页面使用的数据范围、更新时间和统计口径。</p>
      </div>
      <SourceBadge
        :mode="session.mode"
        :snapshot-id="session.snapshotId ?? undefined"
        :scope-label="session.scopeLabel ?? undefined"
      />
    </header>

    <LoadingState v-if="status === 'loading' || status === 'idle'" label="正在读取数据概览…" />

    <ErrorState
      v-else-if="status === 'failed'"
      :error="error"
      title="数据概览暂时无法显示"
      :retryable="true"
      @retry="retry"
    />

    <div v-else class="panel-body">
      <EmptyState
        v-if="headlineMetrics.length === 0"
        title="数据源没有返回可展示的指标"
        description="请求成功但指标为空。本面板不使用 0 或示例数字补位，请核对数据包或接口的统计范围。"
      />
      <div v-else class="metric-grid">
        <MetricCard v-for="metric in headlineMetrics" :key="metric.key" :metric="metric">
          <template #source>
            <SourceBadge
              :mode="session.mode"
              :snapshot-id="session.snapshotId ?? undefined"
              :scope-label="metric.scopeLabel ?? session.scopeLabel ?? undefined"
            />
          </template>
        </MetricCard>
      </div>

      <div class="panel-columns">
        <section class="block">
          <h3 class="block-title">风险分布（与上方指标同源）</h3>
          <p class="block-note">
            {{
              session.isSample
                ? '当前为演示数据，仅用于了解页面功能。'
                : '分布与上方指标使用同一数据范围。'
            }}
          </p>
          <table v-if="distributionRows.length > 0" class="dist-table">
            <thead>
              <tr>
                <th scope="col">等级</th>
                <th scope="col">数量</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in distributionRows" :key="row.key">
                <td><RiskBadge :level="row.key" /></td>
                <td class="tabular-nums">
                  {{
                    formatMetricValue({
                      key: row.key,
                      label: row.label,
                      value: row.count,
                      unit: row.unit,
                      status: 'known',
                    })
                  }}
                </td>
              </tr>
            </tbody>
            <tfoot>
              <tr>
                <th scope="row">合计</th>
                <td class="tabular-nums">{{ distributionTotalText }}</td>
              </tr>
            </tfoot>
          </table>
          <EmptyState
            v-else
            title="当前数据包没有可统计的风险区要素"
            description="请求成功且结果为空。本面板不显示 0 值行，也不以示例数字补位。"
          />
        </section>

        <section class="block">
          <h3 class="block-title">来源与更新时间</h3>
          <dl class="prov-list">
            <div v-for="row in provenanceRows" :key="row.key" class="prov-row">
              <dt>{{ row.label }}</dt>
              <dd>{{ row.value }}</dd>
            </div>
          </dl>
        </section>
      </div>

      <ul v-if="overview && overview.notes.length > 0" class="note-list">
        <li v-for="note in overview.notes" :key="note">{{ note }}</li>
      </ul>

      <p class="panel-footnote">
        说明：2050 / 2100 为未来情景年份，不是实时预警，也不构成预报结论。
      </p>
    </div>
  </section>
</template>

<style scoped>
.panel {
  max-width: 1120px;
  padding: var(--space-6);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.panel-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
  flex-wrap: wrap;
}

.panel-title {
  margin: 0 0 var(--space-2);
  font-size: 20px;
}

.panel-subtitle {
  margin: 0;
  color: var(--color-muted);
  font-size: 13px;
}

.panel-body {
  margin-top: var(--space-4);
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(200px, 1fr));
  gap: var(--space-3);
}

.panel-columns {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--space-4);
  margin-top: var(--space-6);
}

.block-title {
  margin: 0 0 var(--space-2);
  font-size: 15px;
}

.block-note {
  margin: 0 0 var(--space-3);
  color: var(--color-muted);
  font-size: 12px;
}

.dist-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}

.dist-table th,
.dist-table td {
  padding: var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
}

.prov-list {
  margin: 0;
  font-size: 13px;
}

.prov-row {
  display: flex;
  justify-content: space-between;
  gap: var(--space-3);
  padding: var(--space-2) 0;
  border-bottom: 1px dashed var(--color-border);
}

.prov-row dt {
  color: var(--color-muted);
}

.prov-row dd {
  margin: 0;
  text-align: right;
  word-break: break-all;
}

.note-list {
  margin: var(--space-6) 0 0;
  padding-left: 1.25em;
  color: var(--color-muted);
  font-size: 12px;
}

.panel-footnote {
  margin: var(--space-4) 0 0;
  padding-top: var(--space-3);
  border-top: 1px solid var(--color-border);
  color: var(--color-muted);
  font-size: 12px;
}
.block {
  min-width: 0;
  overflow-x: auto;
}
.dist-table th:first-child,
.dist-table td:first-child {
  min-width: 132px;
}
.prov-row {
  display: grid;
  grid-template-columns: minmax(100px, 0.8fr) minmax(0, 1.2fr);
}
.prov-row dd {
  text-align: left;
  overflow-wrap: anywhere;
  word-break: normal;
}
@media (max-width: 760px) {
  .panel {
    padding: var(--space-4);
  }
  .panel-columns {
    grid-template-columns: minmax(0, 1fr);
  }
  .metric-grid {
    grid-template-columns: minmax(0, 1fr);
  }
}
</style>
