<script setup lang="ts">
/**
 * 阶段4：重点对象（当前筛选下指数最高的前 10 个）。
 * 与地图、统计同一份筛选结果；null 不进榜，0 如实显示为 0。
 * 点击行选中对象，地图高亮同步（同一份选中状态）。
 */
import { computed } from 'vue'
import { formatCount } from '@/domain/format'
import {
  SCENARIO_METRIC_META,
  formatScenarioValue,
  type ScenarioMetric,
  type ScenarioRecord,
} from '@/domain/scenario'

const props = defineProps<{
  metric: ScenarioMetric
  records: ScenarioRecord[]
  selectedId: string | null
}>()

const emit = defineEmits<{
  select: [glacierId: string]
  locate: [record: ScenarioRecord]
}>()

const TOP_N = 10

const topRecords = computed(() =>
  [...props.records]
    .filter((record) => record.values[props.metric] !== null)
    .sort((a, b) => (b.values[props.metric] ?? 0) - (a.values[props.metric] ?? 0))
    .slice(0, TOP_N),
)
</script>

<template>
  <section class="top" data-testid="risk-top-list" aria-label="重点对象">
    <header class="top-head">
      <h3 class="top-title">
        重点对象（{{ SCENARIO_METRIC_META[props.metric].label }} 最高前 {{ TOP_N }}）
      </h3>
      <span class="top-count">当前筛选 {{ formatCount(props.records.length) }} 条</span>
    </header>
    <p v-if="topRecords.length === 0" class="top-empty" data-testid="top-empty">
      当前筛选下没有可排序的对象（无记录，或全部为缺失值）。
    </p>
    <ol v-else class="top-list">
      <li
        v-for="(record, index) in topRecords"
        :key="record.glacierId"
        class="top-row"
        :class="{ 'is-selected': record.glacierId === props.selectedId }"
      >
        <button
          type="button"
          class="top-select"
          :data-testid="`top-row-${index + 1}`"
          @click="emit('select', record.glacierId)"
        >
          <span class="rank">{{ index + 1 }}</span>
          <span class="id" :title="record.glacierId">{{ record.glacierId }}</span>
          <span class="value">{{ formatScenarioValue(record.values[props.metric]) }}</span>
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small locate"
          :aria-label="`在地图上定位 ${record.glacierId}`"
          :data-testid="`top-locate-${index + 1}`"
          @click="emit('locate', record)"
        >
          定位
        </button>
      </li>
    </ol>
  </section>
</template>

<style scoped>
.top {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  min-width: 0;
}

.top-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.top-title {
  margin: 0;
  font-size: var(--font-size-body);
  font-weight: 600;
  color: var(--color-text);
}

.top-count {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.top-empty {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.top-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  gap: var(--space-1);
}

.top-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  width: 100%;
  padding: var(--space-1) var(--space-2);
  border: 1px solid transparent;
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
  min-width: 0;
}

.top-row:hover {
  border-color: var(--color-border);
}

.top-row.is-selected {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
}

.top-select {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex: 1 1 auto;
  min-width: 0;
  padding: 0;
  border: 0;
  background: transparent;
  cursor: pointer;
  text-align: left;
}

.rank {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  flex: 0 0 1.4em;
}

.id {
  flex: 1 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
  white-space: nowrap;
  color: var(--color-text);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.value {
  color: var(--color-text);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  flex: 0 0 auto;
}

.locate {
  flex: 0 0 auto;
}
</style>
