<script setup lang="ts">
/**
 * 阶段4：情景连续色域图例。
 *
 * 铁律：没有正式风险阈值，图例只能表达「连续指数 + 统一色域」，
 * 不得出现等级名（如「高风险区」「较高」），不得五等分；
 * null（未提供）用数据不足灰单独标出，明确「缺失 ≠ 0」。
 */
import { computed } from 'vue'
import { SCENARIO_METRIC_META, type ScenarioMetric } from '@/domain/scenario'
import { NOT_PROVIDED_TEXT } from '@/domain/format'

const props = defineProps<{
  metric: ScenarioMetric
  /** 是否显示缺失说明（当前筛选里有 null 值时特别提示）。 */
  nullCount: number
}>()

/** CSS 渐变与地图色域同源：直接引用 tokens.css 的 ramp 令牌（组件守卫允许 var()）。 */
const gradient = computed(
  () =>
    `linear-gradient(to right, var(--color-scenario-ramp-0), var(--color-scenario-ramp-1), var(--color-scenario-ramp-2), var(--color-scenario-ramp-3), var(--color-scenario-ramp-4))`,
)

const meta = computed(() => SCENARIO_METRIC_META[props.metric])
</script>

<template>
  <section class="legend" data-testid="risk-legend" aria-label="情景指数图例">
    <header class="legend-head">
      <h3 class="legend-title">{{ meta.label }} · 统一连续色域</h3>
      <span class="legend-unit">{{ meta.unit }}</span>
    </header>
    <div class="legend-bar-row">
      <span class="legend-end">0</span>
      <span class="legend-bar" :style="{ background: gradient }" aria-hidden="true"></span>
      <span class="legend-end">1</span>
    </div>
    <p class="legend-note">
      连续指数：颜色深浅只表示指数高低，<b>未划分等级</b>；没有正式风险阈值，界面不提供任何分级命名。
    </p>
    <p class="legend-null">
      <span class="null-dot" aria-hidden="true"></span>
      值缺失（null）：{{ nullCount }} 条，显示为「{{ NOT_PROVIDED_TEXT }}」——缺失不是
      0，不参与色域与分布分箱。
    </p>
  </section>
</template>

<style scoped>
.legend {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.legend-head {
  display: flex;
  align-items: baseline;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.legend-title {
  margin: 0;
  font-size: var(--font-size-body);
  font-weight: 600;
  color: var(--color-text);
}

.legend-unit {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.legend-bar-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.legend-end {
  font-variant-numeric: tabular-nums;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.legend-bar {
  flex: 1 1 auto;
  height: 12px;
  border-radius: 6px;
  border: 1px solid var(--color-border);
}

.legend-note,
.legend-null {
  margin: 0;
  font-size: var(--font-size-caption);
  color: var(--color-muted);
  line-height: var(--line-height-body);
}

.legend-null {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  flex-wrap: wrap;
}

.null-dot {
  display: inline-block;
  width: 10px;
  height: 10px;
  border-radius: 50%;
  background: var(--color-risk-insufficient);
  border: 1px solid var(--color-border);
}
</style>
