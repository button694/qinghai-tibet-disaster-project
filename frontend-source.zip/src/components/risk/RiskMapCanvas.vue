<script setup lang="ts">
/**
 * 阶段4：情景点地图画布。
 *
 * 与 MapCanvas 相同的生命周期纪律（阶段2 的教训）：
 * - OpenLayers 实例/图层/源都是普通变量，不进响应式系统；
 * - onMounted 单次注册监听，onBeforeUnmount 逐条注销并 dispose；
 * - 容器高度由父级网格给确定值，组件自身不设 min-height（避免把行撑破）。
 *
 * 渲染铁律：情景数据是**点**，只按点渲染（CircleStyle），不插值成面、不叫风险等级；
 * 颜色取 `config/mapStyle.ts` 的统一连续色域（scenarioRampColor），
 * 2050 与 2100 用同一函数同一色域；null 用数据不足灰。
 */
import Feature from 'ol/Feature'
import type { FeatureLike } from 'ol/Feature'
import OlMap from 'ol/Map'
import type MapBrowserEvent from 'ol/MapBrowserEvent'
import View from 'ol/View'
import { defaults as defaultControls, ScaleLine } from 'ol/control'
import type { EventsKey } from 'ol/events'
import Point from 'ol/geom/Point'
import VectorLayer from 'ol/layer/Vector'
import { fromLonLat } from 'ol/proj'
import { unByKey } from 'ol/Observable'
import VectorSource from 'ol/source/Vector'
import { Circle, Fill, Stroke, Style } from 'ol/style'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { scenarioRampColor, MAP_COLORS } from '@/config/mapStyle'
import { formatFixed } from '@/domain/format'
import type { DataMode } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  createResearchBoundaryLayer,
  loadResearchBoundary,
  type ResearchBoundarySource,
} from '@/services/researchBoundary'
import {
  SCENARIO_METRICS,
  type ScenarioMetric,
  type ScenarioRecord,
  type ScenarioYear,
} from '@/domain/scenario'

const props = defineProps<{
  year: ScenarioYear
  metric: ScenarioMetric
  /** 当前应上图的记录（已按筛选过滤，与统计/列表同一份）。 */
  records: ScenarioRecord[]
  selectedId: string | null
  /** API 模式下加载真实研究区边界；mock/snapshot 不请求正式边界。 */
  mode?: DataMode
  /** 无记录可适配时的默认视野中心（经纬度）。 */
  fallbackCenter?: [number, number]
}>()

const emit = defineEmits<{
  select: [glacierId: string | null]
  viewChange: [view: { center: number[]; zoom: number }]
}>()

const host = ref<HTMLDivElement | null>(null)
const zoomText = ref('—')
const recordCount = ref(0)
const boundaryCount = ref(0)
const boundaryStatus = ref<'idle' | 'loading' | 'ready' | 'failed'>('idle')

/* ---- OpenLayers 对象：普通变量，非响应式 ---- */
let map: OlMap | null = null
let source: VectorSource<Feature<Point>> | null = null
let boundarySource: ResearchBoundarySource | null = null
let boundaryController: AbortController | null = null
const fillCache = new Map<string, Style>()
let nullStyle: Style | null = null
let selectedStylesCache: Style[] | null = null
const listenerKeys: EventsKey[] = []
let disposed = false

function baseStyle(color: string): Style {
  return new Style({
    image: new Circle({
      radius: 5,
      fill: new Fill({ color }),
      stroke: new Stroke({ color: MAP_COLORS.pointStroke, width: 1 }),
    }),
  })
}

function selectedStyles(): Style[] {
  if (selectedStylesCache) return selectedStylesCache
  selectedStylesCache = [
    new Style({
      image: new Circle({
        radius: 10,
        fill: new Fill({ color: MAP_COLORS.selectionHalo }),
      }),
    }),
    new Style({
      image: new Circle({
        radius: 7,
        fill: new Fill({ color: MAP_COLORS.selectionStroke }),
        stroke: new Stroke({ color: MAP_COLORS.pointStroke, width: 1.5 }),
      }),
    }),
  ]
  return selectedStylesCache
}

function styleFunction(feature: FeatureLike): Style | Style[] {
  const glacierId = feature.get('glacierId') as string | undefined
  if (glacierId !== undefined && glacierId === props.selectedId) return selectedStyles()
  const value = feature.get('value') as number | null
  if (value === null) {
    nullStyle ??= baseStyle(scenarioRampColor(null))
    return nullStyle
  }
  const color = scenarioRampColor(value)
  const cached = fillCache.get(color)
  if (cached) return cached
  const created = baseStyle(color)
  fillCache.set(color, created)
  return created
}

function rebuildFeatures(): void {
  if (!source) return
  fillCache.clear()
  nullStyle = null
  const features = props.records.map((record) => {
    const feature = new Feature({
      geometry: new Point(fromLonLat([record.longitude, record.latitude])),
    })
    feature.set('glacierId', record.glacierId, true)
    // 三个指标的值都存进要素：切换指标只需改 `value` 并重绘，不重建几何。
    for (const metric of SCENARIO_METRICS) {
      feature.set(`value_${metric}`, record.values[metric], true)
    }
    feature.set('value', record.values[props.metric], true)
    return feature
  })
  source.clear()
  source.addFeatures(features)
  recordCount.value = features.length
  map?.render()
}

function syncValues(): void {
  if (!source) return
  for (const feature of source.getFeatures()) {
    feature.set('value', feature.get(`value_${props.metric}`) ?? null, true)
  }
  fillCache.clear()
  map?.render()
}

function fitToRecords(): void {
  if (!map || props.records.length === 0) return
  let minX = Infinity
  let minY = Infinity
  let maxX = -Infinity
  let maxY = -Infinity
  for (const record of props.records) {
    const [x = 0, y = 0] = fromLonLat([record.longitude, record.latitude])
    minX = Math.min(minX, x)
    minY = Math.min(minY, y)
    maxX = Math.max(maxX, x)
    maxY = Math.max(maxY, y)
  }
  map.getView().fit([minX, minY, maxX, maxY], { padding: [40, 40, 40, 40], maxZoom: 9 })
}

function fitToBoundaryAndRecords(): void {
  if (!map) return
  const geometries = [...(boundarySource?.getFeatures() ?? []), ...(source?.getFeatures() ?? [])]
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  for (const feature of geometries) {
    const box = feature.getGeometry()?.getExtent()
    if (!box || box.length < 4) continue
    extent[0] = Math.min(extent[0], box[0] ?? 0)
    extent[1] = Math.min(extent[1], box[1] ?? 0)
    extent[2] = Math.max(extent[2], box[2] ?? 0)
    extent[3] = Math.max(extent[3], box[3] ?? 0)
  }
  if (Number.isFinite(extent[0])) {
    map.getView().fit(extent, { padding: [40, 40, 40, 40], maxZoom: 8 })
  } else {
    fitToRecords()
  }
}

/** 把指定真实对象移到视野中心；供重点对象列表的“定位”操作使用。 */
function focusCoordinate(longitude: number, latitude: number): void {
  if (!map) return
  const view = map.getView()
  view.setCenter(fromLonLat([longitude, latitude]))
  view.setZoom(Math.max(view.getZoom() ?? 0, 10))
}

function applyView(view: { center: number[]; zoom: number }): void {
  if (!map) return
  map.getView().setCenter(view.center)
  map.getView().setZoom(view.zoom)
}

function getView(): { center: number[]; zoom: number } | null {
  if (!map) return null
  return { center: map.getView().getCenter() ?? [], zoom: map.getView().getZoom() ?? 0 }
}

const onSingleClick = (event: MapBrowserEvent): void => {
  if (!map) return
  const hits = map.getFeaturesAtPixel(event.pixel, { hitTolerance: 6 })
  for (const feature of hits) {
    const glacierId = feature.get('glacierId')
    if (typeof glacierId === 'string') {
      emit('select', glacierId)
      return
    }
  }
  emit('select', null)
}

const onMoveEnd = (): void => {
  if (!map) return
  const view = map.getView()
  const zoom = view.getZoom()
  zoomText.value = zoom === undefined ? '—' : formatFixed(zoom, 1)
  emit('viewChange', { center: view.getCenter() ?? [], zoom: zoom ?? 0 })
}

onMounted(() => {
  if (disposed || !host.value) return
  source = new VectorSource<Feature<Point>>()
  boundarySource = new VectorSource()
  const boundaryLayer = createResearchBoundaryLayer(boundarySource, 1)
  const layer = new VectorLayer<VectorSource<Feature<Point>>>({
    source,
    style: styleFunction,
    zIndex: 10,
  })
  const center = fromLonLat(props.fallbackCenter ?? [88, 32])
  map = new OlMap({
    target: host.value,
    layers: [boundaryLayer, layer],
    view: new View({ center, zoom: 4, minZoom: 3, maxZoom: 14 }),
    controls: defaultControls({ attribution: false, zoom: false }).extend([new ScaleLine()]),
  })
  listenerKeys.push(map.on('singleclick', onSingleClick), map.on('moveend', onMoveEnd))
  rebuildFeatures()
  fitToRecords()

  if (props.mode === 'api') {
    boundaryStatus.value = 'loading'
    boundaryController = new AbortController()
    void loadResearchBoundary(props.mode, { signal: boundaryController.signal })
      .then((items) => {
        if (disposed || !boundarySource) return
        const { features } = toOlFeatures(items)
        boundarySource.clear()
        boundarySource.addFeatures(features)
        boundaryCount.value = features.length
        boundaryStatus.value = 'ready'
        fitToBoundaryAndRecords()
      })
      .catch((error: unknown) => {
        if (disposed || (error instanceof DOMException && error.name === 'AbortError')) return
        boundaryStatus.value = 'failed'
      })
  }
})

onBeforeUnmount(() => {
  disposed = true
  for (const key of listenerKeys) unByKey(key)
  listenerKeys.length = 0
  if (map) {
    map.setTarget(undefined)
    map.dispose()
    map = null
  }
  boundaryController?.abort()
  boundaryController = null
  source = null
  boundarySource = null
  fillCache.clear()
})

watch(
  () => props.records,
  () => {
    rebuildFeatures()
  },
)

watch(
  () => props.metric,
  () => {
    syncValues()
  },
)

watch(
  () => props.selectedId,
  () => {
    // 选中态画在样式函数里，重绘即可，不需要移动地图。
    map?.render()
  },
)

defineExpose({ applyView, getView, fitToRecords, focusCoordinate })
</script>

<template>
  <div class="risk-map-wrap">
    <div
      ref="host"
      class="risk-map"
      :data-testid="`risk-map-${props.year}`"
      :data-zoom="zoomText"
      :data-count="recordCount"
      :aria-label="boundaryStatus === 'ready' ? '情景点与研究区边界地图' : '情景点地图'"
    ></div>
    <p class="map-chip">
      {{ props.year }} ·
      <template v-if="boundaryStatus === 'ready'">研究区边界 {{ boundaryCount }} 片 · </template>
      <template v-else-if="boundaryStatus === 'loading'">研究区边界加载中 · </template>
      <template v-else-if="boundaryStatus === 'failed'">研究区边界暂不可用 · </template>
      {{ recordCount }} 个点 · 缩放 {{ zoomText }}
    </p>
  </div>
</template>

<style scoped>
.risk-map-wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  /* 父级 .map-cell 有确定高度；这里必须撑满，否则高度塌缩为 0，
     OL 不会创建 canvas（阶段4 浏览器用例抓到的真实缺陷）。 */
  height: 100%;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-map-bg);
}

/* 高度由父级网格行给确定值；组件不自带 min-height（阶段3 的布局教训）。 */
.risk-map {
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.map-chip {
  position: absolute;
  top: var(--space-2);
  left: var(--space-2);
  margin: 0;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: rgb(16 29 43 / 78%);
  color: var(--color-shell-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  white-space: nowrap;
}
</style>
