<script setup lang="ts">
/**
 * 阶段4：对象详情。
 *
 * 同一 glacier_id 在两期数据中都出现才算「同对象」可比（03 §7-5）：
 * 详情并排显示 2050 / 2100 两期的三个指标；只出现在一期时明确标注，
 * 不把缺失的一期填 0 或复制另一期的值。
 */
import { computed } from 'vue'
import { NOT_PROVIDED_TEXT, formatFixed } from '@/domain/format'
import {
  MATCH_STATUS_TEXT,
  SCENARIO_METRIC_META,
  SCENARIO_METRICS,
  formatScenarioValue,
  type ScenarioRecord,
} from '@/domain/scenario'
import { useRiskStore } from '@/stores/risk'

const props = defineProps<{
  record: ScenarioRecord | null
}>()

const emit = defineEmits<{
  close: []
}>()

const store = useRiskStore()

const matchStatus = computed(() =>
  props.record === null ? null : store.matchStatusOfId(props.record.glacierId),
)

function recordOf(year: 2050 | 2100): { record: ScenarioRecord | null; loaded: boolean } {
  const dataset = store.datasetOf(year)
  if (props.record === null || dataset === null) return { record: null, loaded: false }
  return {
    record: dataset.records.find((item) => item.glacierId === props.record?.glacierId) ?? null,
    loaded: true,
  }
}

const record2050 = computed(() => recordOf(2050))
const record2100 = computed(() => recordOf(2100))

/** 该期显示值：有记录显示数值；该期已装载但无此对象 → 无此对象；该期未装载 → 未装载。 */
function valueText(
  cell: { record: ScenarioRecord | null; loaded: boolean },
  metric: (typeof SCENARIO_METRICS)[number],
): string {
  if (!cell.loaded) return '未装载'
  if (cell.record === null) return '无此对象'
  return formatScenarioValue(cell.record.values[metric])
}
</script>

<template>
  <section
    v-if="props.record !== null"
    class="detail"
    data-testid="risk-detail"
    aria-label="对象详情"
  >
    <header class="detail-head">
      <div class="detail-id-block">
        <h3 class="detail-title" data-testid="detail-glacier-id">{{ props.record.glacierId }}</h3>
        <p class="detail-sub">
          <span
            v-if="matchStatus !== null"
            class="match-badge"
            :data-testid="`match-status-${matchStatus}`"
            >{{ MATCH_STATUS_TEXT[matchStatus] }}</span
          >
          <span>区域 {{ props.record.region ?? NOT_PROVIDED_TEXT }}</span>
          <span>流域 {{ props.record.basin ?? NOT_PROVIDED_TEXT }}</span>
          <span data-testid="detail-coords"
            >{{ formatFixed(props.record.longitude, 4) }},
            {{ formatFixed(props.record.latitude, 4) }}</span
          >
        </p>
      </div>
      <button
        type="button"
        class="btn btn--ghost btn--small"
        data-testid="detail-close"
        @click="emit('close')"
      >
        关闭
      </button>
    </header>

    <div class="value-grid" data-testid="detail-values">
      <div class="value-head-row" aria-hidden="true">
        <span></span>
        <span>2050</span>
        <span>2100</span>
      </div>
      <template v-for="metric in SCENARIO_METRICS" :key="metric">
        <span class="metric-name">{{ SCENARIO_METRIC_META[metric].label }}</span>
        <span class="metric-value" :data-testid="`detail-${metric}-2050`">
          {{ valueText(record2050, metric) }}
        </span>
        <span class="metric-value" :data-testid="`detail-${metric}-2100`">
          {{ valueText(record2100, metric) }}
        </span>
      </template>
    </div>
    <p class="detail-note">
      缺失值显示「{{ NOT_PROVIDED_TEXT }}」（源数据未提供），不显示
      0；两期同用统一色域与同一指标语义，可按同对象直接对比。
    </p>
  </section>
</template>

<style scoped>
.detail {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-primary);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  min-width: 0;
}

.detail-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
}

.detail-title {
  margin: 0;
  font-size: var(--font-size-body);
  font-weight: 600;
  color: var(--color-text);
  overflow-wrap: anywhere;
}

.detail-sub {
  margin: var(--space-1) 0 0;
  display: flex;
  gap: var(--space-3);
  flex-wrap: wrap;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.match-badge {
  padding: 1px var(--space-2);
  border-radius: var(--badge-radius);
  background: var(--color-info-surface);
  color: var(--color-text);
}

.value-grid {
  display: grid;
  grid-template-columns: minmax(72px, auto) 1fr 1fr;
  gap: var(--space-1) var(--space-3);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.value-head-row {
  display: contents;
}

.value-head-row span {
  color: var(--color-muted);
  font-weight: 600;
}

.metric-name {
  color: var(--color-muted);
}

.metric-value {
  color: var(--color-text);
  text-align: right;
}

.detail-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}
</style>
