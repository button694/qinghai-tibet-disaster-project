<script setup lang="ts">
/**
 * 阶段4：指标分布直方图与统计口径。
 *
 * 直方图展示的是**连续指数的分布**（10 个等宽展示区间），不是风险分级；
 * 点击分箱按该连续区间筛选地图与列表（再点同一箱取消）。
 * null 不进任何箱，单独统计显示（缺失 ≠ 0）；0 属于第一箱（真实为零）。
 *
 * 实现说明：用 DOM 柱状图而不是 ECharts——分箱点击必须同时满足
 * 「键盘可达」「浏览器用例可稳定点击」「颜色来自令牌」三个要求，
 * DOM 柱条天然满足；ECharts 留给阶段5/6 的复杂图表（D-056）。
 */
import { computed } from 'vue'
import { formatCount, formatFixed } from '@/domain/format'
import {
  SCENARIO_BIN_COUNT,
  SCENARIO_METRIC_META,
  distributionBins,
  type ScenarioMetric,
  type ScenarioRecord,
} from '@/domain/scenario'

const props = defineProps<{
  metric: ScenarioMetric
  /** 已按区域/流域筛选后的记录（直方图与地图同一份口径）。 */
  records: ScenarioRecord[]
  /** 当前直方图筛选区间；命中分箱高亮。 */
  binRange: [number, number] | null
  /** 全量条数（含被区域/流域筛掉的），用于口径说明。 */
  totalCountAll: number
}>()

const emit = defineEmits<{
  binSelect: [range: [number, number] | null]
}>()

const distribution = computed(() => distributionBins(props.records, props.metric))

const maxCount = computed(() => Math.max(1, ...distribution.value.bins.map((bin) => bin.count)))

function binLabel(index: number): string {
  const width = 1 / SCENARIO_BIN_COUNT
  return `${formatFixed(index * width, 1)}–${formatFixed((index + 1) * width, 1)}`
}

function isActive(index: number): boolean {
  if (props.binRange === null) return false
  const width = 1 / SCENARIO_BIN_COUNT
  return props.binRange[0] === index * width && props.binRange[1] === (index + 1) * width
}

function toggleBin(index: number): void {
  if (isActive(index)) {
    emit('binSelect', null)
    return
  }
  const width = 1 / SCENARIO_BIN_COUNT
  emit('binSelect', [index * width, (index + 1) * width])
}

const zeroCount = computed(
  () => props.records.filter((record) => record.values[props.metric] === 0).length,
)
const nullCount = computed(
  () => props.records.filter((record) => record.values[props.metric] === null).length,
)
</script>

<template>
  <section class="stats" data-testid="risk-stats" aria-label="指标分布与统计">
    <header class="stats-head">
      <h3 class="stats-title">分布（展示区间，不是等级）</h3>
      <span class="stats-unit">{{ SCENARIO_METRIC_META[props.metric].unit }}</span>
    </header>

    <div
      class="bars"
      data-testid="risk-histogram"
      role="group"
      aria-label="指数分布直方图，点击分箱可筛选"
    >
      <button
        v-for="(bin, index) in distribution.bins"
        :key="index"
        type="button"
        class="bin"
        :class="{ 'is-active': isActive(index) }"
        :data-testid="`bin-${index}`"
        :title="`区间 ${binLabel(index)}：${formatCount(bin.count)} 条`"
        :aria-label="`区间 ${binLabel(index)}，${formatCount(bin.count)} 条，点击筛选`"
        :aria-pressed="isActive(index)"
        @click="toggleBin(index)"
      >
        <span
          class="bin-bar"
          :style="{ height: `${Math.round((bin.count / maxCount) * 100)}%` }"
        ></span>
        <span class="bin-label">{{ formatFixed(index / SCENARIO_BIN_COUNT, 1) }}</span>
        <span class="bin-count">{{ formatCount(bin.count) }}</span>
      </button>
    </div>
    <p v-if="distribution.nullCount > 0" class="null-note" data-testid="histogram-null-note">
      另有 {{ formatCount(distribution.nullCount) }} 条值为缺失（null），未进任何区间，不计入上图。
    </p>

    <dl class="stat-list">
      <div class="stat">
        <dt>当前筛选</dt>
        <dd data-testid="stats-filtered">{{ formatCount(props.records.length) }} 条</dd>
      </div>
      <div class="stat">
        <dt>全部对象</dt>
        <dd data-testid="stats-total">{{ formatCount(props.totalCountAll) }} 条</dd>
      </div>
      <div class="stat">
        <dt>值为 0（真实为零）</dt>
        <dd data-testid="stats-zero">{{ formatCount(zeroCount) }} 条</dd>
      </div>
      <div class="stat">
        <dt>值缺失（null，未提供）</dt>
        <dd data-testid="stats-null">{{ formatCount(nullCount) }} 条</dd>
      </div>
    </dl>
    <p class="stats-note">
      0 与缺失分开统计：0 是真实测得值，null 是源数据未提供；缺失不计入任何分箱，也不当作低值。
    </p>
  </section>
</template>

<style scoped>
.stats {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  min-width: 0;
}

.stats-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.stats-title {
  margin: 0;
  font-size: var(--font-size-body);
  font-weight: 600;
  color: var(--color-text);
}

.stats-unit {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.bars {
  display: flex;
  align-items: stretch;
  gap: 3px;
  height: 150px;
  min-width: 0;
}

.bin {
  flex: 1 1 0;
  min-width: 0;
  display: flex;
  flex-direction: column;
  align-items: center;
  justify-content: flex-end;
  gap: 2px;
  padding: 2px;
  border: 1px solid transparent;
  border-radius: var(--radius-sm);
  background: transparent;
  cursor: pointer;
}

.bin:hover {
  border-color: var(--color-border);
}

.bin.is-active {
  border-color: var(--color-map-query);
  background: var(--color-warning-surface);
}

.bin-bar {
  width: 100%;
  min-height: 2px;
  border-radius: 2px 2px 0 0;
  background: var(--color-primary);
}

.bin.is-active .bin-bar {
  background: var(--color-map-query);
}

.bin-label {
  color: var(--color-muted);
  font-size: 9px;
  font-variant-numeric: tabular-nums;
}

.bin-count {
  color: var(--color-text);
  font-size: 9px;
  font-variant-numeric: tabular-nums;
}

.null-note {
  margin: 0;
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.stat-list {
  margin: 0;
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-2);
}

.stat {
  display: flex;
  justify-content: space-between;
  gap: var(--space-2);
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
  min-width: 0;
}

.stat dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.stat dd {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.stats-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}
</style>
