<script setup lang="ts">
/**
 * 阶段4：来源与边界面板（持续可见）。
 *
 * 显示：数据来源、情景年份、导出时间、坐标系转换、版本（源图层 + SHA-256 前缀）、
 * 指标语义与「未来情景，不是实时预警」提示。这些都是只读事实，不参与交互。
 */
import { formatCount } from '@/domain/format'
import {
  SCENARIO_METRIC_META,
  SCENARIO_METRICS,
  type ScenarioDataset,
  type ScenarioYear,
} from '@/domain/scenario'
import type { PreviewManifest } from '@/repositories/realPreview'

const props = defineProps<{
  manifest: PreviewManifest | null
  /** 已装载的各年数据（含 sha256 与源图层名）。 */
  datasets: Partial<Record<ScenarioYear, ScenarioDataset>>
}>()

const YEAR_LABEL: Record<ScenarioYear, string> = { 2050: '2050 情景', 2100: '2100 情景' }

function datasetList(): Array<{ year: ScenarioYear; dataset: ScenarioDataset }> {
  return ([2050, 2100] as const)
    .map((year) => ({ year, dataset: props.datasets[year] }))
    .filter(
      (item): item is { year: ScenarioYear; dataset: ScenarioDataset } =>
        item.dataset !== undefined,
    )
}
</script>

<template>
  <section class="source" data-testid="risk-source-panel" aria-label="数据来源与边界">
    <header class="source-head">
      <h2 class="source-title">数据来源与口径</h2>
      <span class="source-badge" data-testid="source-mode-badge">情景数据</span>
    </header>

    <dl v-if="props.manifest" class="source-list">
      <dt>数据来源</dt>
      <dd data-testid="source-label">{{ props.manifest.sourceLabel }}</dd>
      <dt>导出时间</dt>
      <dd data-testid="source-generated">{{ props.manifest.generatedAt }}（UTC）</dd>
      <dt>坐标转换</dt>
      <dd data-testid="source-crs">
        {{ props.manifest.sourceCrs }} → {{ props.manifest.displayCrs }} → Web Mercator
        显示；未做控制点精度验收。
      </dd>
      <template v-for="item in datasetList()" :key="item.year">
        <dt>{{ YEAR_LABEL[item.year] }}版本</dt>
        <dd :data-testid="`source-version-${item.year}`">
          {{ formatCount(item.dataset.total) }} 条情景记录
          <template v-if="item.dataset.skippedInvalid > 0">
            （{{ item.dataset.skippedInvalid }} 条因标识或坐标无效未纳入，未静默丢弃）
          </template>
        </dd>
      </template>
    </dl>
    <p v-else class="source-pending">来源信息暂时无法显示。</p>

    <div class="metric-notes">
      <h3 class="notes-title">指标解释</h3>
      <ul class="notes-list">
        <li v-for="metric in SCENARIO_METRICS" :key="metric" :data-testid="`metric-note-${metric}`">
          <b>{{ SCENARIO_METRIC_META[metric].label }}</b
          >（{{ SCENARIO_METRIC_META[metric].unit }}）：
          {{ SCENARIO_METRIC_META[metric].explanation }}
        </li>
      </ul>
      <p class="notes-foot">指标为项目已有分析输出；暂未提供参数调整和重新计算。</p>
    </div>
  </section>
</template>

<style scoped>
.source {
  display: grid;
  gap: var(--space-3);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  min-width: 0;
}

.source-head {
  display: flex;
  align-items: center;
  justify-content: space-between;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.source-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.source-badge {
  padding: 2px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.source-list {
  margin: 0;
  display: grid;
  grid-template-columns: 110px minmax(0, 1fr);
  gap: var(--space-2);
  font-size: var(--font-size-caption);
}

.source-list dt {
  color: var(--color-muted);
}

.source-list dd {
  margin: 0;
  color: var(--color-text);
  overflow-wrap: anywhere;
  font-variant-numeric: tabular-nums;
}

.source-pending {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.metric-notes {
  display: grid;
  gap: var(--space-2);
}

.notes-title {
  margin: 0;
  font-size: var(--font-size-body);
  color: var(--color-text);
}

.notes-list {
  margin: 0;
  padding-left: var(--space-4);
  display: grid;
  gap: var(--space-1);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

.notes-foot {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

@media (max-width: 600px) {
  .source-list {
    grid-template-columns: minmax(0, 1fr);
  }

  .source-list dt {
    margin-top: var(--space-1);
  }
}
</style>
