<script setup lang="ts">
/**
 * 阶段4：风险研判控制面板。
 *
 * 成果选择区分两类（03 §7-1）：
 * - projectAnalysis：项目分析成果。API 模式读取 QTP_GEOHAZARD 正式易发性点成果，
 *   其它模式保留「正式成果服务待发布/待联调」边界，不用 2050/2100 情景冒充；
 * - externalScenario：外部未来情景（2050/2100只读文件快照）。
 *
 * 参数只读：本页没有任何可写参数入口（未接计算服务，S14）。
 */
import { computed } from 'vue'
import { formatCount, formatFixed } from '@/domain/format'
import { SCENARIO_METRIC_META, SCENARIO_METRICS } from '@/domain/scenario'
import { useRiskStore, type RiskSourceKind, type RiskYearMode } from '@/stores/risk'

const props = defineProps<{
  /** 全量对象数（用于「筛选后 / 全部」显示；两年都装时为两年之和）。 */
  totalCount: number
}>()

const emit = defineEmits<{
  fit: []
}>()

const store = useRiskStore()

const SOURCE_OPTIONS: Array<{ value: RiskSourceKind; label: string; note: string }> = [
  {
    value: 'externalScenario',
    label: '未来情景（2050 / 2100）',
    note: '2050 / 2100 情景数据',
  },
  { value: 'projectAnalysis', label: '项目分析成果', note: '正式易发性点成果' },
]

const YEAR_OPTIONS: Array<{ mode: RiskYearMode; year?: 2050 | 2100; label: string }> = [
  { mode: 'single', year: 2050, label: '2050 单图' },
  { mode: 'single', year: 2100, label: '2100 单图' },
  { mode: 'compare', label: '双图对比' },
]

const metricOptions = computed(() =>
  SCENARIO_METRICS.map((key) => ({ key, meta: SCENARIO_METRIC_META[key] })),
)

const filtersActive = computed(
  () => store.regionFilter !== null || store.basinFilter !== null || store.binRange !== null,
)

function pickYearMode(option: (typeof YEAR_OPTIONS)[number]): void {
  if (option.mode === 'compare') {
    store.setYearMode('compare')
    return
  }
  if (option.year !== undefined) store.setActiveYear(option.year)
}

function isActive(option: (typeof YEAR_OPTIONS)[number]): boolean {
  if (option.mode === 'compare') return store.isCompare
  return !store.isCompare && store.activeYear === option.year
}
</script>

<template>
  <section class="control" data-testid="risk-control" aria-label="风险研判控制">
    <fieldset class="group">
      <legend>成果类型</legend>
      <div class="kind-row" role="radiogroup" aria-label="成果类型">
        <label
          v-for="option in SOURCE_OPTIONS"
          :key="option.value"
          class="kind-option"
          :class="{ 'is-active': store.sourceKind === option.value }"
        >
          <input
            v-model="store.sourceKind"
            type="radio"
            name="risk-source-kind"
            :value="option.value"
            :data-testid="`source-kind-${option.value}`"
          />
          <span class="kind-label">{{ option.label }}</span>
          <span
            class="kind-note"
            :data-testid="option.value === 'projectAnalysis' ? 'kind-note-pending' : null"
          >
            {{ option.note }}
          </span>
        </label>
      </div>
    </fieldset>

    <template v-if="store.sourceKind === 'externalScenario'">
      <fieldset class="group">
        <legend>情景与指标</legend>
        <div class="row">
          <div class="segment" role="radiogroup" aria-label="情景年份">
            <button
              v-for="option in YEAR_OPTIONS"
              :key="option.label"
              type="button"
              class="btn btn--ghost btn--small segment-btn"
              :class="{ 'is-active': isActive(option) }"
              :data-testid="option.mode === 'compare' ? 'year-mode-compare' : `year-${option.year}`"
              :aria-pressed="isActive(option)"
              @click="pickYearMode(option)"
            >
              {{ option.label }}
            </button>
          </div>
          <label class="field">
            指标
            <select
              :value="store.metric"
              data-testid="metric-select"
              aria-label="选择指标"
              @change="store.setMetric(($event.target as HTMLSelectElement).value)"
            >
              <option v-for="item in metricOptions" :key="item.key" :value="item.key">
                {{ item.meta.label }}（{{ item.meta.unit }}）
              </option>
            </select>
          </label>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="fit-maps"
            @click="emit('fit')"
          >
            适配范围
          </button>
        </div>
        <p class="metric-hint" data-testid="metric-hint">
          {{ SCENARIO_METRIC_META[store.metric].explanation }}
        </p>
      </fieldset>

      <fieldset class="group">
        <legend>筛选（与地图、统计、重点对象同步）</legend>
        <div class="row">
          <label class="field">
            区域
            <select
              :value="store.regionFilter ?? ''"
              data-testid="region-select"
              aria-label="按区域筛选"
              @change="store.setRegion(($event.target as HTMLSelectElement).value || null)"
            >
              <option value="">全部区域</option>
              <option v-for="item in store.regionOptions" :key="item" :value="item">
                {{ item }}
              </option>
            </select>
          </label>
          <label class="field">
            流域
            <select
              :value="store.basinFilter ?? ''"
              data-testid="basin-select"
              aria-label="按流域筛选"
              @change="store.setBasin(($event.target as HTMLSelectElement).value || null)"
            >
              <option value="">全部流域</option>
              <option v-for="item in store.basinOptions" :key="item" :value="item">
                {{ item }}
              </option>
            </select>
          </label>
          <span class="count" data-testid="filter-count">
            筛选后 {{ formatCount(store.filteredCount) }} / 全部
            {{ formatCount(props.totalCount) }} 条
          </span>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="clear-filters"
            :disabled="!filtersActive"
            @click="store.clearFilters()"
          >
            清除筛选
          </button>
        </div>
        <p v-if="store.binRange !== null" class="metric-hint" data-testid="bin-range-hint">
          已按直方图选中区间 {{ formatFixed(store.binRange[0], 2) }}—{{
            formatFixed(store.binRange[1], 2)
          }}
          筛选（连续区间，不是等级）。
        </p>
      </fieldset>
    </template>
  </section>
</template>

<style scoped>
.control {
  display: grid;
  gap: var(--space-3);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.group {
  margin: 0;
  padding: 0;
  border: none;
  display: grid;
  gap: var(--space-2);
  min-width: 0;
}

legend {
  padding: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.kind-row {
  display: flex;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.kind-option {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  cursor: pointer;
  min-width: 0;
}

.kind-option.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
}

.kind-label {
  font-size: var(--font-size-body);
  color: var(--color-text);
}

.kind-note {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.row {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
  min-width: 0;
}

.segment {
  display: inline-flex;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
}

.segment-btn {
  border: none;
  border-radius: 0;
}

.segment-btn + .segment-btn {
  border-left: 1px solid var(--color-border);
}

.segment-btn.is-active {
  background: var(--color-primary);
  color: var(--color-on-primary);
}

.field {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  color: var(--color-muted);
  font-size: var(--font-size-body);
  min-width: 0;
}

select {
  font: inherit;
  padding: 4px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  max-width: 220px;
  color: var(--color-text);
  background: var(--color-surface);
}

.count {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.metric-hint {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}
</style>
