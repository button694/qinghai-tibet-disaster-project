<script setup lang="ts">
/**
 * 地图工具栏（03 §5-4）。
 *
 * 只放真实可用的操作：缩放、复位、定位到当前图层、清空选中、图例与列表开关。
 * 不提供「在线底图切换」——当前没有可用的在线底图服务，做了也只会得到空白（01 §8）。
 */
defineProps<{
  /** 是否存在选中对象，决定「清空选中」是否可用。 */
  hasSelection: boolean
  /** 当前对象列表图层是否可定位（无几何或未加载时为 false）。 */
  canFocusActive: boolean
  /** 「清空选中」不可用时的原因说明。 */
  clearDisabledReason: string | null
  /** 查询面板是否打开（阶段3）。 */
  queryOpen: boolean
}>()

const emit = defineEmits<{
  zoomIn: []
  zoomOut: []
  reset: []
  focusActive: []
  clearSelection: []
  toggleLegend: []
  toggleObjectList: []
  toggleLayerDrawer: []
  toggleQuery: []
}>()
</script>

<template>
  <div class="toolbar" role="toolbar" aria-label="地图工具" data-testid="map-toolbar">
    <button
      type="button"
      class="btn btn--small"
      aria-label="放大一级"
      data-testid="zoom-in"
      @click="emit('zoomIn')"
    >
      放大 +
    </button>
    <button
      type="button"
      class="btn btn--small"
      aria-label="缩小一级"
      data-testid="zoom-out"
      @click="emit('zoomOut')"
    >
      缩小 −
    </button>
    <button
      type="button"
      class="btn btn--small"
      aria-label="复位视图"
      data-testid="reset-view"
      @click="emit('reset')"
    >
      复位
    </button>
    <button
      type="button"
      class="btn btn--small"
      :disabled="!canFocusActive"
      aria-label="定位到当前对象列表图层"
      data-testid="focus-active"
      @click="emit('focusActive')"
    >
      定位当前图层
    </button>
    <button
      type="button"
      class="btn btn--ghost btn--small"
      :disabled="!hasSelection"
      :title="clearDisabledReason ?? '清除地图高亮与右侧详情'"
      aria-label="清空选中"
      data-testid="clear-selection"
      @click="emit('clearSelection')"
    >
      清空选中
    </button>
    <span class="toolbar-sep" aria-hidden="true"></span>
    <button
      type="button"
      class="btn btn--small"
      :class="{ 'is-active': queryOpen }"
      aria-label="显示或隐藏查询面板"
      :aria-pressed="queryOpen"
      data-testid="toggle-query"
      @click="emit('toggleQuery')"
    >
      查询
    </button>
    <button
      type="button"
      class="btn btn--ghost btn--small"
      aria-label="显示或隐藏图例"
      data-testid="toggle-legend"
      @click="emit('toggleLegend')"
    >
      图例
    </button>
    <button
      type="button"
      class="btn btn--ghost btn--small"
      aria-label="显示或隐藏对象列表"
      data-testid="toggle-object-list"
      @click="emit('toggleObjectList')"
    >
      对象列表
    </button>
    <button
      type="button"
      class="btn btn--ghost btn--small toolbar-drawer"
      aria-label="显示或隐藏图层面板"
      data-testid="toggle-layer-drawer"
      @click="emit('toggleLayerDrawer')"
    >
      图层
    </button>
  </div>
</template>

<style scoped>
.toolbar {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.btn--small {
  min-height: 30px;
  padding: 0 var(--space-3);
  font-size: var(--font-size-caption);
}

.toolbar-sep {
  flex: 1 1 auto;
}

.btn.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
}

.toolbar-drawer {
  display: none;
}

@media (max-width: 1023px) {
  .toolbar-drawer {
    display: inline-flex;
  }
}
</style>
