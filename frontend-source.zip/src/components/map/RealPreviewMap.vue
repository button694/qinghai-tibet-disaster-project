<script setup lang="ts">
import 'ol/ol.css'
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import OlMap from 'ol/Map'
import View from 'ol/View'
import GeoJSON from 'ol/format/GeoJSON'
import VectorLayer from 'ol/layer/Vector'
import VectorSource from 'ol/source/Vector'
import { fromLonLat } from 'ol/proj'
import { Circle, Fill, Stroke, Style } from 'ol/style'
import { createRealPreviewRepository, type PreviewLayer } from '@/repositories/realPreview'

const props = defineProps<{ layers: PreviewLayer[] }>()
const host = ref<HTMLElement | null>(null)
const active = ref('scenario2050')
const status = ref('正在加载')
const busy = ref(false)
const error = ref('')
const selected = ref<Record<string, unknown> | null>(null)
const opacity = ref(0.8)
const repository = createRealPreviewRepository()
const source = new VectorSource()
const boundarySource = new VectorSource()
const boundary = new VectorLayer({
  source: boundarySource,
  style: new Style({
    stroke: new Stroke({ color: '#8faebd', width: 1 }),
    fill: new Fill({ color: '#294451' }),
  }),
})
const dataLayer = new VectorLayer({
  source,
  style: new Style({
    image: new Circle({
      radius: 4,
      fill: new Fill({ color: '#62d2cb' }),
      stroke: new Stroke({ color: '#102b36', width: 0.7 }),
    }),
  }),
})
let map: OlMap | undefined
let ticket = 0
let disposed = false
const current = computed(() => props.layers.find((l) => l.id === active.value))
const count = ref(0)
const fields = computed(() =>
  Object.entries(selected.value ?? {}).filter(([key]) => key !== 'geometry'),
)
function fit(): void {
  const extent = source.getFeatures().length ? source.getExtent() : boundarySource.getExtent()
  if (extent && extent.every(Number.isFinite))
    map?.getView().fit(extent, { padding: [40, 40, 40, 40], maxZoom: 7 })
}
async function load(): Promise<void> {
  const id = ++ticket
  busy.value = true
  error.value = ''
  selected.value = null
  source.clear()
  count.value = 0
  try {
    const layer = current.value
    if (!layer) throw new Error('图层未登记')
    const data = await repository.features(layer)
    if (disposed || id !== ticket) return
    source.addFeatures(
      new GeoJSON().readFeatures(data, {
        dataProjection: 'EPSG:4326',
        featureProjection: 'EPSG:3857',
      }),
    )
    count.value = data.features.length
    status.value = `${layer.label} · ${count.value.toLocaleString()} 条（全量）`
    fit()
  } catch (e) {
    if (!disposed && id === ticket) {
      error.value = e instanceof Error ? e.message : String(e)
      status.value = '加载失败，无示例回退'
    }
  } finally {
    if (!disposed && id === ticket) busy.value = false
  }
}
watch(active, () => {
  void load()
})
watch(opacity, (value) => dataLayer.setOpacity(Number(value)))
onMounted(async () => {
  if (!host.value) return
  map = new OlMap({
    target: host.value,
    layers: [boundary, dataLayer],
    view: new View({ center: fromLonLat([90, 32]), zoom: 4, maxZoom: 15 }),
  })
  dataLayer.setOpacity(opacity.value)
  map.on('singleclick', (event) => {
    selected.value = null
    map?.forEachFeatureAtPixel(
      event.pixel,
      (feature) => {
        selected.value = feature.getProperties() as Record<string, unknown>
        return true
      },
      { layerFilter: (layer) => layer === dataLayer, hitTolerance: 7 },
    )
  })
  // Boundary failure is visible but does not block point data. Avoid implicit OL network loaders.
  const b = props.layers.find((l) => l.id === 'provinces')
  if (b) {
    try {
      const data = await repository.features(b)
      if (!disposed)
        boundarySource.addFeatures(
          new GeoJSON().readFeatures(data, { featureProjection: 'EPSG:3857' }),
        )
    } catch {
      if (!disposed) boundaryError.value = '省界加载失败；仍可查看点位。'
    }
  }
  if (!disposed) await load()
})
const boundaryError = ref('')
onBeforeUnmount(() => {
  disposed = true
  ++ticket
  map?.setTarget(undefined)
  map?.dispose()
})
</script>

<template>
  <section class="real-map" aria-label="真实地图预览">
    <div class="map-toolbar">
      <label
        >显示图层
        <select v-model="active" aria-label="显示图层">
          <option
            v-for="layer in layers.filter((l) => l.id !== 'provinces')"
            :key="layer.id"
            :value="layer.id"
          >
            {{ layer.label }}
          </option>
        </select></label
      >
      <label
        >透明度
        <input
          v-model.number="opacity"
          aria-label="透明度"
          type="range"
          min="0.1"
          max="1"
          step="0.1"
      /></label>
      <button type="button" class="btn" @click="fit">定位全部</button>
      <span role="status" data-testid="real-map-status">{{ busy ? '正在加载…' : status }}</span>
    </div>
    <p v-if="error" role="alert" class="map-error">
      {{ error }} <button type="button" class="btn" @click="load">重试图层</button>
    </p>
    <p v-if="boundaryError" role="alert" class="map-error">{{ boundaryError }}</p>
    <div class="map-body">
      <div ref="host" class="map-canvas" tabindex="0" aria-label="可缩放、可点选的真实地图"></div>
      <aside class="feature-panel">
        <h3>要素属性</h3>
        <p v-if="!selected">点击青色点查看原始字段。颜色只区分数据，不代表正式风险等级。</p>
        <dl v-else>
          <template v-for="[key, value] in fields" :key="key"
            ><dt>{{ key }}</dt>
            <dd>{{ value === null ? '未提供' : value }}</dd></template
          >
        </dl>
        <p class="map-note">
          2050 / 2100
          是未来情景，不是实时预警。省界仅为背景，不当作青藏高原研究区范围。简化边界不用于精确空间运算。
        </p>
      </aside>
    </div>
  </section>
</template>

<style scoped>
.real-map {
  overflow: hidden;
  border: 1px solid #b4cbd3;
  border-radius: 14px;
  box-shadow: 0 12px 35px rgb(13 42 54 / 10%);
}
.map-toolbar {
  display: flex;
  align-items: center;
  gap: 16px;
  padding: 14px;
  flex-wrap: wrap;
  background: #fff;
}
.map-toolbar label {
  display: flex;
  align-items: center;
  gap: 8px;
  font-size: 13px;
}
select {
  max-width: 100%;
  padding: 8px;
  border: 1px solid #b9cbd3;
  border-radius: 6px;
  font: inherit;
}
input {
  max-width: 110px;
  accent-color: #087f8c;
}
.map-toolbar span {
  font-size: 12px;
  color: #456473;
}
.map-body {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 280px;
}
.map-canvas {
  height: 520px;
  background: #132d39;
}
.feature-panel {
  padding: 20px;
  background: #f8fbfc;
  max-height: 520px;
  overflow: auto;
}
.feature-panel h3 {
  margin: 0 0 16px;
}
.feature-panel p {
  font-size: 13px;
  color: #456473;
  line-height: 1.8;
}
dl {
  font-size: 12px;
  display: grid;
  grid-template-columns: 95px minmax(0, 1fr);
  gap: 8px;
}
dt,
dd {
  overflow-wrap: anywhere;
}
dd {
  margin: 0;
}
.map-note {
  border-top: 1px solid #d6e1e6;
  padding-top: 18px;
  margin-top: 20px;
}
.map-error {
  margin: 0;
  padding: 12px;
  color: #862d36;
  background: #fff0f0;
}
@media (max-width: 800px) {
  .map-body {
    grid-template-columns: minmax(0, 1fr);
  }
  .map-canvas {
    height: 390px;
  }
  .feature-panel {
    max-height: 280px;
  }
}
</style>
