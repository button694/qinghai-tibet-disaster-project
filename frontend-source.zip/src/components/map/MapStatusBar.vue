<script setup lang="ts">
/**
 * 地图状态栏（03 §5-4、§5-6）。
 *
 * 显示四类信息，全部是**事实**而非意图：
 * - 鼠标经纬度（来自地图 pointermove，WGS84，保留 5 位小数）；
 * - 当前缩放级别（来自 OL View）；
 * - 可见图层数与实际渲染要素数（来自 OL 矢量源，不是界面勾选状态）；
 * - 生命周期指标仅保留在辅助技术节点中，不占用客户视野。
 *
 * 不显示「实时监测中」这类无来源信息（D-024）。
 */
import { computed } from 'vue'

import { formatCount, formatLonLat, formatNumber, NOT_PROVIDED_TEXT } from '@/domain/format'
import type { LonLat } from '@/domain/types'
import { useMapStore } from '@/stores/map'

const props = defineProps<{
  /** 鼠标经纬度；移出地图为 null。 */
  pointer: LonLat | null
  /** 当前对象列表图层的名称。 */
  activeLayerLabel: string | null
  /** 当前对象列表已加载的记录数。 */
  activeLayerCount: number | null
}>()

const store = useMapStore()

const coordinateText = computed(() =>
  props.pointer === null ? '鼠标不在图上' : formatLonLat(props.pointer),
)

const zoomText = computed(() => {
  const zoom = store.renderState?.zoom
  return zoom === undefined
    ? NOT_PROVIDED_TEXT
    : `缩放 ${formatNumber(zoom, { maximumFractionDigits: 2 })}`
})

const visibleText = computed(() => {
  const state = store.renderState
  if (!state) return '地图尚未就绪'
  return `可见图层 ${formatCount(state.visibleLayerCount)} · 已渲染要素 ${formatCount(state.renderedFeatureCount)}`
})

const lifecycleText = computed(() => {
  const state = store.renderState
  if (!state) return '生命周期计数未知'
  return `地图实例 ${formatCount(state.mapInstances)} · 事件监听 ${formatCount(state.listeners)}`
})
</script>

<template>
  <div class="status-bar" data-testid="map-status-bar">
    <span class="chip" data-testid="status-coordinate">坐标 {{ coordinateText }}</span>
    <span class="chip" data-testid="status-zoom">{{ zoomText }}</span>
    <span class="chip" data-testid="status-visible">{{ visibleText }}</span>
    <span class="visually-hidden" data-testid="status-lifecycle">{{ lifecycleText }}</span>
    <span class="chip" data-testid="status-active-layer">
      当前查看：{{ activeLayerLabel ?? NOT_PROVIDED_TEXT }} ·
      {{ activeLayerCount === null ? NOT_PROVIDED_TEXT : `${formatCount(activeLayerCount)} 条` }}
    </span>
  </div>
</template>

<style scoped>
.status-bar {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  /* 高度写死，不随内容变化：
     鼠标进入地图时坐标文案会从「鼠标不在图上」变成具体经纬度，若状态栏因此换行变高，
     地图容器就被挤矮，鼠标那一瞬间的坐标映射整体偏移——用户点选会点偏。
     内容放不下时由内部横向滚动或末尾 chip 省略号处理，绝不改变高度。 */
  height: var(--statusbar-height);
  min-height: var(--statusbar-height);
  flex-wrap: nowrap;
  overflow: hidden;
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.chip {
  flex: 0 0 auto;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: var(--color-info-surface);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

/* 坐标位数固定，避免同一行内其它 chip 左右抖动。 */
.chip:first-child {
  min-width: 24ch;
}

/* 末尾的「当前查看」可收缩并可省略，保证客户关心的地图信息完整可见。 */
.chip:last-child {
  flex: 0 1 auto;
  min-width: 0;
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
