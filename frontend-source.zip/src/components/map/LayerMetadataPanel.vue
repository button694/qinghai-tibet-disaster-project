<script setup lang="ts">
/**
 * 图层元数据面板（03 §5-3「元数据」）。
 *
 * 显示注册表里的图层定义 + 数据集元数据 + 图例定义，全部经 Repository 读取。
 * 三处必须保持诚实：
 * - 数据集的「已登记」与「服务可用」分开显示（01 §5.6）；
 * - 栅格分辨率、范围、质量未登记时写「未登记」，不填 0 或猜测值（D-020）；
 * - 读取失败显示失败原因，不用空字段冒充实数据。
 */
import { computed, ref, watch } from 'vue'

import { formatBbox, formatCount, formatTimeValue, NOT_PROVIDED_TEXT } from '@/domain/format'
import { ACCESS_LEVEL_LABEL, DATASET_STATUS_LABEL, GEOMETRY_FAMILY_LABEL } from '@/domain/labels'
import type { Dataset, LayerDefinition, Legend } from '@/domain/types'
import { layerAvailability, layerTimeText, layerTypeText, mapSourceLabel } from '@/config/mapLayers'
import { getMapLayerService } from '@/services/mapLayers'
import { isRepositoryError, toRepositoryError } from '@/repositories/types'

const props = defineProps<{ layer: LayerDefinition }>()
const emit = defineEmits<{ close: [] }>()

const legend = ref<Legend | null>(null)
const dataset = ref<Dataset | null>(null)
const notes = ref<string[]>([])
const loading = ref(false)

const availability = computed(() => layerAvailability(props.layer))

/** 来源地址：`unavailable` 时显示数据包给出的原因，而不是一个空 URL。 */
const sourceText = computed(() => {
  const source = props.layer.source
  if (source.type === 'unavailable') return `服务未接入：${source.reason}`
  if (source.type === 'geojson') return `${mapSourceLabel(source)} · ${source.url}`
  if (source.type === 'xyz') return `${mapSourceLabel(source)} · ${source.url}`
  if (source.type === 'wmts') return `${mapSourceLabel(source)} · ${source.capabilitiesUrl}`
  if (source.type === 'wms') return `${mapSourceLabel(source)} · ${source.url}`
  return `${mapSourceLabel(source)} · ${source.url}`
})

const datasetRows = computed(() => {
  const item = dataset.value
  if (item === null) return []
  const time = item.availableTimes[0]
  return [
    { key: 'name', label: '数据集名称', value: item.name },
    { key: 'version', label: '数据集版本', value: item.version },
    { key: 'type', label: '数据类型', value: item.dataType },
    { key: 'status', label: '登记状态', value: DATASET_STATUS_LABEL[item.status] },
    {
      key: 'service',
      label: '服务可用',
      value: item.serviceAvailable ? '可用' : `不可用：${item.serviceNote ?? NOT_PROVIDED_TEXT}`,
    },
    { key: 'access', label: '访问级别', value: ACCESS_LEVEL_LABEL[item.accessLevel] },
    { key: 'crs', label: '源坐标系', value: item.sourceCrs || NOT_PROVIDED_TEXT },
    { key: 'extent', label: '范围（西/南/东/北）', value: formatBbox(item.extent) },
    { key: 'resolution', label: '分辨率', value: item.resolution ?? NOT_PROVIDED_TEXT },
    { key: 'quality', label: '质量说明', value: item.quality ?? NOT_PROVIDED_TEXT },
    { key: 'time', label: '可用时相', value: time ? formatTimeValue(time) : '未登记' },
    {
      key: 'fields',
      label: '登记字段数',
      value: formatCount(item.fields.length, { unitSuffix: ' 个' }),
    },
  ]
})

async function load(): Promise<void> {
  loading.value = true
  notes.value = []
  legend.value = null
  dataset.value = null
  const service = getMapLayerService()
  try {
    const [legendResult, datasetResult] = await Promise.all([
      props.layer.legendId === '' || props.layer.legendId === undefined
        ? Promise.resolve({ legend: null, note: '该图层未登记图例 ID。' })
        : service.getLegend(props.layer.legendId),
      service.getDataset(props.layer.datasetId),
    ])
    legend.value = legendResult.legend
    dataset.value = datasetResult.dataset
    if (legendResult.note) notes.value.push(legendResult.note)
    if (datasetResult.note) notes.value.push(datasetResult.note)
  } catch (error) {
    const repositoryError = isRepositoryError(error) ? error : toRepositoryError(error, 'UNKNOWN')
    notes.value.push(repositoryError.userMessage)
  } finally {
    loading.value = false
  }
}

watch(
  () => props.layer.id,
  () => void load(),
  { immediate: true },
)
</script>

<template>
  <aside class="metadata" data-testid="layer-metadata" aria-label="图层元数据">
    <header class="meta-head">
      <h2 class="meta-title">{{ layer.label }}</h2>
      <button
        type="button"
        class="btn btn--ghost btn--small"
        aria-label="关闭图层元数据"
        data-testid="metadata-close"
        @click="emit('close')"
      >
        关闭
      </button>
    </header>

    <p class="meta-note" :class="{ 'is-warn': !availability.available }">
      {{ availability.available ? '本阶段可在地图上渲染该图层。' : availability.reason }}
    </p>

    <dl class="meta-list" data-testid="layer-metadata-list">
      <div>
        <dt>图层 ID</dt>
        <dd>{{ layer.id }}</dd>
      </div>
      <div>
        <dt>业务主题</dt>
        <dd>{{ layer.theme }}</dd>
      </div>
      <div>
        <dt>几何类型</dt>
        <dd>{{ GEOMETRY_FAMILY_LABEL[layer.geometryType] }}</dd>
      </div>
      <div>
        <dt>图层类型</dt>
        <dd>{{ layerTypeText(layer) }}</dd>
      </div>
      <div>
        <dt>数据来源</dt>
        <dd>{{ sourceText }}</dd>
      </div>
      <div>
        <dt>源坐标系</dt>
        <dd>{{ layer.sourceCrs || NOT_PROVIDED_TEXT }}</dd>
      </div>
      <div>
        <dt>源 WKT</dt>
        <dd>{{ layer.sourceWkt ?? NOT_PROVIDED_TEXT }}</dd>
      </div>
      <div>
        <dt>时相</dt>
        <dd>{{ layerTimeText(layer) }}</dd>
      </div>
      <div>
        <dt>默认可见</dt>
        <dd>{{ layer.defaultVisible ? '是' : '否' }}</dd>
      </div>
      <div>
        <dt>默认透明度</dt>
        <dd>{{ layer.defaultOpacity }}</dd>
      </div>
      <div>
        <dt>最小缩放</dt>
        <dd>{{ layer.minZoom ?? NOT_PROVIDED_TEXT }}</dd>
      </div>
      <div>
        <dt>可查询</dt>
        <dd>{{ layer.queryable ? '是' : '否' }}</dd>
      </div>
      <div>
        <dt>导出格式</dt>
        <dd>
          {{ layer.exportFormats.length > 0 ? layer.exportFormats.join(' / ') : NOT_PROVIDED_TEXT }}
        </dd>
      </div>
      <div>
        <dt>数据集 ID</dt>
        <dd>{{ layer.datasetId }}</dd>
      </div>
      <div>
        <dt>图例 ID</dt>
        <dd>{{ layer.legendId || NOT_PROVIDED_TEXT }}</dd>
      </div>
      <div>
        <dt>字段数</dt>
        <dd>{{ formatCount(layer.fields.length, { unitSuffix: ' 个' }) }}</dd>
      </div>
    </dl>

    <section class="meta-block">
      <h3 class="block-title">字段字典</h3>
      <table class="field-table">
        <thead>
          <tr>
            <th scope="col">字段</th>
            <th scope="col">类型</th>
            <th scope="col">单位</th>
            <th scope="col">可空</th>
          </tr>
        </thead>
        <tbody>
          <tr v-for="field in layer.fields" :key="field.key">
            <td>
              {{ field.label }}<span class="field-key">{{ field.key }}</span>
            </td>
            <td>{{ field.type }}</td>
            <td>{{ field.unit ?? NOT_PROVIDED_TEXT }}</td>
            <td>{{ field.nullable ? '是' : '否' }}</td>
          </tr>
        </tbody>
      </table>
    </section>

    <section class="meta-block">
      <h3 class="block-title">数据集与来源</h3>
      <p v-if="loading" class="meta-note" role="status">正在读取数据集与图例定义…</p>
      <template v-else>
        <dl v-if="datasetRows.length > 0" class="meta-list" data-testid="layer-metadata-dataset">
          <div v-for="row in datasetRows" :key="row.key">
            <dt>{{ row.label }}</dt>
            <dd>{{ row.value }}</dd>
          </div>
        </dl>
        <p v-else class="meta-note">未取到数据集元数据。</p>
        <p class="meta-note">
          图例：{{
            legend
              ? `${legend.items.length} 个条目，版本 ${legend.classificationVersion ?? NOT_PROVIDED_TEXT}`
              : '未取到图例定义'
          }}
        </p>
      </template>
      <p v-for="note in notes" :key="note" class="meta-note is-warn" role="note">{{ note }}</p>
    </section>

    <p class="meta-foot">
      元数据如实展示；未登记项写「未登记」，不填 0。指标单位与分级阈值以成果元数据为准。
    </p>
  </aside>
</template>

<style scoped>
.metadata {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  height: 100%;
  min-height: 0;
  overflow-y: auto;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.meta-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
}

.meta-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  overflow-wrap: anywhere;
}

.meta-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.meta-note.is-warn {
  padding: var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
}

.meta-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  margin: 0;
  font-size: var(--font-size-caption);
}

.meta-list > div {
  display: grid;
  grid-template-columns: minmax(88px, 0.7fr) minmax(0, 1.3fr);
  gap: var(--space-2);
}

.meta-list dt {
  color: var(--color-muted);
}

.meta-list dd {
  margin: 0;
  overflow-wrap: anywhere;
}

.meta-block {
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
}

.block-title {
  margin: 0 0 var(--space-2);
  font-size: var(--font-size-body);
}

.field-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.field-table th,
.field-table td {
  padding: var(--space-1) var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  vertical-align: top;
}

.field-table thead th {
  color: var(--color-muted);
}

.field-key {
  display: block;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.meta-foot {
  margin: auto 0 0;
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.btn--small {
  min-height: 28px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
