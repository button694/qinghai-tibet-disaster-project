<script setup lang="ts">
/**
 * 地图图例（03 §5-4）。
 *
 * 图例只描述**当前图层树里勾选显示的、且是可渲染的**图层，且内容来自注册表的 legendId，
 * 由 Repository 读取，不在前端另造一套分级方案。
 *
 * 两条语义必须保持：
 * - 图例是可选的（`分类` / `分级` / `连续`）与图层几何类型无关，点图层也可能有分级图例；
 * - 数据不足必须有文字或纹理，本组件用斜线纹理 + 文字同时表达（01 §4.2、D-030）。
 *
 * 修复（`legend === null` 分支）：库内没有图例登记表，`legendId` 一律为空，此前这里对
 * 每个图层都只输出同一句占位文字——这正是「不同图层图例都相同」的直接原因。
 * 现在改为用 `@/config/mapStyle` 里驱动地图渲染的同一套函数（`riskColorField` /
 * `categoricalColorField` / `THEME_COLOR` / `pointShapeFor`）计算「当前地图实际使用的符号」，
 * 保证图例与渲染规则不漂移；分类取值原样显示源数据文字，不改写、不发明等级名。
 */
import { computed } from 'vue'

import {
  categoricalColorField,
  isBackgroundPolygon,
  MAP_COLORS,
  pointShapeFor,
  riskColorField,
  THEME_COLOR,
  type PointShapeKind,
} from '@/config/mapStyle'
import { formatNumber, NOT_PROVIDED_TEXT } from '@/domain/format'
import { LEGEND_KIND_LABEL, THEME_LABEL } from '@/domain/labels'
import { GRADED_RISK_LEVELS, RISK_LEVEL_COLOR, RISK_LEVEL_LABEL } from '@/domain/risk'
import type { LayerDefinition, Legend } from '@/domain/types'

const props = defineProps<{
  entries: Array<{ layer: LayerDefinition; legend: Legend | null; note: string | null }>
}>()

/** 「当前地图实际使用的符号」：分级项（图例列出每个取值）或单一主题符号，二者取一。 */
interface RenderedSymbol {
  shape: PointShapeKind | null
  /** 该图层是否按线宽编码尺寸（`roadGrade`）；点图层的尺寸编码是符号半径，走 `shape` 缩放。 */
  isLine: boolean
  items: Array<{ label: string; color: string; size?: number }>
  /** 只有分级项才有「数据不足」对应行；单一主题符号本身已经是固定颜色，不存在数据不足。 */
  insufficientColor: string | null
}

function renderedSymbol(layer: LayerDefinition): RenderedSymbol {
  const shape = layer.geometryType === 'Point' ? pointShapeFor(layer) : null
  const isLine = layer.geometryType === 'LineString'

  const riskField = riskColorField(layer)
  if (riskField !== null) {
    return {
      shape,
      isLine,
      items: GRADED_RISK_LEVELS.map((level) => ({
        label: RISK_LEVEL_LABEL[level],
        color: RISK_LEVEL_COLOR[level],
      })),
      insufficientColor: RISK_LEVEL_COLOR.insufficient,
    }
  }

  const categorical = categoricalColorField(layer)
  if (categorical !== null) {
    return {
      shape,
      isLine,
      // 尺寸编码随图例一起显示：点图层的 size 是符号半径、线图层的 size 是线宽，
      // 与 mapStyle.ts 里 createLayerStyleFunction 实际喂给地图渲染的值同源，
      // 保证「图例色块大小」与「地图上符号/线条粗细」不会对不上。
      items: categorical.values.map((entry) => ({ label: entry.value, color: entry.color, size: entry.size })),
      insufficientColor: RISK_LEVEL_COLOR.insufficient,
    }
  }

  // 背景面图层（如研究区范围）用地图底色平铺，不是「数据不足」，图例应如实标注为背景参考，
  // 不能落回 insufficient 灰——那会让人误以为这一层缺数据。
  if (isBackgroundPolygon(layer)) {
    return {
      shape,
      isLine,
      items: [{ label: '背景参考图层（地图底色，非数据分级）', color: MAP_COLORS.background }],
      insufficientColor: null,
    }
  }

  return {
    shape,
    isLine,
    items: [{ label: THEME_LABEL[layer.theme], color: THEME_COLOR[layer.theme] }],
    insufficientColor: null,
  }
}

/** 形状→CSS 类名；线/面图层没有形状，落回默认的圆角方块样式。 */
function shapeClass(shape: PointShapeKind | null): string {
  return shape === null ? '' : `shape-${shape}`
}

/**
 * 图例色块的尺寸样式：把 `size`（点半径 / 线宽，单位与地图渲染一致）换算成可辨的 CSS 像素，
 * 让图例色块的大小差异与地图上符号/线条的大小差异保持同一方向，不会「图例三个方块一样大，
 * 地图上却是三种大小」（返工要求）。未登记尺寸的条目（风险等级、主题色、背景参考）保持
 * 默认 14px 方块，不受影响。
 */
function swatchSizeStyle(size: number | undefined, isLine: boolean): Record<string, string> {
  if (size === undefined) return {}
  if (isLine) {
    // 线图层：宽度固定，用高度（越粗的线段落成越高的色块）体现线宽差异。
    const height = Math.round(6 + size * 2.2)
    return { width: '22px', height: `${height}px`, borderRadius: '2px' }
  }
  // 点图层：符号半径按比例放大整个方块（含形状 clip-path），与地图上的点半径缩放规则一致。
  const px = Math.round(10 + size * 1.6)
  return { width: `${px}px`, height: `${px}px` }
}

const enrichedEntries = computed(() =>
  props.entries.map((entry) => ({
    ...entry,
    symbol: entry.legend === null ? renderedSymbol(entry.layer) : null,
  })),
)

/**
 * 条目区间文案。
 *
 * 分类图例（categorical）本来就没有数值区间，写「区间未登记」会让人误以为缺数据；
 * 因此只有在确实存在上下限时才显示区间。
 */
function itemRangeText(
  kind: Legend['kind'],
  min: number | null,
  max: number | null,
  unit: string | null,
): string {
  if (kind === 'categorical') return ''
  if (min === null && max === null) return ''
  return rangeText(min, max, unit)
}

function rangeText(min: number | null, max: number | null, unit: string | null): string {
  const left = min === null ? '未登记' : formatNumber(min)
  const right = max === null ? '未登记' : formatNumber(max)
  const suffix = unit === null ? '' : ` ${unit}`
  return `${left} — ${right}${suffix}`
}

function rangeSummary(legend: Legend): string {
  if (legend.kind === 'categorical') return '分类图例，无数值区间'
  if (legend.range === null) return '范围未登记'
  return `范围 ${rangeText(legend.range.min, legend.range.max, legend.unit)}`
}
</script>

<template>
  <section class="legend" data-testid="map-legend" aria-label="地图图例">
    <h2 class="legend-title">地图图例</h2>
    <p class="legend-note">
      只显示已勾选且可渲染的图层；图层若有接口注册表登记的图例则按登记内容显示，未登记的图层显示地图当前实际使用的渲染规则——两种情况都不在前端另建分级方案，分类取值均原样来自数据本身。
    </p>

    <p v-if="entries.length === 0" class="legend-empty" role="status">
      当前没有可显示图例的图层：请在图层面板中勾选可渲染图层，或该模式尚未加载图例。
    </p>

    <article v-for="entry in enrichedEntries" :key="entry.layer.id" class="legend-group">
      <header class="group-head">
        <h3 class="group-title">{{ entry.layer.label }}</h3>
        <span class="group-theme">{{ THEME_LABEL[entry.layer.theme] }}</span>
      </header>

      <template v-if="entry.legend === null && entry.symbol">
        <p class="group-note" role="note">
          库内暂无该图层的图例登记记录（接口未返回图例定义）；以下是当前地图实际使用的渲染规则，
          不是数据库登记的分级方案。
        </p>
        <ul class="legend-items">
          <li v-for="item in entry.symbol.items" :key="item.label" class="legend-item">
            <span
              class="swatch"
              :class="shapeClass(entry.symbol.shape)"
              :style="{ background: item.color, ...swatchSizeStyle(item.size, entry.symbol.isLine) }"
              aria-hidden="true"
            ></span>
            <span class="item-label">{{ item.label }}</span>
            <span class="item-range"></span>
          </li>
          <li v-if="entry.symbol.insufficientColor" class="legend-item is-nodata">
            <span
              class="swatch is-hatch"
              :class="shapeClass(entry.symbol.shape)"
              :style="{ backgroundColor: entry.symbol.insufficientColor }"
              aria-hidden="true"
            ></span>
            <span class="item-label">数据不足</span>
            <span class="item-range">斜线纹理</span>
          </li>
        </ul>
        <p v-if="entry.note" class="group-note" role="note">{{ entry.note }}</p>
      </template>

      <template v-else-if="entry.legend">
        <p class="group-meta">
          {{ LEGEND_KIND_LABEL[entry.legend.kind] }} · 单位
          {{ entry.legend.unit ?? NOT_PROVIDED_TEXT }} · {{ rangeSummary(entry.legend) }} · 分级版本
          {{ entry.legend.classificationVersion ?? NOT_PROVIDED_TEXT }}
        </p>
        <ul class="legend-items">
          <li v-for="item in entry.legend.items" :key="item.code" class="legend-item">
            <span class="swatch" :style="{ background: item.color }" aria-hidden="true"></span>
            <span class="item-label">{{ item.label }}</span>
            <span class="item-range">
              {{ itemRangeText(entry.legend.kind, item.min, item.max, entry.legend.unit) }}
            </span>
          </li>
          <li class="legend-item is-nodata">
            <span
              class="swatch is-hatch"
              :style="{ backgroundColor: entry.legend.noDataStyle.color }"
              aria-hidden="true"
            ></span>
            <span class="item-label">{{ entry.legend.noDataStyle.label }}</span>
            <span class="item-range">
              {{ entry.legend.noDataStyle.pattern === 'hatch' ? '斜线纹理' : '无纹理' }}
            </span>
          </li>
        </ul>
        <p v-if="entry.note" class="group-note" role="note">{{ entry.note }}</p>
      </template>
    </article>

    <p class="legend-foot">
      图例颜色用于区分数据，不代表发生概率；单位未登记时只显示数值，不做换算。
    </p>
  </section>
</template>

<style scoped>
.legend {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  max-height: 100%;
  overflow-y: auto;
}

.legend-title {
  margin: 0;
  font-size: var(--font-size-body);
}

.legend-note,
.legend-foot {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.legend-empty {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.legend-group {
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
}

.group-head {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
}

.group-title {
  margin: 0;
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.group-theme {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.group-meta,
.group-note {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.legend-items {
  margin: var(--space-1) 0 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.legend-item {
  display: grid;
  /* 尺寸编码（返工新增）让色块最大能到约 23px（点）/ 15px 高（线），列宽按最大尺寸留够空间，
     小尺寸色块在列内居左对齐，不会因为列变宽而让不同档位看起来一样大。 */
  grid-template-columns: 24px minmax(0, 1fr) auto;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--font-size-caption);
}

.swatch {
  width: 14px;
  height: 14px;
  border: 1px solid var(--color-border);
  border-radius: 3px;
  justify-self: start;
}

/* 点图层的形状区分（01 §4.2：不能只靠颜色区分）；圆形之外的形状用 clip-path 裁出轮廓。 */
.swatch.shape-circle {
  border-radius: 50%;
}

.swatch.shape-triangle {
  border-radius: 0;
  clip-path: polygon(50% 0%, 0% 100%, 100% 100%);
}

.swatch.shape-square {
  border-radius: 0;
}

.swatch.shape-diamond {
  border-radius: 0;
  clip-path: polygon(50% 0%, 100% 50%, 50% 100%, 0% 50%);
}

.swatch.shape-star {
  border-radius: 0;
  clip-path: polygon(
    50% 0%,
    61% 35%,
    98% 35%,
    68% 57%,
    79% 91%,
    50% 70%,
    21% 91%,
    32% 57%,
    2% 35%,
    39% 35%
  );
}

.swatch.is-hatch {
  background-image: repeating-linear-gradient(
    45deg,
    var(--color-surface) 0,
    var(--color-surface) 1px,
    transparent 1px,
    transparent var(--risk-hatch-size)
  );
}

.item-range {
  color: var(--color-muted);
  font-variant-numeric: tabular-nums;
  white-space: nowrap;
}

.legend-foot {
  margin-top: auto;
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
}
</style>
