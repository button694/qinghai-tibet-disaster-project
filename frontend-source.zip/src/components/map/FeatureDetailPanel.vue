<script setup lang="ts">
/**
 * 对象详情面板（03 §5-4、§5-5）。
 *
 * 三条诚实规则：
 * 1. **无几何记录**：属性照常显示，定位按钮禁用并写明原因，不提供「假装定位到某处」；
 * 2. **字段显示**：只在字段字典里声明过的字段按标签/单位/代码字典显示，
 *    数据包里多出来的原始键单独列在「未登记字段」下原样展示，不隐藏也不猜含义；
 * 3. **示例身份**：面板底部始终保留示例数据说明（D-016），导出与截图同理。
 */
import { computed } from 'vue'

import RiskBadge from '@/components/ui/RiskBadge.vue'
import { riskColorField } from '@/config/mapStyle'
import { formatCount, formatFieldValue, formatId, NOT_PROVIDED_TEXT } from '@/domain/format'
import { GEOMETRY_FAMILY_LABEL } from '@/domain/labels'
import { toRiskLevel } from '@/domain/risk'
import type {
  DictionaryItem,
  FeatureDetail,
  FieldDefinition,
  LayerDefinition,
} from '@/domain/types'

const props = defineProps<{
  detail: FeatureDetail | null
  layer: LayerDefinition | null
  /** 按 dictionaryId 组织的代码字典条目，用于把 enum 代码显示成中文。 */
  dictionaries: Record<string, DictionaryItem[]>
  /** 字典读取失败的说明，照实显示。 */
  dictionaryNotes: string[]
  /** 是否可定位（无几何记录为 false）。 */
  canLocate: boolean
  /** 不可定位时的原因说明。 */
  locateNote: string | null
}>()

const emit = defineEmits<{
  locate: []
  close: []
}>()

const declaredKeys = computed(() => new Set((props.layer?.fields ?? []).map((field) => field.key)))

/** 把字典条目转成 `formatFieldValue` 需要的 code → label 映射。 */
function dictionaryMapFor(field: FieldDefinition): Record<string, string> | undefined {
  if (field.dictionaryId === undefined) return undefined
  const items = props.dictionaries[field.dictionaryId]
  if (items === undefined) return undefined
  const map: Record<string, string> = {}
  for (const item of items) map[item.code] = item.label
  return map
}

const declaredRows = computed(() => {
  const detail = props.detail
  if (!detail || !props.layer) return []
  return props.layer.fields
    .filter((field) => field.key in detail.properties)
    .map((field) => {
      const dictionary = dictionaryMapFor(field)
      return {
        key: field.key,
        label: field.label,
        value: formatFieldValue(
          field,
          detail.properties[field.key],
          dictionary === undefined ? {} : { dictionary },
        ),
        dictionaryId: field.dictionaryId ?? null,
        resolved: dictionary !== undefined,
      }
    })
})

/** 数据包里出现、但字段字典没有登记的键：原样展示，不隐藏也不猜含义。 */
const undeclaredRows = computed(() => {
  const detail = props.detail
  if (!detail) return []
  return Object.entries(detail.properties)
    .filter(([key]) => !declaredKeys.value.has(key))
    .map(([key, value]) => ({
      key,
      label: key,
      value: value === null ? NOT_PROVIDED_TEXT : String(value),
    }))
})

const geometryLabel = computed(() => {
  if (props.detail === null) return NOT_PROVIDED_TEXT
  if (props.detail.geometry === null) return '无几何（属性可查，不可定位）'
  return GEOMETRY_FAMILY_LABEL[familyOfType(props.detail.geometry.type)]
})

function familyOfType(type: string): 'Point' | 'LineString' | 'Polygon' {
  if (type.includes('Point')) return 'Point'
  if (type.includes('LineString')) return 'LineString'
  return 'Polygon'
}

const multiPartText = computed(() => {
  const type = props.detail?.geometry?.type
  if (type === undefined) return null
  if (type === 'MultiPoint') return '多部件点记录（MultiPoint），地图按多部件渲染。'
  if (type === 'MultiLineString') return '多部件线记录（MultiLineString），地图按多部件渲染。'
  if (type === 'MultiPolygon') return '多部件面记录（MultiPolygon），地图按多部件渲染。'
  return null
})

const geometryNote = computed(() => {
  if (props.detail === null) return null
  if (props.detail.geometry === null) {
    return '该记录无几何：属性可查，定位不可用；地图上不会出现该对象，也不为其补造坐标。'
  }
  return multiPartText.value
})

const riskLevel = computed(() => {
  if (!props.detail || !props.layer) return null
  const field = riskColorField(props.layer)
  if (field === null) return null
  const value = props.detail.properties[field]
  return typeof value === 'string' ? toRiskLevel(value) : null
})
</script>

<template>
  <aside class="detail" data-testid="feature-detail" aria-label="对象详情">
    <template v-if="detail">
      <header class="detail-head">
        <h2 class="detail-title" data-testid="detail-title">{{ detail.title }}</h2>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          aria-label="关闭对象详情"
          data-testid="detail-close"
          @click="emit('close')"
        >
          关闭
        </button>
      </header>

      <dl class="detail-facts">
        <div>
          <dt>所属图层</dt>
          <dd data-testid="detail-layer">{{ layer ? layer.label : detail.ref.layerId }}</dd>
        </div>
        <div>
          <dt>图层 ID</dt>
          <dd>{{ detail.ref.layerId }}</dd>
        </div>
        <div>
          <dt>对象 ID</dt>
          <dd>{{ formatId(detail.ref.id) }}</dd>
        </div>
        <div>
          <dt>几何类型</dt>
          <dd>{{ geometryLabel }}</dd>
        </div>
        <div v-if="detail.entityKey">
          <dt>业务对象标识</dt>
          <dd>{{ detail.entityKey }}</dd>
        </div>
        <div v-if="riskLevel">
          <dt>自带风险等级</dt>
          <dd><RiskBadge :level="riskLevel" /></dd>
        </div>
      </dl>

      <p v-if="geometryNote" class="detail-note" data-testid="detail-geometry-note">
        {{ geometryNote }}
      </p>

      <div class="detail-actions">
        <button
          type="button"
          class="btn btn--small"
          :disabled="!canLocate"
          :title="canLocate ? '把地图定位到该对象' : (locateNote ?? '不可定位')"
          data-testid="detail-locate"
          @click="emit('locate')"
        >
          在地图上定位
        </button>
        <span
          v-if="!canLocate && locateNote"
          class="action-reason"
          data-testid="detail-locate-note"
        >
          {{ locateNote }}
        </span>
      </div>

      <section class="detail-block">
        <h3 class="block-title">属性（字段字典已登记）</h3>
        <dl class="prop-list" data-testid="detail-properties">
          <div v-for="row in declaredRows" :key="row.key" class="prop-row">
            <dt>{{ row.label }}</dt>
            <dd>
              <span class="prop-value">{{ row.value }}</span>
              <span v-if="row.dictionaryId" class="prop-dict">
                字典 {{ row.dictionaryId }}{{ row.resolved ? '' : '（未解析，显示原始代码）' }}
              </span>
            </dd>
          </div>
        </dl>
        <p v-if="declaredRows.length === 0" class="detail-note">
          该记录没有任何字段在字段字典中登记。
        </p>
      </section>

      <section v-if="undeclaredRows.length > 0" class="detail-block">
        <h3 class="block-title">未登记字段（原样显示）</h3>
        <dl class="prop-list">
          <div v-for="row in undeclaredRows" :key="row.key" class="prop-row">
            <dt>{{ row.label }}</dt>
            <dd>
              <span class="prop-value">{{ row.value }}</span>
            </dd>
          </div>
        </dl>
      </section>

      <p v-if="dictionaryNotes.length > 0" class="detail-note" role="note">
        {{ dictionaryNotes.join(' ') }}
      </p>

      <section class="detail-block">
        <h3 class="block-title">关联成果</h3>
        <p class="detail-note" data-testid="detail-related">
          {{
            detail.relatedResultIds.length === 0
              ? '该对象未关联任何已存成果；不做推测性关联。'
              : `关联 ${formatCount(detail.relatedResultIds.length)} 项已存成果：${detail.relatedResultIds.join('、')}`
          }}
        </p>
      </section>

      <p class="detail-foot">
        当前为示例数据（合成样本），不代表真实入库成果；2050 / 2100 为未来情景，不是实时预警。
      </p>
    </template>

    <p v-else class="detail-empty" role="status">
      尚未选中对象。在地图上点选一个要素，或在对象列表中选择一行。
    </p>
  </aside>
</template>

<style scoped>
.detail {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.detail-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-2);
}

.detail-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  overflow-wrap: anywhere;
}

.detail-facts {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
  gap: var(--space-1);
  margin: 0;
  font-size: var(--font-size-caption);
}

.detail-facts > div {
  display: grid;
  grid-template-columns: minmax(84px, 0.6fr) minmax(0, 1.4fr);
  gap: var(--space-2);
}

.detail-facts dt {
  color: var(--color-muted);
}

.detail-facts dd {
  margin: 0;
  overflow-wrap: anywhere;
}

.detail-note {
  margin: 0;
  padding: var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-info-surface);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.detail-actions {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.action-reason {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.detail-block {
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
}

.block-title {
  margin: 0 0 var(--space-2);
  font-size: var(--font-size-body);
}

.prop-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  margin: 0;
  font-size: var(--font-size-caption);
}

.prop-row {
  display: grid;
  grid-template-columns: minmax(96px, 0.8fr) minmax(0, 1.2fr);
  gap: var(--space-2);
  padding-bottom: var(--space-1);
  border-bottom: 1px dashed var(--color-border);
}

.prop-row dt {
  color: var(--color-muted);
}

.prop-row dd {
  margin: 0;
  display: flex;
  align-items: baseline;
  gap: var(--space-1);
  flex-wrap: wrap;
  overflow-wrap: anywhere;
}

.prop-value {
  font-variant-numeric: tabular-nums;
}

.prop-unit,
.prop-dict {
  color: var(--color-muted);
}

.detail-empty {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.detail-foot {
  margin: auto 0 0;
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.btn--small {
  min-height: 28px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
