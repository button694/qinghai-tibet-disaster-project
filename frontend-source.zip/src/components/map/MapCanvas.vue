<script setup lang="ts">
/**
 * 交互地图画布（03 §5-1、§5-4、§5-6）。
 *
 * 生命周期规则（本组件的核心职责）：
 * 1. OpenLayers 实例、矢量源与图层只保存在组件内的普通变量里，不进 Pinia、不做深度响应式；
 * 2. 事件监听在 `onMounted` 里只注册一次，并在 `onBeforeUnmount` 里逐条 `un` 后
 *    `setTarget(undefined)` + `dispose()`，同时把生命周期计数减回 0（`services/mapLifecycle`）；
 * 3. 容器尺寸变化由 `useElementResize` 监听并调用 `updateSize()`，面板开合与窗口缩放后
 *    地图不会被拉伸成黑边；
 * 4. 对外只暴露方法：数据灌入、缩放/复位/定位、尺寸刷新、读取「实际渲染状态」。
 *
 * 断网可用：几何一律来自本地数据包（经 Repository），不加载任何在线底图，
 * 因此断网时示例几何照常可浏览（03 §5-2）。
 */
import 'ol/ol.css'
import Feature from 'ol/Feature'
import type { FeatureLike } from 'ol/Feature'
import OlMap from 'ol/Map'
import type MapBrowserEvent from 'ol/MapBrowserEvent'
import { unByKey } from 'ol/Observable'
import View from 'ol/View'
import { ScaleLine, defaults as defaultControls } from 'ol/control'
import type { EventsKey } from 'ol/events'
import type { Extent } from 'ol/extent'
import GeoJSON from 'ol/format/GeoJSON'
import type Geometry from 'ol/geom/Geometry'
import DragBox from 'ol/interaction/DragBox'
import DragPan from 'ol/interaction/DragPan'
import Draw from 'ol/interaction/Draw'
import VectorLayer from 'ol/layer/Vector'
import { fromLonLat, toLonLat } from 'ol/proj'
import VectorSource from 'ol/source/Vector'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { featureKey } from '@/domain/format'
import type { FeatureDetail, FeatureRef, LonLat } from '@/domain/types'
import type { Geometry as GeoJsonGeometry } from 'geojson'
import { useElementResize } from '@/composables/useElementResize'
import {
  createLayerStyleFunction,
  queryHitStyles,
  selectionStyles,
  spatialAreaStyle,
} from '@/config/mapStyle'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  mapLifecycleCounts,
  registerMapInstance,
  registerMapListeners,
  unregisterMapInstance,
} from '@/services/mapLifecycle'
import type { CanvasLayerState, MapRenderState, RenderLayerState } from '@/services/mapRenderState'

type VectorSource3857 = VectorSource<Feature<Geometry>>

function createSource(): VectorSource3857 {
  return new VectorSource<Feature<Geometry>>()
}

/** 绘制模式：`box` 拉框、`polygon` 点选成面；二者与点选互斥（03 §6-3）。 */
export type DrawMode = 'none' | 'box' | 'polygon'

const props = defineProps<{
  /** 按图层树顺序（index 0 在最上层）传入的图层状态。 */
  layerStates: CanvasLayerState[]
  /** 当前选中的要素全局键 `layerId:id`；null 表示无选中。 */
  selectedKey: string | null
  /** 绘制模式。非 `none` 时点选被禁用，Esc 取消绘制。 */
  drawMode: DrawMode
  /** 空间查询范围（EPSG:4326）；null 表示不显示。 */
  spatialGeometry: GeoJsonGeometry | null
  /** 查询命中集合（本页）：以覆盖层高亮，与「选中」不同色。 */
  queryRefs: FeatureRef[]
}>()

const emit = defineEmits<{
  /** 点选结果；未命中任何要素时为 null。 */
  select: [payload: { layerId: string; featureId: string } | null]
  /** 鼠标经纬度；移出画布为 null。 */
  pointerMove: [position: LonLat | null]
  /** 视图缩放级别变化（用于状态栏）。 */
  zoomChange: [zoom: number]
  /** 从 OpenLayers 对象本身读出的实际渲染状态。 */
  renderState: [state: MapRenderState]
  /** 绘制完成：给出 EPSG:4326 的多边形几何。 */
  drawComplete: [geometry: GeoJsonGeometry]
  /** 绘制被取消（Esc）。 */
  drawCancel: []
}>()

const host = ref<HTMLElement | null>(null)
const hint = ref('')

interface Entry {
  layer: VectorLayer<VectorSource3857>
  source: VectorSource3857
}

/* ---- OpenLayers 对象：普通变量，非响应式 ---- */
let map: OlMap | null = null
let highlightLayer: VectorLayer<VectorSource3857> | null = null
/** 阶段3：绘制范围与查询命中各用一个覆盖层，不混进数据图层。 */
let spatialLayer: VectorLayer<VectorSource3857> | null = null
let queryLayer: VectorLayer<VectorSource3857> | null = null
let dragBox: DragBox | null = null
let drawPolygon: Draw | null = null
let escHandler: ((event: KeyboardEvent) => void) | null = null
const entries = new Map<string, Entry>()
/** 注册过的监听键：注销用 `unByKey`，避免按类型字符串猜测重载。 */
const handlerKeys: EventsKey[] = []
const stopHandlers: Array<() => void> = []
let disposed = false

const defaultCenter = fromLonLat([91.2, 30.2])
const defaultZoom = 6

/* ------------------------------------------------------------------ *
 * 状态回传（只读 OL，不改 OL）
 * ------------------------------------------------------------------ */

function currentRenderState(): MapRenderState {
  const layers: RenderLayerState[] = props.layerStates.map((state) => {
    const entry = entries.get(state.definition.id)
    return {
      layerId: state.definition.id,
      visible: entry ? entry.layer.getVisible() : false,
      opacity: entry ? entry.layer.getOpacity() : state.opacity,
      zIndex: entry ? (entry.layer.getZIndex() ?? 0) : 0,
      featureCount: entry ? entry.source.getFeatures().length : 0,
    }
  })
  const counts = mapLifecycleCounts()
  return {
    layers,
    visibleLayerCount: layers.filter((layer) => layer.visible && layer.featureCount > 0).length,
    renderedFeatureCount: layers.reduce((sum, layer) => sum + layer.featureCount, 0),
    mapInstances: counts.mapInstances,
    listeners: counts.listeners,
    zoom: map ? Math.round((map.getView().getZoom() ?? defaultZoom) * 100) / 100 : 0,
  }
}

function publish(): void {
  if (disposed) return
  emit('renderState', currentRenderState())
}

/* ------------------------------------------------------------------ *
 * 图层
 * ------------------------------------------------------------------ */

function zIndexFor(layerId: string): number {
  const index = props.layerStates.findIndex((state) => state.definition.id === layerId)
  if (index < 0) return 0
  // 数组首位在最上层：总数减下标，保证「上移」在视觉上真的往上。
  return (props.layerStates.length - index) * 10
}

function ensureEntry(state: CanvasLayerState): Entry | null {
  if (!state.renderable) return null
  const existing = entries.get(state.definition.id)
  if (existing) return existing
  const source = createSource()
  const layer = new VectorLayer<VectorSource3857>({
    source,
    visible: state.visible,
    opacity: state.opacity,
    zIndex: zIndexFor(state.definition.id),
    style: createLayerStyleFunction(state.definition),
  })
  entries.set(state.definition.id, { layer, source })
  map?.addLayer(layer)
  return { layer, source }
}

/** 把某图层的要素灌入地图；几何由调用方通过 Repository 取回。 */
function applyLayerData(
  layerId: string,
  features: FeatureDetail[],
): { rendered: number; skipped: number } {
  const state = props.layerStates.find((item) => item.definition.id === layerId)
  if (!state) return { rendered: 0, skipped: 0 }
  const entry = ensureEntry(state)
  if (!entry) return { rendered: 0, skipped: 0 }
  const { features: olFeatures, skipped } = toOlFeatures(features)
  entry.source.clear()
  entry.source.addFeatures(olFeatures)
  publish()
  // `skipped` 是无几何记录的条数：它们不上图，但必须在列表里可查、可解释。
  return { rendered: olFeatures.length, skipped }
}

function clearLayerData(layerId: string): void {
  entries.get(layerId)?.source.clear()
  publish()
}

function syncLayerState(): void {
  for (const state of props.layerStates) {
    const entry = entries.get(state.definition.id)
    if (!entry) continue
    entry.layer.setVisible(state.visible)
    entry.layer.setOpacity(state.opacity)
    entry.layer.setZIndex(zIndexFor(state.definition.id))
  }
  syncHighlight()
}

/* ------------------------------------------------------------------ *
 * 阶段3：绘制、空间范围与命中覆盖层
 * ------------------------------------------------------------------ */

const reader = new GeoJSON()

/** EPSG:3857 几何 → EPSG:4326 的 GeoJSON 几何对象（与契约坐标顺序一致）。 */
function toGeoJsonGeometry(geometry: Geometry): GeoJsonGeometry | null {
  try {
    return reader.writeGeometryObject(geometry, {
      featureProjection: 'EPSG:3857',
      dataProjection: 'EPSG:4326',
    }) as GeoJsonGeometry
  } catch {
    return null
  }
}

function toOlGeometry(geometry: GeoJsonGeometry): Geometry | null {
  try {
    return reader.readGeometry(geometry, {
      dataProjection: 'EPSG:4326',
      featureProjection: 'EPSG:3857',
    })
  } catch {
    return null
  }
}

/** 绘制中的范围（橙色虚线）；绘制完成与行政区选择都走这里。 */
function applySpatialGeometry(geometry: GeoJsonGeometry | null): void {
  const source = spatialLayer?.getSource()
  if (!source) return
  source.clear()
  if (geometry === null) return
  const olGeometry = toOlGeometry(geometry)
  if (olGeometry) source.addFeature(new Feature({ geometry: olGeometry }))
}

/**
 * 查询命中集合：从各数据图层里按全局键取出要素并克隆到覆盖层。
 *
 * 只取本页（`queryRefs` 已由分页限制），避免一次把成千上万条要素塞进覆盖层；
 * 命中总数由结果表单独显示，不靠地图上的点数推导。
 */
function applyQueryHits(refs: FeatureRef[]): void {
  const source = queryLayer?.getSource()
  if (!source) return
  source.clear()
  for (const ref of refs) {
    const entry = entries.get(ref.layerId)
    if (!entry) continue
    const feature = entry.source.getFeatureById(featureKey(ref.layerId, ref.id))
    if (feature) source.addFeature(feature.clone())
  }
}

/** 绘制期间禁用拖拽平移：否则拉框与平移会同时响应，框选无法完成。 */
function setPanEnabled(enabled: boolean): void {
  if (!map) return
  for (const interaction of map.getInteractions().getArray()) {
    if (interaction instanceof DragPan) interaction.setActive(enabled)
  }
}

function removeDrawInteractions(): void {
  if (dragBox && map) {
    map.removeInteraction(dragBox)
    dragBox = null
  }
  if (drawPolygon && map) {
    map.removeInteraction(drawPolygon)
    drawPolygon = null
  }
  if (escHandler !== null) {
    document.removeEventListener('keydown', escHandler)
    escHandler = null
  }
  setPanEnabled(true)
}

/**
 * 切换绘制模式。
 *
 * 三条规则（03 §6-3）：
 * 1. 绘制与点选互斥——绘制期间 `singleclick` 直接返回，不会产生选中；
 * 2. Esc 取消：监听挂在 document 上，绘制时才注册、退出时注销，不留悬挂监听；
 * 3. 一次只激活一种绘制方式，切换时先清干净的再装新的。
 */
function setDrawMode(mode: DrawMode): void {
  if (!map) return
  removeDrawInteractions()
  if (mode === 'none') return

  setPanEnabled(false)
  escHandler = (event: KeyboardEvent): void => {
    if (event.key !== 'Escape') return
    removeDrawInteractions()
    emit('drawCancel')
    hint.value = '已取消绘制，未产生空间范围。'
    publish()
  }
  document.addEventListener('keydown', escHandler)

  if (mode === 'box') {
    dragBox = new DragBox({ className: 'ol-dragbox' })
    dragBox.on('boxend', () => {
      const geometry = dragBox?.getGeometry()
      removeDrawInteractions()
      if (geometry) {
        const geoJson = toGeoJsonGeometry(geometry)
        if (geoJson) {
          emit('drawComplete', geoJson)
          return
        }
      }
      hint.value = '框选范围无法解析为多边形，请重新框选。'
      publish()
    })
    map.addInteraction(dragBox)
    hint.value = '在地图上按住左键拖出一个矩形；Esc 取消。'
    publish()
    return
  }

  drawPolygon = new Draw({ type: 'Polygon' })
  drawPolygon.on('drawend', (event: { feature: Feature<Geometry> }) => {
    const geometry = event.feature.getGeometry()
    removeDrawInteractions()
    if (geometry) {
      const geoJson = toGeoJsonGeometry(geometry)
      if (geoJson) {
        emit('drawComplete', geoJson)
        return
      }
    }
    hint.value = '多边形无法解析，请重新绘制。'
    publish()
  })
  map.addInteraction(drawPolygon)
  hint.value = '逐个点选顶点画多边形，双击结束；Esc 取消。'
  publish()
}

/* ------------------------------------------------------------------ *
 * 选中高亮：只使用焦点色，与风险等级配色分开（01 §4.2）
 * ------------------------------------------------------------------ */

function syncHighlight(): void {
  if (!highlightLayer) {
    publish()
    return
  }
  const source = highlightLayer.getSource()
  source?.clear()
  if (props.selectedKey !== null && source) {
    for (const entry of entries.values()) {
      const feature = entry.source.getFeatureById(props.selectedKey)
      if (feature) {
        source.addFeature(feature.clone())
        break
      }
    }
  }
  publish()
}

/* ------------------------------------------------------------------ *
 * 视图
 * ------------------------------------------------------------------ */

function extentOfVisible(): Extent | null {
  let extent: Extent | null = null
  for (const entry of entries.values()) {
    if (!entry.layer.getVisible() || entry.source.getFeatures().length === 0) continue
    const next = entry.source.getExtent()
    if (!next || !next.every((value) => Number.isFinite(value))) continue
    extent =
      extent === null
        ? [...next]
        : [
            Math.min(extent[0] ?? 0, next[0] ?? 0),
            Math.min(extent[1] ?? 0, next[1] ?? 0),
            Math.max(extent[2] ?? 0, next[2] ?? 0),
            Math.max(extent[3] ?? 0, next[3] ?? 0),
          ]
  }
  return extent
}

function fitExtent(extent: Extent | null, maxZoom = 11): boolean {
  if (!map || extent === null) return false
  if (!extent.every((value) => Number.isFinite(value))) return false
  if (extent[0] === extent[2] && extent[1] === extent[3]) {
    // 退化范围（单点）：直接定位，避免 fit 得到无限缩放。
    map.getView().setCenter([extent[0] ?? 0, extent[1] ?? 0])
    map.getView().setZoom(Math.min(maxZoom, 12))
  } else {
    map.getView().fit(extent, { padding: [48, 48, 48, 48], maxZoom })
  }
  publish()
  return true
}

/** 缩放；`delta > 0` 放大。 */
function zoomBy(delta: number): void {
  if (!map) return
  const view = map.getView()
  const zoom = view.getZoom() ?? defaultZoom
  view.setZoom(Math.min(15, Math.max(3, zoom + delta)))
  publish()
}

/** 复位：回到默认视野并适配当前可见图层范围。 */
function resetView(): void {
  if (!map) return
  map.getView().setCenter(defaultCenter)
  map.getView().setZoom(defaultZoom)
  fitExtent(extentOfVisible(), 9)
  publish()
}

/** 定位到某图层范围；没有已渲染要素时返回 false，界面据此说明原因。 */
function focusLayer(layerId: string): boolean {
  const entry = entries.get(layerId)
  if (!entry) return false
  return fitExtent(entry.source.getExtent(), 12)
}

/** 定位到单个要素。无几何要素不会被调用（调用方须先按 geometry === null 判断）。 */
function focusFeature(layerId: string, featureId: string): boolean {
  const entry = entries.get(layerId)
  if (!entry) return false
  const feature = entry.source.getFeatureById(featureKey(layerId, featureId))
  if (!feature) return false
  const geometry = feature.getGeometry()
  return fitExtent(geometry ? geometry.getExtent() : null, 13)
}

function updateSize(): void {
  map?.updateSize()
}

/* ------------------------------------------------------------------ *
 * 生命周期
 * ------------------------------------------------------------------ */

const KEY_ZOOM_IN = ['+', '=']
const KEY_ZOOM_OUT = ['-', '_']

function onKeydown(event: KeyboardEvent): void {
  if (KEY_ZOOM_IN.includes(event.key)) zoomBy(1)
  else if (KEY_ZOOM_OUT.includes(event.key)) zoomBy(-1)
}

onMounted(() => {
  if (!host.value) return
  map = new OlMap({
    target: host.value,
    // 不启用 OL 自带缩放按钮与旋转控件：缩放由工具栏按钮与键盘控制，避免两套交互叠加。
    controls: defaultControls({ attribution: false, rotate: false, zoom: false }).extend([
      new ScaleLine({ units: 'metric', bar: false, text: true }),
    ]),
    layers: [],
    view: new View({ center: defaultCenter, zoom: defaultZoom, minZoom: 3, maxZoom: 15 }),
  })
  registerMapInstance()

  highlightLayer = new VectorLayer<VectorSource3857>({
    source: createSource(),
    style: selectionStyles(),
    zIndex: 9999,
  })
  map.addLayer(highlightLayer)

  spatialLayer = new VectorLayer<VectorSource3857>({
    source: createSource(),
    style: spatialAreaStyle(),
    zIndex: 8000,
  })
  map.addLayer(spatialLayer)

  queryLayer = new VectorLayer<VectorSource3857>({
    source: createSource(),
    style: queryHitStyles(),
    zIndex: 8500,
  })
  map.addLayer(queryLayer)

  const onSingleClick = (event: MapBrowserEvent): void => {
    hint.value = ''
    if (!map) return
    // 绘制与点选互斥（03 §6-3）：绘制期间的点击是顶点，不是选中，直接忽略。
    if (props.drawMode !== 'none') return
    // OpenLayers 的 `getFeaturesAtPixel` 按图层**加入顺序**依次命中，而图层加入顺序取决于
    // 并发装载的完成顺序（小文件先回来），与用户看到的叠放顺序不一致。因此这里拿到全部
    // 命中后自行按真实 zIndex 取最上层的一个：所见即所点。
    const hits: FeatureLike[] = map.getFeaturesAtPixel(event.pixel, {
      hitTolerance: 7,
      layerFilter: (layer) => layer !== highlightLayer,
    })
    let topmost: { layerId: string; featureId: string; zIndex: number } | null = null
    for (const feature of hits) {
      const layerId = feature.get('__layerId')
      const featureId = feature.get('__featureId')
      if (typeof layerId !== 'string' || typeof featureId !== 'string') continue
      const entry = entries.get(layerId)
      if (!entry) continue
      const zIndex = entry.layer.getZIndex() ?? 0
      if (topmost === null || zIndex > topmost.zIndex) {
        topmost = { layerId, featureId, zIndex }
      }
    }
    if (topmost === null) {
      emit('select', null)
      hint.value = '此处没有可拾取的要素；可继续点选，或在对象列表里按名称选择记录。'
      publish()
      return
    }
    emit('select', { layerId: topmost.layerId, featureId: topmost.featureId })
  }

  const onPointerMove = (event: MapBrowserEvent): void => {
    if (!map || event.dragging) return
    const coordinate = map.getCoordinateFromPixel(event.pixel)
    const lonLat = toLonLat(coordinate)
    emit('pointerMove', [
      Math.round((lonLat[0] ?? 0) * 1e5) / 1e5,
      Math.round((lonLat[1] ?? 0) * 1e5) / 1e5,
    ])
  }

  const onMoveEnd = (): void => {
    emit('zoomChange', map ? (map.getView().getZoom() ?? defaultZoom) : defaultZoom)
    publish()
  }

  handlerKeys.push(
    map.on('singleclick', onSingleClick),
    map.on('pointermove', onPointerMove),
    map.on('moveend', onMoveEnd),
  )
  registerMapListeners(handlerKeys.length)

  // 容器尺寸变化 → updateSize；停止函数在卸载时统一调用。
  stopHandlers.push(useElementResize(host, () => updateSize()).stop)

  for (const state of props.layerStates) {
    if (state.renderable) ensureEntry(state)
  }
  syncLayerState()
})

watch(
  () => props.layerStates,
  () => {
    for (const state of props.layerStates) {
      if (state.renderable) ensureEntry(state)
    }
    syncLayerState()
  },
  { deep: true },
)

watch(
  () => props.selectedKey,
  () => syncHighlight(),
)

watch(
  () => props.drawMode,
  (next) => setDrawMode(next),
)

watch(
  () => props.spatialGeometry,
  (next) => applySpatialGeometry(next),
  { deep: true },
)

watch(
  () => props.queryRefs,
  (next) => applyQueryHits(next),
  { deep: true },
)

onBeforeUnmount(() => {
  disposed = true
  // 先卸绘制交互：它会连带注销 document 上的 Esc 监听并恢复平移，避免留下悬挂监听。
  removeDrawInteractions()
  for (const stop of stopHandlers) stop()
  stopHandlers.length = 0
  if (map) {
    const listenerCount = handlerKeys.length
    // 逐条注销本次注册的监听，再释放目标与实例：重复挂载不会累积监听。
    unByKey(handlerKeys)
    handlerKeys.length = 0
    map.setTarget(undefined)
    map.dispose()
    map = null
    // 注销实例并按本实例注册的监听数扣减：重复挂载后计数不会累积。
    unregisterMapInstance(listenerCount)
  }
  entries.clear()
  highlightLayer = null
  spatialLayer = null
  queryLayer = null
})

defineExpose({
  applyLayerData,
  clearLayerData,
  zoomBy,
  resetView,
  focusLayer,
  focusFeature,
  updateSize,
  getRenderState: currentRenderState,
})
</script>

<template>
  <div class="canvas-wrap">
    <div
      ref="host"
      class="map-canvas"
      data-testid="map-canvas"
      tabindex="0"
      role="application"
      aria-label="可缩放、可点选的示例地图；键盘 + / - 可缩放"
      @keydown="onKeydown"
    />
    <p v-if="hint" class="map-hint" role="status">{{ hint }}</p>
  </div>
</template>

<style scoped>
.canvas-wrap {
  position: relative;
  height: 100%;
  min-width: 0;
  min-height: 0;
}

.map-canvas {
  width: 100%;
  height: 100%;
  /* 不在这里给最小高度：地图行的高度由工作台的网格行（minmax(320px,1fr)）决定。
     若组件自带 min-height，行高不足时画布会溢出行、盖住下方控件并拦截其点击。 */
  min-height: 0;
  background: var(--color-map-bg);
  border-radius: var(--radius-sm);
}

.map-hint {
  position: absolute;
  left: var(--space-3);
  bottom: var(--space-3);
  max-width: 60%;
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  box-shadow: var(--shadow-panel);
}
</style>
