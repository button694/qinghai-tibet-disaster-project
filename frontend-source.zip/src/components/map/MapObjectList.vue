<script setup lang="ts">
/**
 * 对象列表（03 §5-5）。
 *
 * 地图服务按服务端分页分批取回完整要素；本组件只对 DOM 做 100 行一页的
 * 客户端分页，避免把“当前页可见行数”误当成总数。无几何记录仍可在列表中
 * 查到属性，但定位按钮保持禁用。
 */
import { computed, ref, watch } from 'vue'

import { formatCount, NOT_PROVIDED_TEXT } from '@/domain/format'
import { GEOMETRY_FAMILY_LABEL } from '@/domain/labels'
import type { FeatureDetail, FeatureRef, LayerDefinition } from '@/domain/types'
import { useMapStore } from '@/stores/map'

const props = defineProps<{
  features: FeatureDetail[]
  layer: LayerDefinition | null
  loading: boolean
  /** 服务端 COUNT 返回的源记录总数；不以 features.length 代替。 */
  serverTotal: number
  /** 地图服务是否已完整取回所有服务端分页。 */
  complete: boolean
  /** 数据加载说明（缺页、无几何、服务未接入等）。 */
  note: string | null
  /** 读取失败原因；失败时列表必须为空，不显示上一次结果。 */
  errorText: string | null
}>()

const emit = defineEmits<{
  select: [ref: FeatureRef]
  locate: [ref: FeatureRef]
}>()

type FilterKind = 'all' | 'locatable' | 'noGeometry'

const PAGE_SIZE = 100
const store = useMapStore()
const filter = ref<FilterKind>('all')
const page = ref(1)

const filteredFeatures = computed(() =>
  props.features.filter((item) => {
    if (filter.value === 'locatable') return item.geometry !== null
    if (filter.value === 'noGeometry') return item.geometry === null
    return true
  }),
)

const filteredTotal = computed(() => filteredFeatures.value.length)
const pageCount = computed(() => Math.max(1, Math.ceil(filteredTotal.value / PAGE_SIZE)))
const rows = computed(() => {
  const start = (page.value - 1) * PAGE_SIZE
  return filteredFeatures.value.slice(start, start + PAGE_SIZE)
})
const rangeStart = computed(() =>
  filteredTotal.value === 0 ? 0 : (page.value - 1) * PAGE_SIZE + 1,
)
const rangeEnd = computed(() => Math.min(filteredTotal.value, page.value * PAGE_SIZE))
const sourceTotal = computed(() =>
  props.serverTotal > 0 ? props.serverTotal : props.features.length,
)

const noGeometryCount = computed(
  () => props.features.filter((item) => item.geometry === null).length,
)

watch(filter, () => {
  page.value = 1
})
watch(
  () => [props.features.length, pageCount.value] as const,
  () => {
    if (page.value > pageCount.value) page.value = pageCount.value
  },
)

function goToPage(target: number): void {
  if (target < 1 || target > pageCount.value || target === page.value) return
  page.value = target
}

function isSelected(item: FeatureDetail): boolean {
  const selected = store.selected
  if (selected === null) return false
  return selected.ref.layerId === item.ref.layerId && selected.ref.id === item.ref.id
}

function geometryText(item: FeatureDetail): string {
  if (item.geometry === null) return '无几何'
  const type = item.geometry.type
  const family = type.includes('Point')
    ? 'Point'
    : type.includes('LineString')
      ? 'LineString'
      : 'Polygon'
  return type.startsWith('Multi')
    ? `${GEOMETRY_FAMILY_LABEL[family]}（多部件）`
    : GEOMETRY_FAMILY_LABEL[family]
}
</script>

<template>
  <section class="object-list" data-testid="object-list" aria-label="对象列表">
    <header class="list-head">
      <h2 class="list-title">
        对象列表
        <span class="list-layer" data-testid="object-list-layer">
          {{ layer ? layer.label : NOT_PROVIDED_TEXT }}
        </span>
      </h2>
      <label class="list-filter">
        <span>筛选</span>
        <select v-model="filter" aria-label="对象列表筛选" data-testid="object-list-filter">
          <option value="all">全部记录</option>
          <option value="locatable">仅可定位记录</option>
          <option value="noGeometry">仅无几何记录</option>
        </select>
      </label>
      <span class="list-count" data-testid="object-list-count">
        已加载/去重 {{ formatCount(features.length) }} 条 · 源数据共
        {{ formatCount(sourceTotal) }} 条 · 当前显示 {{ formatCount(rangeStart) }}—{{
          formatCount(rangeEnd)
        }}
        条 · 其中无几何 {{ formatCount(noGeometryCount) }} 条
      </span>
    </header>

    <p v-if="loading" class="list-note" role="status">正在读取该图层要素…</p>
    <p v-else-if="errorText" class="list-error" role="alert" data-testid="object-list-error">
      {{ errorText }}
    </p>
    <p v-else-if="note" class="list-note" role="note" data-testid="object-list-note">{{ note }}</p>
    <p v-else-if="!complete" class="list-note" role="note" data-testid="object-list-incomplete">
      当前只展示已取回的记录，服务端分页尚未完整完成；请重试该图层后再作全量判断。
    </p>

    <div v-if="!loading && !errorText" class="table-wrap">
      <table class="object-table">
        <caption class="visually-hidden">
          当前图层对象列表；行点击选中并查看详情，定位按钮会把地图移动到该对象
        </caption>
        <thead>
          <tr>
            <th scope="col">名称</th>
            <th scope="col">对象 ID</th>
            <th scope="col">几何</th>
            <th scope="col">操作</th>
          </tr>
        </thead>
        <tbody>
          <tr
            v-for="item in rows"
            :key="`${item.ref.layerId}:${item.ref.id}`"
            :class="{ 'is-selected': isSelected(item) }"
            :data-testid="`object-row-${item.ref.id}`"
          >
            <td class="cell-title">
              <button type="button" class="link" @click="emit('select', item.ref)">
                {{ item.title }}
              </button>
            </td>
            <td class="cell-id">{{ item.ref.id }}</td>
            <td class="cell-geom" :class="{ 'is-none': item.geometry === null }">
              {{ geometryText(item) }}
            </td>
            <td class="cell-action">
              <button
                type="button"
                class="btn btn--ghost btn--small"
                :disabled="item.geometry === null"
                :title="item.geometry === null ? '该记录无几何，定位不可用' : '定位到该对象'"
                :data-testid="`row-locate-${item.ref.id}`"
                @click="emit('locate', item.ref)"
              >
                定位
              </button>
              <span v-if="item.geometry === null" class="cell-reason"
                >定位不可用：该记录无几何</span
              >
            </td>
          </tr>
          <tr v-if="rows.length === 0">
            <td colspan="4" class="cell-empty">
              {{ features.length === 0 ? '该图层暂无已加载记录。' : '当前筛选条件下没有记录。' }}
            </td>
          </tr>
        </tbody>
      </table>
    </div>

    <nav v-if="filteredTotal > PAGE_SIZE" class="object-pager" aria-label="对象列表分页">
      <button
        type="button"
        class="btn btn--small"
        data-testid="object-list-prev"
        :disabled="page <= 1"
        @click="goToPage(page - 1)"
      >
        上一页
      </button>
      <span data-testid="object-list-page">第 {{ page }} / {{ pageCount }} 页</span>
      <button
        type="button"
        class="btn btn--small"
        data-testid="object-list-next"
        :disabled="page >= pageCount"
        @click="goToPage(page + 1)"
      >
        下一页
      </button>
      <span class="pager-note">每页 {{ PAGE_SIZE }} 条；筛选后重新从第 1 页开始。</span>
    </nav>
  </section>
</template>

<style scoped>
.object-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.list-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.list-title {
  margin: 0;
  font-size: var(--font-size-body);
}

.list-layer {
  margin-left: var(--space-2);
  color: var(--color-muted);
  font-weight: 400;
  font-size: var(--font-size-caption);
}

.list-filter {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.list-filter select {
  height: var(--control-height);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  font: inherit;
}

.list-count {
  margin-left: auto;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.list-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.list-error {
  margin: 0;
  padding: var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-danger-surface);
  color: var(--color-danger-text);
  font-size: var(--font-size-caption);
}

.table-wrap {
  max-height: var(--result-table-height);
  overflow: auto;
}

.object-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.object-table th,
.object-table td {
  padding: var(--space-1) var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  vertical-align: top;
}

.object-table thead th {
  position: sticky;
  top: 0;
  background: var(--color-surface);
  color: var(--color-muted);
  font-weight: 600;
}

.object-table tr.is-selected {
  background: var(--color-primary-soft);
}

.cell-title {
  min-width: 140px;
}

.link {
  padding: 0;
  border: 0;
  background: none;
  color: var(--color-primary-strong);
  font: inherit;
  text-align: left;
  text-decoration: underline;
  cursor: pointer;
  overflow-wrap: anywhere;
}

.cell-id {
  font-variant-numeric: tabular-nums;
  overflow-wrap: anywhere;
}

.cell-geom.is-none {
  color: var(--color-danger-text);
}

.cell-action {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.cell-reason {
  color: var(--color-muted);
}

.cell-empty {
  color: var(--color-muted);
}

.object-pager {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.pager-note {
  margin-left: auto;
}

.btn--small {
  min-height: 26px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
