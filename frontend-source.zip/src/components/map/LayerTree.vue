<script setup lang="ts">
/**
 * 图层树（03 §5-3、§5-6）。
 *
 * 结构：五个业务主题分组 → 图层行。**图层清单与默认可见性全部来自注册表**
 * （`LayerRegistry`，示例模式下读数据包），本组件不写死任何图层 ID、不新增图层。
 *
 * 每行提供的控制：显示开关、透明度、上移/下移（叠放顺序）、定位、元数据、设为对象列表图层；
 * 并如实标出三种数据状态：已加载（含无几何记录数）、服务未接入、读取失败。
 *
 * 行的「实际要素数」取自 `store.renderState`——那是从 OpenLayers 对象读回来的真实值，
 * 不是把界面意图再抄一遍，因此控件没真正生效时这里会立刻显示不一致。
 */
import { computed, ref } from 'vue'
import { RouterLink } from 'vue-router'

import { layerAvailability, layerTimeText, layerTypeText } from '@/config/mapLayers'
import { formatCount, formatPercent, NOT_PROVIDED_TEXT } from '@/domain/format'
import { GEOMETRY_FAMILY_LABEL, THEME_LABEL } from '@/domain/labels'
import type { LayerDefinition, Theme } from '@/domain/types'
import { useMapStore } from '@/stores/map'

const emit = defineEmits<{
  focus: [layerId: string]
  metadata: [layer: LayerDefinition]
  retry: [layer: LayerDefinition]
  /** 取消某图层的在途加载（重几何图层的全量翻页循环）。 */
  cancel: [layerId: string]
}>()

const store = useMapStore()
const rasterAssets: Record<string,string> = {
  DS_BASE_WORLDPOP_2020:'BASE_POPULATION_RS', DS_TNR_COPERNICUS_DEM:'TNR_DEM_RS',
  DS_TNR_PERMAFROST_2017:'TNR_PERMAFROST_RS', DS_TNR_TPLC10_2022:'TNR_LANDCOVER_RS_LCC',
  DS_TNR_CHIRPS_PRECIP_2001_2023:'TNR_PRECIP_ANNUAL_RS_2023_LCC', DS_TNR_COPERNICUS_ASPECT:'TNR_ASPECT_RS',
  DS_TNR_COPERNICUS_RELIEF:'TNR_RELIEF_RS', DS_TNR_COPERNICUS_SLOPE:'TNR_SLOPE_RS', DS_TNR_GLIM_LITHOLOGY:'TNR_LITHOLOGY_RS',
}
const expanded = ref<Record<string, boolean>>({})

const groups = computed(() => store.groups)
const totalCount = computed(() => store.layers.length)
const matchedCount = computed(() => store.selectedCount)

/** 地图侧真实状态，用于显示「实际渲染要素数」。 */
const renderCounts = computed(() => {
  const map = new Map<string, number>()
  for (const layer of store.renderState?.layers ?? []) map.set(layer.layerId, layer.featureCount)
  return map
})

function toggleRow(layerId: string): void {
  expanded.value = { ...expanded.value, [layerId]: !expanded.value[layerId] }
}

function isExpanded(layerId: string): boolean {
  return expanded.value[layerId] ?? false
}

function availabilityOf(layer: LayerDefinition) {
  return layerAvailability(layer)
}

function availabilityReason(layer: LayerDefinition): string {
  if (layer.geometryType === 'Raster') {
    return '该栅格数据已收录，请前往“环境因子地图”查看。'
  }
  if (layer.geometryType === 'Table') {
    return '该数据用于属性信息展示，当前不在地图上绘制。'
  }
  return '数据已收录。来源、字段与数据说明见数据目录。'
}

function themeCount(theme: Theme): number {
  return store.layers.filter((layer) => layer.theme === theme).length
}

function dataStateText(layer: LayerDefinition): string {
  const summary = store.summaryOf(layer.id)
  const availability = availabilityOf(layer)
  if (!availability.available) return layer.geometryType === 'Raster' ? '栅格地图' : '已收录'
  if (summary.status === 'loading') {
    return summary.progress
      ? `加载中 ${formatCount(summary.progress.loaded)} / ${formatCount(summary.progress.total)}`
      : '加载中'
  }
  if (summary.status === 'failed') return '加载失败'
  if (summary.status === 'cancelled') return '已取消'
  if (summary.status === 'ready') {
    const rendered = renderCounts.value.get(layer.id) ?? summary.renderedCount
    if (!summary.complete) {
      return `已显示 ${formatCount(rendered)} / 取回 ${formatCount(summary.uniqueCount)} / 源总 ${formatCount(summary.serverTotal)}（未完整）`
    }
    if (summary.uniqueCount !== summary.serverTotal || rendered !== summary.uniqueCount) {
      return `已显示 ${formatCount(rendered)} / 去重 ${formatCount(summary.uniqueCount)} / 源总 ${formatCount(summary.serverTotal)}`
    }
    return `已显示 ${formatCount(rendered)} / 共 ${formatCount(summary.serverTotal)}`
  }
  return '待显示'
}

function dataStateKind(layer: LayerDefinition): string {
  const summary = store.summaryOf(layer.id)
  const availability = availabilityOf(layer)
  if (!availability.available) return 'is-unavailable'
  if (summary.status === 'failed' || summary.status === 'cancelled') return 'is-failed'
  if (summary.status === 'ready') return 'is-ready'
  return 'is-idle'
}

function summaryNote(layer: LayerDefinition): string | null {
  const summary = store.summaryOf(layer.id)
  if (summary.status === 'failed') return summary.errorText
  if (summary.status === 'cancelled') return summary.note
  if (!availabilityOf(layer).available) return availabilityReason(layer)
  const notes: string[] = []
  if (summary.note) notes.push(summary.note)
  if (summary.skippedNoGeometry > 0) {
    notes.push(
      `其中 ${formatCount(summary.skippedNoGeometry)} 条记录无几何：可在对象列表中查看属性，定位不可用。`,
    )
  }
  if (summary.geometrySimplified) {
    notes.push(
      `地图几何已按 ${formatCount(summary.simplifyToleranceMeters ?? 0)} 米容差简化，仅用于地图渲染；属性表格、要素详情与导出仍使用原始精度几何。`,
    )
  }
  return notes.length > 0 ? notes.join(' ') : null
}

/** 该图层是否正在加载中（用于显示「取消」按钮）。 */
function isLoading(layer: LayerDefinition): boolean {
  return store.summaryOf(layer.id).status === 'loading'
}

/** 叠放顺序取自 OL 图层的真实 zIndex（越大越靠上），不是数组下标。 */
function zIndexOf(layerId: string): string {
  const state = store.renderState?.layers.find((item) => item.layerId === layerId)
  return state === undefined ? NOT_PROVIDED_TEXT : String(state.zIndex)
}

function isFailed(layer: LayerDefinition): boolean {
  const status = store.summaryOf(layer.id).status
  return status === 'failed' || status === 'cancelled'
}
</script>

<template>
  <section class="layer-tree" data-testid="layer-tree" aria-label="图层目录">
    <header class="tree-head">
      <h2 class="tree-title">图层目录</h2>
      <p class="tree-note">共 {{ formatCount(totalCount) }} 个图层，按业务主题分类展示。</p>
      <label class="search">
        <span class="search-label">搜索图层</span>
        <input
          :value="store.search"
          type="search"
          data-testid="layer-search"
          placeholder="名称 / ID / 类型 / 数据集"
          @input="store.setSearch(($event.target as HTMLInputElement).value)"
        />
      </label>
      <p class="tree-note" data-testid="layer-search-result">
        命中 {{ formatCount(matchedCount) }} / {{ formatCount(totalCount) }} 个图层
      </p>
      <button type="button" class="btn btn--ghost btn--small" @click="store.resetOrder()">
        恢复默认顺序与可见性
      </button>
    </header>

    <p v-if="groups.length === 0" class="tree-empty" role="status">
      没有匹配的图层。清除搜索词可恢复完整目录。
    </p>

    <div v-for="group in groups" :key="group.theme" class="theme-group">
      <h3 class="theme-title" :data-testid="`theme-${group.theme}`">
        {{ group.label }}
        <span class="theme-count">{{ formatCount(themeCount(group.theme)) }} 个图层</span>
      </h3>
      <ul class="layer-list">
        <li
          v-for="layer in group.layers"
          :key="layer.id"
          class="layer-row"
          :class="{ 'is-active': layer.id === store.activeLayerId }"
          :data-testid="`layer-${layer.id}`"
        >
          <div class="row-main">
            <input
              v-if="availabilityOf(layer).available"
              :id="`visible-${layer.id}`"
              type="checkbox"
              class="row-check"
              :checked="store.isVisible(layer.id)"
              :disabled="!availabilityOf(layer).available"
              :aria-label="`显示图层 ${layer.label}`"
              :data-testid="`visible-${layer.id}`"
              @change="store.setVisible(layer.id, ($event.target as HTMLInputElement).checked)"
            />
            <button
              type="button"
              class="row-name"
              :title="`设为对象列表当前图层：${layer.label}`"
              :data-testid="`name-${layer.id}`"
              @click="store.setActiveLayer(layer.id)"
            >
              {{ layer.label }}
            </button>
            <span class="row-meta">{{ layerTypeText(layer) }}</span>
            <RouterLink v-if="!availabilityOf(layer).available" class="btn btn--small" :to="layer.geometryType === 'Raster' ? {path:'/rasters',query:{asset:rasterAssets[layer.id]}} : `/catalog/${layer.datasetId}`">{{ layer.geometryType === 'Raster' ? '查看栅格 ↗' : '查看数据 ↗' }}</RouterLink>
            <span
              class="row-state"
              :class="dataStateKind(layer)"
              :data-testid="`state-${layer.id}`"
            >
              {{ dataStateText(layer) }}
            </span>
            <button
              type="button"
              class="row-toggle"
              :aria-expanded="isExpanded(layer.id)"
              :aria-label="`展开图层设置 ${layer.label}`"
              :data-testid="`expand-${layer.id}`"
              @click="toggleRow(layer.id)"
            >
              {{ isExpanded(layer.id) ? '收起' : '设置' }}
            </button>
          </div>

          <p v-if="!availabilityOf(layer).available" class="row-reason" role="note">
            {{ availabilityReason(layer) }}
          </p>
          <p v-else-if="summaryNote(layer)" class="row-reason" role="note">
            {{ summaryNote(layer) }}
          </p>

          <div v-if="isExpanded(layer.id)" class="row-detail">
            <dl class="row-facts">
              <div>
                <dt>几何类型</dt>
                <dd>{{ GEOMETRY_FAMILY_LABEL[layer.geometryType] }}</dd>
              </div>
              <div>
                <dt>主题</dt>
                <dd>{{ THEME_LABEL[layer.theme] }}</dd>
              </div>
              <div>
                <dt>时相</dt>
                <dd>{{ layerTimeText(layer) }}</dd>
              </div>
              <div>
                <dt>数据集</dt>
                <dd>{{ layer.datasetId }}</dd>
              </div>
              <div>
                <dt>图层 ID</dt>
                <dd>{{ layer.id }}</dd>
              </div>
              <div>
                <dt>可查询</dt>
                <dd>{{ layer.queryable ? '是' : '否' }}</dd>
              </div>
              <div>
                <dt>叠放顺序（zIndex）</dt>
                <dd :data-testid="`zindex-${layer.id}`">{{ zIndexOf(layer.id) }}</dd>
              </div>
            </dl>
            <label class="opacity">
              <span>透明度 {{ formatPercent(store.opacityOf(layer.id), 0) }}</span>
              <input
                type="range"
                min="0"
                max="1"
                step="0.05"
                :value="store.opacityOf(layer.id)"
                :disabled="!availabilityOf(layer).available"
                :aria-label="`图层透明度 ${layer.label}`"
                :data-testid="`opacity-${layer.id}`"
                @input="
                  store.setOpacity(layer.id, Number(($event.target as HTMLInputElement).value))
                "
              />
            </label>
            <div class="row-actions">
              <button
                type="button"
                class="btn btn--ghost btn--small"
                :data-testid="`up-${layer.id}`"
                @click="store.moveLayer(layer.id, 'up')"
              >
                上移
              </button>
              <button
                type="button"
                class="btn btn--ghost btn--small"
                :data-testid="`down-${layer.id}`"
                @click="store.moveLayer(layer.id, 'down')"
              >
                下移
              </button>
              <button
                type="button"
                class="btn btn--small"
                :disabled="!availabilityOf(layer).available"
                :data-testid="`focus-${layer.id}`"
                @click="emit('focus', layer.id)"
              >
                定位
              </button>
              <button
                type="button"
                class="btn btn--ghost btn--small"
                :data-testid="`metadata-${layer.id}`"
                @click="emit('metadata', layer)"
              >
                元数据
              </button>
              <button
                v-if="isFailed(layer)"
                type="button"
                class="btn btn--small"
                :data-testid="`retry-${layer.id}`"
                @click="emit('retry', layer)"
              >
                重试
              </button>
              <button
                v-if="isLoading(layer)"
                type="button"
                class="btn btn--ghost btn--small"
                :data-testid="`cancel-${layer.id}`"
                @click="emit('cancel', layer.id)"
              >
                取消加载
              </button>
            </div>
            <p class="row-note">
              图例编号 {{ layer.legendId || NOT_PROVIDED_TEXT }}；导出格式
              {{
                layer.exportFormats.length > 0
                  ? layer.exportFormats.join(' / ')
                  : NOT_PROVIDED_TEXT
              }}。
            </p>
          </div>
        </li>
      </ul>
    </div>

    <footer class="tree-foot">
      <p>
        叠放顺序默认按几何类型分层：点在上、线居中、面在下；可在每行“设置”里调整。
        栅格数据请前往“环境因子地图”查看，2050 / 2100 为未来情景成果。
      </p>
    </footer>
  </section>
</template>

<style scoped>
.layer-tree {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  min-height: 0;
  height: 100%;
  overflow-y: auto;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.tree-head {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.tree-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.tree-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.search {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.search input {
  height: var(--control-height);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  font: inherit;
  color: var(--color-text);
}

.theme-group {
  border-top: 1px solid var(--color-border);
  padding-top: var(--space-2);
}

.theme-title {
  display: flex;
  align-items: baseline;
  justify-content: space-between;
  gap: var(--space-2);
  margin: 0 0 var(--space-2);
  font-size: var(--font-size-body);
}

.theme-count {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-weight: 400;
}

.layer-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.layer-row {
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
}

.layer-row.is-active {
  border-color: var(--color-focus);
  box-shadow: inset 0 0 0 1px var(--color-focus);
}

.row-main {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.row-check {
  flex: 0 0 auto;
  width: 16px;
  height: 16px;
}

.row-name {
  flex: 1 1 120px;
  min-width: 0;
  padding: 0;
  border: 0;
  background: none;
  color: var(--color-text);
  font: inherit;
  font-weight: 600;
  text-align: left;
  overflow-wrap: anywhere;
  cursor: pointer;
}

.row-meta {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.row-state {
  flex: 0 0 auto;
  padding: 2px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--badge-surface);
  color: var(--badge-text);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.row-state.is-ready {
  border-color: var(--color-success);
  color: var(--color-success-text);
}

.row-state.is-failed {
  border-color: var(--color-danger);
  color: var(--color-danger-text);
}

.row-state.is-unavailable {
  border-color: var(--color-border);
  color: var(--color-primary-strong);
}

.row-toggle {
  flex: 0 0 auto;
  min-height: var(--tool-button-size);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: var(--font-size-caption);
  cursor: pointer;
}

.row-reason {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.row-detail {
  margin-top: var(--space-2);
  padding-top: var(--space-2);
  border-top: 1px dashed var(--color-border);
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.row-facts {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(120px, 1fr));
  gap: var(--space-1) var(--space-2);
  margin: 0;
  font-size: var(--font-size-caption);
}

.row-facts dt {
  color: var(--color-muted);
}

.row-facts dd {
  margin: 0;
  overflow-wrap: anywhere;
}

.opacity {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.opacity input {
  width: 100%;
  accent-color: var(--color-primary);
}

.row-actions {
  display: flex;
  gap: var(--space-1);
  flex-wrap: wrap;
}

.btn--small {
  min-height: 28px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}

.row-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.tree-empty {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.tree-foot {
  margin-top: auto;
  padding-top: var(--space-2);
  border-top: 1px solid var(--color-border);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
</style>
