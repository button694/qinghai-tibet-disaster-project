<script setup lang="ts">
/**
 * 阶段6：成果文件面板（纯展示）。
 *
 * 下载口径（01 §5.5 + 任务要求）：只有「available 且登记了 url」的文件才给
 * 下载入口；available=false 的文件保留元数据、禁用入口并显示原因；
 * available=true 但没有 url（正式接口未提供文件地址）同样不给下载入口，
 * 说明文案如实写「文件地址未提供」，不伪造链接。
 */
import { NOT_REGISTERED_TEXT } from '@/domain/format'
import type { ResultFile } from '@/domain/types'

defineProps<{
  files: ResultFile[]
}>()

const FORMAT_LABEL: Record<string, string> = {
  csv: 'CSV',
  geojson: 'GeoJSON',
  pdf: 'PDF',
  png: 'PNG',
}
</script>

<template>
  <section class="files-panel" data-testid="result-files">
    <h3 class="section-title">成果文件</h3>
    <ul class="file-list">
      <li v-for="file in files" :key="file.id" class="file-row" :data-file-id="file.id">
        <span class="file-label">{{ file.label }}</span>
        <span class="file-format">{{ FORMAT_LABEL[file.format] ?? file.format }}</span>

        <a
          v-if="file.available && file.url"
          class="btn btn--small file-action"
          :href="file.url"
          download
          :data-testid="`download-${file.id}`"
        >
          下载
        </a>
        <button
          v-else
          type="button"
          class="btn btn--small file-action"
          disabled
          :data-testid="`download-disabled-${file.id}`"
          :title="
            file.available
              ? '文件地址未提供，下载入口不可用。'
              : (file.unavailableReason ?? '文件不可用。')
          "
        >
          下载不可用
        </button>

        <p v-if="!file.available && file.unavailableReason" class="file-reason">
          {{ file.unavailableReason }}
        </p>
        <p v-else-if="file.available && !file.url" class="file-reason">
          文件地址{{ NOT_REGISTERED_TEXT }}，暂不提供下载入口。
        </p>
      </li>
    </ul>
  </section>
</template>

<style scoped>
.files-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.file-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.file-row {
  display: grid;
  grid-template-columns: 1fr auto auto;
  gap: var(--space-2) var(--space-3);
  align-items: center;
  padding-bottom: var(--space-2);
  border-bottom: 1px dashed var(--color-border);
}

.file-row:last-child {
  border-bottom: none;
  padding-bottom: 0;
}

.file-label {
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.file-format {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.file-action {
  white-space: nowrap;
}

.file-action:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.file-reason {
  grid-column: 1 / -1;
  margin: 0;
  color: var(--color-warning-text);
  font-size: 11px;
}

@media (max-width: 720px) {
  .file-row {
    grid-template-columns: 1fr auto;
  }

  .file-format {
    order: 3;
  }

  .file-action {
    order: 2;
  }
}
</style>
