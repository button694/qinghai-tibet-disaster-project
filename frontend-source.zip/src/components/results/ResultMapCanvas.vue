<script setup lang="ts">
/**
 * 阶段6：成果详情地图画布。
 *
 * 只画成果登记的已存要素（result 图层），样式沿用阶段2—5 的统一色板：
 * - 风险区成果 → riskLevelStyle（等级色 + 数据不足斜线纹理）；
 * - 影响范围成果 → impactAreaStyle（风险红半透明）；
 * - 应急路线成果 → routeLineStyle（通行绿，实线主方案）。
 * 已登记研究区边界作为真实底图置于成果要素下方；不新增未登记几何。
 */
import Feature from 'ol/Feature'
import type { FeatureLike } from 'ol/Feature'
import OlMap from 'ol/Map'
import View from 'ol/View'
import { defaults as defaultControls, ScaleLine } from 'ol/control'
import type { EventsKey } from 'ol/events'
import VectorLayer from 'ol/layer/Vector'
import type Geometry from 'ol/geom/Geometry'
import { fromLonLat } from 'ol/proj'
import { unByKey } from 'ol/Observable'
import VectorSource from 'ol/source/Vector'
import { onBeforeUnmount, onMounted, ref, watch } from 'vue'

import { formatFixed } from '@/domain/format'
import type { DataMode, FeatureDetail } from '@/domain/types'
import { toOlFeatures } from '@/services/mapFeatures'
import {
  createResearchBoundaryLayer,
  loadResearchBoundary,
  type ResearchBoundarySource,
} from '@/services/researchBoundary'
import { baseLayerStyle, impactAreaStyle, riskLevelStyle, routeLineStyle } from '@/config/mapStyle'

const props = defineProps<{
  /** 成果已存要素（带 __layerId 标记，用于按成果类型选样式）。 */
  features: FeatureDetail[]
  /** API 模式下加载真实研究区边界；mock/snapshot 不请求正式边界。 */
  mode?: DataMode
  /**
   * 可选的标准化风险等级字段。传 null 时不按等级着色，适用于只登记
   * HAZ_LEVEL 但尚未确认前端等级字典的正式成果点。
   */
  riskLevelField?: string | null
}>()

const host = ref<HTMLDivElement | null>(null)
const zoomText = ref('—')
const drawnCount = ref(0)
const skippedCount = ref(0)
const boundaryCount = ref(0)
const boundaryStatus = ref<'idle' | 'loading' | 'ready' | 'failed'>('idle')

type VectorSource3857 = VectorSource<Feature<Geometry>>

let map: OlMap | null = null
let featureSource: VectorSource3857 | null = null
let boundarySource: ResearchBoundarySource | null = null
let boundaryController: AbortController | null = null
const listenerKeys: EventsKey[] = []
let disposed = false

function styleFor(feature: FeatureLike): ReturnType<typeof riskLevelStyle> {
  const layerId = String(feature.get('__layerId') ?? '')
  if (layerId.includes('.impact')) return impactAreaStyle()
  if (layerId.includes('.route')) return routeLineStyle('primary')
  const riskLevelField = props.riskLevelField === undefined ? 'riskLevel' : props.riskLevelField
  if (riskLevelField === null) return baseLayerStyle()
  const value = feature.get(riskLevelField)
  return value === undefined || value === null ? baseLayerStyle() : riskLevelStyle(String(value))
}

function rebuild(): void {
  if (!featureSource) return
  const { features, skipped } = toOlFeatures(props.features)
  featureSource.clear()
  featureSource.addFeatures(features)
  drawnCount.value = features.length
  skippedCount.value = skipped
  fitAll()
}

function fitAll(): void {
  if (!map) return
  const extent: [number, number, number, number] = [Infinity, Infinity, -Infinity, -Infinity]
  for (const feature of [
    ...(boundarySource?.getFeatures() ?? []),
    ...(featureSource?.getFeatures() ?? []),
  ]) {
    const geometry = feature.getGeometry()
    if (!geometry) continue
    const box = geometry.getExtent()
    if (box.length < 4) continue
    extent[0] = Math.min(extent[0], box[0] ?? 0)
    extent[1] = Math.min(extent[1], box[1] ?? 0)
    extent[2] = Math.max(extent[2], box[2] ?? 0)
    extent[3] = Math.max(extent[3], box[3] ?? 0)
  }
  if (!Number.isFinite(extent[0])) return
  map.getView().fit(extent, { padding: [36, 36, 36, 36], maxZoom: 12 })
}

const onMoveEnd = (): void => {
  const zoom = map?.getView().getZoom()
  zoomText.value = zoom === undefined ? '—' : formatFixed(zoom, 1)
}

onMounted(() => {
  if (disposed || !host.value) return
  featureSource = new VectorSource()
  boundarySource = new VectorSource()
  const boundaryLayer = createResearchBoundaryLayer(boundarySource, 1)
  const featureLayer = new VectorLayer<VectorSource3857>({
    source: featureSource,
    style: styleFor,
    zIndex: 5,
  })
  map = new OlMap({
    target: host.value,
    layers: [boundaryLayer, featureLayer],
    view: new View({ center: fromLonLat([90, 30]), zoom: 7, minZoom: 3, maxZoom: 15 }),
    controls: defaultControls({ attribution: false, zoom: false }).extend([new ScaleLine()]),
  })
  listenerKeys.push(map.on('moveend', onMoveEnd))
  rebuild()

  if (props.mode === 'api') {
    boundaryStatus.value = 'loading'
    boundaryController = new AbortController()
    void loadResearchBoundary(props.mode, { signal: boundaryController.signal })
      .then((items) => {
        if (disposed || !boundarySource) return
        const { features } = toOlFeatures(items)
        boundarySource.clear()
        boundarySource.addFeatures(features)
        boundaryCount.value = features.length
        boundaryStatus.value = 'ready'
        fitAll()
      })
      .catch((error: unknown) => {
        if (disposed || (error instanceof DOMException && error.name === 'AbortError')) return
        boundaryStatus.value = 'failed'
      })
  }
})

onBeforeUnmount(() => {
  disposed = true
  for (const key of listenerKeys) unByKey(key)
  listenerKeys.length = 0
  if (map) {
    map.setTarget(undefined)
    map.dispose()
    map = null
  }
  boundaryController?.abort()
  boundaryController = null
  featureSource = null
  boundarySource = null
})

watch(
  () => props.features,
  () => rebuild(),
)

defineExpose({ fitAll })
</script>

<template>
  <div class="result-map-wrap">
    <div
      ref="host"
      class="result-map"
      data-testid="result-map"
      :data-count="drawnCount"
      :aria-label="boundaryStatus === 'ready' ? '研究区边界与成果要素地图' : '成果要素地图'"
    ></div>
    <p class="map-chip">
      <template v-if="boundaryStatus === 'ready'">研究区边界 {{ boundaryCount }} 片 · </template>
      <template v-else-if="boundaryStatus === 'loading'">研究区边界加载中 · </template>
      <template v-else-if="boundaryStatus === 'failed'">研究区边界暂不可用 · </template>
      已上图 {{ drawnCount }} 个成果要素<template v-if="skippedCount > 0">
        · {{ skippedCount }} 条无几何未上图</template
      >
      · 缩放 {{ zoomText }}
    </p>
  </div>
</template>

<style scoped>
.result-map-wrap {
  position: relative;
  display: flex;
  flex-direction: column;
  min-width: 0;
  min-height: 0;
  height: 100%;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  overflow: hidden;
  background: var(--color-map-bg);
}

.result-map {
  flex: 1 1 auto;
  min-height: 0;
  width: 100%;
}

.map-chip {
  position: absolute;
  top: var(--space-2);
  left: var(--space-2);
  margin: 0;
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: rgb(16 29 43 / 78%);
  color: var(--color-shell-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
  pointer-events: none;
  white-space: nowrap;
  max-width: calc(100% - 16px);
  overflow: hidden;
  text-overflow: ellipsis;
}
</style>
