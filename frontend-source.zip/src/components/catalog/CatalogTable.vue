<script setup lang="ts">
/**
 * 阶段6：数据目录表格（纯展示）。
 *
 * 四类状态分列显示（任务硬性要求，不合并为单一「可用」状态）：
 * - 登记：DATASET_STATUS_LABEL（registered/published）；
 * - 文件：已验证存在 / 仅元数据 / 未登记图层（来自服务对要素文件的探测）；
 * - 预览：可预览（vector 可进 /map）/ 服务待接入（栅格）/ 不适用（表格）；
 * - 服务：数据集登记的 serviceAvailable，false 必须带 serviceNote。
 *
 * 本组件不自行格式化数字（计数统一由 formatCount 输出）。
 */
import { computed } from 'vue'

import { formatCount } from '@/domain/format'
import { DATASET_STATUS_LABEL, THEME_LABEL } from '@/domain/labels'
import type { DatasetType } from '@/domain/types'
import type { CatalogDatasetRow } from '@/services/catalogWorkspace'

const props = defineProps<{
  rows: CatalogDatasetRow[]
}>()

const emit = defineEmits<{
  open: [datasetId: string]
}>()

const DATATYPE_LABEL: Record<DatasetType, string> = {
  vector: '矢量',
  raster: '栅格',
  table: '表格',
}

const FILE_STATE_TEXT = {
  verified: '文件已核验',
  metadataOnly: '基础信息',
  noLayers: '未关联图层',
} as const

const PREVIEW_STATE_TEXT = {
  previewable: '可查看',
  servicePending: '暂未提供在线预览',
  notApplicable: '暂不适用',
} as const

const rowsWithText = computed(() =>
  props.rows.map((row) => ({
    row,
    typeText: DATATYPE_LABEL[row.dataset.dataType],
    themeText: THEME_LABEL[row.dataset.theme],
    statusText: DATASET_STATUS_LABEL[row.dataset.status],
    fileText: FILE_STATE_TEXT[row.fileState],
    previewText: PREVIEW_STATE_TEXT[row.previewState],
    serviceText: row.dataset.serviceAvailable ? '可用' : '暂未提供',
  })),
)

function countText(value: number): string {
  return formatCount(value) ?? '—'
}
</script>

<template>
  <div class="catalog-table-wrap" data-testid="catalog-table">
    <table class="catalog-table">
      <thead>
        <tr>
          <th scope="col">数据集</th>
          <th scope="col">主题</th>
          <th scope="col">类型</th>
          <th scope="col">版本</th>
          <th scope="col">状态</th>
          <th scope="col">文件</th>
          <th scope="col">查看</th>
          <th scope="col">在线数据</th>
        </tr>
      </thead>
      <tbody>
        <tr v-for="entry in rowsWithText" :key="entry.row.dataset.id">
          <td>
            <button
              type="button"
              class="catalog-link"
              data-testid="catalog-open"
              @click="emit('open', entry.row.dataset.id)"
            >
              {{ entry.row.dataset.name }}
            </button>
            <p v-if="entry.row.note" class="row-note">{{ entry.row.note }}</p>
          </td>
          <td>{{ entry.themeText }}</td>
          <td>{{ entry.typeText }}</td>
          <td class="tabular-nums">{{ entry.row.dataset.version }}</td>
          <td>
            <span class="state-chip" :data-file-state="entry.row.fileState">{{
              entry.statusText
            }}</span>
          </td>
          <td>
            <span class="state-chip" :data-file-state="entry.row.fileState">{{
              entry.fileText
            }}</span>
          </td>
          <td>
            <span class="state-chip" :data-preview-state="entry.row.previewState">{{
              entry.previewText
            }}</span>
            <span v-if="entry.row.previewState === 'previewable'" class="row-sub">{{
              countText(entry.row.layerCount)
            }}</span>
          </td>
          <td>
            <span
              class="state-chip"
              :class="{ 'is-bad': !entry.row.dataset.serviceAvailable }"
              :data-service-state="entry.row.dataset.serviceAvailable ? 'ok' : 'down'"
              :title="entry.row.dataset.serviceNote ?? undefined"
              >{{ entry.serviceText }}</span
            >
          </td>
        </tr>
      </tbody>
    </table>
  </div>
</template>

<style scoped>
.catalog-table-wrap {
  overflow-x: auto;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.catalog-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.catalog-table th,
.catalog-table td {
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  vertical-align: top;
  min-width: 72px;
}

.catalog-table th {
  color: var(--color-muted);
  font-weight: 600;
  white-space: nowrap;
}

.catalog-table tbody tr:last-child td {
  border-bottom: none;
}

.catalog-link {
  padding: 0;
  border: none;
  background: none;
  color: var(--color-primary);
  cursor: pointer;
  font: inherit;
  text-align: left;
  text-decoration: underline;
  text-underline-offset: 2px;
}

.row-note {
  margin: 2px 0 0;
  color: var(--color-muted);
  font-size: 11px;
  max-width: 320px;
}

.row-sub {
  display: block;
  color: var(--color-muted);
  font-size: 11px;
}

.state-chip {
  display: inline-block;
  padding: 1px 6px;
  border-radius: var(--badge-radius);
  background: var(--color-surface-sunken);
  color: var(--color-text);
  white-space: nowrap;
}

.state-chip.is-bad {
  color: var(--color-warning-text);
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}
</style>
