<script setup lang="ts">
/**
 * 阶段6：年度降水浏览（栅格数据集详情页内嵌）。
 *
 * 硬性边界：
 * - 年份列表完全由数据集的 availableTimes 派生（当前真实登记 2001—2023，共 23 个
 *   时相，属于同一数据集的不同年份，不是 23 套数据集）；
 * - 切换年份只同步「图层身份、年份、统计说明」三处展示，不发起任何请求；
 * - 当前没有年度统计服务：统计一律显示「未提供 / 统计服务待接入」，
 *   禁止生成随机曲线、随机数值或虚假趋势，也不绘制任何图表。
 */
import { computed } from 'vue'

import { NOT_PROVIDED_TEXT } from '@/domain/format'
import type { Dataset } from '@/domain/types'

const props = defineProps<{
  /** 当前数据集（应为 raster 且 availableTimes 含年精度时相）。 */
  dataset: Dataset
  /** 已派生的年份列表（服务层从 availableTimes 过滤得到）。 */
  years: string[]
  /** 当前选中年份（由 store 持有，深链接/刷新后恢复默认第一年）。 */
  selectedYear: string | null
}>()

const emit = defineEmits<{
  select: [year: string]
}>()

const layerIdentity = computed(() => {
  const layerId = props.dataset.layerIds[0] ?? null
  if (layerId === null) return NOT_PROVIDED_TEXT
  return props.selectedYear === null ? layerId : `${layerId} @ ${props.selectedYear}`
})
</script>

<template>
  <section class="precip-browser" data-testid="precip-browser">
    <h3 class="section-title">年度降水浏览</h3>

    <p class="coverage-note">
      该数据集为<strong>同一个年度降水数据集</strong>的 {{ years.length }} 个年度时相（{{
        dataset.temporalCoverage ?? NOT_PROVIDED_TEXT
      }}），不是多套独立数据集。年份列表来自登记的 availableTimes。
    </p>

    <div class="year-picker" role="group" aria-label="选择年份">
      <button
        v-for="year in years"
        :key="year"
        type="button"
        class="year-chip"
        :class="{ 'is-active': year === selectedYear }"
        :data-testid="`precip-year-${year}`"
        @click="emit('select', year)"
      >
        {{ year }}
      </button>
    </div>

    <dl class="identity-list">
      <div class="identity-row">
        <dt>图层身份</dt>
        <dd data-testid="precip-layer-identity">{{ layerIdentity }}（示例登记）</dd>
      </div>
      <div class="identity-row">
        <dt>当前年份</dt>
        <dd data-testid="precip-current-year">{{ selectedYear ?? NOT_PROVIDED_TEXT }}</dd>
      </div>
      <div class="identity-row">
        <dt>年度统计</dt>
        <dd data-testid="precip-stats-note">
          {{ NOT_PROVIDED_TEXT }}——统计服务待接入；界面不生成任何曲线、数值或趋势。
        </dd>
      </div>
      <div class="identity-row">
        <dt>地图预览</dt>
        <dd data-testid="precip-map-note">
          栅格服务待接入：无浏览器可用的瓦片/图像服务，不拼接本机文件路径。
        </dd>
      </div>
    </dl>
  </section>
</template>

<style scoped>
.precip-browser {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.coverage-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.year-picker {
  display: flex;
  flex-wrap: wrap;
  gap: 6px;
}

.year-chip {
  padding: 4px 10px;
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  background: var(--color-surface);
  color: var(--color-text);
  cursor: pointer;
  font: inherit;
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.year-chip:hover {
  border-color: var(--color-primary);
}

.year-chip.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-weight: 600;
}

.identity-list {
  display: grid;
  gap: var(--space-2);
  margin: 0;
}

.identity-row {
  display: grid;
  grid-template-columns: 88px 1fr;
  gap: var(--space-2);
  align-items: baseline;
}

.identity-row dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.identity-row dd {
  margin: 0;
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

@media (max-width: 720px) {
  .identity-row {
    grid-template-columns: 1fr;
    gap: 2px;
  }
}
</style>
