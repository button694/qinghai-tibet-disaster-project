<script setup lang="ts">
/**
 * 属性条件区（03 §6-1）。
 *
 * 条件入口**完全来自注册表的 `FieldDefinition`**：
 * - 只有 `filterable === true` 的字段才出现在可添加列表里；
 * - 字段类型决定控件形态（文本包含 / 分类多选 / 数值比较与区间 / 日期区间 / 布尔 / 空值）；
 * - 被隐藏的字段不在列表里，但会把隐藏条数写在页面上，不假装它们可查。
 *
 * 同一字段只允许一条条件（02 §3.1 第一版统一 AND 语义，同字段两条条件要么冗余要么恒假）。
 */
import { computed } from 'vue'

import type { FieldDefinition } from '@/domain/types'
import {
  conditionKindOf,
  emptyCondition,
  numberOperatorsOf,
  NUMBER_OPERATOR_LABEL,
  type DictionaryMap,
  type FieldCondition,
} from '@/domain/queryFields'
import { useQueryStore } from '@/stores/query'

const props = defineProps<{
  /** 代码字典：dictionaryId → 条目数组；分类字段的选项来自数据包字典，不写死在组件里。 */
  dictionaries: DictionaryMap
}>()

const store = useQueryStore()

/** 「添加条件」下拉的候选项：可查询字段 ×（该类型条件 / 空值条件）。 */
const addOptions = computed(() =>
  store.addableFields.flatMap((field) => {
    const items = [
      {
        value: `${field.key}::${conditionKindOf(field)}`,
        label: `${field.label}（${kindLabel(field)}）`,
      },
    ]
    if (field.nullable) {
      items.push({ value: `${field.key}::isNull`, label: `${field.label}（为空）` })
    }
    return items
  }),
)

function kindLabel(field: FieldDefinition): string {
  switch (field.type) {
    case 'enum':
      return '分类选择'
    case 'number':
      return '数值比较'
    case 'date':
      return '日期区间'
    case 'boolean':
      return '是否'
    default:
      return '包含文本'
  }
}

function addCondition(optionValue: string): void {
  const [fieldKey, kind] = optionValue.split('::')
  if (fieldKey === undefined || kind === undefined) return
  const field = store.availableFields.find((item) => item.key === fieldKey)
  if (!field) return
  store.addCondition(
    kind === 'isNull' ? { field: fieldKey, kind: 'isNull' } : emptyCondition(field),
  )
}

function fieldOf(condition: FieldCondition): FieldDefinition | null {
  return store.availableFields.find((item) => item.key === condition.field) ?? null
}

function optionsOf(field: FieldDefinition): Array<{ code: string; label: string }> {
  const items =
    field.dictionaryId === undefined ? undefined : props.dictionaries[field.dictionaryId]
  if (!items) return []
  return items.map((item) => ({ code: item.code, label: item.label }))
}

function updateField(field: string, patch: Partial<FieldCondition>): void {
  const current = store.conditions.find((item) => item.field === field)
  if (!current) return
  store.updateCondition(field, { ...current, ...patch } as FieldCondition)
}

function toggleCode(condition: FieldCondition, code: string): void {
  if (condition.kind !== 'enum') return
  const codes = condition.codes.includes(code)
    ? condition.codes.filter((item) => item !== code)
    : [...condition.codes, code]
  store.updateCondition(condition.field, { field: condition.field, kind: 'enum', codes })
}
</script>

<template>
  <section class="filter-panel" data-testid="query-conditions" aria-label="属性查询条件">
    <header class="panel-head">
      <h3 class="panel-title">属性条件</h3>
      <div class="add-row">
        <label class="visually-hidden" for="add-condition-select">添加条件字段</label>
        <select
          id="add-condition-select"
          class="control"
          data-testid="add-condition"
          :disabled="addOptions.length === 0"
          @change="addCondition(($event.target as HTMLSelectElement).value)"
        >
          <option value="">{{ addOptions.length === 0 ? '无可添加字段' : '选择字段…' }}</option>
          <option v-for="option in addOptions" :key="option.value" :value="option.value">
            {{ option.label }}
          </option>
        </select>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="clear-conditions"
          :disabled="store.conditions.length === 0"
          @click="store.clearConditions()"
        >
          清除条件
        </button>
      </div>
    </header>

    <p v-if="store.conditions.length === 0" class="panel-note" data-testid="no-condition">
      未加属性条件：将在所选图层的全部记录上查询。条件之间为「且」关系（02 §3.1）。
    </p>

    <ul v-else class="condition-list">
      <li
        v-for="condition in store.conditions"
        :key="condition.field"
        class="condition-row"
        :data-testid="`condition-row-${condition.field}`"
      >
        <template v-if="fieldOf(condition)">
          <span class="condition-name">{{ fieldOf(condition)?.label }}</span>

          <template v-if="condition.kind === 'text'">
            <input
              class="control"
              type="search"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：包含文本`"
              :data-testid="`condition-text-${condition.field}`"
              :placeholder="`包含文本`"
              :value="condition.text"
              @input="
                updateField(condition.field, { text: ($event.target as HTMLInputElement).value })
              "
            />
          </template>

          <template v-else-if="condition.kind === 'enum'">
            <span class="enum-options">
              <label
                v-for="option in optionsOf(fieldOf(condition) as FieldDefinition)"
                :key="option.code"
                class="enum-option"
              >
                <input
                  type="checkbox"
                  :data-testid="`condition-enum-${condition.field}-${option.code}`"
                  :checked="condition.codes.includes(option.code)"
                  @change="toggleCode(condition, option.code)"
                />
                <span>{{ option.label }}</span>
              </label>
            </span>
          </template>

          <template v-else-if="condition.kind === 'number'">
            <select
              class="control"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：比较方式`"
              :data-testid="`condition-op-${condition.field}`"
              :value="condition.operator"
              @change="
                updateField(condition.field, {
                  operator: ($event.target as HTMLSelectElement).value,
                } as Partial<FieldCondition>)
              "
            >
              <option
                v-for="operator in numberOperatorsOf(fieldOf(condition) as FieldDefinition)"
                :key="operator"
                :value="operator"
              >
                {{ NUMBER_OPERATOR_LABEL[operator] }}
              </option>
            </select>
            <input
              class="control control--num"
              type="number"
              step="any"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：数值${condition.operator === 'between' ? '下限' : ''}`"
              :data-testid="`condition-min-${condition.field}`"
              :value="condition.min"
              @input="
                updateField(condition.field, { min: ($event.target as HTMLInputElement).value })
              "
            />
            <template v-if="condition.operator === 'between'">
              <span class="dash">—</span>
              <input
                class="control control--num"
                type="number"
                step="any"
                :aria-label="`${fieldOf(condition)?.label ?? condition.field}：数值上限`"
                :data-testid="`condition-max-${condition.field}`"
                :value="condition.max"
                @input="
                  updateField(condition.field, { max: ($event.target as HTMLInputElement).value })
                "
              />
            </template>
            <span v-if="fieldOf(condition)?.unit" class="unit">{{ fieldOf(condition)?.unit }}</span>
          </template>

          <template v-else-if="condition.kind === 'date'">
            <input
              class="control"
              type="date"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：开始日期`"
              :data-testid="`condition-from-${condition.field}`"
              :value="condition.from"
              @input="
                updateField(condition.field, { from: ($event.target as HTMLInputElement).value })
              "
            />
            <span class="dash">—</span>
            <input
              class="control"
              type="date"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：结束日期`"
              :data-testid="`condition-to-${condition.field}`"
              :value="condition.to"
              @input="
                updateField(condition.field, { to: ($event.target as HTMLInputElement).value })
              "
            />
          </template>

          <template v-else-if="condition.kind === 'boolean'">
            <select
              class="control"
              :aria-label="`${fieldOf(condition)?.label ?? condition.field}：是否`"
              :data-testid="`condition-bool-${condition.field}`"
              :value="condition.value ? 'true' : 'false'"
              @change="
                updateField(condition.field, {
                  value: ($event.target as HTMLSelectElement).value === 'true',
                } as Partial<FieldCondition>)
              "
            >
              <option value="true">是</option>
              <option value="false">否</option>
            </select>
          </template>

          <template v-else>
            <span class="condition-static">为空（未提供）</span>
          </template>

          <button
            type="button"
            class="btn btn--ghost btn--small"
            :aria-label="`移除条件：${fieldOf(condition)?.label ?? condition.field}`"
            :data-testid="`remove-condition-${condition.field}`"
            @click="store.removeCondition(condition.field)"
          >
            移除
          </button>
        </template>
      </li>
    </ul>

    <p v-if="store.hiddenNote" class="panel-note" data-testid="hidden-fields">
      {{ store.hiddenNote }}
    </p>
  </section>
</template>

<style scoped>
.filter-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.panel-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.panel-title {
  margin: 0;
  font-size: var(--font-size-caption);
  color: var(--color-muted);
  font-weight: 600;
}

.add-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-left: auto;
}

.control {
  height: var(--control-height);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: var(--font-size-caption);
}

.control--num {
  width: 7rem;
  font-variant-numeric: tabular-nums;
}

.panel-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.condition-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.condition-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.condition-name {
  min-width: 7rem;
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.condition-static {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.enum-options {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.enum-option {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
}

.dash {
  color: var(--color-muted);
}

.unit {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.btn--small {
  min-height: 26px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
