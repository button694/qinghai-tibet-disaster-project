<script setup lang="ts">
/**
 * 空间条件区（03 §6-3、§6-4）。
 *
 * 四种空间条件，语义与 02 §3.1 一一对应：
 * - 框选 / 多边形：绘制范围，可选「相交」或「覆盖」；**绘制与点选互斥，Esc 取消**（由画布负责）；
 * - 行政区或流域：取登记范围参与判定；本数据包只登记范围框，因此如实说明「按范围框，非行政边界」；
 * - 对象缓冲：以选定对象为中心按半径缓冲，半径单位米；
 * - 最近邻：限制半径 + 返回数量，结果按距离升序，逐条距离随结果返回。
 *
 * 距离方法与单位（`DISTANCE_METHOD_TEXT`）在这里与结果、导出共用同一句话，
 * 不允许三处各写一套。
 */
import { computed } from 'vue'

import { formatDistance, NOT_PROVIDED_TEXT } from '@/domain/format'
import { DISTANCE_METHOD_TEXT, SPATIAL_PREDICATE_TEXT } from '@/domain/spatialRelations'
import type { Region, SpatialPredicate } from '@/domain/types'
import { useQueryStore, type SpatialSourceKind } from '@/stores/query'

type SpatialMode = 'none' | 'box' | 'polygon' | 'region' | 'buffer' | 'nearest'

const props = defineProps<{
  regions: Region[]
  /** 地图当前选中的对象；对象缓冲与最近邻以它为源对象。 */
  selectedTitle: string | null
  selectedRef: { layerId: string; id: string } | null
  /** 源对象没有几何时禁用「用当前选中对象」，并说明原因。 */
  selectedHasGeometry: boolean
  drawMode: 'none' | 'box' | 'polygon'
}>()

const emit = defineEmits<{
  startDraw: [mode: 'box' | 'polygon']
  clearDraw: []
  useSelected: []
}>()

const store = useQueryStore()

/** 缓冲与最近邻的界面默认值：可见、可改，实际取值会写入导出元数据。 */
const DEFAULT_BUFFER_METERS = 5000
const DEFAULT_NEAREST_METERS = 20000
const DEFAULT_NEAREST_LIMIT = 5

const currentMode = computed<SpatialMode>(() => {
  const draft = store.spatial
  if (draft === null) return 'none'
  if (draft.source === 'draw') return props.drawMode === 'polygon' ? 'polygon' : 'box'
  if (draft.source === 'region') return 'region'
  return draft.predicate === 'nearest' ? 'nearest' : 'buffer'
})

function onModeChange(value: string): void {
  const mode = value as SpatialMode
  if (mode === 'none') {
    emit('clearDraw')
    store.setSpatial(null)
    return
  }
  if (mode === 'box' || mode === 'polygon') {
    const keep = store.spatial?.source === 'draw' ? store.spatial.geometry : null
    store.setSpatial({
      predicate: store.spatial?.predicate === 'within' ? 'within' : 'intersects',
      source: 'draw' as SpatialSourceKind,
      geometry: keep,
      regionId: null,
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: null,
      limit: null,
    })
    emit('startDraw', mode)
    return
  }
  if (mode === 'region') {
    emit('clearDraw')
    store.setSpatial({
      predicate: 'intersects',
      source: 'region',
      geometry: null,
      regionId: props.regions[0]?.id ?? null,
      sourceFeature: null,
      sourceLabel: null,
      distanceMeters: null,
      limit: null,
    })
    return
  }
  emit('clearDraw')
  store.setSpatial({
    predicate: mode === 'nearest' ? 'nearest' : 'bufferIntersects',
    source: 'feature',
    geometry: null,
    regionId: null,
    sourceFeature: null,
    sourceLabel: null,
    distanceMeters: mode === 'nearest' ? DEFAULT_NEAREST_METERS : DEFAULT_BUFFER_METERS,
    limit: mode === 'nearest' ? DEFAULT_NEAREST_LIMIT : null,
  })
}

function setPredicate(value: string): void {
  store.updateSpatial({ predicate: value as SpatialPredicate })
}

function setRegion(value: string): void {
  store.updateSpatial({ regionId: value === '' ? null : value })
}

function setRadius(value: string): void {
  const parsed = Number(value)
  store.updateSpatial({ distanceMeters: Number.isFinite(parsed) && parsed > 0 ? parsed : null })
}

function setLimit(value: string): void {
  const parsed = Number(value)
  store.updateSpatial({ limit: Number.isFinite(parsed) && parsed >= 1 ? Math.floor(parsed) : null })
}

const drawn = computed(() => store.spatial?.geometry != null)
const isFeatureMode = computed(
  () => currentMode.value === 'buffer' || currentMode.value === 'nearest',
)

const radiusText = computed(() => {
  const meters = store.spatial?.distanceMeters ?? null
  if (meters === null) return NOT_PROVIDED_TEXT
  return formatDistance(meters, { unit: 'm' })
})

/** 空间条件是否完整：不完整的条件不会生效，必须在界面上说清楚（口径来自 store，界面与运行共用）。 */
const incompleteReason = computed(() => store.spatialIncompleteReason)
</script>

<template>
  <section class="spatial-panel" data-testid="query-spatial" aria-label="空间查询条件">
    <header class="panel-head">
      <h3 class="panel-title">空间条件</h3>
      <label class="mode-row">
        <span class="visually-hidden">空间条件方式</span>
        <select
          class="control"
          data-testid="spatial-mode"
          :value="currentMode"
          @change="onModeChange(($event.target as HTMLSelectElement).value)"
        >
          <option value="none">不使用空间条件</option>
          <option value="box">框选（拉框）</option>
          <option value="polygon">多边形（点选成面）</option>
          <option value="region">行政区或流域</option>
          <option value="buffer">对象缓冲</option>
          <option value="nearest">最近邻</option>
        </select>
      </label>
    </header>

    <template v-if="currentMode === 'none'">
      <p class="panel-note" data-testid="spatial-none">
        未加空间条件。加上后查询会在属性条件的结果上再做空间判定。
      </p>
    </template>

    <template v-else>
      <div v-if="currentMode === 'box' || currentMode === 'polygon'" class="spatial-row">
        <label class="inline">
          <span>关系</span>
          <select
            class="control"
            data-testid="spatial-predicate"
            :value="store.spatial?.predicate"
            @change="setPredicate(($event.target as HTMLSelectElement).value)"
          >
            <option value="intersects">相交</option>
            <option value="within">覆盖（目标整体在范围内）</option>
          </select>
        </label>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="start-draw"
          @click="emit('startDraw', currentMode === 'polygon' ? 'polygon' : 'box')"
        >
          {{ currentMode === 'polygon' ? '开始画面' : '开始框选' }}
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="clear-draw"
          :disabled="!drawn"
          @click="emit('clearDraw')"
        >
          清除范围
        </button>
        <span class="state" data-testid="spatial-draw-state">
          {{ drawn ? '已绘制范围' : props.drawMode === 'none' ? '未绘制' : '正在绘制（Esc 取消）' }}
        </span>
      </div>

      <div v-else-if="currentMode === 'region'" class="spatial-row">
        <label class="inline">
          <span>范围</span>
          <select
            class="control"
            data-testid="spatial-region"
            :value="store.spatial?.regionId ?? ''"
            @change="setRegion(($event.target as HTMLSelectElement).value)"
          >
            <option value="">选择范围…</option>
            <option v-for="region in props.regions" :key="region.id" :value="region.id">
              {{ region.name }}
            </option>
          </select>
        </label>
        <label class="inline">
          <span>关系</span>
          <select
            class="control"
            data-testid="spatial-predicate"
            :value="store.spatial?.predicate"
            @change="setPredicate(($event.target as HTMLSelectElement).value)"
          >
            <option value="intersects">相交</option>
            <option value="within">覆盖（目标整体在范围内）</option>
          </select>
        </label>
      </div>

      <div v-else class="spatial-row">
        <span class="source" data-testid="spatial-source">
          源对象：{{ store.spatial?.sourceLabel ?? props.selectedTitle ?? NOT_PROVIDED_TEXT }}
        </span>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="use-selected"
          :disabled="props.selectedRef === null || !props.selectedHasGeometry"
          :title="
            props.selectedRef === null
              ? '请先在地图上点选一个对象'
              : props.selectedHasGeometry
                ? '以当前选中对象为源'
                : '该记录无几何，不能作为缓冲或最近邻的源对象'
          "
          @click="emit('useSelected')"
        >
          用当前选中对象
        </button>
        <label class="inline">
          <span>{{ currentMode === 'nearest' ? '限制半径' : '缓冲半径' }}</span>
          <input
            class="control control--num"
            type="number"
            step="100"
            min="1"
            data-testid="spatial-radius"
            :value="store.spatial?.distanceMeters ?? ''"
            @input="setRadius(($event.target as HTMLInputElement).value)"
          />
          <span class="unit">米（{{ radiusText }}）</span>
        </label>
        <label v-if="currentMode === 'nearest'" class="inline">
          <span>返回数量</span>
          <input
            class="control control--num"
            type="number"
            step="1"
            min="1"
            data-testid="spatial-limit"
            :value="store.spatial?.limit ?? ''"
            @input="setLimit(($event.target as HTMLInputElement).value)"
          />
          <span class="unit">条</span>
        </label>
      </div>

      <p class="panel-note" data-testid="spatial-semantics">
        {{ SPATIAL_PREDICATE_TEXT[store.spatial?.predicate ?? 'intersects'] }}
      </p>
      <p v-if="currentMode === 'region'" class="panel-note" data-testid="spatial-region-note">
        本数据包的行政区只登记范围框（西、南、东、北），按范围框参与判定，不声称按行政边界裁切。
      </p>
      <p v-if="isFeatureMode" class="panel-note" data-testid="spatial-method">
        {{ DISTANCE_METHOD_TEXT }}
      </p>
      <p v-if="incompleteReason" class="panel-warn" data-testid="spatial-incomplete">
        {{ incompleteReason }}
      </p>
    </template>
  </section>
</template>

<style scoped>
.spatial-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.panel-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.panel-title {
  margin: 0;
  font-size: var(--font-size-caption);
  color: var(--color-muted);
  font-weight: 600;
}

.mode-row {
  margin-left: auto;
}

.control {
  height: var(--control-height);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: var(--font-size-caption);
}

.control--num {
  width: 7rem;
  font-variant-numeric: tabular-nums;
}

.spatial-row {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.inline {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
}

.source {
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.state {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.unit {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.panel-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.panel-warn {
  margin: 0;
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface, var(--color-info-surface));
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.btn--small {
  min-height: 26px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
