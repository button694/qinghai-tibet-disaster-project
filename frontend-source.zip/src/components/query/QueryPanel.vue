<script setup lang="ts">
/**
 * 查询面板（阶段3 入口，03 §6）。
 *
 * 组装三块：属性条件（`QueryFilterPanel`）、空间条件（`QuerySpatialPanel`）、
 * 结果表与导出（`QueryResultTable`）。执行与取数全部走 `stores/query` →
 * `services/queryWorkspace` → `QueryRepository`，本组件不直接读示例 JSON。
 *
 * 与地图的分工：绘制由 `MapCanvas` 负责（绘制与点选互斥、Esc 取消），
 * 本面板只保存绘制结果与查询状态；命中集合交回地图以覆盖层高亮。
 */
import { computed, ref, watch } from 'vue'

import { layerAvailability } from '@/config/mapLayers'
import { formatCount, formatNumber, NOT_PROVIDED_TEXT } from '@/domain/format'
import { DATA_MODE_LABEL } from '@/domain/labels'
import { DISTANCE_METHOD_TEXT } from '@/domain/spatialRelations'
import type { DictionaryMap } from '@/domain/queryFields'
import type { DataMode, FeatureRef, Region } from '@/domain/types'
import {
  buildCsv,
  buildExportColumns,
  buildGeoJson,
  buildMetadataJson,
  downloadText,
  exportFileName,
  EXPORT_SCOPE_LABEL,
  type ExportMeta,
  type ExportScope,
} from '@/services/queryExport'
import { getQueryWorkspaceService, MAX_EXPORT_RECORDS } from '@/services/queryWorkspace'
import { useMapStore } from '@/stores/map'
import { useQueryStore } from '@/stores/query'
import { useSessionStore } from '@/stores/session'
import QueryFilterPanel from '@/components/query/QueryFilterPanel.vue'
import QueryResultTable from '@/components/query/QueryResultTable.vue'
import QuerySpatialPanel from '@/components/query/QuerySpatialPanel.vue'

type DrawMode = 'none' | 'box' | 'polygon'

const props = defineProps<{
  /** 代码字典：dictionaryId → 条目数组；分类字段选项与中文标签都来自数据包字典。 */
  dictionaries: DictionaryMap
  regions: Region[]
  drawMode: DrawMode
}>()

const emit = defineEmits<{
  startDraw: [mode: 'box' | 'polygon']
  clearDraw: []
  locate: [ref: FeatureRef]
}>()

const mapStore = useMapStore()
const store = useQueryStore()
const session = useSessionStore()

const exportNote = ref<string | null>(null)
const exporting = ref(false)

/** 可查询图层：注册表声明可查询，且当前数据包下确实可渲染（01 §5.1）。 */
const queryableLayers = computed(() =>
  mapStore.orderedLayers.filter((layer) => layer.queryable && layerAvailability(layer).available),
)

/** 打开面板时默认选中地图当前图层（若可查询），否则取第一个可查询图层。 */
watch(
  () => store.open,
  (open) => {
    if (!open || store.layerId !== null) return
    const preferred =
      queryableLayers.value.find((layer) => layer.id === mapStore.activeLayerId) ??
      queryableLayers.value[0]
    store.setLayer(preferred?.id ?? null)
  },
)

const blockReason = computed<string | null>(() => {
  if (store.layerId === null) return '请先选择要查询的图层。'
  return store.spatialIncompleteReason
})

/**
 * 正式接口的查询能力由后端清单决定。
 *
 * API 模式严格以服务端 capabilities 决定是否开放：当前已支持白名单属性筛选、
 * 相交/覆盖/缓冲/最近邻与短期续页令牌；未声明的字段或谓词仍由服务端明确拒绝。
 * mock 模式继续保留阶段3 的本地完整查询行为。
 */
const queryCapabilityReason = computed<string | null>(() => {
  if (session.mode !== 'api') return null
  if (session.status !== 'ready' || session.capabilities === null) {
    if (session.status === 'failed') {
      return '查询功能暂时无法使用，请稍后重试。'
    }
    return '正在准备查询功能，请稍候。'
  }

  const attributeEnabled = session.canAttributeQuery
  const spatialEnabled = session.canSpatialQuery
  if (attributeEnabled && spatialEnabled) return null

  const missing = [
    !attributeEnabled ? '属性筛选' : null,
    !spatialEnabled ? '空间查询' : null,
  ].filter((value): value is string => value !== null)
  return missing.length > 0 ? '当前暂未提供' + missing.join('与') + '，相关功能正在完善。' : null
})

const queryUnavailable = computed(() => queryCapabilityReason.value !== null)

function onLayerChange(value: string): void {
  exportNote.value = null
  store.setLayer(value === '' ? null : value)
}

/** 空间条件的中文摘要：界面、导出元数据与测试共用同一份文案。 */
const spatialSummary = computed<string | null>(() => {
  const draft = store.spatial
  if (draft === null) return null
  if (draft.source === 'region') {
    const region = props.regions.find((item) => item.id === draft.regionId)
    const predicate = draft.predicate === 'within' ? '覆盖' : '相交'
    return `行政区或流域：${region?.name ?? NOT_PROVIDED_TEXT}（按登记范围框） · ${predicate}`
  }
  if (draft.source === 'draw') {
    return `绘制范围 · ${draft.predicate === 'within' ? '覆盖' : '相交'}`
  }
  const label = draft.sourceLabel ?? NOT_PROVIDED_TEXT
  if (draft.predicate === 'nearest') {
    return `最近邻：以「${label}」为中心，限制半径 ${formatNumber(draft.distanceMeters)} 米内取最近 ${formatNumber(draft.limit)} 条`
  }
  return `对象缓冲：以「${label}」为中心 ${formatNumber(draft.distanceMeters)} 米`
})

const sortSummary = computed<string | null>(() => {
  const sort = store.sort
  if (sort === null) return null
  const field = store.layer?.fields.find((item) => item.key === sort.field)
  return `${field?.label ?? sort.field} ${sort.direction === 'asc' ? '升序' : '降序'}`
})

function buildMeta(
  scope: ExportScope,
  exportedCount: number,
  complete: boolean,
  total: number,
  notes: string[],
): ExportMeta {
  const context = store.context
  const layer = store.layer
  const mode: DataMode = context?.mode ?? 'mock'
  return {
    modeLabel: DATA_MODE_LABEL[mode],
    snapshotId: context?.snapshotId ?? NOT_PROVIDED_TEXT,
    scopeLabel: context?.scopeLabel ?? NOT_PROVIDED_TEXT,
    boundaryVersion: context?.boundaryVersion ?? NOT_PROVIDED_TEXT,
    datasetVersion: context && layer ? (context.datasetVersions[layer.datasetId] ?? null) : null,
    layerId: layer?.id ?? NOT_PROVIDED_TEXT,
    layerLabel: layer?.label ?? NOT_PROVIDED_TEXT,
    conditions: store.conditionsText(props.dictionaries),
    spatial: spatialSummary.value,
    distanceMethod: store.nearestDistances !== null ? DISTANCE_METHOD_TEXT : null,
    sort: sortSummary.value,
    total,
    exportedCount,
    scope,
    complete,
    generatedAt: new Date().toISOString(),
    sample: mode === 'mock',
    notes,
  }
}

/**
 * 导出。范围由调用方（按钮）显式给出，没有含糊的默认：
 * 「全部匹配」会逐页受控按同一份已校验查询条件重新读取；取不到全部时文件内写明「不是全部结果」。
 */
async function exportRows(payload: {
  format: 'csv' | 'geojson'
  scope: ExportScope
}): Promise<void> {
  const layer = store.layer
  const queryId = store.queryId
  if (layer === null || queryId === null) return
  const notes: string[] = []
  let rows = store.rows
  let complete = true
  let total = store.total
  if (exporting.value) return
  exporting.value = true
  try {
    if (payload.scope === 'all') {
      // 固定用较大的服务端页大小逐页拉全部（与界面当前每页条数脱钩，见 queryWorkspace.fetchAll），
      // 并把进度实时写进 exportNote，避免大图层导出时界面像是卡住了。
      exportNote.value = `正在获取全部匹配记录（保护上限 ${formatCount(MAX_EXPORT_RECORDS)} 条，超限或缺页会标记为非完整）…`
      const outcome = await getQueryWorkspaceService().fetchAll(
        queryId,
        undefined,
        undefined,
        (loaded, total) => {
          exportNote.value = `正在获取全部匹配记录：已获取 ${formatCount(loaded)} / ${formatCount(total)} 条…`
        },
      )
      rows = outcome.rows
      complete = outcome.complete
      total = outcome.total
      if (outcome.note) notes.push(outcome.note)
    }
    if (store.spatial?.source === 'region') {
      notes.push('行政区条件按登记范围框参与判定，非行政边界多边形。')
    }
    const meta = buildMeta(payload.scope, rows.length, complete, total, notes)
    const base = exportFileName(layer.id, payload.scope, new Date())
    if (payload.format === 'csv') {
      const text = buildCsv({
        rows,
        columns: buildExportColumns(layer.fields, {
          withDistance: store.nearestDistances !== null,
        }),
        meta,
        dictionaries: props.dictionaries,
        distances: store.nearestDistances,
      })
      downloadText(`${base}.csv`, text, 'text/csv')
    } else {
      // 02 §7：GeoJSON 附带独立 metadata.json，不往 GeoJSON 里塞 crs 成员。
      downloadText(`${base}.geojson`, buildGeoJson(rows), 'application/geo+json')
      downloadText(`${base}.metadata.json`, buildMetadataJson(meta), 'application/json')
    }
    exportNote.value = `已导出「${EXPORT_SCOPE_LABEL[payload.scope]}」${formatCount(rows.length)} 条${
      complete ? '' : '（未取到全部，文件内已注明）'
    }。`
  } catch (unknownError) {
    const message = unknownError instanceof Error ? unknownError.message : String(unknownError)
    exportNote.value = `导出失败：${message || '读取数据时发生未知错误'}。未生成可冒充全量的文件。`
  } finally {
    exporting.value = false
  }
}

function useSelected(): void {
  const detail = mapStore.selected
  if (detail === null || detail.geometry === null) return
  store.updateSpatial({ sourceFeature: detail.ref, sourceLabel: detail.title })
}

function onRun(): void {
  if (queryUnavailable.value) return
  exportNote.value = null
  void store.run()
}
</script>

<template>
  <section class="query-panel" data-testid="query-panel" aria-label="属性与空间查询">
    <header class="query-head">
      <h3 class="query-title">属性与空间查询</h3>

      <label class="layer-row">
        <span>图层</span>
        <select
          class="control"
          data-testid="query-layer"
          :value="store.layerId ?? ''"
          @change="onLayerChange(($event.target as HTMLSelectElement).value)"
        >
          <option value="">选择图层…</option>
          <option v-for="layer in queryableLayers" :key="layer.id" :value="layer.id">
            {{ layer.label }}
          </option>
        </select>
      </label>

      <div class="action-row">
        <button
          type="button"
          class="btn btn--primary btn--small"
          data-testid="run-query"
          :disabled="queryUnavailable || store.layerId === null || store.status === 'loading'"
          :title="queryCapabilityReason ?? undefined"
          @click="onRun"
        >
          {{ store.status === 'loading' ? '查询中…' : '运行查询' }}
        </button>
        <button
          v-if="store.status === 'loading'"
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="cancel-query"
          @click="store.cancel()"
        >
          取消
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="clear-query"
          :disabled="store.conditions.length === 0 && store.spatial === null && store.sort === null"
          @click="
            () => {
              store.clearConditions()
              emit('clearDraw')
              store.setSpatial(null)
              store.setSort(null)
            }
          "
        >
          清除条件
        </button>
      </div>
    </header>

    <p
      v-if="queryCapabilityReason"
      class="panel-warn panel-warn--capability"
      data-testid="query-capability-notice"
    >
      {{ queryCapabilityReason }}
    </p>

    <p v-if="blockReason" class="panel-warn" data-testid="query-block-reason">{{ blockReason }}</p>

    <div class="query-body">
      <QueryFilterPanel :dictionaries="props.dictionaries" />
      <QuerySpatialPanel
        :regions="props.regions"
        :selected-title="mapStore.selected?.title ?? null"
        :selected-ref="mapStore.selected?.ref ?? null"
        :selected-has-geometry="mapStore.selected?.geometry != null"
        :draw-mode="props.drawMode"
        @start-draw="emit('startDraw', $event)"
        @clear-draw="emit('clearDraw')"
        @use-selected="useSelected"
      />
    </div>

    <p v-if="exportNote" class="panel-note" data-testid="export-note">{{ exportNote }}</p>

    <QueryResultTable
      :dictionaries="props.dictionaries"
      @locate="emit('locate', $event)"
      @export-rows="exportRows"
    />
  </section>
</template>

<style scoped>
.query-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.query-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.query-title {
  margin: 0;
  font-size: var(--font-size-body);
}

.layer-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.control {
  height: var(--control-height);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: var(--font-size-caption);
}

.action-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-left: auto;
}

.query-body {
  display: grid;
  grid-template-columns: minmax(0, 1fr) minmax(0, 1fr);
  gap: var(--space-3);
}

@media (max-width: 1023px) {
  .query-body {
    grid-template-columns: minmax(0, 1fr);
  }
}

.panel-warn {
  margin: 0;
  padding: var(--space-1) var(--space-2);
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.panel-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.btn--small {
  min-height: 28px;
  padding: 0 var(--space-3);
  font-size: var(--font-size-caption);
}
</style>
