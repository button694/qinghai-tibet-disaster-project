<script setup lang="ts">
/**
 * 查询结果表（03 §6-2、§6-5、§6-7）。
 *
 * 四条必须做对的展示：
 * 1. **全部匹配与本页数量分开显示**：`total` 是条件下的全部匹配数（翻页不变），
 *    `rows.length` 是本页条数；两者不得互相替代。
 * 2. **空结果与失败是两件事**：空结果是查到了 0 条（有结果），失败是没拿到结果——
 *    分别用 `query-empty` 与 `query-error` 呈现，不混用同一句「没有数据」。
 * 3. 行可定位并高亮；无几何记录的定位按钮禁用并说明原因（与阶段2 的对象列表一致）。
 * 4. 导出必须显式选择「当前页」或「全部匹配」，不允许存在含义不明的默认导出。
 */
import { computed, ref } from 'vue'

import EmptyState from '@/components/ui/EmptyState.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import {
  formatCount,
  formatFieldValue,
  formatMetricValue,
  formatNumber,
  NOT_PROVIDED_TEXT,
} from '@/domain/format'
import { dictionaryLabels, type DictionaryMap } from '@/domain/queryFields'
import type { FeatureRef, FieldDefinition } from '@/domain/types'
import { useQueryStore } from '@/stores/query'

const props = defineProps<{
  /** 代码字典：dictionaryId → 条目数组，用于把原始代码显示成中文标签。 */
  dictionaries: DictionaryMap
}>()

const emit = defineEmits<{
  locate: [ref: FeatureRef]
  exportRows: [payload: { format: 'csv' | 'geojson'; scope: 'page' | 'all' }]
}>()

const store = useQueryStore()

const columns = computed<FieldDefinition[]>(() => store.layer?.fields ?? [])

const showDistance = computed(() => store.nearestDistances !== null)

const pageInfo = computed(() =>
  store.hasResult
    ? `第 ${formatNumber(store.page)} / ${formatNumber(store.pageCount)} 页 · 本页 ${formatCount(store.rows.length)} 条`
    : '尚未查询',
)

/** 可选每页条数：服务端单页上限为 2000（见后端 app/config.py），这里同步开放到该上限。 */
const PAGE_SIZE_OPTIONS = [5, 10, 20, 50, 100, 200, 500, 1000, 2000]

/** 跳页输入框：只在失焦/回车时提交，避免每敲一位数字就触发一次查询。 */
const jumpPageInput = ref('')

function submitJumpPage(): void {
  const target = Number(jumpPageInput.value)
  if (!Number.isFinite(target) || target < 1) {
    jumpPageInput.value = ''
    return
  }
  void store.goToPage(Math.floor(target))
  jumpPageInput.value = ''
}

function cellValue(rowIndex: number, field: FieldDefinition): string {
  const row = store.rows[rowIndex]
  if (!row) return NOT_PROVIDED_TEXT
  const items =
    field.dictionaryId === undefined ? undefined : props.dictionaries[field.dictionaryId]
  return formatFieldValue(
    field,
    row.properties[field.key],
    items === undefined ? {} : { dictionary: dictionaryLabels(items) },
  )
}

function distanceOf(rowIndex: number): string {
  const row = store.rows[rowIndex]
  const distances = store.nearestDistances
  if (!row || !distances) return NOT_PROVIDED_TEXT
  const value = distances[`${row.ref.layerId}:${row.ref.id}`]
  return value === undefined ? NOT_PROVIDED_TEXT : `${formatNumber(Math.round(value))} 米`
}

function sortMark(field: string): string {
  if (store.sort?.field !== field) return ''
  return store.sort.direction === 'asc' ? '↑' : '↓'
}
</script>

<template>
  <section class="result-panel" data-testid="query-result" aria-label="查询结果">
    <header class="result-head">
      <span class="counts">
        全部匹配
        <strong data-testid="query-total">{{
          store.hasResult ? formatCount(store.total) : '—'
        }}</strong>
        条 · 本页
        <strong data-testid="query-page-count">{{ formatCount(store.rows.length) }}</strong>
        条
      </span>
      <span class="page-info" data-testid="query-page-info">{{ pageInfo }}</span>
      <span v-if="store.status === 'loading'" class="state" data-testid="query-loading"
        >查询中…</span
      >
      <label class="size-row">
        <span>每页</span>
        <select
          class="control"
          data-testid="query-page-size"
          :value="store.pageSize"
          @change="store.setPageSize(Number(($event.target as HTMLSelectElement).value))"
        >
          <option v-for="size in PAGE_SIZE_OPTIONS" :key="size" :value="size">{{ size }}</option>
        </select>
        <span>条</span>
      </label>
      <div class="export-row">
        <span class="export-label">导出</span>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="export-csv-page"
          :disabled="!store.hasResult"
          @click="emit('exportRows', { format: 'csv', scope: 'page' })"
        >
          CSV · 当前页
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="export-csv-all"
          :disabled="!store.hasResult"
          @click="emit('exportRows', { format: 'csv', scope: 'all' })"
        >
          CSV · 全部匹配
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="export-geojson-page"
          :disabled="!store.hasResult"
          @click="emit('exportRows', { format: 'geojson', scope: 'page' })"
        >
          GeoJSON · 当前页
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="export-geojson-all"
          :disabled="!store.hasResult"
          @click="emit('exportRows', { format: 'geojson', scope: 'all' })"
        >
          GeoJSON · 全部匹配
        </button>
      </div>
    </header>

    <ErrorState
      v-if="store.status === 'failed' && store.error"
      data-testid="query-error"
      title="查询失败"
      :error="store.error"
      :retryable="store.error.retryable"
    />

    <p v-else-if="store.status === 'idle'" class="state" data-testid="query-idle">
      设置条件后点「运行查询」。
    </p>

    <template v-else-if="store.hasResult">
      <!--
        指标始终显示（包括 0 条命中）：缓冲半径、距离方法与「因无几何被排除」的说明
        正是「为什么是 0 条」的解释，命中为空时恰恰最需要它们，不能随空状态一起藏掉。
      -->
      <ul v-if="store.metrics.length > 0" class="metric-row" data-testid="query-metrics">
        <li v-for="metric in store.metrics" :key="metric.key" class="metric">
          <span class="metric-label">{{ metric.label }}</span>
          <span class="metric-value">{{ formatMetricValue(metric) }}</span>
          <span class="metric-method">{{ metric.method }}</span>
        </li>
      </ul>

      <EmptyState
        v-if="store.total === 0"
        data-testid="query-empty"
        title="查询结果为 0 条"
        description="当前条件下没有命中任何记录。这是查询结果为空，不是服务失败：可放宽条件或换一个图层再查。"
      />

      <div v-else class="table-wrap">
        <table class="result-table" data-testid="query-table">
          <caption class="visually-hidden">
            查询结果表；行内「查看」可在地图上定位并高亮该对象
          </caption>
          <thead>
            <tr>
              <th
                v-for="field in columns"
                :key="field.key"
                scope="col"
                :aria-sort="
                  field.sortable && store.sort?.field === field.key
                    ? store.sort.direction === 'asc'
                      ? 'ascending'
                      : 'descending'
                    : undefined
                "
              >
                <button
                  v-if="field.sortable"
                  type="button"
                  class="sort-btn"
                  :aria-label="`${field.label}：${
                    store.sort?.field === field.key && store.sort.direction === 'asc'
                      ? '当前升序，点击改为降序'
                      : '点击按升序排列'
                  }`"
                  :data-testid="`sort-${field.key}`"
                  @click="store.setSort(field.key)"
                >
                  {{ field.label }}<span class="sort-mark">{{ sortMark(field.key) }}</span>
                </button>
                <span v-else>{{ field.label }}</span>
              </th>
              <th v-if="showDistance" scope="col">距离</th>
              <th scope="col">操作</th>
            </tr>
          </thead>
          <tbody>
            <tr
              v-for="(row, index) in store.rows"
              :key="`${row.ref.layerId}:${row.ref.id}`"
              :data-testid="`query-row-${row.ref.id}`"
            >
              <td v-for="field in columns" :key="field.key" class="cell">
                {{ cellValue(index, field) }}
              </td>
              <td v-if="showDistance" class="cell cell--num">{{ distanceOf(index) }}</td>
              <td class="cell">
                <button
                  type="button"
                  class="btn btn--ghost btn--small"
                  :disabled="row.geometry === null"
                  :title="row.geometry === null ? '该记录无几何，定位不可用' : '在地图上定位并高亮'"
                  :data-testid="`query-locate-${row.ref.id}`"
                  @click="emit('locate', row.ref)"
                >
                  定位
                </button>
                <span v-if="row.geometry === null" class="cell-reason">无几何，定位不可用</span>
              </td>
            </tr>
          </tbody>
        </table>
      </div>

      <footer v-if="store.total > 0" class="pager">
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="query-first"
          :disabled="store.page <= 1"
          @click="store.goToPage(1)"
        >
          首页
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="query-prev"
          :disabled="store.page <= 1"
          @click="store.goToPage(store.page - 1)"
        >
          上一页
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="query-next"
          :disabled="store.page >= store.pageCount"
          @click="store.goToPage(store.page + 1)"
        >
          下一页
        </button>
        <button
          type="button"
          class="btn btn--ghost btn--small"
          data-testid="query-last"
          :disabled="store.page >= store.pageCount"
          @click="store.goToPage(store.pageCount)"
        >
          末页
        </button>
        <label class="jump-row">
          <span>跳至</span>
          <input
            v-model="jumpPageInput"
            type="number"
            min="1"
            :max="store.pageCount"
            class="control jump-input"
            data-testid="query-jump-input"
            :placeholder="String(store.page)"
            @keyup.enter="submitJumpPage"
          />
          <span>页</span>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="query-jump-submit"
            @click="submitJumpPage"
          >
            跳转
          </button>
        </label>
      </footer>
    </template>
  </section>
</template>

<style scoped>
.result-panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
}

.result-head {
  display: flex;
  align-items: center;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.counts {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.counts strong {
  color: var(--color-text);
  font-variant-numeric: tabular-nums;
}

.page-info {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
  font-variant-numeric: tabular-nums;
}

.size-row {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.control {
  height: var(--control-height);
  padding: 0 var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: var(--font-size-caption);
}

.export-row {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  margin-left: auto;
  flex-wrap: wrap;
}

.export-label {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.state {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.metric-row {
  display: flex;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
  flex-wrap: wrap;
}

.metric {
  display: flex;
  flex-direction: column;
  gap: 2px;
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  max-width: 22rem;
}

.metric-label {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.metric-value {
  font-size: var(--font-size-body);
  font-weight: 600;
  font-variant-numeric: tabular-nums;
}

.metric-method {
  font-size: var(--font-size-caption);
  color: var(--color-muted);
  line-height: var(--line-height-tight);
}

.table-wrap {
  max-height: var(--result-table-height);
  overflow: auto;
}

.result-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.result-table th,
.result-table td {
  padding: var(--space-1) var(--space-2);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  vertical-align: top;
  white-space: nowrap;
}

.result-table thead th {
  position: sticky;
  top: 0;
  background: var(--color-surface);
  color: var(--color-muted);
  font-weight: 600;
  z-index: 1;
}

.sort-btn {
  padding: 0;
  border: 0;
  background: none;
  color: inherit;
  font: inherit;
  cursor: pointer;
}

.sort-mark {
  margin-left: 2px;
}

.cell {
  overflow-wrap: anywhere;
}

.cell--num {
  font-variant-numeric: tabular-nums;
}

.cell-reason {
  margin-left: var(--space-1);
  color: var(--color-muted);
}

.pager {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.jump-row {
  display: flex;
  align-items: center;
  gap: var(--space-1);
  margin-left: var(--space-2);
  font-size: var(--font-size-caption);
  color: var(--color-muted);
}

.jump-input {
  width: 4.5em;
  text-align: center;
}

.btn--small {
  min-height: 26px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}
</style>
