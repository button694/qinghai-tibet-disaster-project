/**
 * 图层注册表的前端视图配置（01 §5.1、§7.1）。
 *
 * 图层清单的**唯一来源**是接口注册表（`LayerRepository.listLayers`；示例模式下读
 * `public/demo/layers.json`）。本文件只做三件事，不含任何写死的图层 ID：
 * 1. 规定五个业务主题的展示顺序与分组（`sys` 系统元数据不作为地图图层）；
 * 2. 判断图层在当前数据包下是否「可渲染」，并给出面向用户的中文原因；
 * 3. 按名称 / ID / 主题 / 几何类型 / 数据集搜索图层。
 *
 * 与栅格有关的诚实口径（01 §5.6）：数据集「已登记」不等于「服务可用」，两者分开显示。
 */
import { GEOMETRY_FAMILY_LABEL, THEME_LABEL } from '@/domain/labels'
import type { GeometryFamily, LayerDefinition, MapSource, Theme } from '@/domain/types'

/** 地图工作台展示的五个业务主题，顺序固定（01 §5.1）。 */
export const MAP_THEMES = ['base', 'tnr', 'hazard', 'emg', 'result'] as const

export type MapTheme = (typeof MAP_THEMES)[number]

export function isMapTheme(theme: Theme): theme is MapTheme {
  return (MAP_THEMES as readonly string[]).includes(theme)
}

/** 五主题分组。空分组不渲染，但分组顺序与主题标签始终来自本表。 */
export interface ThemeGroup {
  theme: MapTheme
  label: string
  layers: LayerDefinition[]
}

/* ------------------------------------------------------------------ *
 * 可用性
 * ------------------------------------------------------------------ */

export interface LayerAvailability {
  /** 是否可以在地图上渲染几何。 */
  available: boolean
  /** 不可渲染时的中文原因（必填）；可渲染时为 null。 */
  reason: string | null
}

/**
 * 是否属于「矢量点线面」家族。MultiPoint / MultiLineString / MultiPolygon
 * 归入同一家族，不为适配单部件丢弃多部件（02 §3）。
 */
export function isVectorGeometry(layer: LayerDefinition): boolean {
  return (
    layer.geometryType === 'Point' ||
    layer.geometryType === 'LineString' ||
    layer.geometryType === 'Polygon'
  )
}

/**
 * 图层在本阶段是否可渲染，以及不可渲染的原因。
 *
 * 两种不可渲染情形必须区分，不能都写成「加载失败」：
 * - 栅格 / 表格：本阶段不渲染像元，只登记元数据（服务状态另见数据目录）；
 * - `source.type === 'unavailable'`：数据包明确声明服务未接入，原因来自数据包本身。
 */
export function layerAvailability(layer: LayerDefinition): LayerAvailability {
  if (layer.geometryType === 'Raster' || layer.geometryType === 'Table') {
    const scopeNote = `${GEOMETRY_FAMILY_LABEL[layer.geometryType]}图层：本阶段不渲染像元；数据集已登记，栅格服务是否可用以数据目录的服务状态为准。`
    // 数据包若已明确声明服务未接入，把它的原话附在后面，避免只给通用说明。
    return {
      available: false,
      reason:
        layer.source.type === 'unavailable'
          ? `${scopeNote}数据包声明：${layer.source.reason}`
          : scopeNote,
    }
  }
  if (layer.source.type === 'unavailable') {
    return { available: false, reason: layer.source.reason }
  }
  return { available: true, reason: null }
}

/* ------------------------------------------------------------------ *
 * 展示文案
 * ------------------------------------------------------------------ */

const MAP_SOURCE_LABEL: Record<MapSource['type'], string> = {
  geojson: '空间图层',
  xyz: '在线地图',
  wmts: '在线地图',
  wms: '在线地图',
  cog: '栅格图层',
  unavailable: '数据目录',
}

export function mapSourceLabel(source: MapSource): string {
  return MAP_SOURCE_LABEL[source.type]
}

/** 图层类型文案，例如「面 · 空间图层」。 */
export function layerTypeText(layer: LayerDefinition): string {
  return `${GEOMETRY_FAMILY_LABEL[layer.geometryType]} · ${mapSourceLabel(layer.source)}`
}

/** 图层的时相文案：无时相时明确写「未登记」，不推测年份（02 §2.4）。 */
export function layerTimeText(layer: LayerDefinition): string {
  const times = layer.availableTimes
  if (times.length === 0) return '时相未登记'
  const values = times.map((item) => item.value ?? '值未提供')
  return `时相 ${values.join(' / ')}`
}

/* ------------------------------------------------------------------ *
 * 搜索与分组
 * ------------------------------------------------------------------ */

/** 图层搜索：中文名、layerId、主题名、几何类型、数据集 ID 都可命中。 */
export function matchesLayerSearch(layer: LayerDefinition, keyword: string): boolean {
  const needle = keyword.trim().toLowerCase()
  if (needle === '') return true
  const haystack = [
    layer.label,
    layer.id,
    layer.datasetId,
    THEME_LABEL[layer.theme],
    GEOMETRY_FAMILY_LABEL[layer.geometryType],
    mapSourceLabel(layer.source),
  ]
    .join(' ')
    .toLowerCase()
  return haystack.includes(needle)
}

/**
 * 按五主题分组。`layers` 的顺序由注册表（Repository）决定，本函数只分组、不重排，
 * 组内顺序即注册表顺序；空分组不返回。
 */
export function groupLayersByTheme(layers: LayerDefinition[], keyword = ''): ThemeGroup[] {
  const groups: ThemeGroup[] = []
  for (const theme of MAP_THEMES) {
    const matched = layers.filter(
      (layer) => layer.theme === theme && matchesLayerSearch(layer, keyword),
    )
    if (matched.length === 0) continue
    groups.push({ theme, label: THEME_LABEL[theme], layers: matched })
  }
  return groups
}

/** 注册表中属于地图工作台的图层（排除系统元数据主题）。 */
export function mapLayersOf(layers: LayerDefinition[]): LayerDefinition[] {
  return layers.filter((layer) => isMapTheme(layer.theme))
}

/**
 * 初始叠放顺序（数组首位＝最上层）。
 *
 * 注册表按**业务主题**排序（基础地理、地形与冰冻圈、灾害与情景……），这是分类顺序，
 * 不是叠放顺序。直接用注册表顺序会出现「研究区边界（面）压在居民地点之上」，
 * 点要素既看不见也点不中。因此这里按 GIS 常规做法分层：**点在上、线居中、面在下**，
 * 同一层内保持注册表顺序；用户仍可在图层树里逐层上下移动。
 */
const FAMILY_RANK: Record<GeometryFamily, number> = {
  Point: 2,
  LineString: 1,
  Polygon: 0,
  Raster: 0,
  Table: 0,
}

export function initialDrawOrder(layers: LayerDefinition[]): string[] {
  return [...layers]
    .map((layer, index) => ({ layer, index }))
    .sort((a, b) => {
      // 数组首位＝最上层：先按家族从高到低，再按注册表顺序（同家族不因排序而倒置）。
      const rankDiff = FAMILY_RANK[b.layer.geometryType] - FAMILY_RANK[a.layer.geometryType]
      return rankDiff !== 0 ? rankDiff : a.index - b.index
    })
    .map((item) => item.layer.id)
}
