/**
 * 地图渲染配色与 OpenLayers 样式（01 §4.2、§4.5、§5.1）。
 *
 * 为什么要单独一份颜色常量：OpenLayers 的 canvas 样式只接受具体颜色字符串，
 * 不能直接使用 CSS `var(--...)`；因此地图专用颜色在本文件集中定义，
 * 并由 `tests/unit/map-style.spec.ts` 解析 `src/styles/tokens.css` 交叉校验，
 * 任何一处漂移都会让单测变红（与 `domain/risk.ts` 的做法一致，D-018 / D-030）。
 *
 * 三条硬规则：
 * 1. **选择色与风险色分开**：选中态只用 `--color-focus` 蓝白双描边，绝不复用风险红；
 * 2. **只显示要素自带的风险等级，不计算等级**：仅当图层字段字典里登记了 `riskLevel`
 *    （字典 `dict.risk-level`）时才按该字段着色；其余图层按主题配色区分。
 *    2050/2100 情景点没有正式阈值，只用文件末尾的统一连续色域（`SCENARIO_RAMP`），
 *    不派生任何等级名。
 * 3. **分类着色只认注册表里已声明的字段取值，不发明等级**：`CATEGORICAL_FIELD_RAMPS`
 *    只覆盖数据库里已查证的两个枚举字段（危险等级、道路等级），颜色顺序只用来让同一字段
 *    单调排列（底图 `MAP_COLORS.background = #152635` 是深藏蓝，所以单调性体现为
 *    越重要/越高等级越亮、对比度越高，而不是越深——见 CATEGORICAL_FIELD_RAMPS 上方注释）；
 *    同一档同时用色相 + 尺寸（点半径 / 线宽）编码，不再只靠明度区分（见该常量上方注释的
 *    「区分度不足」返工记录）；图例与地图上必须原样显示源数据取值文字，不改写、不翻译。
 *
 * 图层之间、同一图层不同取值之间如何可辨（本次针对“图例全部相同”的修复）：
 * - 6 个业务主题（`THEME_COLOR`）各有一个主色，未登记分类字段的图层按主题上色；
 * - 点图层再按 `pointShapeFor()` 从 5 种形状中取一种，同一主题内的点图层也能靠形状区分，
 *   形状本身不承载任何业务语义，只是视觉区分手段；
 * - `MapLegend.vue` 通过本文件导出的同一套函数（`riskColorField` / `categoricalColorField` /
 *   `THEME_COLOR` / `pointShapeFor`）计算图例符号，保证图例与地图渲染规则永远一致。
 */
import type { FeatureLike } from 'ol/Feature'
import { Circle, Fill, RegularShape, Stroke, Style } from 'ol/style'

import { isRiskLevel, RISK_LEVEL_COLOR, toRiskLevel } from '@/domain/risk'
import type { LayerDefinition, Theme } from '@/domain/types'

/** 地图专用配色。取值来自 `src/styles/tokens.css`，由单测交叉校验。 */
export const MAP_COLORS = {
  background: '#152635',
  pointFill: '#087f8c',
  pointStroke: '#ffffff',
  geometryStroke: '#4b9bc7',
  polygonFill: '#bde8f5',
  selectionStroke: '#176bca',
  selectionHalo: '#ffffff',
  hatchStroke: '#ffffff',
  /** 阶段3：绘制范围与命中高亮（查询专用色，与选中蓝、风险红分开）。 */
  queryStroke: '#de7c3b',
  /**
   * 本次修复新增：六个业务主题各一个主色（01 §5.1 的主题分组），
   * 未登记分类字段的图层按主题上色，替代此前「所有图层同一青色圆点/浅蓝面」的问题。
   */
  themeBase: '#5b6b7a',
  themeTnr: '#3f8fb0',
  themeHazard: '#a8522f',
  themeEmg: '#7f63b8',
  themeResult: '#a15c8a',
  themeSys: '#7c8791',
} as const

/** 每个地图颜色对应的令牌名，供单测比对 tokens.css。 */
export const MAP_COLOR_TOKENS: Record<keyof typeof MAP_COLORS, string> = {
  background: '--color-map-bg',
  pointFill: '--color-primary',
  pointStroke: '--color-surface',
  geometryStroke: '--color-water',
  polygonFill: '--color-glacier',
  selectionStroke: '--color-focus',
  selectionHalo: '--color-surface',
  hatchStroke: '--color-surface',
  queryStroke: '--color-map-query',
  themeBase: '--color-theme-base',
  themeTnr: '--color-theme-tnr',
  themeHazard: '--color-theme-hazard',
  themeEmg: '--color-theme-emg',
  themeResult: '--color-theme-result',
  themeSys: '--color-theme-sys',
}

/** 按主题查主色，供 `baseLayerStyle` / `createLayerStyleFunction` / 图例共用同一份取色规则。 */
export const THEME_COLOR: Record<Theme, string> = {
  base: MAP_COLORS.themeBase,
  tnr: MAP_COLORS.themeTnr,
  hazard: MAP_COLORS.themeHazard,
  emg: MAP_COLORS.themeEmg,
  result: MAP_COLORS.themeResult,
  sys: MAP_COLORS.themeSys,
}

/**
 * 点图层的可用形状（仅视觉区分，不承载业务语义）。`Circle` 之外的形状用
 * `RegularShape` 实现——OpenLayers 的 `Circle` 只能画圆，无法画三角/方/菱/星。
 */
export const POINT_SHAPES = ['circle', 'triangle', 'square', 'diamond', 'star'] as const
export type PointShapeKind = (typeof POINT_SHAPES)[number]

/** 简单字符串哈希，仅用于从固定形状列表里稳定取一个索引，不用于任何安全用途。 */
function hashLayerId(id: string): number {
  let hash = 0
  for (let index = 0; index < id.length; index += 1) {
    hash = (hash * 31 + id.charCodeAt(index)) >>> 0
  }
  return hash
}

/** 按图层 ID 稳定选形状：同一图层每次渲染都取同一形状，同主题内的点图层因此可辨。 */
export function pointShapeFor(layer: LayerDefinition): PointShapeKind {
  const index = hashLayerId(layer.id) % POINT_SHAPES.length
  return POINT_SHAPES[index] ?? 'circle'
}

/**
 * 显式的字段→有序取值配色表。只覆盖已在数据库里查证过的两个枚举字段：
 * - `hazardLevel`（危险等级，取值 中/高/极高，来自 `HAZ_LEVEL`）；
 * - `roadGrade`（道路等级，取值 高速/一级/二级/三级/四级/等外，来自 `road_grade`）。
 * `value` 必须与源数据取值逐字相同，图例与地图都原样显示这个字符串；
 * 顺序只用于让颜色单调变化，不生成任何等级名；未出现在列表里的取值按数据不足处理。
 *
 * 颜色方向：底图 `MAP_COLORS.background = #152635` 是深藏蓝，所以“单调排列”必须是
 * **越重要/越高等级越亮、对比度越高**，否则最需要被看见的类别（危险等级“极高”、道路“高速”）
 * 会糊进深色底图里。每个取值与底色的对比度都 ≥ 3.0（WCAG 相对亮度公式）。
 *
 * 第二轮返工记录（区分度不足）：第一轮只约束了「与底色对比度 ≥3.0」，结果每个字段都做成了
 * 单一色相、只改明度的色带——hazardLevel 三档色相只差 0.2°~1.3°，roadGrade 六档色相只差
 * 0.2°~0.9°，肉眼基本看不出深浅之外的区别。改为**色相 + 明度 + 尺寸三重编码**：
 * - hazardLevel（只有 3 档，不放宽）：相邻档位色相差 ≥35°、相邻对比度 ≥1.8，
 *   同时每档与底色对比度 ≥3.0；点符号半径按 `size` 递增（见 familyStyle 的 pointRadius）。
 *   （本字段第二轮验收通过后未再改动。）
 * - roadGrade（6 档）：第二轮曾用「相邻色相差 ≥25° 或相邻对比度 ≥2.2」放宽，结果后四档
 *   （三级/二级/一级/高速）全是高明度低饱和的淡绿、相邻对比度只有 1.01~1.12（肉眼分不出明暗），
 *   只靠色相角差在低饱和度下几乎不起感知作用，数学过了但眼睛没过，被打回。
 *
 * 第三轮返工记录（roadGrade，ΔE 硬指标）：改用不可规避的 CIE76 ΔE（Lab 欧氏距离）作为主指标，
 * 不再允许色相角/对比度二选一放宽：
 * - 相邻档位 ΔE ≥22（CIE76）；
 * - 相邻档位对比度 ≥1.35（明度必须有真实差异，不允许再出现 ~1.0x 的同明度相邻对）；
 * - 每档与底色对比度仍 ≥3.0，且沿等外→高速单调递增；
 * - 与全部专用色（选中蓝 `#176bca`、查询橙/风险较高 `#de7c3b`、影响范围红/风险高 `#bf454b`、
 *   风险低 `#3d8f78`、风险较低 `#8bae69`、风险中 `#d8b24c`、风险数据不足 `#929eab`）的 ΔE ≥25，
 *   避免被误读成风险分级或影响范围。
 * 色相改走青→蓝→紫→品红（约 192°→330°），与 hazardLevel 的蓝紫品红（约 235°→331°）同属冷色系
 * 但角度错开、且靠饱和度与线宽两个维度进一步区分（roadGrade 是线状要素、hazardLevel 是点状要素），
 * 同时依旧避开绿-黄-橙-红的风险色带语义。线宽按 `size`（道路场景语义为线宽像素）递增，
 * 高速最粗、等外最细。
 *
 * 数值全部由 `tests/unit/map-style.spec.ts` 用同一套 WCAG 对比度 / HSL 色相 / CIE76 ΔE 公式
 * 重新算出并断言，任何人再改色都会被单测拦下来，不会退化回单一色相色带或同明度相邻对。
 *
 * 颜色不得与 `RISK_LEVEL_COLOR`、`--color-focus`、`--color-map-query`、`--color-impact-area` 重复：
 * hazardLevel 用蓝→紫→品红的色相路径（易发性等级不是本项目的风险等级，刻意避开
 * 绿-黄-橙-红那种典型风险色带语义，也避开与选中蓝 `#176bca`、数据不足灰过近的色相）；
 * roadGrade 用青→蓝→紫→品红的色相路径，同样避开风险色带语义。
 */
export interface CategoricalColorEntry {
  value: string
  color: string
  token: string
  /**
   * 尺寸编码：点图层（hazardLevel）语义是符号半径（像素），线图层（roadGrade）语义是线宽（像素）。
   * 由 `createLayerStyleFunction` 按图层几何类型分别喂给 `familyStyle` 的 `pointRadius` / `lineWidth`，
   * `MapLegend.vue` 用同一个值缩放图例色块，保证图例与地图渲染的尺寸差异一致。
   */
  size: number
}

export const CATEGORICAL_FIELD_RAMPS: Record<string, CategoricalColorEntry[]> = {
  hazardLevel: [
    { value: '中', color: '#646ed8', token: '--color-field-hazard-level-medium', size: 4.5 },
    { value: '高', color: '#cf98e1', token: '--color-field-hazard-level-high', size: 6 },
    { value: '极高', color: '#f9e2ed', token: '--color-field-hazard-level-extreme', size: 8 },
  ],
  roadGrade: [
    { value: '等外', color: '#25788d', token: '--color-field-road-grade-none', size: 1.5 },
    { value: '四级', color: '#6786bc', token: '--color-field-road-grade-4', size: 2 },
    { value: '三级', color: '#9e8fff', token: '--color-field-road-grade-3', size: 2.5 },
    { value: '二级', color: '#c0aff8', token: '--color-field-road-grade-2', size: 3 },
    { value: '一级', color: '#eacff2', token: '--color-field-road-grade-1', size: 3.5 },
    { value: '高速', color: '#fefafc', token: '--color-field-road-grade-expressway', size: 4.5 },
  ],
}

/** 该图层是否登记了 `CATEGORICAL_FIELD_RAMPS` 里配置的分类字段（注册表驱动，不认图层 ID）。 */
export function categoricalColorField(
  layer: LayerDefinition,
): { field: string; values: CategoricalColorEntry[] } | null {
  for (const [field, values] of Object.entries(CATEGORICAL_FIELD_RAMPS)) {
    if (layer.fields.some((item) => item.key === field)) return { field, values }
  }
  return null
}

/** 风险等级字典 ID：图层字段字典里出现它，才按要素自带的等级着色。 */
export const RISK_LEVEL_DICTIONARY_ID = 'dict.risk-level'

/** 数据不足的斜线纹理；CanvasPattern 不可用时回落纯色（01 §4.2 要求纹理或文字至少其一）。 */
let hatchPattern: CanvasPattern | null | undefined

function hatchFillColor(): string | CanvasPattern {
  if (hatchPattern === undefined) {
    hatchPattern = null
    if (typeof document !== 'undefined') {
      const canvas = document.createElement('canvas')
      canvas.width = 6
      canvas.height = 6
      const context = canvas.getContext('2d')
      if (context) {
        context.strokeStyle = MAP_COLORS.hatchStroke
        context.lineWidth = 1.4
        context.beginPath()
        context.moveTo(-1, 7)
        context.lineTo(7, -1)
        context.stroke()
        hatchPattern = context.createPattern(canvas, 'repeat')
      }
    }
  }
  return hatchPattern ?? RISK_LEVEL_COLOR.insufficient
}

/** 供单测重置纹理缓存。 */
export function resetHatchPattern(): void {
  hatchPattern = undefined
}

/* ------------------------------------------------------------------ *
 * 样式
 * ------------------------------------------------------------------ */

/** Fill/Stroke 都能接色，但 `Stroke` 不接受 CanvasPattern；纹理只用在面/点填充上，线一律回落纯色。 */
function resolveSolidColor(color: string | CanvasPattern): string {
  return typeof color === 'string' ? color : RISK_LEVEL_COLOR.insufficient
}

/** 各形状在默认半径（5px，对应 `DEFAULT_POINT_RADIUS`）下的基础尺寸，仅用于形状之间的视觉配平。 */
const SHAPE_BASE_RADIUS: Record<Exclude<PointShapeKind, 'circle'>, number> = {
  triangle: 6,
  square: 5,
  diamond: 6,
  star: 7,
}

/** 点符号的默认半径；分类字段（`CATEGORICAL_FIELD_RAMPS`）按取值传入更大/更小的半径覆盖它。 */
export const DEFAULT_POINT_RADIUS = 5

/**
 * 按形状构造点符号：`circle` 用 `Circle`，其余用 `RegularShape`（01 §4.2 不能只靠颜色区分）。
 *
 * `radius` 是调用方按等级传入的实际半径（默认 5px）；非圆形状按 `radius / DEFAULT_POINT_RADIUS`
 * 等比缩放自己的基础尺寸，保证「同一等级、不同形状」的视觉分量大致相当，不会因为形状不同
 * 而让尺寸编码失真（返工新增：尺寸编码是本轮提升区分度的核心手段之一）。
 */
function pointImage(
  shape: PointShapeKind,
  fillColor: string,
  strokeColor: string,
  radius: number = DEFAULT_POINT_RADIUS,
): Circle | RegularShape {
  const fill = new Fill({ color: fillColor })
  const stroke = new Stroke({ color: strokeColor, width: 1.2 })
  const scale = radius / DEFAULT_POINT_RADIUS
  switch (shape) {
    case 'triangle':
      return new RegularShape({ points: 3, radius: SHAPE_BASE_RADIUS.triangle * scale, fill, stroke })
    case 'square':
      return new RegularShape({
        points: 4,
        radius: SHAPE_BASE_RADIUS.square * scale,
        angle: Math.PI / 4,
        fill,
        stroke,
      })
    case 'diamond':
      return new RegularShape({ points: 4, radius: SHAPE_BASE_RADIUS.diamond * scale, fill, stroke })
    case 'star':
      return new RegularShape({
        points: 5,
        radius: SHAPE_BASE_RADIUS.star * scale,
        radius2: 3 * scale,
        fill,
        stroke,
      })
    case 'circle':
    default:
      return new Circle({ radius, fill, stroke })
  }
}

/** 线图层的默认线宽；分类字段（`roadGrade`）按取值传入更粗/更细的线宽覆盖它。 */
export const DEFAULT_LINE_WIDTH = 1.5

/**
 * 点图层需要 image，线/面需要 stroke / fill；一套样式同时给出三者，OL 按几何取用。
 *
 * 修复：此前线的 `stroke` 与点的 `image.fill` 都写死同一固定色，语义色（风险等级/主题色）
 * 传进来也不起作用——这是「不同图层图例都相同」「同图层不同等级都相同」的直接原因。
 * 现在线描边与点填充都取传入的语义色；点的白色描边保留，保证深色底图上仍可见轮廓。
 *
 * 返工新增：`pointRadius` / `lineWidth` 让调用方（分类字段着色）按等级传入不同尺寸，
 * 与颜色一起构成「色相 + 明度 + 尺寸」三重编码，不再只靠颜色区分同一图层的不同取值。
 */
function familyStyle(
  fillColor: string | CanvasPattern,
  options: { pointShape?: PointShapeKind; pointRadius?: number; lineWidth?: number } = {},
): Style {
  const solid = resolveSolidColor(fillColor)
  return new Style({
    fill: new Fill({ color: fillColor }),
    stroke: new Stroke({ color: solid, width: options.lineWidth ?? DEFAULT_LINE_WIDTH }),
    image: pointImage(options.pointShape ?? 'circle', solid, MAP_COLORS.pointStroke, options.pointRadius),
  })
}

/** 该图层是否声明了可用于着色的风险等级字段（注册表驱动，不认图层 ID）。 */
export function riskColorField(layer: LayerDefinition): string | null {
  const field = layer.fields.find(
    (item) => item.key === 'riskLevel' && item.dictionaryId === RISK_LEVEL_DICTIONARY_ID,
  )
  return field?.key ?? null
}

/**
 * 背景面图层：基础地理主题里**不可查询**的面（示例研究区边界即属此类，01 §5.1 把它列为背景）。
 *
 * 若与数据面同色，整个研究区会被涂成与其它面一样的颜色，数据反而看不清。
 * 这里让背景面使用地图底色填充，只留描边，既符合「背景」定位，也保留点击命中（面仍有填充）。
 * 规则只依赖注册表字段，不认图层 ID。
 */
export function isBackgroundPolygon(layer: LayerDefinition): boolean {
  return layer.theme === 'base' && layer.geometryType === 'Polygon' && !layer.queryable
}

/** 该图层按几何类型取用的点形状；非点图层不需要形状，返回 `undefined` 让样式退回默认圆点。 */
function shapeOf(layer: LayerDefinition): PointShapeKind | undefined {
  return layer.geometryType === 'Point' ? pointShapeFor(layer) : undefined
}

/**
 * 基础样式：未登记分类字段的图层按所属主题上色，背景面使用地图底色填充。
 * 点图层再叠加按图层区分的形状，同主题内的多个点图层因此仍可分辨。
 */
export function baseLayerStyle(layer?: LayerDefinition): Style {
  if (layer === undefined) return familyStyle(MAP_COLORS.polygonFill)
  if (isBackgroundPolygon(layer)) return familyStyle(MAP_COLORS.background, { pointShape: shapeOf(layer) })
  const themeColor = THEME_COLOR[layer.theme] ?? MAP_COLORS.polygonFill
  return familyStyle(themeColor, { pointShape: shapeOf(layer) })
}

/** 要素自带风险等级时的样式：填充取等级色，数据不足叠加斜线纹理。 */
export function riskLevelStyle(value: string, layer?: LayerDefinition): Style {
  const level = toRiskLevel(value)
  const fill = level === 'insufficient' ? hatchFillColor() : RISK_LEVEL_COLOR[level]
  return familyStyle(fill, { pointShape: layer !== undefined ? shapeOf(layer) : undefined })
}

/**
 * 图层样式函数。样式按「取值」缓存，避免每帧为每个要素新建样式对象。
 *
 * 三级优先：
 * 1. 登记了 `dict.risk-level` 字段——按要素自带的风险等级着色（不计算等级）；
 * 2. 登记了 `CATEGORICAL_FIELD_RAMPS` 里配置的分类字段——按要素取值原样查色，
 *    未配置的取值或缺失一律按「数据不足」处理，不猜成中间等级；
 * 3. 都没有——按图层所属主题给一个固定颜色（+ 点图层的固定形状）。
 */
export function createLayerStyleFunction(
  layer: LayerDefinition,
): (feature: FeatureLike, resolution: number) => Style {
  const riskField = riskColorField(layer)
  const categorical = categoricalColorField(layer)
  const shape = shapeOf(layer)
  const themeColor = THEME_COLOR[layer.theme] ?? MAP_COLORS.polygonFill
  const cache = new Map<string, Style>()

  return (feature: FeatureLike): Style => {
    let key: string
    let build: () => Style
    if (riskField !== null) {
      key = `risk:${String(feature.get(riskField) ?? 'insufficient')}`
      build = () => {
        const raw = String(feature.get(riskField) ?? 'insufficient')
        return isRiskLevel(raw) ? riskLevelStyle(raw, layer) : baseLayerStyle(layer)
      }
    } else if (categorical !== null) {
      const raw = feature.get(categorical.field)
      const value = typeof raw === 'string' && raw.length > 0 ? raw : null
      key = `cat:${value ?? 'insufficient'}`
      build = () => {
        const match = value === null ? undefined : categorical.values.find((item) => item.value === value)
        const fill = match ? match.color : hatchFillColor()
        // 尺寸编码：点图层的 size 是符号半径，线图层的 size 是线宽；未匹配到取值时用默认尺寸，
        // 不猜成某一档的大小（与颜色回落「数据不足」的原则一致）。
        const sizeOptions =
          match === undefined
            ? {}
            : layer.geometryType === 'Point'
              ? { pointRadius: match.size }
              : layer.geometryType === 'LineString'
                ? { lineWidth: match.size }
                : {}
        return familyStyle(fill, { pointShape: shape, ...sizeOptions })
      }
    } else {
      key = 'default'
      build = () => familyStyle(themeColor, { pointShape: shape })
    }
    const cached = cache.get(key)
    if (cached) return cached
    const created = build()
    cache.set(key, created)
    return created
  }
}

/**
 * 选中高亮：蓝白双描边，只用焦点色，与风险等级配色完全分开（01 §4.2）。
 * 返回两个样式，后一个绘制在上层。
 */
export function selectionStyles(): Style[] {
  return [
    new Style({
      stroke: new Stroke({ color: MAP_COLORS.selectionHalo, width: 5 }),
      image: new Circle({ radius: 9, fill: new Fill({ color: MAP_COLORS.selectionHalo }) }),
    }),
    new Style({
      stroke: new Stroke({ color: MAP_COLORS.selectionStroke, width: 2.5 }),
      image: new Circle({ radius: 6, fill: new Fill({ color: MAP_COLORS.selectionStroke }) }),
    }),
  ]
}

/** 供单测断言：选中色不得等于任何风险等级色。 */
export function selectionColor(): string {
  return MAP_COLORS.selectionStroke
}

/**
 * 阶段3：绘制范围（框选 / 多边形 / 行政区）的样式——橙色虚线 + 极淡填充。
 *
 * 用虚线而不是实线，是为了与「数据图层」本身区分：它不是数据，
 * 只是本次查询的范围；橙色也不与选中蓝、风险红冲突。
 */
export function spatialAreaStyle(): Style {
  return new Style({
    fill: new Fill({ color: 'rgba(222, 124, 59, 0.10)' }),
    stroke: new Stroke({ color: MAP_COLORS.queryStroke, width: 2.5, lineDash: [8, 5] }),
    image: new Circle({
      radius: 5,
      fill: new Fill({ color: 'rgba(222, 124, 59, 0.10)' }),
      stroke: new Stroke({ color: MAP_COLORS.queryStroke, width: 2.5 }),
    }),
  })
}

/**
 * 阶段3：查询命中集合的高亮（覆盖层）。
 *
 * 与「选中」是两件事：选中是单个对象（蓝白双描边），命中集合是本次查询的全部本页结果
 * （橙色粗环）。两者可以同时出现，因此不能同色。
 */
export function queryHitStyles(): Style[] {
  return [
    new Style({
      stroke: new Stroke({ color: MAP_COLORS.queryStroke, width: 7 }),
      image: new Circle({
        radius: 11,
        stroke: new Stroke({ color: MAP_COLORS.queryStroke, width: 3 }),
      }),
    }),
  ]
}

/** 供单测断言：查询色不得等于选中色，也不得等于任何风险等级色。 */
export function queryColor(): string {
  return MAP_COLORS.queryStroke
}

/* ------------------------------------------------------------------ *
 * 阶段5：影响范围、受影响对象与已存路线
 * ------------------------------------------------------------------ */

/** 影响范围面（已存成果）：风险红半透明；与查询橙、选中蓝都不同。 */
export const IMPACT_AREA_COLOR = '#bf454b'
export const IMPACT_AREA_TOKEN = '--color-impact-area'

/** 已存路线（可达）：绿色系表达「通行」，与风险红语义相对。 */
export const ROUTE_LINE_COLOR = '#3d8f78'
export const ROUTE_LINE_TOKEN = '--color-route-line'

/** 影响范围面样式：半透明红填充 + 红描边；选中时加深描边。 */
export function impactAreaStyle(selected = false): Style {
  return new Style({
    fill: new Fill({ color: 'rgba(191, 69, 75, 0.18)' }),
    stroke: new Stroke({
      color: IMPACT_AREA_COLOR,
      width: selected ? 3.5 : 2,
      lineDash: selected ? undefined : [6, 4],
    }),
  })
}

/** 受影响对象样式：按几何家族取基础配色；选中对象交给 selectionStyles 覆盖层。 */
export function affectedFeatureStyle(family: 'Point' | 'LineString' | 'Polygon'): Style {
  switch (family) {
    case 'Point':
      return new Style({
        image: new Circle({
          radius: 5,
          fill: new Fill({ color: MAP_COLORS.pointFill }),
          stroke: new Stroke({ color: MAP_COLORS.pointStroke, width: 1 }),
        }),
      })
    case 'LineString':
      return new Style({
        stroke: new Stroke({ color: MAP_COLORS.geometryStroke, width: 3 }),
      })
    case 'Polygon':
      return new Style({
        fill: new Fill({ color: 'rgba(189, 232, 245, 0.28)' }),
        stroke: new Stroke({ color: MAP_COLORS.geometryStroke, width: 1.5 }),
      })
  }
}

/**
 * 已存路线样式：主方案实线加粗，备选方案虚线；角色未登记（unregistered）同样用
 * 虚线但更细——不把未登记角色画成主方案样式（B3：缺失不能变成主方案或备选）。
 */
export function routeLineStyle(role: 'primary' | 'alternative' | 'unregistered'): Style {
  return new Style({
    stroke: new Stroke({
      color: ROUTE_LINE_COLOR,
      width: role === 'primary' ? 4.5 : role === 'alternative' ? 3 : 2,
      lineDash: role === 'primary' ? undefined : [10, 7],
    }),
  })
}

/** 路线起终点标记：终点用焦点蓝，起点用路线绿；都不是风险红。 */
export function routeEndpointStyle(kind: 'origin' | 'destination'): Style {
  const color = kind === 'origin' ? ROUTE_LINE_COLOR : MAP_COLORS.selectionStroke
  return new Style({
    image: new Circle({
      radius: 7,
      fill: new Fill({ color }),
      stroke: new Stroke({ color: MAP_COLORS.pointStroke, width: 2 }),
    }),
  })
}

/** 路线风险段/阻断点标记：风险红环，表达「该段需核实」，不表达等级。 */
export function routeRiskSegmentStyle(): Style {
  return new Style({
    image: new Circle({
      radius: 8,
      fill: new Fill({ color: 'rgba(191, 69, 75, 0.35)' }),
      stroke: new Stroke({ color: IMPACT_AREA_COLOR, width: 2.5 }),
    }),
  })
}

/* ------------------------------------------------------------------ *
 * 阶段4：2050/2100 未来情景的连续色域（无正式阈值，不做等级化）
 * ------------------------------------------------------------------ */

/** 情景连续色域的色标（低 → 高），取值来自 tokens.css 的 --color-scenario-ramp-*。 */
export const SCENARIO_RAMP: Array<{ offset: number; color: string; token: string }> = [
  { offset: 0, color: '#17395a', token: '--color-scenario-ramp-0' },
  { offset: 0.25, color: '#1f6f79', token: '--color-scenario-ramp-1' },
  { offset: 0.5, color: '#3d8f78', token: '--color-scenario-ramp-2' },
  { offset: 0.75, color: '#d8b24c', token: '--color-scenario-ramp-3' },
  { offset: 1, color: '#de7c3b', token: '--color-scenario-ramp-4' },
]

/** 指标值缺失（null）时的点色：数据不足灰，与色带任何一段都不同。 */
export const SCENARIO_NULL_COLOR = '#929eab'
export const SCENARIO_NULL_TOKEN = '--color-risk-insufficient'

function hexToRgb(hex: string): [number, number, number] {
  return [
    Number.parseInt(hex.slice(1, 3), 16),
    Number.parseInt(hex.slice(3, 5), 16),
    Number.parseInt(hex.slice(5, 7), 16),
  ]
}

/**
 * 在统一色域上取色：[0,1] 线性插值，越界截断；null（缺失）返回数据不足灰。
 * 2050 与 2100 使用同一函数与同一色域，保证两期数值可比。
 */
export function scenarioRampColor(value: number | null): string {
  if (value === null || !Number.isFinite(value)) return SCENARIO_NULL_COLOR
  const clamped = Math.min(1, Math.max(0, value))
  for (let i = 1; i < SCENARIO_RAMP.length; i += 1) {
    const high = SCENARIO_RAMP[i]
    const low = SCENARIO_RAMP[i - 1]
    if (high === undefined || low === undefined) break
    if (clamped <= high.offset) {
      const t = high.offset === low.offset ? 0 : (clamped - low.offset) / (high.offset - low.offset)
      const from = hexToRgb(low.color)
      const to = hexToRgb(high.color)
      const channel = (a: number, b: number): string =>
        Math.round(a + (b - a) * t)
          .toString(16)
          .padStart(2, '0')
      return `#${channel(from[0], to[0])}${channel(from[1], to[1])}${channel(from[2], to[2])}`
    }
  }
  const top = SCENARIO_RAMP[SCENARIO_RAMP.length - 1]
  return top?.color ?? SCENARIO_NULL_COLOR
}
