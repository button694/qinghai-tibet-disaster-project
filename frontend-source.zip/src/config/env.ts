/**
 * 运行配置读取（阶段1 起同时提供数据层所需的目录配置）。
 *
 * 三种数据模式的定义见 01 §6.3：
 * - mock     当前独立开发与交互验收，界面持续显示“示例数据”
 * - snapshot 可选，真实导出成果离线答辩，显示“成果快照”与生成时间
 * - api      真实数据库与地图服务联调，失败不自动改用示例
 */
import type { DataMode } from '@/domain/types'

export type { DataMode }

const DATA_MODES: readonly DataMode[] = ['mock', 'snapshot', 'api']

function isDataMode(value: string): value is DataMode {
  return (DATA_MODES as readonly string[]).includes(value)
}

/**
 * 解析数据模式。缺省或非法值一律落到 mock，
 * 这样未配置环境的机器只会看到示例数据，不会误连正式接口。
 */
export function parseDataMode(raw: string | undefined): DataMode {
  if (raw === undefined || raw.trim() === '') {
    return 'mock'
  }
  const value = raw.trim()
  if (!isDataMode(value)) {
    console.warn(`[env] VITE_DATA_MODE="${value}" 不是 mock|snapshot|api，已按 mock 处理`)
    return 'mock'
  }
  return value
}

/** 去掉首尾斜杠，保证拼接路径时不会出现 `//`。 */
function normalizeBaseUrl(raw: string | undefined, fallback: string): string {
  const value = (raw ?? '').trim() || fallback
  return value.replace(/^\/+/, '').replace(/\/+$/, '')
}

export interface AppEnv {
  dataMode: DataMode
  apiBaseUrl: string
  defaultRoute: string
  /** 示例数据包目录（相对站点根）。 */
  demoBaseUrl: string
  /** 成果快照目录（相对站点根）。 */
  snapshotBaseUrl: string
}

export const appEnv: AppEnv = {
  dataMode: parseDataMode(import.meta.env.VITE_DATA_MODE),
  apiBaseUrl: import.meta.env.VITE_API_BASE_URL?.trim() || '/api/v1',
  defaultRoute: import.meta.env.VITE_DEFAULT_ROUTE?.trim() || '/overview',
  demoBaseUrl: `/${normalizeBaseUrl(import.meta.env.VITE_DEMO_BASE_URL, 'demo')}/`,
  snapshotBaseUrl: `/${normalizeBaseUrl(import.meta.env.VITE_SNAPSHOT_BASE_URL, 'snapshot')}/`,
}
