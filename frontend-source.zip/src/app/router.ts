/**
 * 路由表（阶段0 只建立页面骨架，各页业务在后续阶段实现）。
 *
 * 路径与一级导航依据 01 §3：
 * /overview、/map、/analysis/{risk,emergency}、
 * /results(/:resultId)、/catalog(/:datasetId)、/about。
 *
 * 本文件不产生副作用，便于单元测试直接引用 routes 做断言。
 */
import { createRouter, createWebHistory, createWebHashHistory, type RouteRecordRaw, type RouterHistory } from 'vue-router'

declare module 'vue-router' {
  interface RouteMeta {
    /** 页面标题，用于浏览器标题与面包屑 */
    title?: string
    /** 打印视图：AppShell 隐藏顶栏/页脚/导览，页面自带打印与返回按钮 */
    print?: boolean
  }
}

export const routes: RouteRecordRaw[] = [
  {
    path: '/rasters',
    name: 'rasters',
    component: () => import('@/views/RasterView.vue'),
    meta: { title: '真实栅格地图' },
  },
  {
    path: '/real-preview',
    name: 'real-preview',
    component: () => import('@/views/RealPreviewView.vue'),
    meta: { title: '真实数据预览' },
  },
  {
    path: '/',
    // 01 §3：默认首页为总览
    redirect: { name: 'overview' },
  },
  {
    path: '/overview',
    name: 'overview',
    component: () => import('@/views/OverviewView.vue'),
    meta: { title: '总览' },
  },
  {
    path: '/map',
    name: 'map',
    component: () => import.meta.env.VITE_PUBLISHED_SNAPSHOT === 'true' ? import('@/views/HazardExplorerView.vue') : import('@/views/MapView.vue'),
    meta: { title: '风险一张图' },
  },
  {
    path: '/layers',
    name: 'layers',
    component: () => import('@/views/MapView.vue'),
    meta: { title: '图层工作台' },
  },
  {
    path: '/analysis/risk',
    name: 'analysis-risk',
    component: () => import('@/views/RiskView.vue'),
    meta: { title: '风险研判' },
  },
  {
    path: '/analysis/emergency',
    name: 'analysis-emergency',
    component: () => import('@/views/EmergencyView.vue'),
    meta: { title: '应急保障' },
  },
  {
    path: '/results',
    name: 'results',
    component: () => import('@/views/ResultsView.vue'),
    meta: { title: '成果中心' },
  },
  {
    path: '/results/:resultId',
    name: 'result-detail',
    component: () => import('@/views/ResultDetailView.vue'),
    props: true,
    meta: { title: '成果详情' },
  },
  {
    path: '/catalog',
    name: 'catalog',
    component: () => import('@/views/CatalogView.vue'),
    meta: { title: '数据目录' },
  },
  {
    path: '/catalog/:datasetId',
    name: 'catalog-detail',
    component: () => import('@/views/CatalogDetailView.vue'),
    props: true,
    meta: { title: '数据集详情' },
  },
  {
    path: '/about',
    name: 'about',
    component: () => import('@/views/AboutView.vue'),
    meta: { title: '项目说明' },
  },
  {
    // 阶段8B：最小只读API垂直链路浏览页（仅 api 模式可用，页面内说明）
    path: '/api-data',
    name: 'api-data',
    component: () => import('@/views/ApiDataView.vue'),
    meta: { title: '数据服务状态' },
  },
  {
    // 阶段7：三类专题图打印视图（浏览器打印 PDF；独立布局，隐藏应用外壳）
    path: '/print/:kind(risk|emergency)',
    name: 'print',
    component: () => import('@/views/PrintView.vue'),
    props: true,
    meta: { title: '专题图打印', print: true },
  },
  {
    // 404 兜底，必须放在最后一条
    path: '/:pathMatch(.*)*',
    name: 'not-found',
    component: () => import('@/views/NotFoundView.vue'),
    meta: { title: '页面不存在' },
  },
]

export function createAppRouter(history?: RouterHistory) {
  return createRouter({
    history: history ?? (import.meta.env.VITE_PUBLISHED_SNAPSHOT === 'true' ? createWebHashHistory(import.meta.env.BASE_URL) : createWebHistory(import.meta.env.BASE_URL)),
    routes,
    scrollBehavior: () => ({ top: 0 }),
  })
}
