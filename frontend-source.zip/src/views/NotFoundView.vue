<script setup lang="ts">
/**
 * 404 页：阶段0 真实实现（不是占位说明）。
 * 保持顶部导航可用，让用户能回到已有页面。
 */
import { RouterLink, useRoute } from 'vue-router'

const route = useRoute()
</script>

<template>
  <section class="not-found" data-testid="not-found">
    <p class="code">404</p>
    <h1 class="heading">页面不存在</h1>
    <p class="reason">
      没有与路径 <code data-testid="not-found-path">{{ route.fullPath }}</code> 匹配的页面。
      该地址可能写错，或对应的功能尚未在本阶段开放。
    </p>
    <p class="hint">可用的入口：总览、风险一张图、专题研判、成果中心、数据目录、项目说明。</p>
    <RouterLink class="back-link" to="/overview">返回总览</RouterLink>
  </section>
</template>

<style scoped>
.not-found {
  max-width: 640px;
  padding: var(--space-6);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.code {
  margin: 0;
  font-size: 32px;
  font-weight: 700;
  color: var(--color-muted);
  font-variant-numeric: tabular-nums;
}

.heading {
  margin: var(--space-2) 0 var(--space-4);
  font-size: 24px;
}

.reason,
.hint {
  margin: 0 0 var(--space-3);
  color: var(--color-muted);
}

.back-link {
  display: inline-block;
  margin-top: var(--space-2);
  padding: var(--space-2) var(--space-4);
  border-radius: var(--radius-sm);
  background: var(--color-shell);
  color: var(--color-shell-text);
  text-decoration: none;
}
</style>
