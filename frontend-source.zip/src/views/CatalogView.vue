<script setup lang="ts">
/**
 * 阶段6：数据目录页。
 *
 * - 按业务主题、数据类型和关键词筛选；分页、筛选结果与清除筛选保持一致
 *   （筛选变化页码回 1，计数随筛选变化）。
 * - 「已登记 / 文件存在 / 前端可预览 / 服务可用」四类状态分列显示（CatalogTable）。
 * - 示例身份持续标注（SourceBadge）；数据服务失败显示错误与重试，不回退示例数据。
 */
import { onMounted } from 'vue'
import { useRouter } from 'vue-router'

import CatalogTable from '@/components/catalog/CatalogTable.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import { THEME_LABEL } from '@/domain/labels'
import type { DatasetType, Theme } from '@/domain/types'
import { useCatalogStore } from '@/stores/catalog'
import { useSessionStore } from '@/stores/session'

const router = useRouter()
const store = useCatalogStore()
const session = useSessionStore()

const themes = Object.keys(THEME_LABEL) as Theme[]
const dataTypes: Array<{ key: DatasetType; label: string }> = [
  { key: 'vector', label: '矢量' },
  { key: 'raster', label: '栅格' },
  { key: 'table', label: '表格' },
]

onMounted(() => {
  void session.loadCapabilities()
  if (store.listStatus === 'idle') void store.loadList(1)
})

function openDataset(datasetId: string): void {
  void router.push({ name: 'catalog-detail', params: { datasetId } })
}
</script>

<template>
  <div class="catalog-view" data-testid="catalog-page">
    <header class="page-head">
      <div>
        <h1 class="page-heading">数据目录</h1>
        <p class="page-lead">查看平台现有数据资源、来源、版本与可用情况。</p>
      </div>
      <SourceBadge
        :mode="session.mode"
        :snapshot-id="session.snapshotId ?? undefined"
        :scope-label="session.scopeLabel ?? undefined"
      />
    </header>

    <section class="filter-bar" data-testid="catalog-filters" aria-label="目录筛选">
      <label class="filter-field">
        <span class="filter-label">主题</span>
        <select
          :value="store.filters.theme ?? ''"
          data-testid="catalog-theme"
          @change="
            store.setFilter({
              theme:
                ($event.target as HTMLSelectElement).value === ''
                  ? null
                  : (($event.target as HTMLSelectElement).value as Theme),
            })
          "
        >
          <option value="">全部主题</option>
          <option v-for="theme in themes" :key="theme" :value="theme">
            {{ THEME_LABEL[theme] }}
          </option>
        </select>
      </label>

      <label class="filter-field">
        <span class="filter-label">类型</span>
        <select
          :value="store.filters.dataType ?? ''"
          data-testid="catalog-datatype"
          @change="
            store.setFilter({
              dataType:
                ($event.target as HTMLSelectElement).value === ''
                  ? null
                  : (($event.target as HTMLSelectElement).value as DatasetType),
            })
          "
        >
          <option value="">全部类型</option>
          <option v-for="item in dataTypes" :key="item.key" :value="item.key">
            {{ item.label }}
          </option>
        </select>
      </label>

      <label class="filter-field filter-field--keyword">
        <span class="filter-label">关键词</span>
        <input
          type="search"
          :value="store.filters.keyword"
          placeholder="数据集名称包含…"
          data-testid="catalog-keyword"
          @input="store.setFilter({ keyword: ($event.target as HTMLInputElement).value })"
        />
      </label>

      <button
        type="button"
        class="btn btn--small"
        data-testid="catalog-clear"
        :disabled="!store.hasActiveFilters"
        @click="store.clearFilters()"
      >
        清除筛选
      </button>
    </section>

    <p class="result-count" data-testid="catalog-count" role="status">
      共 {{ store.total }} 个数据集<template v-if="store.hasActiveFilters">（筛选后）</template> ·
      第 {{ store.page }} / {{ store.totalPages }} 页
    </p>

    <LoadingState
      v-if="store.listStatus === 'loading' || store.listStatus === 'idle'"
      label="正在读取数据目录…"
    />
    <ErrorState
      v-else-if="store.listStatus === 'failed'"
      :error="store.listError"
      title="数据目录读取失败"
      data-testid="catalog-error"
      @retry="store.loadList()"
    />
    <template v-else>
      <CatalogTable :rows="store.rows" @open="openDataset" />

      <nav v-if="store.totalPages > 1" class="pager" aria-label="目录分页">
        <button
          type="button"
          class="btn btn--small"
          data-testid="catalog-prev"
          :disabled="store.page <= 1"
          @click="store.goToPage(store.page - 1)"
        >
          上一页
        </button>
        <span class="pager-text">第 {{ store.page }} / {{ store.totalPages }} 页</span>
        <button
          type="button"
          class="btn btn--small"
          data-testid="catalog-next"
          :disabled="store.page >= store.totalPages"
          @click="store.goToPage(store.page + 1)"
        >
          下一页
        </button>
      </nav>
    </template>
  </div>
</template>

<style scoped>
.catalog-view {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
  max-width: 720px;
}

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: flex-end;
  gap: var(--space-3);
}

.filter-field {
  display: flex;
  flex-direction: column;
  gap: 2px;
}

.filter-field--keyword {
  flex: 1 1 220px;
  min-width: 180px;
}

.filter-label {
  color: var(--color-muted);
  font-size: 11px;
}

.filter-field select,
.filter-field input {
  padding: 6px 8px;
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-text);
  font: inherit;
  font-size: 13px;
}

.result-count {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.pager {
  display: flex;
  align-items: center;
  gap: var(--space-3);
}

.pager-text {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

@media (max-width: 720px) {
  .page-head {
    flex-direction: column;
  }
}
</style>
