<script setup lang="ts">
/**
 * 阶段5：应急保障页（/analysis/emergency）。
 *
 * 数据链路：本页 → stores/emergency.ts → services/emergencyWorkspace.ts →
 * ResultRepository / LayerRepository。只读已存路线与资源；
 * `routeRecompute` 未接入，全部条件只读（说明取自能力清单 reasons）。
 *
 * 上下文链路：支持深链接 `?resultId=...&routeId=...`；页面提供
 * 暴露度 ↔ 应急保障 的互链；方案切换时地图与指标同步清空旧状态（store 职责）。
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

import RouteInfoPanel from '@/components/emergency/RouteInfoPanel.vue'
import RouteMapCanvas from '@/components/emergency/RouteMapCanvas.vue'
import RoutePlanPanel from '@/components/emergency/RoutePlanPanel.vue'
import RouteDirectoryPanel from '@/components/emergency/RouteDirectoryPanel.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import { useEmergencyStore } from '@/stores/emergency'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const store = useEmergencyStore()
const session = useSessionStore()

const mapRef = ref<InstanceType<typeof RouteMapCanvas> | null>(null)

onMounted(() => {
  void session.loadCapabilities()
  void store.initFromQuery({
    resultId: asString(route.query.resultId),
    routeId: asString(route.query.routeId),
  })
})

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() !== '' ? value : null
}

/** 深链接变化（同一路由组件复用）时重新进入。 */
watch(
  () => [route.query.resultId, route.query.routeId] as const,
  ([nextResult, nextRoute]) => {
    if (route.name !== 'analysis-emergency') return
    void store.initFromQuery({ resultId: asString(nextResult), routeId: asString(nextRoute) })
  },
)

const canRecompute = computed(() => session.canRecomputeRoute)
const recomputeReason = computed(() => session.reasonFor('routeRecompute'))
</script>

<template>
  <div class="emergency-page" data-testid="emergency-page">
    <header class="page-head">
      <div>
        <h1 class="page-title">应急保障</h1>
        <p class="page-subtitle">
          查看已发布的救援路线与应急资源：起点、终点、距离、时间、阻断条件与风险路段； 方案 A/B/C
          切换时地图与指标同步更新，无可达路径会明确提示。
        </p>
      </div>
      <nav class="context-chain" aria-label="上下文链路">
        <span class="chain-current">应急保障</span>
      </nav>
    </header>

    <p class="pending-banner" data-testid="emergency-pending-banner" role="note">
      <b>数据说明：</b>本页展示综合、2050 与 2100 情景救援路线，以及路线关联的应急资源。
      受影响对象与暴露汇总正在完善；
      <template v-if="session.mode === 'mock'"
        >本页当前为<b>演示数据</b>，仅用于了解页面功能。</template
      >
      <template v-else>路线与资源来自已发布成果。</template>
      未来情景不代表实时路况。
    </p>

    <section
      v-if="store.results.length > 0"
      class="result-scope"
      data-testid="emergency-result-scopes"
      aria-label="路线成果选择"
    >
      <span class="result-scope-label">路线成果</span>
      <button
        v-for="item in store.results"
        :key="item.id"
        type="button"
        class="scope-chip"
        :class="{ 'is-active': item.id === store.resultId }"
        :aria-pressed="item.id === store.resultId"
        :data-testid="'emergency-scope-' + item.id"
        @click="store.selectResult(item.id)"
      >
        {{ item.scenarioYear === undefined ? '综合路线' : `${item.scenarioYear} 情景路线` }}
        <small
          >{{ item.metrics.find((metric) => metric.key === 'routeCount')?.value ?? '' }} 条</small
        >
      </button>
    </section>

    <ErrorState
      v-if="store.listStatus === 'failed'"
      data-testid="emergency-list-error"
      title="应急成果清单读取失败"
      :error="store.listError"
      :retryable="true"
      @retry="store.retry()"
    />

    <template v-else>
      <div class="emergency-grid">
        <div class="map-cell">
          <RouteMapCanvas
            ref="mapRef"
            :route-detail="store.routeDetail"
            :marked-features="store.markedFeatures"
            :detail-status="store.detailStatus"
            :mode="session.mode"
          />
        </div>

        <aside class="side">
          <RoutePlanPanel
            :routes="store.routes"
            :selected-route-id="store.selectedRouteId"
            :loading="store.routesStatus === 'loading'"
            :error-text="store.routesError?.userMessage ?? null"
            :recompute-reason="recomputeReason"
            :emergency-title="store.result?.title ?? null"
            :sample-badge="session.mode === 'mock'"
            @select="store.selectRoute"
            @retry="store.retry"
          />
          <RouteInfoPanel
            :route-detail="store.routeDetail"
            :status="store.detailStatus"
            :error-text="store.detailError?.userMessage ?? null"
            :sample-badge="session.mode === 'mock'"
            @retry="store.retry"
          />
        </aside>
      </div>

      <RouteDirectoryPanel
        :routes="store.allRoutes"
        :total="store.allRoutesTotal"
        :page="store.allRoutesPage"
        :page-size="store.allRoutesPageSize"
        :loading="store.allRoutesStatus === 'loading'"
        :error-text="store.allRoutesError?.userMessage ?? null"
        @select="store.selectRoute"
        @page-change="store.loadAllRoutesPage"
      />

      <section class="footer-note" data-testid="emergency-footer">
        <h2>使用说明</h2>
        <ul>
          <li>
            路线重新规划：{{ canRecompute ? '当前可用。' : '暂未提供，当前展示已发布路线。' }}
            修改条件后不会自动生成新路线。
          </li>
          <li>
            无可达路径使用专用状态展示，不画直线冒充路线；通行时间只显示成果登记值
            （未登记显示「未提供」），不按固定速度估算。
          </li>
          <li>应急资源与路线来自已发布成果；风险路段说明不代表实时路况。</li>
        </ul>
      </section>
    </template>
  </div>
</template>

<style scoped>
.emergency-page {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.page-title {
  margin: 0;
  font-size: var(--font-size-page-title);
  color: var(--color-text);
}

.page-subtitle {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
  max-width: 72ch;
}

.context-chain {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.chain-link {
  padding: 2px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  background: var(--color-surface-sunken);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
}

.chain-current {
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
  font-weight: var(--button-font-weight);
}

.chain-sep {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.pending-banner {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-warning);
  border-left-width: 4px;
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.result-scope {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}
.result-scope-label {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-weight: 600;
}
.scope-chip {
  display: inline-flex;
  align-items: center;
  gap: var(--space-1);
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  background: var(--color-surface);
  color: var(--color-text);
  cursor: pointer;
}
.scope-chip.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
}
.scope-chip small {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}
.emergency-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 420px;
  gap: var(--space-3);
  align-items: start;
}

.map-cell {
  height: clamp(340px, 52vh, 620px);
  min-width: 0;
  min-height: 0;
}

.side {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.footer-note {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-info-surface);
}

.footer-note h2 {
  margin: 0;
  font-size: var(--font-size-body);
  color: var(--color-text);
}

.footer-note ul {
  margin: 0;
  padding-left: var(--space-4);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

@media (max-width: 1100px) {
  .emergency-grid {
    grid-template-columns: minmax(0, 1fr);
  }

  .map-cell {
    height: clamp(280px, 48vh, 480px);
  }
}

@media (max-width: 600px) {
  .map-cell {
    height: 300px;
  }
}
</style>
