<script setup lang="ts">
import { computed, onMounted } from 'vue'
import { RouterLink } from 'vue-router'
import OverviewMapCanvas from '@/components/overview/OverviewMapCanvas.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import { formatCount, formatMetricValue, formatTimeValue } from '@/domain/format'
import { useOverviewStore } from '@/stores/overview'
import { useSessionStore } from '@/stores/session'
import { useLanguage } from '@/composables/useLanguage'
const store = useOverviewStore()
const session = useSessionStore()
const { t, language } = useLanguage()
const data = computed(() => store.data)
const mainMetrics = computed(() => (data.value?.metrics ?? []).slice(0,4))
const metricLabels = computed(() => [t('潜在危险点','Potential hazard locations'),t('救援路线','Rescue routes'),t('医院设施','Hospitals'),t('数据集','Datasets')])
const distributionTotal = computed(() => (data.value?.riskDistribution ?? []).reduce((sum,item) => sum+item.count,0))
const entries = computed(() => [
  {to:'/map',title:t('危险点与救援','Hazards & rescue'),text:t('搜索地区，选择危险点，查看关联设施和救援路线。','Search a region and select a hazard location to explore linked facilities and rescue routes.')},
  {to:'/analysis/risk',title:t('分析与情景','Analysis & scenarios'),text:t('了解团队分析成果、2050 / 2100 冰湖情景及数据来源。','Explore team analyses, external 2050 / 2100 glacial-lake scenarios and their sources.')},
  {to:'/rasters',title:t('环境因子地图','Environmental factors'),text:t('查看地形、气候及其他环境因子的空间分布。','View terrain, climate and other environmental factors on the map.')},
])
onMounted(() => { void session.loadCapabilities(); if(store.status==='idle') void store.load() })
</script>

<template>
  <div class="overview-view" data-testid="overview-page">
    <header class="hero panel">
      <p class="eyebrow">{{ t('青藏高原 · 灾害与应急','QINGHAI–TIBET PLATEAU · HAZARDS & RESPONSE') }}</p>
      <h1>{{ t('从危险点识别，到救援路线探索','From hazard locations to rescue routes') }}</h1>
      <p class="hero-lead">{{ t('整合青藏高原中国境内的自然环境、灾害与应急设施数据，在地图中连接潜在危险点和救援资源。','Explore environmental, hazard and emergency-facility data for the Chinese portion of the Qinghai–Tibet Plateau, connecting potential hazard locations with response resources.') }}</p>
      <div class="hero-actions"><RouterLink class="btn btn--primary" to="/map">{{ t('探索危险点与救援 →','Explore hazards & rescue →') }}</RouterLink><RouterLink class="text-link" to="/catalog">{{ t('查看数据来源','View data sources') }}</RouterLink></div>
    </header>
    <LoadingState v-if="store.status==='loading' || store.status==='idle'" :label="t('正在加载项目成果…','Loading project results…')" />
    <ErrorState v-else-if="store.status==='failed'" :error="store.error" :title="t('成果加载失败','Unable to load results')" @retry="store.load()" />
    <template v-else-if="data">
      <section class="workflow" :aria-label="t('如何使用','How it works')">
        <article class="panel"><span class="step">01</span><h2>{{ t('了解危险点','Understand the locations') }}</h2><p>{{ t('团队结合自然环境因子与历史灾害数据开展分析，形成潜在危险点筛查成果。','The team combined environmental factors with historical hazard data to screen potential hazard locations.') }}</p></article>
        <article class="panel"><span class="step">02</span><h2>{{ t('选择关注地点','Choose a location') }}</h2><p>{{ t('搜索地区或点击地图上的危险点，查看关联的医院、消防站等救援设施。','Search a region or select a hazard location on the map to view linked hospitals, fire stations and other response facilities.') }}</p></article>
        <article class="panel"><span class="step">03</span><h2>{{ t('查看救援路线','Explore rescue routes') }}</h2><p>{{ t('结合 OpenStreetMap 公开路网、危险点和设施位置，通过最短路径求解，展示已计算的救援路线与距离。','Using OpenStreetMap road-network data, hazard locations and facilities, shortest-path analysis provides saved rescue routes and distances.') }}</p></article>
      </section>
      <section class="metric-grid" :aria-label="t('成果概览','Results at a glance')">
        <article class="panel metric" v-for="(metric,index) in mainMetrics" :key="metric.key" :data-testid="`overview-metric-${metric.key}`"><span>{{ metricLabels[index] }}</span><strong>{{ language === 'en' ? formatMetricValue(metric).replace(/\s*[点条处]$/, '') : formatMetricValue(metric) }}</strong></article>
      </section>
      <div class="overview-grid">
        <section class="panel map-panel"><h2>{{ t('研究区域','Study area') }}</h2><p>{{ t('青藏高原中国境内部分','The Chinese portion of the Qinghai–Tibet Plateau') }}</p><div class="map-host"><OverviewMapCanvas :zones="store.zones" :mode="session.mode" /></div></section>
        <section class="panel" data-testid="overview-distribution"><h2>{{ t('易发性成果分布','Susceptibility results') }}</h2><p>{{ t('按成果中记录的等级统计，共','Counts by the levels recorded in the results:') }} {{ formatCount(distributionTotal) }} {{ t('个点','locations') }}</p>
          <ul class="dist-list"><li v-for="item in data.riskDistribution" :key="item.key"><div class="dist-label"><span>{{ t(item.label, ({'极高':'Very high','高':'High','中':'Moderate','低':'Low','极低':'Very low'} as Record<string,string>)[item.label] ?? item.label) }}</span><strong>{{ formatCount(item.count) }}</strong></div><div class="track"><span :style="{width: `${distributionTotal ? item.count/distributionTotal*100 : 0}%`,background:item.color ?? 'var(--color-primary)'}"></span></div></li></ul>
          <RouterLink class="text-link" to="/map">{{ t('在地图中查看 →','View on the map →') }}</RouterLink>
        </section>
      </div>
      <section class="entry-grid" data-testid="overview-entries"><RouterLink v-for="entry in entries" :key="entry.to" :to="entry.to" class="panel entry-card"><h2>{{ entry.title }}</h2><p>{{ entry.text }}</p><span class="text-link">{{ t('进入查看 →','Explore →') }}</span></RouterLink></section>
      <p class="snapshot-date" v-if="data.snapshotTime">{{ t('成果更新时间：','Results updated: ') }}{{ formatTimeValue(data.snapshotTime) }}</p>
    </template>
  </div>
</template>

<style scoped>
.overview-view{display:flex;flex-direction:column;gap:24px}.panel{padding:24px;border:1px solid var(--color-border);border-radius:12px;background:var(--color-surface);min-width:0}.hero{padding:36px;background:linear-gradient(120deg,#edf5f5,#fff 80%);border-top:3px solid var(--color-primary)}.eyebrow,.step{color:var(--color-primary);font-size:12px;font-weight:700;letter-spacing:.06em}.hero h1{font-size:30px;line-height:1.35;margin:12px 0}.hero-lead{max-width:850px;line-height:1.9}.hero-actions{display:flex;align-items:center;gap:24px;flex-wrap:wrap;margin-top:24px}.workflow,.entry-grid{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:16px}h2{font-size:18px;margin:10px 0}p{color:var(--color-muted);line-height:1.8;margin:8px 0}.metric-grid{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:16px}.metric{border-left:3px solid var(--color-primary);display:flex;flex-direction:column;gap:12px}.metric>span{color:var(--color-muted);font-size:14px}.metric strong{font-size:30px;font-variant-numeric:tabular-nums}.overview-grid{display:grid;grid-template-columns:minmax(0,1.3fr) minmax(0,1fr);gap:24px}.map-panel{display:flex;flex-direction:column}.map-host{height:290px;margin-top:12px}.dist-list{list-style:none;padding:0;margin:24px 0;display:grid;gap:24px}.dist-label{display:flex;justify-content:space-between;margin-bottom:8px;font-size:14px}.track{height:10px;background:#edf1f4;border-radius:6px;overflow:hidden}.track span{display:block;height:100%;border-radius:6px}.entry-card{color:inherit;text-decoration:none;display:flex;flex-direction:column;transition:border-color .15s,box-shadow .15s}.entry-card:hover{border-color:var(--color-primary);box-shadow:0 4px 18px #162d3a0d}.entry-card p{flex:1;font-size:14px}.text-link{color:var(--color-primary);font-weight:600}.snapshot-date{font-size:12px;text-align:right;margin:0}@media(max-width:900px){.workflow,.entry-grid,.overview-grid{grid-template-columns:1fr}.metric-grid{grid-template-columns:repeat(2,minmax(0,1fr))}.hero{padding:24px}.hero h1{font-size:25px}}@media(max-width:480px){.panel{padding:18px}.overview-view{gap:16px}.metric strong{font-size:24px}.hero-actions{gap:16px}.hero h1{font-size:23px}}
</style>
