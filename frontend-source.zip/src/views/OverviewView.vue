<script setup lang="ts">
/**
 * 阶段6：总览。
 *
 * 数据全部来自 OverviewRepository（getOverview）与同一数据源的已存要素：
 * - 主地图：mock 为已存风险区成果图层；api 为正式研究区边界片段；
 * - 四项主指标：均带统计范围与时点口径（MetricCard emphasis=high）；
 * - 风险分布：按登记等级计数（与指标「已登记/已分级」同一批要素派生）；
 * - 重点对象：指标完整的 Top 3（与 RiskTopList 同一口径）；
 * - 三个专题入口：风险研判 / 暴露评估 / 应急保障（成果中心已登记成果）。
 *
 * 总览数字可在数据目录与成果明细中找到对应依据（风险区成果图层、暴露统计），
 * 页面不写死任何统计值；读取失败显示错误与重试，不回退示例数据。
 */
import { computed, onMounted } from 'vue'
import { RouterLink } from 'vue-router'

import DataConnectivityPanel from '@/components/overview/DataConnectivityPanel.vue'
import OverviewMapCanvas from '@/components/overview/OverviewMapCanvas.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import MetricCard from '@/components/ui/MetricCard.vue'
import RiskBadge from '@/components/ui/RiskBadge.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import { formatCount, formatMetricValue, formatTimeValue } from '@/domain/format'
import { RESULT_KIND_LABEL } from '@/domain/labels'
import { useOverviewStore } from '@/stores/overview'
import { useSessionStore } from '@/stores/session'

const store = useOverviewStore()
const session = useSessionStore()

const data = computed(() => store.data)
const mainMetrics = computed(() => (data.value?.metrics ?? []).slice(0, 4))
const isApiOverview = computed(() => session.mode === 'api')

const distributionTotal = computed(() =>
  (data.value?.riskDistribution ?? []).reduce((sum, item) => sum + item.count, 0),
)

/** 专题入口：来自总览的已发布成果，kind → 工作台路由。 */
const workspaceOfKind: Record<string, string> = {
  risk: '/analysis/risk',
  emergency: '/analysis/emergency',
}

onMounted(() => {
  void session.loadCapabilities()
  if (store.status === 'idle') void store.load()
})
</script>

<template>
  <div class="overview-view" data-testid="overview-page">
    <header class="page-head">
      <div>
        <h1 class="page-heading">总览</h1>
        <p class="page-lead" v-if="data !== null">
          {{ data.regionLabel }} · 数据更新时间：{{
            data.snapshotTime === null ? '未提供' : formatTimeValue(data.snapshotTime)
          }}（不是实时监测数据）
        </p>
      </div>
      <SourceBadge
        :mode="session.mode"
        :snapshot-id="session.snapshotId ?? undefined"
        :scope-label="session.scopeLabel ?? undefined"
      />
    </header>

    <LoadingState
      v-if="store.status === 'loading' || store.status === 'idle'"
      label="正在读取总览数据…"
    />
    <template v-else-if="store.status === 'failed'">
      <ErrorState
        :error="store.error"
        title="总览数据读取失败"
        data-testid="overview-error"
        @retry="store.load()"
      />
      <!-- 数据接入自检面板独立取数，失败时同样展示其自身错误状态（api 模式联调用例依赖）。 -->
      <DataConnectivityPanel />
    </template>

    <template v-else-if="data !== null">
      <div v-if="store.zoneWarning !== null" class="zone-warning" role="status">
        {{ store.zoneWarning }}
      </div>

      <div class="overview-grid">
        <div class="map-cell">
          <OverviewMapCanvas :zones="store.zones" :mode="session.mode" class="map-host" />
        </div>

        <div class="side-cell">
          <div class="metric-grid">
            <MetricCard
              v-for="metric in mainMetrics"
              :key="metric.key"
              :metric="metric"
              emphasis="high"
              :data-testid="`overview-metric-${metric.key}`"
            />
          </div>
        </div>
      </div>

      <div class="two-col">
        <section
          class="panel"
          :aria-label="isApiOverview ? '易发性成果点分布' : '风险分布'"
          data-testid="overview-distribution"
        >
          <h2 class="section-title">{{ isApiOverview ? '易发性成果点分布' : '风险分布' }}</h2>
          <p class="panel-note">
            <template v-if="isApiOverview">
              按易发性成果点的等级统计，共 {{ formatCount(distributionTotal) }} 个成果点；
              等级沿用成果记录中的标注。
            </template>
            <template v-else>
              按风险区成果图层登记的等级计数，共 {{ formatCount(distributionTotal) }} 个对象；
              分级阈值未登记，等级取自成果记录本身。
            </template>
          </p>
          <ul class="dist-list">
            <li v-for="item in data.riskDistribution" :key="item.key" class="dist-row">
              <span
                class="dist-swatch"
                :style="{ background: item.color ?? 'transparent' }"
                aria-hidden="true"
              ></span>
              <span class="dist-label">{{ item.label }}</span>
              <span
                class="dist-bar"
                :style="{
                  width:
                    distributionTotal === 0 ? '0%' : `${(item.count / distributionTotal) * 100}%`,
                }"
                aria-hidden="true"
              ></span>
              <span class="dist-count tabular-nums" :data-dist-key="item.key">{{
                formatCount(item.count)
              }}</span>
            </li>
          </ul>
        </section>

        <section class="panel" aria-label="重点对象" data-testid="overview-key-features">
          <h2 class="section-title">重点对象</h2>
          <p class="panel-note">
            <template v-if="isApiOverview"> 当前暂未提供重点对象排序。 </template>
            <template v-else>
              综合风险指数最高的前 3 个风险区（与风险研判重点清单同口径）。
            </template>
          </p>
          <ul class="feature-list">
            <li
              v-for="feature in data.keyFeatures"
              :key="`${feature.ref.layerId}:${feature.ref.id}`"
              class="feature-row"
            >
              <RiskBadge :level="feature.level ?? 'insufficient'" />
              <div class="feature-text">
                <p class="feature-title">{{ feature.title }}</p>
                <p class="feature-meta">
                  {{ feature.layerLabel }} ·
                  {{
                    feature.metric === null
                      ? '指标未提供'
                      : `${feature.metric.label} ${formatMetricValue(feature.metric)}`
                  }}
                </p>
              </div>
              <RouterLink class="feature-link" to="/analysis/risk"> 在风险研判中查看 → </RouterLink>
            </li>
            <li v-if="data.keyFeatures.length === 0" class="feature-row">
              <p class="panel-note">暂无指标完整的重点对象。</p>
            </li>
          </ul>
        </section>
      </div>

      <section class="panel" aria-label="专题入口" data-testid="overview-entries">
        <h2 class="section-title">专题入口</h2>
        <div class="entry-grid">
          <RouterLink
            v-for="result in data.currentResults"
            :key="result.id"
            class="entry-card"
            :to="workspaceOfKind[result.kind] ?? '/results'"
          >
            <span class="entry-kind">{{ RESULT_KIND_LABEL[result.kind] }}</span>
            <span class="entry-title">{{ result.title }}</span>
            <span class="entry-meta">版本 {{ result.version }} · {{ result.regionLabel }}</span>
            <span class="entry-go">进入工作台 →</span>
          </RouterLink>
        </div>
        <p class="panel-note">
          栅格数据可前往
          <RouterLink to="/rasters" class="text-link">真实栅格地图</RouterLink>
          查看。
        </p>
      </section>

      <details class="diagnostics" data-testid="overview-diagnostics">
        <summary>数据来源与更新时间</summary>
        <p class="diagnostics-note">查看本页数据的来源、更新时间与统计范围。</p>
        <DataConnectivityPanel />
      </details>
    </template>
  </div>
</template>

<style scoped>
.overview-view {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
}

.zone-warning {
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-border);
  border-left: 3px solid var(--color-warning-text);
  border-radius: var(--radius-sm);
  background: var(--color-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
}

.diagnostics {
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.diagnostics summary {
  cursor: pointer;
  color: var(--color-primary-strong);
  font-weight: 600;
}

.diagnostics-note {
  margin: var(--space-2) 0 var(--space-3);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.overview-grid {
  display: grid;
  grid-template-columns: minmax(0, 3fr) minmax(0, 2fr);
  gap: var(--space-4);
}

.map-cell {
  min-width: 0;
  height: 420px;
}

.map-host {
  height: 100%;
}

.side-cell {
  min-width: 0;
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-3);
}

.panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.panel-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.two-col {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-4);
}

.dist-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.dist-row {
  display: grid;
  grid-template-columns: 14px 96px 1fr 48px;
  align-items: center;
  gap: var(--space-2);
}

.dist-swatch {
  width: 14px;
  height: 14px;
  border-radius: 3px;
  border: 1px solid var(--color-border);
}

.dist-label {
  font-size: var(--font-size-caption);
}

.dist-bar {
  height: 10px;
  min-width: 2px;
  border-radius: 5px;
  background: var(--color-primary);
  opacity: 0.75;
}

.dist-count {
  text-align: right;
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.feature-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  margin: 0;
  padding: 0;
  list-style: none;
}

.feature-row {
  display: flex;
  align-items: flex-start;
  gap: var(--space-3);
}

.feature-text {
  flex: 1;
  min-width: 0;
}

.feature-title {
  margin: 0;
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.feature-meta {
  margin: 2px 0 0;
  color: var(--color-muted);
  font-size: 11px;
}

.feature-link {
  color: var(--color-primary);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.entry-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--space-3);
}

.entry-card {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  padding: var(--space-3) var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  color: inherit;
  text-decoration: none;
  transition: border-color 0.15s;
}

.entry-card:hover {
  border-color: var(--color-primary);
}

.entry-kind {
  color: var(--color-primary);
  font-size: 11px;
  font-weight: 600;
  letter-spacing: 0.06em;
}

.entry-title {
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.entry-meta {
  color: var(--color-muted);
  font-size: 11px;
}

.entry-go {
  margin-top: var(--space-1);
  color: var(--color-primary);
  font-size: var(--font-size-caption);
}

.text-link {
  color: var(--color-primary);
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}

@media (max-width: 1100px) {
  .overview-grid,
  .two-col {
    grid-template-columns: 1fr;
  }

  .map-cell {
    height: 320px;
  }

  .page-head {
    flex-direction: column;
  }
}
</style>
