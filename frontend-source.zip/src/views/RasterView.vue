<script setup lang="ts">
import { onMounted, onBeforeUnmount, ref, computed } from 'vue'
import { useRoute } from 'vue-router'
import { useLanguage } from '@/composables/useLanguage'
const { t } = useLanguage()
import Map from 'ol/Map'
import View from 'ol/View'
import ImageLayer from 'ol/layer/Image'
import ImageStatic from 'ol/source/ImageStatic'
import { transformExtent } from 'ol/proj'
import 'ol/ol.css'
import { appEnv } from '@/config/env'
import {
  rasterData,
  RasterServiceError,
  type RasterAsset,
  type RasterPreview,
  type RasterCategoricalLegendItem,
  type RasterCircularLegendItem,
} from '@/services/rasterData'
const assets = ref<RasterAsset[]>([])
const route = useRoute()
const selected = ref('')
const detail = ref<RasterPreview | null>(null)
const busy = ref(false)
const error = ref('')
// 栅格数据目录整体缺失（交付包里栅格数据单独走网盘分发，不进压缩包）时，
// 后端会返回 503/SERVICE_UNAVAILABLE。这是预期中的降级场景，不是真实故障，
// 不应渲染成告警态的错误横幅，改用平静的说明文案。
const rasterUnavailableMessage = ref('')
const rasterPreviewNotice = ref('')

function describeError(e: unknown, fallback: string): void {
  if (e instanceof RasterServiceError && e.code === 'SERVICE_UNAVAILABLE') {
    rasterUnavailableMessage.value = e.message
    error.value = ''
    return
  }
  rasterUnavailableMessage.value = ''
  error.value = e instanceof Error ? e.message : fallback
}
const opacity = ref(0.9)
const target = ref<HTMLDivElement | null>(null)
let map: Map | null = null
let layer: ImageLayer<ImageStatic> | null = null
let controller: AbortController | null = null
let objectUrl: string | null = null
let generation = 0
let disposed = false

const categoricalLegend = computed<RasterCategoricalLegendItem[]>(() =>
  detail.value?.renderMode === 'categorical'
    ? (detail.value.legend as RasterCategoricalLegendItem[])
    : [],
)
const circularLegend = computed<RasterCircularLegendItem[]>(() =>
  detail.value?.renderMode === 'circular'
    ? (detail.value.legend as RasterCircularLegendItem[])
    : [],
)
const seriesYears = computed(() => detail.value?.series?.years ?? [])

function selectSeriesYear(year: number) {
  const assetId = detail.value?.series?.assets[String(year)]
  if (!assetId || assetId === selected.value) return
  selected.value = assetId
  void load()
}

function isCurrent(current: number, signal: AbortSignal): boolean {
  return !disposed && current === generation && !signal.aborted
}

function beginRequest(): { current: number; signal: AbortSignal } {
  controller?.abort()
  const nextController = new AbortController()
  controller = nextController
  return { current: ++generation, signal: nextController.signal }
}

function clearLayer() {
  if (layer && map) map.removeLayer(layer)
  layer = null
  if (objectUrl) URL.revokeObjectURL(objectUrl)
  objectUrl = null
}

async function load() {
  if (appEnv.dataMode !== 'api' || disposed) return

  const { current, signal } = beginRequest()
  busy.value = true
  error.value = ''
  rasterUnavailableMessage.value = ''
  detail.value = null
  clearLayer()

  if (!selected.value) {
    busy.value = false
    if (controller?.signal === signal) controller = null
    return
  }

  let pendingObjectUrl: string | null = null
  try {
    const result = await rasterData.detail(selected.value, signal)
    const blob = await rasterData.image(result.imageUrl, signal)
    if (!isCurrent(current, signal)) return

    pendingObjectUrl = URL.createObjectURL(blob)
    const source = new ImageStatic({
      url: pendingObjectUrl,
      projection: 'EPSG:4326',
      imageExtent: result.bounds,
      interpolate: false,
    })
    const nextLayer = new ImageLayer({ source, opacity: opacity.value })
    source.once('imageloaderror', () => {
      if (!isCurrent(current, signal) || layer !== nextLayer) return
      clearLayer()
      detail.value = null
      error.value = '地图图像加载失败，请重试'
    })
    objectUrl = pendingObjectUrl
    pendingObjectUrl = null
    layer = nextLayer
    detail.value = result
    map?.addLayer(nextLayer)
    fit()
  } catch (e) {
    if (pendingObjectUrl) URL.revokeObjectURL(pendingObjectUrl)
    if (isCurrent(current, signal)) {
      clearLayer()
      detail.value = null
      describeError(e, '栅格服务读取失败')
    }
  } finally {
    if (isCurrent(current, signal)) {
      busy.value = false
      if (controller?.signal === signal) controller = null
    }
  }
}

function fit() {
  if (detail.value)
    map?.getView().fit(transformExtent(detail.value.bounds, 'EPSG:4326', 'EPSG:3857'), {
      padding: [24, 24, 24, 24],
    })
}

function updateOpacity() {
  layer?.setOpacity(opacity.value)
}

async function initialize() {
  if (appEnv.dataMode !== 'api' || disposed) return

  const { current, signal } = beginRequest()
  busy.value = true
  error.value = ''
  rasterUnavailableMessage.value = ''
  rasterPreviewNotice.value = ''
  assets.value = []
  selected.value = ''
  detail.value = null
  clearLayer()

  try {
    const result = await rasterData.list(signal)
    if (!isCurrent(current, signal)) return

    assets.value = result.items
    rasterPreviewNotice.value =
      result.note ??
      (result.previewOnly
        ? '当前显示交付包内的轻量栅格预览；挂载原始栅格后将自动切换到真实像元。'
        : '')
    const requested = typeof route.query.asset === 'string' ? route.query.asset : ''
    selected.value =
      result.items.find((item) => item.id === requested)?.id ??
      result.items.find((item) => item.id === 'TNR_PERMAFROST_RS')?.id ??
      result.items[0]?.id ??
      ''
    if (selected.value) {
      await load()
      return
    }
  } catch (e) {
    if (isCurrent(current, signal)) describeError(e, '栅格目录读取失败')
  } finally {
    if (isCurrent(current, signal)) {
      busy.value = false
      if (controller?.signal === signal) controller = null
    }
  }
}

onMounted(() => {
  if (target.value)
    map = new Map({
      target: target.value,
      view: new View({ center: [10000000, 4000000], zoom: 3 }),
    })
  void initialize()
})

onBeforeUnmount(() => {
  disposed = true
  ++generation
  controller?.abort()
  controller = null
  clearLayer()
  map?.setTarget(undefined)
  map?.dispose()
  map = null
})
</script>

<template>
  <div class="raster-page" data-testid="raster-page">
    <header>
      <p class="eyebrow">SPATIAL ENVIRONMENT DATA</p>
      <h1>{{ t('环境栅格地图','Environmental raster maps') }}</h1>
      <p>{{ t('浏览青藏高原地形、冻土、土地覆盖、降水等环境数据，按实际坐标展示。','Explore georeferenced elevation, permafrost, land cover, precipitation and other environmental layers.') }}</p>
    </header>
    <p v-if="appEnv.dataMode !== 'api'" class="notice">请从平台主入口打开环境栅格数据。</p>
    <template v-else>
      <div class="raster-controls">
        <label for="raster-select"
          >{{ t('栅格资产','Raster asset') }}（{{ assets.length }}）<select
            id="raster-select"
            v-model="selected"
            data-testid="raster-select"
            @change="void load()"
          >
            <option v-for="asset in assets" :key="asset.id" :value="asset.id">
              {{ asset.name }}
            </option>
          </select></label
        >
        <label v-if="seriesYears.length > 0" for="raster-year-select"
          >{{ t('年份','Year') }}<select
            id="raster-year-select"
            data-testid="raster-year-select"
            :value="detail?.series?.currentYear"
            @change="selectSeriesYear(Number(($event.target as HTMLSelectElement).value))"
          >
            <option v-for="year in seriesYears" :key="year" :value="year">{{ year }}</option>
          </select></label
        >
        <label for="raster-opacity"
          >{{ t('透明度','Opacity') }}<input
            id="raster-opacity"
            v-model.number="opacity"
            type="range"
            min="0.1"
            max="1"
            step="0.1"
            @input="updateOpacity"
        /></label>
        <button class="btn" type="button" :disabled="!detail" @click="fit">{{ t('完整范围','Full extent') }}</button>
      </div>
      <p v-if="busy" role="status">正在读取真实像元并投影，首次读取大文件可能需要稍等…</p>
      <div v-if="rasterPreviewNotice" class="notice" data-testid="raster-preview-notice">
        {{ rasterPreviewNotice }}
      </div>
      <div v-else-if="rasterUnavailableMessage" class="notice" data-testid="raster-unavailable">
        <p>{{ rasterUnavailableMessage }}</p>
        <p>
          栅格数据体量较大（数十
          GB），交付包中不包含，需单独下载后挂载到数据盘；平台其余功能不受影响。
        </p>
      </div>
      <p v-else-if="assets.length === 0" class="notice" data-testid="raster-empty">
        当前没有可展示的环境栅格数据。
      </p>
      <div v-if="error" role="alert" class="notice error">
        <p>{{ error }}</p>
        <button class="btn" type="button" @click="assets.length ? void load() : void initialize()">
          重试
        </button>
      </div>
    </template>
    <div
      ref="target"
      class="raster-map"
      data-testid="raster-map"
      aria-label="真实栅格像元地图"
    ></div>
    <section v-if="detail" class="raster-metadata" data-testid="raster-metadata">
      <h2>{{ detail.id }}</h2>
      <div v-if="detail.renderMode === 'continuous'" class="ramp"></div>
      <ul
        v-else-if="detail.renderMode === 'categorical'"
        class="legend-swatches"
        data-testid="raster-legend-categorical"
      >
        <li v-for="item in categoricalLegend" :key="item.value">
          <span class="swatch" :style="{ background: item.color }" aria-hidden="true"></span>
          <span>{{ item.name ?? `类别 ${item.value}（属性表未提供名称）` }}</span>
          <span v-if="item.count !== null" class="legend-count"
            >{{ item.count.toLocaleString() }} 像元（全幅）</span
          >
        </li>
      </ul>
      <ul
        v-else-if="detail.renderMode === 'circular'"
        class="legend-swatches"
        data-testid="raster-legend-circular"
      >
        <li v-for="item in circularLegend" :key="item.label">
          <span class="swatch" :style="{ background: item.color }" aria-hidden="true"></span>
          <span>{{ item.label }}</span>
        </li>
      </ul>
      <p v-if="detail.legendNote" class="notice" data-testid="raster-legend-note">
        {{ detail.legendNote }}
      </p>
      <p v-if="detail.renderMode === 'continuous'">
        预览像元值：{{ detail.sampleMin ?? '无有效像元' }} — {{ detail.sampleMax ?? '无有效像元'
        }}<template v-if="detail.series">
          ；色阶值域：{{ detail.colorScaleMin ?? '—' }} —
          {{ detail.colorScaleMax ?? '—' }}</template
        >
      </p>
      <p v-if="detail.series" data-testid="raster-series-note">{{ detail.series.domainNote }}</p>
      <p v-if="detail.previewOnly" class="notice">当前为轻量预览图，不代表已加载完整原始栅格。</p>
      <p>
        数据尺寸 {{ detail.sourceWidth }} × {{ detail.sourceHeight }}；本次显示网格
        {{ detail.sampleWidth ?? '—' }} × {{ detail.sampleHeight ?? '—' }}；预览范围
        {{ detail.width }} × {{ detail.height }}。
      </p>
      <p>{{ detail.note }}</p>
    </section>
  </div>
</template>
<style scoped>
.raster-page {
  display: grid;
  gap: 18px;
  min-width: 0;
}
h1,
h2,
p {
  margin: 0;
}
header,
.raster-metadata {
  display: grid;
  gap: 10px;
  min-width: 0;
}
header p,
.raster-metadata p {
  color: var(--color-muted);
  line-height: 1.65;
}
.eyebrow {
  font-size: 12px;
  letter-spacing: 0.15em;
  color: var(--color-primary);
}
.raster-controls {
  display: flex;
  flex-wrap: wrap;
  align-items: end;
  gap: 16px;
  min-width: 0;
  padding: 16px;
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: 12px;
}
label {
  display: grid;
  gap: 8px;
  min-width: 0;
  max-width: 100%;
}
select {
  padding: 9px;
  border: 1px solid var(--color-border);
  border-radius: 6px;
  max-width: 100%;
  background: var(--color-surface);
  color: var(--color-text);
}
.raster-map {
  height: clamp(320px, 57vh, 680px);
  min-width: 0;
  border-radius: 12px;
  overflow: hidden;
  background: #e5ecea;
  border: 1px solid var(--color-border);
}
.raster-metadata {
  padding: 20px;
  background: var(--color-surface);
  border: 1px solid var(--color-border);
  border-radius: 12px;
  overflow-wrap: anywhere;
}
.raster-metadata h2 {
  font-size: 17px;
}
.ramp {
  width: min(320px, 100%);
  height: 14px;
  border-radius: 7px;
  background: linear-gradient(to right, #e7f5ed, #7bbfa1, #26736c, #163c50);
}
.legend-swatches {
  display: flex;
  flex-wrap: wrap;
  gap: 8px 16px;
  margin: 0;
  padding: 0;
  list-style: none;
}
.legend-swatches li {
  display: flex;
  align-items: center;
  gap: 6px;
  font-size: 13px;
}
.legend-swatches .swatch {
  width: 14px;
  height: 14px;
  border-radius: 3px;
  border: 1px solid var(--color-border);
  flex: none;
}
.legend-count {
  color: var(--color-muted);
  font-size: 12px;
}
.notice {
  padding: 16px;
  border: 1px solid var(--color-border);
  border-radius: 8px;
}
.error {
  color: var(--color-danger-text);
}
</style>
