<script setup lang="ts">
import { computed, onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue'
import { useRoute, RouterLink } from 'vue-router'
import Map from 'ol/Map'
import 'ol/ol.css'
import View from 'ol/View'
import Feature from 'ol/Feature'
import GeoJSON from 'ol/format/GeoJSON'
import VectorSource from 'ol/source/Vector'
import VectorLayer from 'ol/layer/Vector'
import { Style, Fill, Stroke, Circle as CircleStyle, RegularShape } from 'ol/style'
import { defaults as controls, ScaleLine } from 'ol/control'
import type Geometry from 'ol/geom/Geometry'
import { useLanguage } from '@/composables/useLanguage'
import type { FeatureDetail, RouteSummary } from '@/domain/types'
import { scopeLayers, snapshotFile, snapshotLayer, pointId, pointsInRegion, routesForPoint, type Scope, type RouteLink } from '@/services/hazardExplorer'

const { t, language } = useLanguage()
const route = useRoute()
const scope = ref<Scope>(route.query.scope === '2050' || route.query.scope === '2100' ? route.query.scope : 'combined')
const host = ref<HTMLDivElement | null>(null)
const loading = ref(true), routeLoading = ref(false), error = ref(''), routeError = ref('')
const points = shallowRef<FeatureDetail[]>([]), regions = shallowRef<FeatureDetail[]>([])
const boundary = shallowRef<FeatureDetail[]>([]), selectedRegion = shallowRef<FeatureDetail | null>(null)
const selected = shallowRef<FeatureDetail | null>(null), selectedRoute = ref<string | null>(null)
const summaries = shallowRef<RouteSummary[]>([]), lines = shallowRef<FeatureDetail[]>([])
const facilities = shallowRef<FeatureDetail[]>([]), links = shallowRef<RouteLink[]>([])
const regionSearch = ref(''), keyword = ref(''), level = ref(''), page = ref(1)
const pageSize = 20
let map: Map | null = null, revision = 0, disposed = false
const reader = new GeoJSON()
const baseSource = new VectorSource<Feature<Geometry>>()
const pointSource = new VectorSource<Feature<Geometry>>()
const regionSource = new VectorSource<Feature<Geometry>>()
const routeSource = new VectorSource<Feature<Geometry>>()
const facilitySource = new VectorSource<Feature<Geometry>>()
const selectedSource = new VectorSource<Feature<Geometry>>()
const levels = ['极高', '高', '中']
const scopeTitle = (s: Scope) => s === 'combined' ? t('团队灾害易发性分析', 'Team susceptibility analysis') : t(`${s} 风险冰湖 · RCP2.6`, `${s} hazardous glacial lakes · RCP2.6`)
const translateValue = (s: unknown) => {
  const dict: Record<string, string> = {'极高':'Very high','高':'High','中':'Moderate','滑坡':'Landslide','泥石流':'Debris flow','崩塌':'Rockfall','冰岩崩塌':'Ice-rock avalanche','医院':'Hospital','消防站':'Fire station','救援站':'Rescue station','应急救援站':'Rescue station','冻融型滑坡':'Thaw-related landslide','地震次生滑坡':'Earthquake-induced landslide','冰湖溃决洪水':'Glacial lake outburst flood'}
  return language.value === 'en' ? dict[String(s)] ?? String(s ?? '') : String(s ?? '')
}
const suggestions = computed(() => {
  const q = regionSearch.value.trim().toLowerCase()
  return q ? regions.value.filter(r => `${r.title} ${r.properties.name} ${r.properties.pac}`.toLowerCase().includes(q)).slice(0, 12) : []
})
const regionalPoints = computed(() => pointsInRegion(points.value, selectedRegion.value))
const filtered = computed(() => regionalPoints.value.filter(p =>
  (!level.value || p.properties.hazardLevel === level.value) &&
  (!keyword.value.trim() || `${pointId(p)} ${p.title} ${p.properties.hazardType ?? ''} ${translateValue(p.properties.hazardType)} ${p.properties.region ?? ''} ${p.properties.basin ?? ''}`.toLowerCase().includes(keyword.value.trim().toLowerCase()))))
const pageCount = computed(() => Math.max(1, Math.ceil(filtered.value.length / pageSize)))
const pageItems = computed(() => filtered.value.slice((page.value - 1) * pageSize, page.value * pageSize))
const pointRoutes = computed(() => selected.value ? routesForPoint(selected.value, summaries.value, links.value) : [])
const routeColors = ['#0d8893', '#e1972e', '#7965b5']
function olFeatures(items: FeatureDetail[]) {
  return items.flatMap(p => {
    const geometry = p.geometry ? reader.readGeometry(p.geometry, {dataProjection:'EPSG:4326', featureProjection:'EPSG:3857'}) : null
    return geometry ? [new Feature({geometry, record:p})] : []
  })
}
function fit(source: VectorSource<Feature<Geometry>>, maxZoom = 10) {
  const extent = source.getExtent()
  if (source.getFeatures().length && extent) map?.getView().fit(extent, {padding:[45,45,45,45], maxZoom, duration:250})
}
function resetMap() { fit(selectedRegion.value ? regionSource : baseSource, 9) }
function pickRegion(region: FeatureDetail | null) {
  selectedRegion.value = region; regionSearch.value = ''; selected.value = null
  regionSource.clear(); if (region) regionSource.addFeatures(olFeatures([region]))
  resetMap()
}
function pickPoint(p: FeatureDetail) { selected.value = p; selectedRoute.value = null; drawSelection() }
function drawSelection() {
  selectedSource.clear(); routeSource.clear(); facilitySource.clear()
  if (!selected.value) return
  selectedSource.addFeatures(olFeatures([selected.value]))
  const visible = selectedRoute.value ? pointRoutes.value.filter(r => r.id === selectedRoute.value) : pointRoutes.value
  for (const r of visible) {
    const code = r.id.split(':')[1]!
    const record = lines.value.find(l => l.properties.routeCode === code)
    const color = routeColors[Math.max(0, pointRoutes.value.indexOf(r)) % routeColors.length]!
    if (record && r.status === 'reachable') for (const f of olFeatures([record])) {
      f.setStyle(new Style({stroke:new Stroke({color, width:3.5})})); routeSource.addFeature(f)
    }
    const link = links.value.find(l => l.routeCode === code)
    const facility = facilities.value.find(f => link && f.ref.layerId === link.facilityLayer && f.ref.id === link.facilityPk)
    if (facility) for (const f of olFeatures([facility])) {
      f.setStyle(new Style({image:new RegularShape({points:4, radius:9, angle:Math.PI/4, fill:new Fill({color}), stroke:new Stroke({color:'#fff',width:2})})})); facilitySource.addFeature(f)
    }
  }
  const source = new VectorSource({features:[...selectedSource.getFeatures(), ...routeSource.getFeatures(), ...facilitySource.getFeatures()]})
  fit(source, 11)
}
async function loadScope() {
  const current = ++revision; loading.value = true; routeLoading.value = true; error.value = ''; routeError.value = ''
  selected.value = null; summaries.value = []; lines.value = []; links.value = []; selectedRoute.value = null
  routeSource.clear(); facilitySource.clear(); selectedSource.clear(); level.value = ''; keyword.value = ''
  points.value = []; pointSource.clear(); page.value = 1
  const currentScope = scope.value
  try {
    const data = await snapshotLayer(scopeLayers[currentScope].points)
    if (disposed || current !== revision) return
    points.value = data; loading.value = false; resetMap()
    const [r, l, a] = await Promise.all([
      snapshotFile<RouteSummary[]>(`route-lists/result.route.${currentScope}.json`),
      snapshotLayer(scopeLayers[currentScope].routes),
      snapshotFile<RouteLink[]>(`route-links/${currentScope}.json`),
    ])
    if (disposed || current !== revision) return
    summaries.value = r; lines.value = l; links.value = a
    const initial = typeof route.query.hazard === 'string' ? points.value.find(p => pointId(p) === route.query.hazard) : null
    if (initial) pickPoint(initial)
    else if (selected.value) drawSelection()
  } catch (e) {
    if (disposed || current !== revision) return
    if (loading.value) error.value = String(e)
    else routeError.value = String(e)
  } finally { if (current === revision && !disposed) { loading.value = false; routeLoading.value = false } }
}
watch(filtered, () => {
  page.value = 1; pointSource.clear(); pointSource.addFeatures(olFeatures(filtered.value))
  if (selected.value && !filtered.value.some(p => p.ref.id === selected.value!.ref.id)) selected.value = null
})
watch(selected, () => { if (!selected.value) { selectedSource.clear(); routeSource.clear(); facilitySource.clear() } })
watch(scope, () => void loadScope())
watch(() => route.query.scope, value => { scope.value = value === '2050' || value === '2100' ? value : 'combined' })
watch(selectedRoute, drawSelection)
onMounted(async () => {
  map = new Map({target:host.value!, controls:controls().extend([new ScaleLine()]), layers:[
    new VectorLayer({source:baseSource, style:new Style({fill:new Fill({color:'#dae5e8'}), stroke:new Stroke({color:'#92aab4',width:1.3})})}),
    new VectorLayer({source:regionSource, style:new Style({fill:new Fill({color:'rgba(9,129,142,.08)'}), stroke:new Stroke({color:'#09818e',width:2})})}),
    new VectorLayer({source:pointSource, style:new Style({image:new CircleStyle({radius:4,fill:new Fill({color:'#736ca3'}),stroke:new Stroke({color:'#fff',width:.7})})})}),
    new VectorLayer({source:routeSource}), new VectorLayer({source:facilitySource}),
    new VectorLayer({source:selectedSource,style:new Style({image:new CircleStyle({radius:8,fill:new Fill({color:'#d65d45'}),stroke:new Stroke({color:'#fff',width:2.5})})})}),
  ], view:new View({center:[10000000,4000000],zoom:4})})
  map.on('singleclick', e => {
    const f = map!.forEachFeatureAtPixel(e.pixel, f => f, {hitTolerance:7, layerFilter:l => l.getSource() === pointSource || l.getSource() === selectedSource})
    if (f) pickPoint(f.get('record') as FeatureDetail)
  })
  map.on('pointermove', e => { if (host.value) host.value.style.cursor = map!.hasFeatureAtPixel(e.pixel,{layerFilter:l=>l.getSource()===pointSource}) ? 'pointer' : '' })
  try {
    const [b, province, city, county, hospital, fire, rescue] = await Promise.all([
      snapshotLayer('DS_BASE_QTP_BOUNDARY'), snapshotLayer('DS_BASE_TIANDITU_PROVINCE_PG'), snapshotLayer('DS_BASE_TIANDITU_CITY_PG'), snapshotLayer('DS_BASE_TIANDITU_COUNTY_PG'),
      snapshotLayer('DS_EMG_AMAP_HOSPITAL'), snapshotLayer('DS_EMG_AMAP_FIRE_STATION'), snapshotLayer('DS_EMG_AMAP_RESCUE_STATION'),
    ])
    if (disposed) return
    boundary.value = b; baseSource.addFeatures(olFeatures(b)); resetMap()
    regions.value = [...province,...city,...county]; facilities.value = [...hospital,...fire,...rescue]
    await loadScope()
  } catch (e) { if (!disposed) { error.value=String(e); loading.value=false } }
})
onBeforeUnmount(() => { disposed = true; ++revision; map?.setTarget(undefined); map = null })
</script>

<template>
  <section class="explorer" data-testid="hazard-explorer">
    <header class="explorer-heading"><div><p class="eyebrow">QINGHAI–TIBET PLATEAU</p><h1>{{ t('危险点与应急救援', 'Hazards & emergency response') }}</h1><p>{{ t('选择地区、发现危险点，查看关联设施与已计算的救援路线。','Find a region, select a hazard location, and explore its facilities and saved rescue routes.') }}</p></div><RouterLink class="btn" to="/layers">{{ t('图层工作台','Layer workspace') }} ↗</RouterLink></header>
    <div class="scope-tabs" role="group" :aria-label="t('分析专题','Analysis topic')"><button v-for="s in (['combined','2050','2100'] as Scope[])" :key="s" :aria-pressed="scope===s" :class="{active:scope===s}" @click="scope=s">{{ scopeTitle(s) }}<small>{{ s==='combined' ? t('团队计算成果','Team analysis') : t('外部冰湖数据 · 团队救援分析','External lake data · team routing') }}</small></button></div>
    <p class="provenance" v-if="scope!=='combined'">{{ t('冰湖来源：Zhang (2025)，国家青藏高原科学数据中心。路线由团队计算；原始 HRGI、EXPOSURE、RRGI 保留，不与团队评分混合。','Lake data: Zhang (2025), National Tibetan Plateau Data Center. Routes computed by the team. Original HRGI, EXPOSURE and RRGI are kept separate from team scores.') }} <a href="https://doi.org/10.11888/Cryos.tpdc.302610" target="_blank" rel="noreferrer">{{ t('来源与引用','Source & citation') }} ↗</a></p>
    <div class="explorer-grid">
      <aside class="search-panel panel">
        <h2>{{ t('查找危险点','Find hazard locations') }}</h2>
        <label>{{ t('搜索地区（省 / 市 / 县 / 编码）','Search region (Chinese name / code)') }}<input v-model="regionSearch" type="search" :placeholder="t('例如：吉隆县、拉萨市','e.g. 吉隆县, 拉萨市')" data-testid="region-search" /></label>
        <ul v-if="regionSearch.trim()" class="suggestions"><li v-for="r in suggestions" :key="r.ref.layerId+r.ref.id"><button @click="pickRegion(r)">{{ r.properties.name ?? r.title }} <small>{{ r.properties.pac }}</small></button></li><li v-if="!suggestions.length">{{ t('没有匹配地区，请尝试中文名称或行政区编码。','No match. Try a Chinese place name or administrative code.') }}</li></ul>
        <div v-if="selectedRegion" class="region-chip"><span>{{ selectedRegion.properties.name ?? selectedRegion.title }}</span><button @click="pickRegion(null)" :aria-label="t('清除地区','Clear region')">×</button></div>
        <label>{{ t('编号 / 类型 / 流域','ID / type / basin') }}<input v-model="keyword" type="search" :placeholder="t('输入关键词筛选','Filter locations')" /></label>
        <label v-if="scope==='combined'">{{ t('易发性等级','Susceptibility level') }}<select v-model="level"><option value="">{{ t('全部等级','All levels') }}</option><option v-for="l in levels" :key="l" :value="l">{{ translateValue(l) }}</option></select></label>
        <p class="count" role="status">{{ loading ? t('正在读取成果…','Loading results…') : `${filtered.length} ${t('个点位','locations')}` }}</p>
        <p v-if="error" role="alert">{{ error }} <button class="btn" @click="loadScope">{{ t('重试','Retry') }}</button></p>
        <div class="point-list"><button v-for="p in pageItems" :key="p.ref.id" class="point-row" :class="{selected:selected?.ref.id===p.ref.id}" @click="pickPoint(p)" :data-testid="`hazard-${pointId(p)}`"><strong>{{ pointId(p) }}</strong><span>{{ scope==='combined' ? `${translateValue(p.properties.hazardType)} · ${translateValue(p.properties.hazardLevel)}` : `${p.properties.region ?? ''} · ${p.properties.basin ?? ''}` }}</span><small v-if="scope==='combined'">{{ t('易发性评分','Score') }} {{ p.properties.score }}</small></button><p v-if="!loading&&!error&&!filtered.length">{{ t('当前条件下没有点位。请调整筛选或清除地区。','No locations match. Adjust filters or clear the region.') }}</p></div>
        <div class="pagination"><button :disabled="page<=1" @click="page--">←</button><span>{{ page }} / {{ pageCount }}</span><button :disabled="page>=pageCount" @click="page++">→</button></div>
      </aside>
      <div class="map-and-details">
        <div class="map-frame panel"><div class="map-tools"><span>{{ scopeTitle(scope) }}</span><button class="btn btn--small" @click="resetMap">{{ t('返回地区范围','Region extent') }}</button><button v-if="selected" class="btn btn--small" @click="drawSelection">{{ t('定位所选点与路线','Fit selection & routes') }}</button></div><div ref="host" class="explorer-map" data-testid="explorer-map"></div><div class="map-legend"><span>● {{ t('候选危险点','Hazard locations') }}</span><span class="selected-key">● {{ t('所选点','Selected location') }}</span><span>◆ {{ t('关联救援设施','Linked facilities') }}</span><span>━ {{ t('已存救援路线','Saved rescue routes') }}</span></div></div>
        <section class="details panel" aria-live="polite">
          <template v-if="selected"><div class="details-head"><div><p class="eyebrow">{{ t('所选点位','SELECTED LOCATION') }}</p><h2>{{ pointId(selected) }}</h2></div><button class="btn btn--small" @click="selected=null">{{ t('清除选中','Clear selection') }}</button></div>
            <div class="metrics" v-if="scope==='combined'"><div><span>{{ t('易发性评分','Susceptibility score') }}</span><strong>{{ selected.properties.score }}</strong></div><div><span>{{ t('灾害类型','Hazard type') }}</span><strong>{{ translateValue(selected.properties.hazardType) }}</strong></div><div><span>{{ t('易发性等级','Susceptibility level') }}</span><strong>{{ translateValue(selected.properties.hazardLevel) }}</strong></div></div>
            <div v-else class="metrics"><div v-for="k in ['hrgi','exposure','rrgi']" :key="k"><span>{{ k.toUpperCase() }}</span><strong>{{ selected.properties[k] }}</strong></div></div>
            <p class="footnote" v-if="selected.geometry?.type==='Point'">{{ t('经纬度','Longitude / latitude') }}: {{ selected.geometry.coordinates.map(n=>n.toFixed(5)).join(', ') }}</p>
            <p v-if="scope==='combined' && selected.properties.triggers" class="footnote">{{ t('潜在触发条件（原始记录）','Potential triggers (original record)') }}: {{ selected.properties.triggers }}</p>
            <h3>{{ t('关联设施与救援路线','Facilities & rescue routes') }}</h3><p v-if="routeLoading">{{ t('正在读取关联路线…','Loading route associations…') }}</p><p v-else-if="routeError" role="alert">{{ routeError }} <button class="btn" @click="loadScope">{{ t('重试','Retry') }}</button></p><p v-else-if="!pointRoutes.length">{{ t('此点位没有关联的已存救援路线。','No saved rescue routes are linked to this location.') }}</p>
            <div class="route-cards"><button v-for="(r,i) in pointRoutes" :key="r.id" :style="{'--route-color':routeColors[i%routeColors.length]}" :class="{chosen:selectedRoute===r.id}" @click="selectedRoute=selectedRoute===r.id?null:r.id" :aria-pressed="selectedRoute===r.id"><small>{{ translateValue(r.facilityType) }}</small><strong>{{ r.label }}</strong><span>{{ r.status==='reachable'&&r.distanceMeters!==null ? `${(r.distanceMeters/1000).toFixed(2)} km` : t('路网不可达','Unreachable on network') }}</span></button></div>
            <p class="footnote">{{ t('距离为已计算路网距离。路线不包含实时路况、灾损及设施运行状态；地图线面经过概化。','Distances are saved network distances. Routes do not incorporate live traffic, damage or facility availability. Map lines and polygons are simplified.') }}</p>
          </template><div v-else class="empty-detail"><span class="empty-icon">⌖</span><h2>{{ t('从一个危险点开始','Start with a hazard location') }}</h2><p>{{ t('点击地图上的点或左侧列表，查看对应设施与路线。','Select a point on the map or in the list to explore linked facilities and routes.') }}</p></div>
        </section>
        <p class="footnote">{{ t('地区筛选使用已发布行政区边界；边界按 200 米容差概化，边缘点归属仅供浏览参考。','Region filtering uses published administrative polygons simplified at 200 m tolerance; boundary-edge assignments are for browsing.') }}</p>
      </div>
    </div>
  </section>
</template>

<style scoped>
.explorer{display:grid;gap:18px;color:var(--color-text)}.explorer-heading,.details-head{display:flex;align-items:center;justify-content:space-between;gap:16px;flex-wrap:wrap}.explorer h1{margin:4px 0 8px;font-size:28px}.explorer-heading p{margin:0;color:var(--color-muted);line-height:1.7}.eyebrow{font-size:11px!important;letter-spacing:.12em;color:#187f8c!important;font-weight:700}.scope-tabs{display:grid;grid-template-columns:repeat(3,1fr);gap:10px}.scope-tabs button{padding:15px 18px;border:1px solid var(--color-border);border-radius:10px;background:var(--color-surface);text-align:left;color:var(--color-text);cursor:pointer;font-weight:650}.scope-tabs button.active{border-color:#157b88;background:#eef7f8;box-shadow:inset 0 3px #157b88}.scope-tabs small{display:block;margin-top:7px;font-size:12px;color:var(--color-muted);font-weight:400}.provenance{margin:0;padding:12px 16px;background:#edf5f8;border-radius:8px;font-size:13px;line-height:1.7}.explorer-grid{display:grid;grid-template-columns:300px minmax(0,1fr);gap:18px;align-items:start}.panel{background:var(--color-surface);border:1px solid var(--color-border);border-radius:12px;overflow:hidden}.search-panel{padding:18px;display:grid;gap:14px}.explorer h2{font-size:18px;margin:0}.search-panel label{display:grid;gap:7px;font-size:12px;font-weight:600;color:var(--color-muted)}.search-panel input,.search-panel select{width:100%;box-sizing:border-box;border:1px solid var(--color-border);border-radius:7px;padding:10px;background:var(--color-surface);color:var(--color-text);font:inherit;font-size:14px}.search-panel input:focus,.search-panel select:focus{outline:2px solid #218796;outline-offset:1px}.suggestions{list-style:none;margin:0;padding:0;max-height:230px;overflow:auto;border:1px solid var(--color-border);border-radius:6px}.suggestions button{width:100%;padding:9px;text-align:left;border:0;background:transparent;color:var(--color-text);cursor:pointer}.suggestions button:hover{background:#eef7f8}.suggestions li{font-size:13px}.suggestions small{color:var(--color-muted)}.region-chip{display:flex;justify-content:space-between;background:#edf7f6;border-radius:6px;padding:8px 10px;font-size:13px}.region-chip button{border:0;background:none;color:#176d78;cursor:pointer}.count{margin:0;font-size:13px;color:var(--color-muted)}.point-list{max-height:490px;overflow:auto;display:grid;gap:6px}.point-row{display:grid;gap:5px;text-align:left;padding:11px;border:1px solid transparent;border-radius:7px;background:#f5f8fa;color:var(--color-text);cursor:pointer}.point-row.selected{background:#edf7f7;border-color:#218796}.point-row span,.point-row small{font-size:12px;color:var(--color-muted)}.pagination{display:flex;align-items:center;justify-content:space-between;font-size:12px}.pagination button{border:1px solid var(--color-border);border-radius:5px;background:var(--color-surface);padding:6px 12px;cursor:pointer}.map-and-details{min-width:0;display:grid;gap:16px}.map-tools{display:flex;gap:8px;align-items:center;flex-wrap:wrap;padding:12px 15px}.map-tools>span{font-size:13px;font-weight:650;margin-right:auto}.explorer-map{height:480px;background:#edf2f4}.map-legend{display:flex;gap:20px;flex-wrap:wrap;padding:11px 16px;font-size:12px;color:#736ca3}.map-legend .selected-key{color:#d65d45}.details{padding:20px}.details h3{font-size:15px;margin:22px 0 12px}.metrics{display:flex;gap:30px;flex-wrap:wrap;margin-top:20px}.metrics div{display:grid;gap:6px}.metrics span{font-size:12px;color:var(--color-muted)}.metrics strong{font-size:20px}.route-cards{display:grid;grid-template-columns:repeat(auto-fit,minmax(180px,1fr));gap:10px}.route-cards button{display:grid;gap:9px;text-align:left;border:1px solid var(--color-border);border-left:4px solid var(--route-color);border-radius:8px;padding:13px;background:var(--color-surface);color:var(--color-text);cursor:pointer}.route-cards button.chosen{background:#edf7f8;box-shadow:0 0 0 1px var(--route-color)}.route-cards small{color:var(--route-color)}.route-cards strong{font-size:14px;line-height:1.5}.route-cards span{font-size:13px}.footnote{font-size:12px;color:var(--color-muted);line-height:1.8;margin:14px 0 0}.empty-detail{text-align:center;padding:25px 10px;color:var(--color-muted)}.empty-icon{font-size:30px;color:#23808e}.empty-detail h2{color:var(--color-text);margin:10px 0}.empty-detail p{font-size:14px}.explorer button:focus-visible{outline:2px solid #218796;outline-offset:2px}.explorer button:disabled{opacity:.45;cursor:default}@media(max-width:1000px){.explorer-grid{grid-template-columns:250px minmax(0,1fr)}.scope-tabs button{padding:12px}.explorer-map{height:420px}}@media(max-width:720px){.scope-tabs{grid-template-columns:1fr}.explorer-grid{grid-template-columns:1fr}.point-list{max-height:230px}.explorer-map{height:340px}.explorer h1{font-size:23px}.map-legend{gap:12px}}
</style>
