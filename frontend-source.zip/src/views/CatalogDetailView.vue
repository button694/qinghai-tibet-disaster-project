<script setup lang="ts">
/**
 * 阶段6：数据集详情页。
 *
 * 展示来源、版本、CRS、年份或时段、分辨率、质量说明、字段字典、关联图层与
 * 关联成果；栅格数据集提供年度降水浏览（年份由 availableTimes 派生）。
 * 硬性约束：不向普通页面暴露服务器或本机绝对路径——本页只显示登记的
 * 数据集名称、图层 ID 与相对引用，不显示 FILE_PATH、磁盘盘符或数据源 URL。
 */
import { computed, onMounted, watch } from 'vue'
import { RouterLink, useRoute } from 'vue-router'

import PrecipYearBrowser from '@/components/catalog/PrecipYearBrowser.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import {
  ACCESS_LEVEL_LABEL,
  DATASET_STATUS_LABEL,
  GEOMETRY_FAMILY_LABEL,
  RESULT_KIND_LABEL,
} from '@/domain/labels'
import { formatAvailableTimes, NOT_PROVIDED_TEXT, NOT_REGISTERED_TEXT } from '@/domain/format'
import type { FieldType } from '@/domain/types'
import { useCatalogStore } from '@/stores/catalog'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const store = useCatalogStore()
const session = useSessionStore()

const datasetId = computed(() => String(route.params.datasetId ?? ''))

const detail = computed(() => store.detail)
const isRasterPrecip = computed(() => detail.value !== null && detail.value.precipYears.length > 0)
/**
 * 多年份栅格资产（目前是年度降水，2001—2023）：由后端 rasterPreviewYears 直接
 * 给出年份→资产 id 映射，独立于 availableTimes 派生的 precipYears/统计口径，
 * 只用于在 /rasters 页面按年份切换浏览，不涉及任何统计数值。
 */
const rasterPreviewYearOptions = computed(() => {
  const years = detail.value?.dataset.rasterPreviewYears
  if (!years) return []
  return Object.entries(years).sort(([a], [b]) => Number(a) - Number(b))
})
const coordinateText = computed(() =>
  detail.value?.dataset.sourceCrs === 'CGCS2000_Tibetan_Plateau_LCC'
    ? '青藏高原区域坐标'
    : (detail.value?.dataset.sourceCrs ?? NOT_REGISTERED_TEXT),
)

const FIELD_TYPE_LABEL: Record<FieldType, string> = {
  string: '文本',
  number: '数值',
  date: '日期',
  enum: '枚举',
  boolean: '布尔',
}

onMounted(() => {
  void session.loadCapabilities()
  if (datasetId.value !== '') void store.loadDetail(datasetId.value)
})

watch(
  () => route.params.datasetId,
  (next) => {
    if (route.name !== 'catalog-detail') return
    const id = String(next ?? '')
    if (id !== '') void store.loadDetail(id)
  },
)
</script>

<template>
  <div class="catalog-detail" data-testid="catalog-detail-page">
    <p class="back-link">
      <RouterLink to="/catalog">← 返回数据目录</RouterLink>
    </p>

    <LoadingState
      v-if="store.detailStatus === 'loading' || store.detailStatus === 'idle'"
      label="正在读取数据集…"
    />
    <template v-else-if="store.detailStatus === 'failed'">
      <!-- 错误态同样保留页面标题（h1）：外壳与全路由回归要求每页有标题锚点。 -->
      <header class="detail-head">
        <div>
          <h1 class="page-heading">数据集详情</h1>
          <p class="page-lead">正在准备数据集信息。</p>
        </div>
      </header>
      <ErrorState
        :error="store.detailError"
        title="数据集读取失败"
        data-testid="catalog-detail-error"
        @retry="store.loadDetail(datasetId)"
      />
    </template>

    <template v-else-if="detail !== null">
      <header class="detail-head">
        <div>
          <h1 class="page-heading" data-testid="catalog-detail-name">{{ detail.dataset.name }}</h1>
          <p class="page-lead">数据来源、覆盖范围与可浏览内容。</p>
        </div>
        <SourceBadge
          :mode="session.mode"
          :snapshot-id="session.snapshotId ?? undefined"
          :scope-label="session.scopeLabel ?? undefined"
        />
      </header>

      <section class="panel" data-testid="catalog-meta" aria-label="数据集登记信息">
        <h2 class="section-title">登记信息</h2>
        <dl class="meta-grid">
          <div class="meta-row">
            <dt>来源</dt>
            <dd data-testid="catalog-source">
              <template v-if="detail.source !== null">
                {{ detail.source.name
                }}<template v-if="detail.source.organization !== null">
                  （{{ detail.source.organization }}）</template
                >
                <span v-if="detail.source.licenseDescription" class="meta-sub">
                  {{ detail.source.licenseDescription }}</span
                >
              </template>
              <template v-else>{{ NOT_REGISTERED_TEXT }}</template>
            </dd>
          </div>
          <div class="meta-row">
            <dt>版本</dt>
            <dd>{{ detail.dataset.version }}</dd>
          </div>
          <div class="meta-row">
            <dt>数据坐标</dt>
            <dd>{{ coordinateText }}</dd>
          </div>
          <div class="meta-row">
            <dt>年份 / 时段</dt>
            <dd data-testid="catalog-times">
              {{
                detail.dataset.temporalCoverage ??
                formatAvailableTimes(detail.dataset.availableTimes)
              }}
              <span v-if="detail.dataset.availableTimes.length === 0"
                >（{{ NOT_PROVIDED_TEXT }}）</span
              >
            </dd>
          </div>
          <div class="meta-row">
            <dt>分辨率</dt>
            <dd>{{ detail.dataset.resolution ?? NOT_REGISTERED_TEXT }}</dd>
          </div>
          <div class="meta-row">
            <dt>质量说明</dt>
            <dd>{{ detail.dataset.quality ?? NOT_REGISTERED_TEXT }}</dd>
          </div>
          <div class="meta-row">
            <dt>状态 / 访问级别</dt>
            <dd>
              {{ DATASET_STATUS_LABEL[detail.dataset.status] }} ·
              {{ ACCESS_LEVEL_LABEL[detail.dataset.accessLevel] }}
            </dd>
          </div>
          <div class="meta-row">
            <dt>服务状态</dt>
            <dd data-testid="catalog-service-state">
              <template v-if="detail.dataset.serviceAvailable">
                可浏览
                <RouterLink
                  v-if="detail.dataset.rasterPreviewId"
                  class="text-link"
                  :to="{ path: '/rasters', query: { asset: detail.dataset.rasterPreviewId } }"
                  >在地图中查看</RouterLink
                >
              </template>
              <template v-else>
                暂无展示图层 —— {{ detail.dataset.serviceNote ?? '暂未登记说明。' }}
              </template>
            </dd>
          </div>
          <div v-if="rasterPreviewYearOptions.length > 0" class="meta-row">
            <dt>按年份浏览</dt>
            <dd data-testid="catalog-raster-year-links">
              <span class="year-link-note"
                >同一个年度数据集的
                {{ rasterPreviewYearOptions.length }}
                个年度时相，各年份色阶已统一，颜色可跨年比较：</span
              >
              <span class="year-link-list">
                <RouterLink
                  v-for="[year, assetId] in rasterPreviewYearOptions"
                  :key="year"
                  class="text-link"
                  :to="{ path: '/rasters', query: { asset: assetId } }"
                  >{{ year }}</RouterLink
                >
              </span>
            </dd>
          </div>
        </dl>
      </section>

      <PrecipYearBrowser
        v-if="isRasterPrecip"
        :dataset="detail.dataset"
        :years="detail.precipYears"
        :selected-year="store.selectedPrecipYear"
        @select="store.selectPrecipYear"
      />

      <section class="panel" aria-label="字段字典">
        <h2 class="section-title">字段字典</h2>
        <div class="table-wrap">
          <table class="plain-table" data-testid="catalog-fields">
            <thead>
              <tr>
                <th scope="col">字段名</th>
                <th scope="col">标签</th>
                <th scope="col">类型</th>
                <th scope="col">单位</th>
                <th scope="col">可空</th>
                <th scope="col">可筛选</th>
                <th scope="col">可排序</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="field in detail.dataset.fields" :key="field.key">
                <td>
                  <code>{{ field.key }}</code>
                </td>
                <td>{{ field.label }}</td>
                <td>{{ FIELD_TYPE_LABEL[field.type] }}</td>
                <td>{{ field.unit ?? NOT_PROVIDED_TEXT }}</td>
                <td>{{ field.nullable ? '是' : '否' }}</td>
                <td>{{ field.filterable ? '是' : '否' }}</td>
                <td>{{ field.sortable ? '是' : '否' }}</td>
              </tr>
              <tr v-if="detail.dataset.fields.length === 0">
                <td colspan="7">该数据集未登记字段字典。</td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <div class="two-col">
        <section class="panel" aria-label="关联图层">
          <h2 class="section-title">关联图层</h2>
          <ul class="link-list" data-testid="catalog-layers">
            <li v-for="layer in detail.relatedLayers" :key="layer.id" class="link-item">
              {{ layer.label }} · {{ GEOMETRY_FAMILY_LABEL[layer.geometryType] }}
              <span v-if="detail.dataset.rasterPreviewId" class="meta-sub"> 可在栅格地图查看</span>
              <span v-else-if="layer.source.type === 'unavailable'" class="meta-sub">
                暂无地图内容</span
              >
            </li>
            <li v-if="detail.relatedLayers.length === 0" class="link-item">
              该数据集未登记关联图层。
            </li>
          </ul>
        </section>

        <section class="panel" aria-label="关联成果">
          <h2 class="section-title">关联成果</h2>
          <ul class="link-list" data-testid="catalog-related-results">
            <li v-for="result in detail.relatedResults" :key="result.id" class="link-item">
              <RouterLink :to="{ name: 'result-detail', params: { resultId: result.id } }">
                {{ result.title }}
              </RouterLink>
              （{{ RESULT_KIND_LABEL[result.kind] }} · {{ result.version }}）
            </li>
            <li v-if="detail.relatedResultsNote" class="link-item is-muted">
              {{ detail.relatedResultsNote }}
            </li>
            <li v-else-if="detail.relatedResults.length === 0" class="link-item">
              暂无使用该数据集作为输入的成果登记。
            </li>
          </ul>
        </section>
      </div>
    </template>
  </div>
</template>

<style scoped>
.catalog-detail {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.back-link {
  margin: 0;
  font-size: var(--font-size-caption);
}

.back-link a {
  color: var(--color-muted);
}

.detail-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
}

.panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.meta-grid {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-2) var(--space-5);
  margin: 0;
}

.meta-row {
  display: grid;
  grid-template-columns: 128px 1fr;
  gap: var(--space-2);
  align-items: baseline;
}

.meta-row dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.meta-row dd {
  margin: 0;
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.meta-sub {
  display: block;
  color: var(--color-muted);
  font-size: 11px;
  margin-top: 2px;
}

.year-link-note {
  display: block;
  color: var(--color-muted);
  font-size: 11px;
  margin-bottom: 4px;
}

.year-link-list {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2);
}

.table-wrap {
  overflow-x: auto;
}

.plain-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.plain-table th,
.plain-table td {
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  white-space: nowrap;
}

.plain-table th {
  color: var(--color-muted);
  font-weight: 600;
}

.two-col {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-4);
}

.link-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
  font-size: var(--font-size-caption);
}

.link-item {
  overflow-wrap: anywhere;
}

.link-item a {
  color: var(--color-primary);
}

@media (max-width: 900px) {
  .meta-grid,
  .two-col {
    grid-template-columns: 1fr;
  }

  .meta-row {
    grid-template-columns: 1fr;
    gap: 2px;
  }

  .detail-head {
    flex-direction: column;
  }
}
</style>
