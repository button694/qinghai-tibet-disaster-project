<script setup lang="ts">
/**
 * 风险一张图（阶段2 地图与图层、阶段3 属性与空间查询已实现）。
 *
 * 本页只做组装：所有图层、要素、图例、数据集与字典都经 Repository 取数，
 * 具体的地图生命周期、三栏布局与面板交互在 `layouts/MapWorkspace.vue` 及其子组件中。
 * 属性查询与空间查询由 `MapWorkspace` 统一组装；示例包会在完整小样本上
 * 实际执行空间关系，并持续标注距离方法、单位和示例身份。
 */
import MapWorkspace from '@/layouts/MapWorkspace.vue'
</script>

<template>
  <MapWorkspace />
</template>
