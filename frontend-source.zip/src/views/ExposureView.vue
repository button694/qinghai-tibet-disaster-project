<script setup lang="ts">
/**
 * 阶段5：暴露度与影响评估页（/analysis/exposure）。
 *
 * 数据链路：本页 → stores/exposure.ts → services/exposureWorkspace.ts →
 * ResultRepository / LayerRepository（页面与组件不直接 fetch JSON）。
 *
 * 上下文链路（03 §8-1、§8-7）：支持深链接 `?resultId=...&hazard=<layerId>:<id>`
 * 从地图危险源进入；页面底部提供到应急方案的链接（携带上下文）。
 * QTP_GEOHAZARD 已恢复并确认存在正式成果表；当前真实演示范围不包含正式影响范围与人口统计，
 * API 模式展示后续深化规划空态，mock 模式仍可独立验证示例交互并持续标注「示例数据」。
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

import ExposureAffectedTable from '@/components/exposure/ExposureAffectedTable.vue'
import ExposureControlPanel from '@/components/exposure/ExposureControlPanel.vue'
import ExposureMapCanvas from '@/components/exposure/ExposureMapCanvas.vue'
import ExposureMetricsPanel from '@/components/exposure/ExposureMetricsPanel.vue'
import ExposureSourcePanel from '@/components/exposure/ExposureSourcePanel.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import { representativeLonLat } from '@/domain/geometry'
import type { FeatureRef, LonLat, ResultSummary } from '@/domain/types'
import { getEmergencyWorkspaceService } from '@/services/emergencyWorkspace'
import { useExposureStore } from '@/stores/exposure'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const store = useExposureStore()
const session = useSessionStore()
const isApiPlanning = computed(() => session.mode === 'api')

const mapRef = ref<InstanceType<typeof ExposureMapCanvas> | null>(null)

/** 应急类成果清单：只取 id/title 供「查看应急方案」链接；失败不阻塞本页。 */
const emergencyResults = ref<ResultSummary[]>([])

onMounted(() => {
  void session.loadCapabilities().then(() => {
    if (session.mode === 'api') return
    void store.initFromQuery({
      resultId: asString(route.query.resultId),
      hazard: asString(route.query.hazard),
    })
    void loadEmergencyResults()
  })
})

function asString(value: unknown): string | null {
  return typeof value === 'string' && value.trim() !== '' ? value : null
}

async function loadEmergencyResults(): Promise<void> {
  try {
    emergencyResults.value = await getEmergencyWorkspaceService().listEmergencyResults()
  } catch {
    emergencyResults.value = []
  }
}

/** 深链接变化（同一路由组件复用）时重新进入。 */
watch(
  () => [route.query.resultId, route.query.hazard] as const,
  ([nextResult, nextHazard]) => {
    if (route.name !== 'analysis-exposure') return
    if (session.mode === 'api') return
    void store.initFromQuery({ resultId: asString(nextResult), hazard: asString(nextHazard) })
  },
)

/** 选中对象的坐标（定位用）；无几何为 null。 */
function lonLatOf(ref: FeatureRef): LonLat | null {
  const row =
    store.affectedRows.find((item) => item.ref.layerId === ref.layerId && item.ref.id === ref.id) ??
    store.impactAreas.find((item) => item.ref.layerId === ref.layerId && item.ref.id === ref.id) ??
    null
  return representativeLonLat(row?.geometry ?? null)
}

function onSelect(ref: FeatureRef | null): void {
  store.select(ref)
}

function onLocate(ref: FeatureRef): void {
  store.select(ref)
  const lonLat = lonLatOf(ref)
  if (lonLat !== null) mapRef.value?.focusCoordinate(lonLat[0], lonLat[1])
}

function onLocateHazard(): void {
  const ref = store.entryHazardRef
  if (ref === null) return
  // 来源危险源的坐标在要素详情里（进入时已读取）。
  const geometry = store.entryHazardDetail?.geometry ?? null
  const lonLat = representativeLonLat(geometry)
  if (lonLat !== null) mapRef.value?.focusCoordinate(lonLat[0], lonLat[1])
}

const emergencyQuery = computed(() => {
  const params = new URLSearchParams()
  const hazard = store.entryHazardRef
  if (hazard !== null) params.set('hazard', `${hazard.layerId}:${hazard.id}`)
  const query = params.toString()
  return query === '' ? '' : `?${query}`
})
</script>

<template>
  <div class="exposure-page" data-testid="exposure-page">
    <header class="page-head">
      <div>
        <h1 class="page-title">暴露度与影响评估</h1>
        <p class="page-subtitle">从危险源或成果进入，查看影响范围、受影响对象和相关统计。</p>
      </div>
      <nav class="context-chain" aria-label="上下文链路">
        <RouterLink class="chain-link" data-testid="to-map" to="/map">危险源（一张图）</RouterLink>
        <span class="chain-sep" aria-hidden="true">→</span>
        <span class="chain-current">暴露度</span>
        <span class="chain-sep" aria-hidden="true">→</span>
        <RouterLink
          class="chain-link"
          data-testid="to-emergency-top"
          :to="`/analysis/emergency${emergencyQuery}`"
          >应急保障</RouterLink
        >
      </nav>
    </header>

    <p class="pending-banner" data-testid="exposure-pending-banner" role="note">
      <b>数据说明：</b>当前版本暂未提供完整影响范围与人口统计关联；
      <template v-if="session.mode === 'mock'"
        >本页当前为<b>演示数据</b>，仅用于了解页面功能。</template
      >
      <template v-else>相关成果准备完成后会在此处显示。</template>
      2050 / 2100 为独立的未来情景，不用于替代本页统计。
    </p>

    <section v-if="isApiPlanning" class="planning-card" data-testid="exposure-planning" role="note">
      <h2>后续深化方向</h2>
      <p>
        当前已具备易发性点、救援路线及应急设施成果，但暂未提供可用于本页面的完整影响范围、
        受影响对象和人口统计关联。
      </p>
      <ul>
        <li>补充影响范围成果及其统计口径。</li>
        <li>完善受影响对象分类与人口统计来源。</li>
        <li>完成后开放影响范围地图、指标、筛选与导出。</li>
      </ul>
      <p class="planning-footnote">该页面属于后续专题，当前不会显示不完整或未经确认的统计。</p>
    </section>

    <template v-else>
      <!-- 清单失败：整体错误 + 重试（mock/snapshot 模式） -->
      <ErrorState
        v-if="store.listStatus === 'failed'"
        data-testid="exposure-list-error"
        title="暴露成果清单读取失败"
        :error="store.listError"
        :retryable="true"
        @retry="store.retry()"
      />

      <template v-else>
        <ExposureControlPanel
          :result="store.result"
          :summary="store.summary"
          :entry-hazard="store.entryHazardDetail"
          :entry-hazard-ref="store.entryHazardRef"
          :hazard-ref="store.hazardRef"
          :active-category="store.category"
          :filtered-count="store.affectedTotal"
          :total-count="store.summary?.matchedRecordCount ?? 0"
          @category="store.setCategory"
          @clear="store.clearFilters"
        />

        <button
          v-if="store.entryHazardRef !== null"
          type="button"
          class="btn btn--ghost btn--small locate-hazard"
          data-testid="locate-entry-hazard"
          @click="onLocateHazard"
        >
          定位来源危险源
        </button>

        <div class="exposure-grid">
          <div class="map-cell">
            <div v-if="store.areasStatus === 'loading'" class="map-state">
              <p>影响范围读取中…</p>
            </div>
            <div v-else-if="store.areasStatus === 'failed'" class="map-state" role="alert">
              <h3>影响范围读取失败</h3>
              <p data-testid="exposure-areas-error">{{ store.areasError?.userMessage }}</p>
              <button
                type="button"
                class="btn btn--small"
                data-testid="exposure-retry-areas"
                @click="store.retry()"
              >
                重试
              </button>
            </div>
            <ExposureMapCanvas
              v-else
              ref="mapRef"
              :impact-areas="store.impactAreas"
              :affected="store.affectedRows"
              :selected-key="store.selectedKey()"
              :hazard-lon-lat="representativeLonLat(store.entryHazardDetail?.geometry ?? null)"
              :mode="session.mode"
              @select="onSelect"
            />
          </div>

          <aside class="side">
            <div v-if="store.summaryStatus === 'loading'" class="panel-box">
              <p>统计读取中…</p>
            </div>
            <div v-else-if="store.summaryStatus === 'failed'" class="panel-box error" role="alert">
              <p>{{ store.summaryError?.userMessage }}</p>
              <button
                type="button"
                class="btn btn--small"
                data-testid="exposure-retry-summary"
                @click="store.retry()"
              >
                重试
              </button>
            </div>
            <ExposureMetricsPanel v-else-if="store.summary" :summary="store.summary" />
          </aside>

          <div class="affected-cell">
            <ExposureAffectedTable
              :rows="store.affectedRows"
              :total="store.affectedTotal"
              :page="store.page"
              :page-size="store.pageSize"
              :loading="store.affectedStatus === 'loading'"
              :error-text="store.affectedError?.userMessage ?? null"
              :selected-key="store.selectedKey()"
              @select="onSelect"
              @locate="onLocate"
              @page="store.goToPage"
            />
          </div>
        </div>

        <ExposureSourcePanel
          :result="store.result"
          :emergency-results="emergencyResults"
          :emergency-query="emergencyQuery"
        />
      </template>
    </template>
  </div>
</template>

<style scoped>
.exposure-page {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.page-title {
  margin: 0;
  font-size: var(--font-size-page-title);
  color: var(--color-text);
}

.page-subtitle {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
  max-width: 72ch;
}

.context-chain {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.chain-link {
  padding: 2px var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--badge-radius);
  background: var(--color-surface-sunken);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
}

.chain-current {
  padding: 2px var(--space-2);
  border-radius: var(--badge-radius);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
  font-weight: var(--button-font-weight);
}

.chain-sep {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.pending-banner {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-warning);
  border-left-width: 4px;
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.locate-hazard {
  justify-self: start;
}

.exposure-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 420px;
  gap: var(--space-3);
  align-items: start;
}

/* 地图行高必须确定（阶段2/3 的布局铁律）。 */
.map-cell {
  height: clamp(340px, 52vh, 620px);
  min-width: 0;
  min-height: 0;
}

.map-state {
  display: grid;
  gap: var(--space-2);
  align-content: center;
  justify-items: start;
  height: 100%;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  color: var(--color-muted);
}

.side {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.affected-cell {
  grid-column: 1 / -1;
  min-width: 0;
}

.panel-box {
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  color: var(--color-muted);
}

.panel-box.error {
  border-color: var(--color-danger);
  color: var(--color-danger-text);
}

.planning-card {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-left: 4px solid var(--color-primary);
  border-radius: var(--radius-md);
  background: var(--color-info-surface);
  color: var(--color-text);
}

.planning-card h2,
.planning-card p {
  margin: 0;
}

.planning-card p,
.planning-card li {
  color: var(--color-muted);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.planning-card ul {
  margin: 0;
  padding-left: var(--space-4);
}

.planning-card .planning-footnote {
  font-size: var(--font-size-caption);
}

@media (max-width: 1100px) {
  .exposure-grid {
    grid-template-columns: minmax(0, 1fr);
  }

  .map-cell {
    height: clamp(280px, 48vh, 480px);
  }
}

@media (max-width: 600px) {
  .map-cell {
    height: 300px;
  }
}
</style>
