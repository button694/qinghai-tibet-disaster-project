<script setup lang="ts">
import { ref } from 'vue'
import { RouterLink } from 'vue-router'
import { useLanguage } from '@/composables/useLanguage'

const { t } = useLanguage()
const notice = ref('')
const sources = [
  { id: 'center', url: 'https://www.tpdc.ac.cn/' },
  { id: 'lakes', url: 'https://www.tpdc.ac.cn/en/data/e1289464-6680-4c7e-b92b-cf7d422bd044' },
]
async function copyUrl(url: string) {
  try {
    await navigator.clipboard.writeText(url)
    notice.value = t('网址已复制。', 'URL copied.')
  } catch {
    notice.value = t('请选中下方完整网址进行复制。', 'Please select and copy the full URL shown below.')
  }
}
</script>

<template>
  <div class="source-page" data-testid="published-risk-sources">
    <header>
      <p class="eyebrow">DATA SOURCES & ANALYSIS</p>
      <h1>{{ t('专题研判与数据来源', 'Analysis & data sources') }}</h1>
      <p class="lead">{{ t('团队灾害易发性成果与外部冰湖数据分开展示。先了解数据来源，再进入地图查看点位与救援路线。', 'Team susceptibility results and externally sourced glacial-lake data are presented separately. Explore the sources below or open the interactive map.') }}</p>
    </header>

    <section class="sources" :aria-label="t('数据来源网址', 'Data source URLs')">
      <article v-for="(source, index) in sources" :key="source.id" class="source-card">
        <div class="card-head"><span class="number">0{{ index + 1 }}</span><span class="category">{{ index === 0 ? t('数据中心主页', 'DATA CENTER') : t('具体数据集', 'DATASET') }}</span></div>
        <h2>{{ index === 0 ? t('国家青藏高原科学数据中心', 'National Tibetan Plateau / Third Pole Environment Data Center') : t('喜马拉雅地区危险冰湖遥感监测数据', 'Remote sensing monitoring data of hazardous glacial lakes in the Himalayan region') }}</h2>
        <p>{{ index === 0 ? t('进入数据中心，检索数据集、查看元数据与数据服务。', 'Visit the data center to search datasets, metadata and data services.') : t('Zhang, G.（2025）。含 2015、2050、2100 三个时期；数据提供方注明未来情景为 RCP2.6。', 'Zhang, G. (2025). Includes 2015, 2050 and 2100; provider metadata specifies RCP2.6 for the future periods.') }}</p>
        <a class="source-url" :href="source.url" target="_blank" rel="noopener noreferrer">{{ source.url }}</a>
        <div class="actions"><a class="btn primary" :href="source.url" target="_blank" rel="noopener noreferrer">{{ t('打开网站', 'Open website') }} ↗</a><button class="btn" type="button" @click="copyUrl(source.url)">{{ t('复制网址', 'Copy URL') }}</button></div>
      </article>
    </section>
    <p class="copy-notice" role="status">{{ notice }}</p>

    <section class="map-section">
      <h2>{{ t('在本项目中查看', 'Explore in this project') }}</h2>
      <p>{{ t('地图支持地区搜索、点位选择，以及关联应急设施和已存救援路线展示。', 'The map supports region search, location selection, and linked emergency facilities and saved routes.') }}</p>
      <div class="map-links">
        <RouterLink :to="{path:'/map',query:{scope:'combined'}}"><strong>{{ t('团队灾害易发性分析', 'Team susceptibility analysis') }}</strong><span>{{ t('CatBoost / SHAP 权重与空间分析成果', 'CatBoost / SHAP-weighted spatial analysis') }} →</span></RouterLink>
        <RouterLink v-for="year in ['2050','2100']" :key="year" :to="{path:'/map',query:{scope:year}}"><strong>{{ year }} {{ t('风险冰湖 · RCP2.6', 'hazardous glacial lakes · RCP2.6') }}</strong><span>{{ t('外部冰湖数据 · 团队救援路线分析', 'External lake data · team rescue-route analysis') }} →</span></RouterLink>
      </div>
    </section>

    <section class="citation">
      <h2>{{ t('来源与引用', 'Attribution & references') }}</h2>
      <p>Zhang, G. (2025). <em>Remote sensing monitoring data of hazardous glacial lakes in the Himalayan region.</em> National Tibetan Plateau / Third Pole Environment Data Center. <a href="https://doi.org/10.11888/Cryos.tpdc.302610" target="_blank" rel="noopener noreferrer">doi:10.11888/Cryos.tpdc.302610</a> · CC BY 4.0.</p>
      <p>Zheng et al. (2021). <em>Increasing risk of glacial lake outburst floods from future Third Pole deglaciation.</em> Nature Climate Change. <a href="https://doi.org/10.1038/s41558-021-01028-3" target="_blank" rel="noopener noreferrer">doi:10.1038/s41558-021-01028-3</a>.</p>
      <p class="note">{{ t('冰湖数据及其危险性评估归原作者；本团队在此基础上进行数据整合和救援路线分析。原始 HRGI、EXPOSURE、RRGI 与团队易发性评分分开保留。', 'Lake data and hazard assessments are attributed to the original authors. Our team integrated the data and computed rescue routes. Original HRGI, EXPOSURE and RRGI values are kept separate from team susceptibility scores.') }}</p>
    </section>
  </div>
</template>

<style scoped>
.source-page{display:grid;gap:22px;color:var(--color-text)}.eyebrow{margin:0 0 8px;color:#187f8c;font-size:11px;font-weight:700;letter-spacing:.12em}.source-page h1{font-size:28px;margin:0 0 10px}.lead,.source-page p{line-height:1.8;color:var(--color-muted)}.lead{max-width:90ch;margin:0}.sources{display:grid;grid-template-columns:1fr 1fr;gap:18px}.source-card,.map-section,.citation{border:1px solid var(--color-border);border-radius:12px;background:var(--color-surface);padding:24px}.source-card{display:flex;flex-direction:column;align-items:flex-start}.card-head{display:flex;gap:12px;align-items:center}.number{display:grid;place-items:center;width:36px;height:36px;border-radius:9px;background:#edf6f7;color:#167a87;font-weight:700}.category{font-size:11px;letter-spacing:.08em;color:var(--color-muted);font-weight:650}.source-card h2{font-size:20px;line-height:1.5;margin:17px 0 4px}.source-card p{font-size:14px;margin:8px 0 16px}.source-url{display:block;width:100%;box-sizing:border-box;padding:13px 14px;border-radius:7px;background:#f3f7f9;color:#1d707d;overflow-wrap:anywhere;font-family:ui-monospace,monospace;font-size:13px;line-height:1.7;margin-top:auto}.actions{display:flex;gap:10px;flex-wrap:wrap;margin-top:18px}.actions .primary{background:#247e89;color:#fff;border-color:#247e89}.copy-notice{min-height:1em;margin:-12px 0 -10px;font-size:13px}.map-section h2,.citation h2{margin:0;font-size:19px}.map-section>p{font-size:14px;margin:10px 0 16px}.map-links{display:grid;grid-template-columns:repeat(3,1fr);gap:12px}.map-links>a{display:grid;gap:10px;border:1px solid var(--color-border);border-radius:9px;padding:17px;color:var(--color-text);text-decoration:none}.map-links>a:hover{border-color:#247e89;background:#f0f8f8}.map-links strong{font-size:15px;line-height:1.6}.map-links span{font-size:12px;color:var(--color-muted);line-height:1.7}.citation p{font-size:13px;overflow-wrap:anywhere}.citation .note{border-top:1px solid var(--color-border);padding-top:13px;margin-bottom:0}.source-page a:focus-visible,.source-page button:focus-visible{outline:2px solid #247e89;outline-offset:3px}@media(max-width:800px){.sources,.map-links{grid-template-columns:1fr}.source-card,.map-section,.citation{padding:18px}.source-page h1{font-size:24px}}
</style>
