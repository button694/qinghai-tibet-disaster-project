<script setup lang="ts">
import { computed, onMounted, ref, watch } from 'vue'
import RealPreviewMap from '@/components/map/RealPreviewMap.vue'
import { createRealPreviewRepository, type PreviewManifest } from '@/repositories/realPreview'
const repository = createRealPreviewRepository()
const data = ref<PreviewManifest | null>(null)
const loading = ref(false)
const error = ref('')
const search = ref('')
const page = ref(1)
const kind = ref('vector')
const pageSize = 12
const totalFeatures = computed(() => data.value?.vectors.reduce((s, r) => s + r.count, 0) ?? 0)
const rasterBytes = computed(() => data.value?.rasters.reduce((s, r) => s + r.bytes, 0) ?? 0)
const rows = computed(() => {
  if (!data.value) return []
  const all =
    kind.value === 'vector'
      ? data.value.vectors.map((v) => ({
          id: v.id,
          type: v.geometry,
          scale: `${v.count.toLocaleString()} 条`,
          crs: v.crs,
        }))
      : data.value.rasters.map((r) => ({
          id: r.id,
          type: `${r.width} × ${r.height}`,
          scale: `${(r.bytes / 1024 ** 2).toFixed(2)} MiB`,
          crs: r.crs,
        }))
  return all.filter((r) => r.id.toLowerCase().includes(search.value.trim().toLowerCase()))
})
const pageCount = computed(() => Math.max(1, Math.ceil(rows.value.length / pageSize)))
const shown = computed(() => rows.value.slice((page.value - 1) * pageSize, page.value * pageSize))
watch([search, kind], () => {
  page.value = 1
})
async function load(): Promise<void> {
  loading.value = true
  error.value = ''
  data.value = null
  try {
    data.value = await repository.manifest()
  } catch (e) {
    error.value = e instanceof Error ? e.message : String(e)
  } finally {
    loading.value = false
  }
}
onMounted(() => {
  void load()
})
</script>

<template>
  <div class="preview-page">
    <header class="preview-header">
      <div>
        <p class="eyebrow">FIELD DATA / READ-ONLY PREVIEW</p>
        <h1>真实数据预览</h1>
        <p>
          本机 FileGDB 导出与 GeoTIFF 资产核验。独立于系统的示例与 API
          模式，不静默替换其他页面的数据。
        </p>
      </div>
      <span class="real-badge">真实文件 · 只读快照</span>
    </header>
    <p v-if="loading" role="status">正在读取真实清单…</p>
    <section v-else-if="error" class="preview-error" role="alert">
      <h2>真实数据读取失败</h2>
      <p>{{ error }}</p>
      <button class="btn" type="button" @click="load">重新读取</button>
    </section>
    <template v-else-if="data">
      <section class="real-stats" aria-label="真实数据底数">
        <article>
          <span>FileGDB 矢量层</span><strong>{{ data.vectors.length }}</strong
          ><small>全量元数据核验</small>
        </article>
        <article>
          <span>矢量记录总数</span><strong>{{ totalFeatures.toLocaleString() }}</strong
          ><small>并非全部加载到地图</small>
        </article>
        <article>
          <span>外部 GeoTIFF</span><strong>{{ data.rasters.length }}</strong
          ><small>栅格清单，不冒充瓦片服务</small>
        </article>
        <article>
          <span>栅格磁盘体量</span
          ><strong>{{ (rasterBytes / 1024 ** 3).toFixed(1) }} <small>GiB</small></strong
          ><small>原始文件未复制进网页</small>
        </article>
      </section>
      <RealPreviewMap :layers="data.exports" />
      <section class="catalog-section">
        <div class="catalog-heading">
          <div>
            <h2>真实资产清单</h2>
            <p>可搜索、分页；记录计数为源数据全量，地图只发布五个选定图层。</p>
          </div>
          <label
            >数据类型
            <select v-model="kind" aria-label="数据类型">
              <option value="vector">矢量</option>
              <option value="raster">外部栅格</option>
            </select></label
          >
        </div>
        <input
          v-model="search"
          class="catalog-search"
          type="search"
          aria-label="搜索真实数据集"
          placeholder="搜索图层编码或栅格文件名，例如 PRECIP、HOSPITAL"
        />
        <div class="table-scroll">
          <table>
            <caption class="visually-hidden">
              真实数据资产清单，包含数据集名称、几何或尺寸、数量或体量以及原始坐标系
            </caption>
            <thead>
              <tr>
                <th>数据集</th>
                <th>几何 / 尺寸</th>
                <th>数量 / 体量</th>
                <th>原始坐标系</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="row in shown" :key="row.id">
                <td>{{ row.id }}</td>
                <td>{{ row.type }}</td>
                <td>{{ row.scale }}</td>
                <td>{{ row.crs }}</td>
              </tr>
            </tbody>
          </table>
        </div>
        <p v-if="!rows.length" role="status">没有匹配的数据集。</p>
        <div class="pager">
          <span>共 {{ rows.length }} 项 · 第 {{ page }} / {{ pageCount }} 页</span
          ><button type="button" class="btn" :disabled="page <= 1" @click="page--">上一页</button
          ><button type="button" class="btn" :disabled="page >= pageCount" @click="page++">
            下一页
          </button>
        </div>
      </section>
      <section class="preview-notes">
        <h2>来源与验收边界</h2>
        <dl>
          <dt>数据来源</dt>
          <dd>{{ data.sourceLabel }}</dd>
          <dt>实际导出时间</dt>
          <dd>{{ data.generatedAt }}（UTC）</dd>
          <dt>坐标转换</dt>
          <dd>
            {{ data.sourceCrs }} → {{ data.displayCrs }} → Web Mercator
            显示；尚未完成控制点精度验收。
          </dd>
        </dl>
        <p>
          <b>备份已恢复为 QTP_GEOHAZARD（ONLINE），正式矢量与成果表已确认</b>（详见
          <code>docs/DB_MAPPING.md</code>）；当前处于数据库字段映射/服务发布阶段，尚未形成可供
          前端调用的正式 HTTP 接口。同目录旧
          sqlserver数据库已弃用。本次FileGDB未检出影响范围和救援路线成果，
          但最新备份中已确认存在正式易发性成果与救援路线表。需服务发布与联调后再验收。
        </p>
        <p>
          不把 RRGI 临时阈值称作正式风险分级；不把 exposure
          指数当受影响人口。空间查询、专题分析、路线、栅格地图发布、导出等完整业务仍需按返工清单补做。
        </p>
      </section>
    </template>
  </div>
</template>

<style scoped>
.preview-page {
  display: grid;
  gap: 24px;
}
.preview-header {
  display: flex;
  gap: 24px;
  align-items: flex-start;
  justify-content: space-between;
}
.preview-header h1 {
  margin: 6px 0 12px;
  font-size: 30px;
  letter-spacing: -0.02em;
}
.preview-header p {
  color: #526c7a;
  font-size: 14px;
  max-width: 780px;
}
.preview-header .eyebrow {
  color: #087f8c;
  font-size: 11px;
  font-weight: 700;
  letter-spacing: 0.15em;
}
.real-badge {
  white-space: nowrap;
  color: #126a64;
  border: 1px solid #a3cfcb;
  border-radius: 99px;
  padding: 7px 12px;
  background: #ebf8f5;
  font-size: 12px;
}
.real-stats {
  display: grid;
  grid-template-columns: repeat(4, minmax(0, 1fr));
  gap: 16px;
}
.real-stats article {
  display: grid;
  gap: 7px;
  padding: 20px;
  border: 1px solid #ccdce2;
  border-top: 3px solid #087f8c;
  border-radius: 10px;
  background: #fff;
  box-shadow: 0 4px 15px rgb(13 42 54 / 5%);
}
.real-stats span {
  color: #526c7a;
  font-size: 13px;
}
.real-stats strong {
  font-size: 29px;
  font-variant-numeric: tabular-nums;
  color: #173542;
}
.real-stats small {
  color: #526c7a;
  font-size: 12px;
}
.catalog-section,
.preview-notes {
  min-width: 0;
  border: 1px solid #ccdce2;
  border-radius: 12px;
  background: #fff;
  padding: 24px;
}
.catalog-heading {
  display: flex;
  justify-content: space-between;
  align-items: center;
  gap: 12px;
  flex-wrap: wrap;
}
h2 {
  font-size: 19px;
  margin: 0 0 8px;
}
.catalog-heading p {
  font-size: 13px;
  color: #526c7a;
}
select,
.catalog-search {
  font: inherit;
  border: 1px solid #b9cbd3;
  border-radius: 6px;
  padding: 9px;
  max-width: 100%;
}
.catalog-search {
  width: 100%;
  margin: 14px 0;
  font-size: 13px;
}
.table-scroll {
  overflow-x: auto;
}
table {
  width: 100%;
  font-size: 12px;
  text-align: left;
}
th,
td {
  padding: 12px;
  border-bottom: 1px solid #e1eaee;
}
th {
  color: #526c7a;
  background: #f4f8fa;
}
td:first-child {
  overflow-wrap: anywhere;
}
.pager {
  display: flex;
  justify-content: flex-end;
  align-items: center;
  gap: 10px;
  margin-top: 16px;
  font-size: 12px;
}
.preview-notes dl {
  display: grid;
  grid-template-columns: 110px minmax(0, 1fr);
  gap: 10px;
  font-size: 13px;
}
dd {
  margin: 0;
  overflow-wrap: anywhere;
}
dt {
  color: #526c7a;
}
.preview-notes p {
  line-height: 1.8;
  font-size: 13px;
  color: #526c7a;
}
.preview-error {
  padding: 22px;
  background: #fff0f0;
  color: #862d36;
}
@media (max-width: 1000px) {
  .real-stats {
    grid-template-columns: repeat(2, minmax(0, 1fr));
  }
}
@media (max-width: 600px) {
  .preview-header {
    flex-direction: column;
  }
  .real-stats {
    gap: 10px;
  }
  .real-stats article {
    padding: 12px;
  }
  .real-stats strong {
    font-size: 22px;
  }
  .catalog-section,
  .preview-notes {
    padding: 14px;
  }
  .pager {
    flex-wrap: wrap;
  }
}
</style>
