<script setup lang="ts">
/**
 * 阶段7：三类专题图打印视图（/print/risk|exposure|emergency）。
 *
 * 打印件固定包含：标题、成果名、地图快照、图例、近似比例尺、范围、时间、
 * 方法或口径、来源、指标与缺失说明、示例/真实身份标识（03 §10-4）。
 * 地图快照失败时明确提示并禁用打印，禁止输出看似成功的空白地图。
 * 浏览器「打印 → 另存为 PDF」即可生成 PDF；@media print 只保留打印内容。
 */
import { computed, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'

import PrintMapCanvas from '@/components/print/PrintMapCanvas.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import { formatFixed } from '@/domain/format'
import type { Metric } from '@/domain/types'
import {
  getPrintSheetService,
  type PrintKind,
  type PrintLegendEntry,
  type PrintSheet,
} from '@/services/printSheet'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const session = useSessionStore()

const status = ref<'loading' | 'ready' | 'failed' | 'planning'>('loading')
const errorText = ref<string | null>(null)
const sheet = ref<PrintSheet | null>(null)
/**
 * 地图快照状态。数据就绪不等于地图已经完成渲染：只有收到 ready 后才允许打印，
 * 避免用户在 OpenLayers 画布尚未转成稳定图片时打印出空白地图。
 */
const mapStatus = ref<'pending' | 'ready' | 'failed'>('pending')

const kind = computed<PrintKind>(() => route.params.kind as PrintKind)

/** mock 深链接缺省成果：与示例演示导览一致的固定可复现案例。 */
const MOCK_DEFAULT_RESULT: Record<PrintKind, string> = {
  risk: 'result.demo.risk',
  exposure: 'result.demo.impact',
  emergency: 'result.demo.route',
}

const isApiMode = computed(() => session.mode === 'api')
const API_DEFAULT_RESULT: Record<PrintKind, string | null> = {
  risk: 'result.susceptibility.combined',
  exposure: null,
  emergency: 'result.route.combined',
}

const resultId = computed<string | null>(() => {
  const value = route.query.resultId
  if (typeof value === 'string' && value.trim() !== '') return value
  return isApiMode.value ? API_DEFAULT_RESULT[kind.value] : MOCK_DEFAULT_RESULT[kind.value]
})

const routeId = computed(() => {
  const value = route.query.routeId
  return typeof value === 'string' && value.trim() !== '' ? value : null
})

async function load(): Promise<void> {
  status.value = 'loading'
  errorText.value = null
  sheet.value = null
  mapStatus.value = 'pending'
  // 暴露成果尚未在正式 API 登记完整影响范围与人口关联，保留明确规划空态。
  if (isApiMode.value && kind.value === 'exposure') {
    status.value = 'planning'
    return
  }
  if (resultId.value === null) {
    status.value = 'planning'
    return
  }
  try {
    sheet.value = await getPrintSheetService().buildSheet(kind.value, resultId.value, routeId.value)
    status.value = 'ready'
  } catch (unknownError) {
    status.value = 'failed'
    errorText.value = unknownError instanceof Error ? unknownError.message : String(unknownError)
  }
}

function onMapReady(): void {
  mapStatus.value = 'ready'
}

function metricText(metric: Metric): string {
  if (metric.value === null) return '未提供'
  const value = formatFixed(metric.value, 2)
  return metric.unit === null ? value : `${value} ${metric.unit}`
}

function legendStyle(entry: PrintLegendEntry): Record<string, string> {
  return entry.dashed
    ? {
        background: 'transparent',
        'border-top': `3px dashed ${entry.color}`,
        height: '0',
      }
    : { background: entry.color }
}

onMounted(() => void load())
watch([kind, resultId, isApiMode], () => void load())

/** 打印 / 返回前确认地图快照已生成；地图不可用时按钮禁用并显示原因。 */
function printNow(): void {
  window.print()
}

const backTarget = computed(() => {
  if (kind.value === 'risk') return { path: '/analysis/risk' }
  if (kind.value === 'exposure') {
    return resultId.value === null
      ? { path: '/analysis/exposure' }
      : { path: '/analysis/exposure', query: { resultId: resultId.value } }
  }
  return resultId.value === null
    ? { path: '/analysis/emergency' }
    : { path: '/analysis/emergency', query: { resultId: resultId.value } }
})
</script>

<template>
  <div class="print-page" data-testid="print-page">
    <div class="print-actions">
      <button
        type="button"
        class="btn btn--primary"
        :disabled="status !== 'ready' || mapStatus !== 'ready'"
        :title="
          status === 'planning'
            ? '正式 API 专题打印尚未接入'
            : mapStatus === 'failed'
              ? '地图快照生成失败，已禁止打印空白地图'
              : mapStatus === 'pending'
                ? '地图快照正在生成，请稍候'
                : '调用浏览器打印（可另存为 PDF）'
        "
        aria-label="打印专题图"
        data-testid="print-button"
        @click="printNow"
      >
        打印 / 另存 PDF
      </button>
      <RouterLink
        class="btn"
        :to="backTarget"
        aria-label="返回对应业务页面"
        data-testid="print-back"
      >
        返回业务页面
      </RouterLink>
    </div>

    <LoadingState v-if="status === 'loading'" label="正在生成打印视图…" />

    <section v-else-if="status === 'planning'" class="print-planning" data-testid="print-planning">
      <h1>正式 API 暴露专题打印暂未接入</h1>
      <p>
        当前正式 API 已支持易发性成果和综合救援路线只读打印；但暴露专题所需的完整影响范围、
        受影响对象与人口统计关联尚未登记。
        本页不预填示例成果、不请求未接入接口，也不生成看似正式的空白或伪统计。
      </p>
      <p>
        需要导出正式易发性成果或综合路线时，请从对应真实成果页进入打印；风险页另支持当前页 CSV /
        GeoJSON / 元数据导出。
      </p>
      <RouterLink class="btn btn--primary" :to="{ path: '/analysis/exposure' }">
        返回暴露度规划说明
      </RouterLink>
    </section>

    <div
      v-else-if="status === 'failed'"
      class="print-failure"
      role="alert"
      data-testid="print-error"
    >
      <h1>打印视图生成失败</h1>
      <p>{{ errorText }}</p>
      <button type="button" class="btn" data-testid="print-retry" @click="load">重试</button>
    </div>

    <article v-else-if="sheet !== null" class="print-sheet" data-testid="print-sheet">
      <header class="print-head">
        <h1 data-testid="print-title">{{ sheet.title }}</h1>
        <p class="print-result" data-testid="print-result-title">{{ sheet.resultTitle }}</p>
        <p class="print-identity" data-testid="print-identity">{{ sheet.identityLabel }}</p>
      </header>

      <div
        v-if="mapStatus === 'failed'"
        class="print-map-warning"
        role="alert"
        data-testid="print-unavailable"
      >
        地图快照生成失败（无几何要素或画布读取失败）：本次打印不含地图，已禁用打印按钮。不输出看似成功的空白地图。
      </div>

      <PrintMapCanvas
        v-if="status === 'ready'"
        :key="kind"
        :variant="kind"
        :features="sheet.features"
        :route="sheet.route"
        :mode="session.mode"
        :risk-level-field="isApiMode && kind === 'risk' ? null : undefined"
        @ready="onMapReady"
        @map-unavailable="mapStatus = 'failed'"
      />

      <section class="print-legend-block" aria-label="图例">
        <h2>图例</h2>
        <ul class="print-legend" data-testid="print-legend">
          <li v-for="entry in sheet.legend" :key="entry.label" data-legend-item>
            <span class="legend-swatch" :style="legendStyle(entry)" aria-hidden="true"></span>
            <span
              >{{ entry.label
              }}<span v-if="entry.note" class="legend-note">（{{ entry.note }}）</span></span
            >
          </li>
        </ul>
      </section>

      <section class="print-meta" aria-label="打印信息">
        <dl>
          <div class="meta-row">
            <dt>统计范围</dt>
            <dd data-testid="print-region">{{ sheet.regionLabel }}</dd>
          </div>
          <div class="meta-row">
            <dt>时间</dt>
            <dd data-testid="print-time">{{ sheet.timeLabel }}</dd>
          </div>
          <div class="meta-row">
            <dt>方法 / 口径</dt>
            <dd data-testid="print-method">{{ sheet.methodLabel ?? '未提供' }}</dd>
          </div>
          <div class="meta-row">
            <dt>来源</dt>
            <dd>
              <ul class="source-list" data-testid="print-source">
                <li v-for="line in sheet.sourceLines" :key="line">{{ line }}</li>
              </ul>
            </dd>
          </div>
          <div v-if="sheet.measureLine !== null" class="meta-row">
            <dt>距离 / 时间</dt>
            <dd data-testid="print-measure">{{ sheet.measureLine }}</dd>
          </div>
        </dl>
      </section>

      <section
        v-if="sheet.metrics.length > 0 || sheet.notes.length > 0"
        class="print-appendix"
        aria-label="指标与说明"
      >
        <h2>指标与说明</h2>
        <ul v-if="sheet.metrics.length > 0" class="metric-list" data-testid="print-metrics">
          <li v-for="metric in sheet.metrics" :key="metric.label">
            {{ metric.label }}：{{ metricText(metric) }}
          </li>
        </ul>
        <ul v-if="sheet.notes.length > 0" class="note-list" data-testid="print-notes">
          <li v-for="note in sheet.notes" :key="note">{{ note }}</li>
        </ul>
      </section>

      <footer class="print-foot">
        <template v-if="isApiMode">
          本打印件由前端生成，仅展示正式 API 已登记成果与口径；不提供实时预警，不执行前端重算。
        </template>
        <template v-else>
          本打印件由前端生成，仅展示已存成果与登记口径；示例数据持续标注，未接正式服务。
        </template>
      </footer>
    </article>
  </div>
</template>

<style scoped>
.print-page {
  width: 100%;
  max-width: 960px;
  margin-inline: auto;
  padding: var(--space-6) var(--space-4);
}

.print-actions {
  display: flex;
  gap: var(--space-3);
  margin-bottom: var(--space-4);
}

.print-failure {
  padding: var(--space-6);
  border: 1px solid var(--color-danger);
  border-radius: var(--radius-md);
  background: var(--color-danger-surface);
}

.print-planning {
  display: grid;
  gap: var(--space-3);
  padding: var(--space-6);
  border: 1px solid var(--color-border);
  border-left: 4px solid var(--color-primary);
  border-radius: var(--radius-md);
  background: var(--color-info-surface);
}

.print-planning h1,
.print-planning p {
  margin: 0;
}

.print-planning p {
  color: var(--color-muted);
  line-height: var(--line-height-body);
}

.print-sheet {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
  padding: var(--space-6);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.print-head h1 {
  font-size: var(--font-size-page-title);
}

.print-result {
  margin: var(--space-1) 0;
  color: var(--color-muted);
}

.print-identity {
  margin: 0;
  padding: var(--space-1) var(--space-2);
  display: inline-block;
  border: 1px solid var(--color-warning);
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.print-map-warning {
  padding: var(--space-3);
  border: 1px solid var(--color-danger);
  border-radius: var(--radius-sm);
  background: var(--color-danger-surface);
  color: var(--color-danger-text);
}

.print-legend-block h2,
.print-appendix h2 {
  font-size: var(--font-size-section-title);
  margin-bottom: var(--space-2);
}

.print-legend {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-2) var(--space-4);
}

.print-legend li {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  font-size: var(--font-size-body);
}

.legend-swatch {
  display: inline-block;
  width: 18px;
  height: 12px;
  border: 1px solid var(--color-border);
  border-radius: 2px;
}

.legend-note {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.print-meta dl {
  margin: 0;
  display: grid;
  grid-template-columns: 1fr;
  gap: var(--space-1);
}

.meta-row {
  display: flex;
  gap: var(--space-2);
}

.meta-row dt {
  flex: 0 0 7em;
  color: var(--color-muted);
}

.meta-row dd {
  margin: 0;
  min-width: 0;
  overflow-wrap: anywhere;
}

.source-list,
.metric-list,
.note-list {
  margin: 0;
  padding-left: 1.2em;
}

.print-foot {
  border-top: 1px solid var(--color-border);
  padding-top: var(--space-2);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

/* 打印：只保留专题图本体。 */
@media print {
  .print-actions {
    display: none;
  }

  .print-page {
    padding: 0;
    max-width: none;
  }

  .print-sheet {
    border: none;
  }
}
</style>
