<script setup lang="ts">
/**
 * 阶段6：项目说明。
 *
 * 解释「一库六体系」、三种数据模式、示例数据与真实数据的边界，并列报告索引。
 * 导入日志按已有登记记录只读展示（ImportLogQuery → listImports），
 * 明确标注「登记记录，不是完整审计日志」。页面不暴露本机磁盘路径。
 */
import { onMounted } from 'vue'

import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import { formatCount } from '@/domain/format'
import { IMPORT_STATUS_LABEL } from '@/domain/labels'
import { useCatalogStore } from '@/stores/catalog'
import { useSessionStore } from '@/stores/session'

const store = useCatalogStore()
const session = useSessionStore()

const reports = [
  { name: '00_阅读顺序与交接说明.md', note: '交接入口与阅读顺序（工程根目录上一级）' },
  { name: '01_前端总体架构与视觉设计方案.md', note: '分层、视觉与页面规格' },
  { name: '02_接口契约与数据接入规范.md', note: '数据契约、错误契约与时间口径' },
  { name: '03_DeepSeek分步执行提示词.md', note: '阶段划分与执行提示词' },
  { name: '04_验收清单与答辩演示脚本.md', note: '验收清单与演示脚本' },
  { name: 'docs/PROGRESS.md', note: '阶段进展记录（工程内）' },
  { name: 'docs/DECISIONS.md', note: '技术决策登记（工程内）' },
  { name: 'docs/API_MAPPING.md', note: '接口映射状态（工程内）' },
  { name: 'docs/ACCEPTANCE.md', note: '验收条目清单（工程内）' },
]

onMounted(() => {
  void session.loadCapabilities()
  if (store.importsStatus === 'idle') void store.loadImports()
})
</script>

<template>
  <div class="about-view" data-testid="about-page">
    <header class="page-head">
      <div>
        <h1 class="page-heading">项目说明</h1>
        <p class="page-lead">
          青藏高原地质灾害风险平台前端：空间数据库成果展示与辅助分析。
          本页解释系统的组织方式、数据模式与当前交付边界。
        </p>
      </div>
      <SourceBadge
        :mode="session.mode"
        :snapshot-id="session.snapshotId ?? undefined"
        :scope-label="session.scopeLabel ?? undefined"
      />
    </header>

    <section class="panel" aria-label="一库六体系">
      <h2 class="section-title">「一库六体系」</h2>
      <p class="body-text">
        平台数据组织为<strong>一个空间数据库</strong>与六个业务体系：基础地理（base）、
        冰川与冻土（tnr）、灾害危险源（hazard）、应急保障（emg）、分析成果（result）
        与系统支撑（sys，字典/边界/来源登记）。每个数据集登记所属主题、类型、版本、
        坐标参照与质量说明，可在<RouterLink class="text-link" to="/catalog">数据目录</RouterLink
        >中逐项查看。
      </p>
    </section>

    <section class="panel" aria-label="三种数据模式">
      <h2 class="section-title">三种数据模式</h2>
      <dl class="mode-list">
        <div class="mode-row">
          <dt>mock（示例数据）</dt>
          <dd>
            本地示例数据包驱动，用于验证界面与交互。界面持续标注「示例数据（非真实数据）」，
            数值固定且相互一致。
          </dd>
        </div>
        <div class="mode-row">
          <dt>snapshot（成果快照）</dt>
          <dd>读取真实成果导出的快照包。当前完整 snapshot 包尚未交付，属待联调项。</dd>
        </div>
        <div class="mode-row">
          <dt>api（正式接口）</dt>
          <dd>连接正式后端服务。接口失败时显示错误与重试，<strong>不回退示例数据</strong>。</dd>
        </div>
      </dl>
    </section>

    <section class="panel" aria-label="示例与真实数据边界">
      <h2 class="section-title">示例数据与真实数据边界</h2>
      <ul class="boundary-list">
        <li>
          示例数据（<code>public/demo/</code>）只用于验证交互，页面、截图与导出持续标注示例身份，
          不与真实文件预览混写。
        </li>
        <li>
          真实文件只读预览（<RouterLink class="text-link" to="/real-preview"
            >/real-preview</RouterLink
          >） 接入本机 FileGDB 导出的 5 个完整矢量预览层与 30 个栅格资产元数据；它不是完整
          snapshot， 也不代表栅格服务可用。
        </li>
        <li>
          2001—2023 年的 23 个降水 GeoTIFF 是<strong>同一个年度降水数据集</strong>的 23 个时相，
          不算 23 套独立数据集；栅格目前仅有资产元数据，地图预览显示「服务待接入」。
        </li>
        <li>
          最新 SQL Server 备份已恢复为 <strong>QTP_GEOHAZARD</strong>（ONLINE），并确认存在正式
          易发性成果、综合/2050/2100 救援路线、选中救援设施、最近机场与医院/救援站/道路等正式表；
          当前处于数据库字段映射/服务发布阶段，尚未形成可供前端调用的正式 HTTP 接口，
          正式影响范围、人口统计与路线联调在服务发布前不提前补造。
        </li>
      </ul>
    </section>

    <section class="panel" aria-label="导入登记日志">
      <h2 class="section-title">导入登记日志（只读）</h2>
      <p class="body-text">
        以下为<strong>已有登记记录</strong>的只读展示，不是完整审计日志；缺失字段如实显示，不补造。
      </p>
      <LoadingState
        v-if="store.importsStatus === 'loading' || store.importsStatus === 'idle'"
        label="正在读取导入登记记录…"
      />
      <ErrorState
        v-else-if="store.importsStatus === 'failed'"
        :error="store.importsError"
        title="导入登记记录读取失败"
        data-testid="about-imports-error"
        @retry="store.loadImports()"
      />
      <div v-else class="table-wrap">
        <table class="plain-table" data-testid="about-imports">
          <thead>
            <tr>
              <th scope="col">批次</th>
              <th scope="col">数据集</th>
              <th scope="col">状态</th>
              <th scope="col">源/目标条数</th>
              <th scope="col">开始 / 结束</th>
            </tr>
          </thead>
          <tbody>
            <tr v-for="log in store.imports?.items ?? []" :key="log.id" :data-import-id="log.id">
              <td>{{ log.batchLabel }}</td>
              <td>
                <code>{{ log.datasetId }}</code>
              </td>
              <td>{{ IMPORT_STATUS_LABEL[log.status] }}</td>
              <td class="tabular-nums">
                <template v-if="log.sourceCount === null || log.targetCount === null">
                  未登记
                </template>
                <template v-else
                  >{{ formatCount(log.sourceCount) }} / {{ formatCount(log.targetCount) }}</template
                >
              </td>
              <td class="tabular-nums">
                {{ log.startedAt ?? '未登记' }} — {{ log.finishedAt ?? '未登记' }}
              </td>
            </tr>
          </tbody>
        </table>
      </div>
    </section>

    <section class="panel" aria-label="报告索引">
      <h2 class="section-title">报告索引</h2>
      <p class="body-text">以下报告位于工程目录内（不提供浏览器直链，避免暴露本机路径）：</p>
      <ul class="report-list" data-testid="about-reports">
        <li v-for="report in reports" :key="report.name" class="report-row">
          <code>{{ report.name }}</code>
          <span class="report-note">{{ report.note }}</span>
        </li>
      </ul>
    </section>
  </div>
</template>

<style scoped>
.about-view {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
  max-width: 720px;
}

.panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.body-text {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-caption);
  line-height: 1.7;
  max-width: 860px;
}

.mode-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  margin: 0;
}

.mode-row {
  display: grid;
  grid-template-columns: 200px 1fr;
  gap: var(--space-3);
}

.mode-row dt {
  color: var(--color-primary);
  font-size: var(--font-size-caption);
  font-weight: 600;
}

.mode-row dd {
  margin: 0;
  font-size: var(--font-size-caption);
  line-height: 1.6;
}

.boundary-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding-left: 18px;
  font-size: var(--font-size-caption);
  line-height: 1.6;
}

.table-wrap {
  overflow-x: auto;
}

.plain-table {
  width: 100%;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.plain-table th,
.plain-table td {
  padding: var(--space-2) var(--space-3);
  border-bottom: 1px solid var(--color-border);
  text-align: left;
  white-space: nowrap;
}

.plain-table th {
  color: var(--color-muted);
  font-weight: 600;
}

.report-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
}

.report-row {
  display: grid;
  grid-template-columns: minmax(220px, auto) 1fr;
  gap: var(--space-3);
  align-items: baseline;
}

.report-note {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.text-link {
  color: var(--color-primary);
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}

@media (max-width: 720px) {
  .page-head {
    flex-direction: column;
  }

  .mode-row,
  .report-row {
    grid-template-columns: 1fr;
    gap: 2px;
  }
}
</style>
