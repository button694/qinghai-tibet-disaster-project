<script setup lang="ts">
/**
 * 阶段6：成果详情页。
 *
 * 展示：成果要素地图（已存成果图层）、指标统计、方法与参数、输入来源、
 * 生成时间与成果文件。文件下载只对「available 且登记 url」的文件开放
 * （ResultFilesPanel）；无几何要素时显示范围框或专用说明，不伪造几何。
 * 深链接 `/results/:resultId` 刷新安全（watch 路由参数重装）。
 */
import { computed, onMounted, watch } from 'vue'
import { RouterLink, useRoute } from 'vue-router'

import ResultFilesPanel from '@/components/results/ResultFilesPanel.vue'
import ResultMapCanvas from '@/components/results/ResultMapCanvas.vue'
import EmptyState from '@/components/ui/EmptyState.vue'
import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import MetricCard from '@/components/ui/MetricCard.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import { formatBbox, formatTimeWithRole } from '@/domain/format'
import { RESULT_KIND_LABEL, RESULT_SOURCE_TYPE_LABEL } from '@/domain/labels'
import { useResultsStore } from '@/stores/results'
import { useSessionStore } from '@/stores/session'

const route = useRoute()
const store = useResultsStore()
const session = useSessionStore()

const resultId = computed(() => String(route.params.resultId ?? ''))
const detail = computed(() => store.detail)

/** 成果上下文链接：保留可交付的风险/应急工作台入口；暴露页本版隐藏。 */
const workspaceLink = computed(() => {
  const kind = detail.value?.result.kind
  if (kind === 'emergency') {
    return {
      to: { name: 'analysis-emergency', query: { resultId: resultId.value } },
      label: '在应急保障中打开',
    }
  }
  if (kind === 'risk') return { to: '/analysis/risk', label: '在风险研判中打开' }
  return null
})

onMounted(() => {
  void session.loadCapabilities()
  if (resultId.value !== '') void store.loadDetail(resultId.value)
})

watch(
  () => route.params.resultId,
  (next) => {
    if (route.name !== 'result-detail') return
    const id = String(next ?? '')
    if (id !== '') void store.loadDetail(id)
  },
)
</script>

<template>
  <div class="result-detail" data-testid="result-detail-page">
    <p class="back-link">
      <RouterLink to="/results">← 返回成果中心</RouterLink>
    </p>

    <LoadingState
      v-if="store.detailStatus === 'loading' || store.detailStatus === 'idle'"
      label="正在读取成果详情…"
    />
    <template v-else-if="store.detailStatus === 'failed'">
      <!-- 错误态同样保留页面标题（h1）：外壳与全路由回归要求每页有标题锚点。 -->
      <header class="detail-head">
        <div>
          <h1 class="page-heading">成果详情</h1>
          <p class="page-lead">
            成果 ID：<code>{{ resultId }}</code>
          </p>
        </div>
      </header>
      <ErrorState
        :error="store.detailError"
        title="成果读取失败"
        data-testid="result-detail-error"
        @retry="store.loadDetail(resultId)"
      />
    </template>

    <template v-else-if="detail !== null">
      <header class="detail-head">
        <div>
          <p class="eyebrow">
            {{ RESULT_KIND_LABEL[detail.result.kind] }} ·
            {{ RESULT_SOURCE_TYPE_LABEL[detail.result.sourceType] }} · 版本
            <span class="tabular-nums">{{ detail.result.version }}</span>
          </p>
          <h1 class="page-heading" data-testid="result-detail-name">{{ detail.result.title }}</h1>
          <p class="page-lead">
            {{ detail.result.regionLabel }} · 生成时间：{{ formatTimeWithRole(detail.result.time) }}
            <template v-if="detail.result.scenarioYear !== undefined">
              · 情景年份 {{ detail.result.scenarioYear }}（未来情景，不是实时预警）</template
            >
          </p>
        </div>
        <SourceBadge
          :mode="session.mode"
          :snapshot-id="session.snapshotId ?? undefined"
          :scope-label="session.scopeLabel ?? undefined"
        />
      </header>

      <div class="map-row">
        <div class="map-cell">
          <ResultMapCanvas
            v-if="detail.features.length > 0"
            :features="detail.features"
            :mode="session.mode"
            class="map-host"
          />
          <EmptyState
            v-else-if="detail.extent !== null"
            title="成果要素未上图"
            :description="`该成果未登记可上图要素，仅显示登记的空间范围：${formatBbox(detail.extent)}（西、南、东、北）。`"
          />
          <EmptyState
            v-else
            title="成果要素未上图"
            description="该成果未登记几何要素与空间范围。"
          />
        </div>
      </div>

      <section class="panel" aria-label="指标统计">
        <h2 class="section-title">指标统计</h2>
        <div class="metric-grid">
          <MetricCard v-for="metric in detail.result.metrics" :key="metric.key" :metric="metric" />
        </div>
        <ul v-if="detail.result.qualityNotes.length > 0" class="note-list">
          <li v-for="note in detail.result.qualityNotes" :key="note">{{ note }}</li>
        </ul>
      </section>

      <div class="two-col">
        <section class="panel" aria-label="方法与参数">
          <h2 class="section-title">方法与参数</h2>
          <p class="body-text" data-testid="result-method">
            {{ detail.result.method ?? '方法说明未登记。' }}
          </p>
          <dl v-if="Object.keys(detail.result.parameters).length > 0" class="param-list">
            <div v-for="(value, key) in detail.result.parameters" :key="key" class="param-row">
              <dt>
                <code>{{ key }}</code>
              </dt>
              <dd class="tabular-nums">{{ String(value) }}</dd>
            </div>
          </dl>
        </section>

        <section class="panel" aria-label="输入来源">
          <h2 class="section-title">输入来源</h2>
          <ul class="link-list" data-testid="result-inputs">
            <li v-for="input in detail.inputLabels" :key="input.datasetId" class="link-item">
              <RouterLink
                v-if="input.name !== null"
                :to="{ name: 'catalog-detail', params: { datasetId: input.datasetId } }"
              >
                {{ input.name }}
              </RouterLink>
              <template v-else>
                <code>{{ input.datasetId }}</code
                >（数据集未登记）
              </template>
              <span class="meta-sub">
                角色：{{ input.role }} · 版本：{{ input.version ?? '未登记' }}
              </span>
            </li>
            <li v-if="detail.inputLabels.length === 0" class="link-item">
              该成果未登记输入数据集。
            </li>
          </ul>
          <RouterLink
            v-if="workspaceLink !== null"
            class="btn btn--small workspace-link"
            :to="workspaceLink.to"
            data-testid="result-workspace-link"
          >
            {{ workspaceLink.label }} →
          </RouterLink>
        </section>
      </div>

      <ResultFilesPanel :files="detail.result.files" />
    </template>
  </div>
</template>

<style scoped>
.result-detail {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.back-link {
  margin: 0;
  font-size: var(--font-size-caption);
}

.back-link a {
  color: var(--color-muted);
}

.detail-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.eyebrow {
  margin: 0 0 2px;
  color: var(--color-primary);
  font-size: 11px;
  letter-spacing: 0.08em;
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
}

.map-row {
  display: grid;
  grid-template-columns: minmax(0, 1fr);
}

.map-cell {
  min-width: 0;
  height: 420px;
}

.map-host {
  height: 100%;
}

.panel {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.section-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.metric-grid {
  display: grid;
  grid-template-columns: repeat(auto-fit, minmax(220px, 1fr));
  gap: var(--space-3);
}

.note-list {
  margin: 0;
  padding-left: 18px;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.two-col {
  display: grid;
  grid-template-columns: repeat(2, minmax(0, 1fr));
  gap: var(--space-4);
}

.body-text {
  margin: 0;
  font-size: var(--font-size-caption);
  overflow-wrap: anywhere;
}

.param-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
  margin: 0;
}

.param-row {
  display: grid;
  grid-template-columns: auto 1fr;
  gap: var(--space-3);
}

.param-row dt {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.param-row dd {
  margin: 0;
  font-size: var(--font-size-caption);
}

.link-list {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  margin: 0;
  padding: 0;
  list-style: none;
  font-size: var(--font-size-caption);
}

.link-item {
  overflow-wrap: anywhere;
}

.link-item a {
  color: var(--color-primary);
}

.meta-sub {
  display: block;
  color: var(--color-muted);
  font-size: 11px;
}

.workspace-link {
  align-self: flex-start;
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}

@media (max-width: 900px) {
  .two-col {
    grid-template-columns: 1fr;
  }

  .detail-head {
    flex-direction: column;
  }

  .map-cell {
    height: 320px;
  }
}
</style>
