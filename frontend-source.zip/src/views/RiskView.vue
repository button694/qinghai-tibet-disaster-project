<script setup lang="ts">
/**
 * 阶段4：风险研判页（/analysis/risk）。
 *
 * 数据链路：本页 → stores/risk.ts → services/riskScenarios.ts →
 * repositories/realPreview.ts → public/real-preview/*.json（只读真实文件快照）。
 * 页面不直接 fetch JSON（B2）。
 *
 * 页面结构：外部情景模式显示「未来情景」横幅 → 成果/情景控制 → 地图（单图或双图对比）
 * + 统计/重点对象/对象详情侧栏 → 连续色域图例 → 来源与口径。
 * API 模式的 projectAnalysis 视图读取 QTP_GEOHAZARD 已登记的正式易发性点成果；
 * mock/snapshot 仍保留待联调边界，不用外部情景或示例数据冒充正式成果。
 */
import { computed, onBeforeUnmount, onMounted, ref, watch } from 'vue'
import { useRoute } from 'vue-router'
import LoadingState from '@/components/ui/LoadingState.vue'
import RiskControlPanel from '@/components/risk/RiskControlPanel.vue'
import RiskDetailPanel from '@/components/risk/RiskDetailPanel.vue'
import RiskLegend from '@/components/risk/RiskLegend.vue'
import RiskMapCanvas from '@/components/risk/RiskMapCanvas.vue'
import RiskSourcePanel from '@/components/risk/RiskSourcePanel.vue'
import RiskStatsPanel from '@/components/risk/RiskStatsPanel.vue'
import RiskTopList from '@/components/risk/RiskTopList.vue'
import ResultMapCanvas from '@/components/results/ResultMapCanvas.vue'
import { DATA_MODE_LABEL } from '@/domain/labels'
import { formatCount } from '@/domain/format'
import type { Context, FeatureDetail, LayerDefinition, ResultDetail } from '@/domain/types'
import { getRepositories } from '@/repositories'
import { toRepositoryError, type RepositoryError } from '@/repositories/types'
import type { ScenarioDataset, ScenarioRecord, ScenarioYear } from '@/domain/scenario'
import {
  buildCsv,
  buildExportColumns,
  buildGeoJson,
  buildMetadataJson,
  downloadText,
  exportFileName,
  type ExportMeta,
} from '@/services/queryExport'
import { useRiskStore } from '@/stores/risk'
import { useSessionStore } from '@/stores/session'

const store = useRiskStore()
const session = useSessionStore()
const route = useRoute()

const FORMAL_RESULT_ID = 'result.susceptibility.combined'
const FORMAL_PAGE_SIZE = 200
type FormalStatus = 'idle' | 'loading' | 'ready' | 'failed'

const formalStatus = ref<FormalStatus>('idle')
const formalError = ref<RepositoryError | null>(null)
const formalResult = ref<ResultDetail | null>(null)
const formalContext = ref<Context | null>(null)
const formalLayer = ref<LayerDefinition | null>(null)
const formalFeatures = ref<FeatureDetail[]>([])
const formalTotal = ref(0)
const formalFetched = ref(0)
const formalComplete = ref(false)
const formalIncompleteNote = ref<string | null>(null)
const formalLayerIds = ref<string[]>([])
const formalPage = ref(1)
const formalRequestToken = ref(0)
let formalController: AbortController | null = null

const isFormalApi = computed(() => store.sourceKind === 'projectAnalysis' && session.mode === 'api')
const formalLoading = computed(() => formalStatus.value === 'loading')
const formalPageFeatures = computed(() => {
  const start = (formalPage.value - 1) * FORMAL_PAGE_SIZE
  return formalFeatures.value.slice(start, start + FORMAL_PAGE_SIZE)
})
const formalTruncated = computed(
  () => !formalComplete.value || formalTotal.value > formalPageFeatures.value.length,
)
const formalTotalPages = computed(() =>
  Math.max(1, Math.ceil(formalTotal.value / FORMAL_PAGE_SIZE)),
)
const formalTableFeatures = computed(() => formalPageFeatures.value)

function formalValue(feature: FeatureDetail, ...keys: string[]): string {
  for (const key of keys) {
    const value = feature.properties[key]
    if (value !== undefined && value !== null && value !== '') return String(value)
  }
  return '未提供'
}

function clearFormalState(): void {
  formalController?.abort()
  formalController = null
  formalStatus.value = 'idle'
  formalError.value = null
  formalResult.value = null
  formalContext.value = null
  formalLayer.value = null
  formalFeatures.value = []
  formalTotal.value = 0
  formalFetched.value = 0
  formalComplete.value = false
  formalIncompleteNote.value = null
  formalLayerIds.value = []
  formalPage.value = 1
}

async function loadFormalFeaturePage(): Promise<void> {
  if (!isFormalApi.value || formalLayerIds.value.length === 0) return
  const token = formalRequestToken.value + 1
  formalRequestToken.value = token
  formalController?.abort()
  const controller = new AbortController()
  formalController = controller
  formalStatus.value = 'loading'
  formalError.value = null
  formalFeatures.value = []
  formalFetched.value = 0
  formalComplete.value = false
  formalIncompleteNote.value = null
  try {
    const repositories = getRepositories()
    const layerLoads = await Promise.all(
      formalLayerIds.value.map(async (layerId) => {
        const first = await repositories.layers.listFeatures(
          layerId,
          { page: 1, pageSize: FORMAL_PAGE_SIZE },
          { signal: controller.signal },
        )
        const serverTotal = first.data.total
        const all: FeatureDetail[] = []
        const seenSourceIds = new Set<string>()
        const duplicateSourceIds = new Set<string>()
        let complete = first.data.items.length >= Math.min(FORMAL_PAGE_SIZE, serverTotal)

        function appendSourcePage(items: FeatureDetail[]): void {
          const pageSourceIds = new Set<string>()
          for (const feature of items) {
            const sourceId = `${feature.ref.layerId}:${feature.ref.id}`
            if (seenSourceIds.has(sourceId) || pageSourceIds.has(sourceId))
              duplicateSourceIds.add(sourceId)
            pageSourceIds.add(sourceId)
            all.push(feature)
          }
          for (const sourceId of pageSourceIds) seenSourceIds.add(sourceId)
        }

        appendSourcePage(first.data.items)
        const pageCount = Math.ceil(serverTotal / FORMAL_PAGE_SIZE)
        for (let start = 2; start <= pageCount; start += 4) {
          const pageNumbers = Array.from(
            { length: Math.min(4, pageCount - start + 1) },
            (_, index) => start + index,
          )
          const nextPages = await Promise.all(
            pageNumbers.map((nextPage) =>
              repositories.layers.listFeatures(
                layerId,
                { page: nextPage, pageSize: FORMAL_PAGE_SIZE },
                { signal: controller.signal },
              ),
            ),
          )
          for (let index = 0; index < nextPages.length; index += 1) {
            const pageNumber = pageNumbers[index]!
            const nextPage = nextPages[index]!
            const expected = Math.min(
              FORMAL_PAGE_SIZE,
              Math.max(0, serverTotal - (pageNumber - 1) * FORMAL_PAGE_SIZE),
            )
            if (nextPage.data.items.length < expected) complete = false
            appendSourcePage(nextPage.data.items)
          }
        }
        if (all.length < serverTotal || duplicateSourceIds.size > 0) complete = false
        return {
          items: all,
          total: serverTotal,
          complete,
          duplicateCount: duplicateSourceIds.size,
        }
      }),
    )
    if (token !== formalRequestToken.value || !isFormalApi.value) return
    const total = layerLoads.reduce((sum, item) => sum + item.total, 0)
    const items = layerLoads.flatMap((item) => item.items)
    const fetched = items.length
    const duplicateCount = layerLoads.reduce((sum, item) => sum + item.duplicateCount, 0)
    const complete =
      layerLoads.every((item) => item.complete) && fetched >= total && duplicateCount === 0
    formalIncompleteNote.value = complete
      ? null
      : duplicateCount > 0
        ? `服务端分页发现 ${duplicateCount} 个重复源记录（同页或跨页），当前成果不能视为全量。`
        : '服务端分页未完整取回，当前成果不能视为全量。'
    formalPage.value = 1
    formalFeatures.value = items
    formalFetched.value = fetched
    formalTotal.value = total
    formalComplete.value = complete
    formalStatus.value = 'ready'
  } catch (error) {
    if (token !== formalRequestToken.value || !isFormalApi.value) return
    formalStatus.value = 'failed'
    formalError.value = toRepositoryError(error)
    formalFeatures.value = []
    formalFetched.value = 0
    formalComplete.value = false
    formalIncompleteNote.value = '正式成果分页读取失败，未取得完整结果。'
  } finally {
    if (token === formalRequestToken.value) formalController = null
  }
}

async function loadFormalResult(): Promise<void> {
  if (!isFormalApi.value) return
  const token = formalRequestToken.value + 1
  formalRequestToken.value = token
  formalController?.abort()
  const controller = new AbortController()
  formalController = controller
  formalStatus.value = 'loading'
  formalError.value = null
  formalResult.value = null
  formalContext.value = null
  formalLayer.value = null
  formalFeatures.value = []
  formalTotal.value = 0
  formalFetched.value = 0
  formalComplete.value = false
  formalIncompleteNote.value = null
  formalLayerIds.value = []
  formalPage.value = 1
  try {
    const resultEnvelope = await getRepositories().results.getResult(FORMAL_RESULT_ID, {
      signal: controller.signal,
    })
    if (token !== formalRequestToken.value || !isFormalApi.value) return
    const detail = resultEnvelope.data
    formalResult.value = detail
    formalContext.value = resultEnvelope.meta
    const registeredTotal = detail.metrics.find((metric) => metric.key === 'pointCount')?.value
    formalTotal.value = typeof registeredTotal === 'number' ? registeredTotal : 0
    formalLayerIds.value = detail.layerIds.filter((layerId) => layerId.trim() !== '')

    // layerIds 未登记时如实显示映射缺口；不把结果详情中的统计数字冒充地图要素。
    if (formalLayerIds.value.length === 0) {
      formalStatus.value = 'ready'
      return
    }
    formalLayer.value = (
      await getRepositories().layers.getLayer(formalLayerIds.value[0]!, {
        signal: controller.signal,
      })
    ).data
    await loadFormalFeaturePage()
  } catch (error) {
    if (token !== formalRequestToken.value || !isFormalApi.value) return
    formalStatus.value = 'failed'
    formalError.value = toRepositoryError(error)
    formalResult.value = null
    formalFeatures.value = []
    formalTotal.value = 0
    formalFetched.value = 0
    formalComplete.value = false
    formalIncompleteNote.value = null
    formalLayerIds.value = []
  } finally {
    if (token === formalRequestToken.value) formalController = null
  }
}

function gotoFormalPage(page: number): void {
  if (page < 1 || page > formalTotalPages.value || page === formalPage.value) return
  formalPage.value = page
  // 地图已经缓存全量点；翻页只切换表格当前页，不再次拆分地图。
}

function formalExportMeta(scope: 'page' | 'all'): ExportMeta | null {
  const detail = formalResult.value
  const context = formalContext.value
  const layer = formalLayer.value
  if (detail === null || context === null || layer === null) return null
  const rows = scope === 'all' ? formalFeatures.value : formalPageFeatures.value
  return {
    modeLabel: DATA_MODE_LABEL.api,
    snapshotId: context.snapshotId,
    scopeLabel: context.scopeLabel || detail.regionLabel,
    boundaryVersion: context.boundaryVersion,
    datasetVersion: context.datasetVersions[layer.datasetId] ?? detail.version ?? null,
    layerId: layer.id,
    layerLabel: layer.label,
    conditions: [],
    spatial: null,
    distanceMethod: null,
    sort: null,
    total: formalTotal.value,
    exportedCount: rows.length,
    scope,
    complete: scope === 'all' ? formalComplete.value && rows.length >= formalTotal.value : true,
    generatedAt: new Date().toISOString(),
    sample: false,
    notes:
      scope === 'all'
        ? [
            '正式易发性成果全量导出：地图已在同一次装载中取得全部登记点，本文件即为该次装载结果。',
            'HAZ_LEVEL 与 SCORE 保留数据库登记值，前端不重算分级阈值。',
          ]
        : [
            '正式易发性成果导出当前服务页，不代表将全部成果一次性导出。',
            'HAZ_LEVEL 与 SCORE 保留数据库登记值，前端不重算分级阈值。',
          ],
  }
}

function exportFormalCsv(): void {
  const layer = formalLayer.value
  const meta = formalExportMeta('page')
  if (layer === null || meta === null) return
  const baseName = exportFileName(layer.id, 'page', new Date())
  const csv = buildCsv({
    rows: formalPageFeatures.value,
    columns: buildExportColumns(layer.fields),
    meta,
  })
  downloadText(`${baseName}.csv`, csv, 'text/csv')
}

function exportFormalGeoJson(): void {
  const layer = formalLayer.value
  const meta = formalExportMeta('page')
  if (layer === null || meta === null) return
  const baseName = exportFileName(layer.id, 'page', new Date())
  downloadText(
    `${baseName}.geojson`,
    buildGeoJson(formalPageFeatures.value),
    'application/geo+json',
  )
  downloadText(`${baseName}.metadata.json`, buildMetadataJson(meta), 'application/json')
}

function exportFormalMetadata(): void {
  const layer = formalLayer.value
  const meta = formalExportMeta('page')
  if (layer === null || meta === null) return
  const baseName = exportFileName(layer.id, 'page', new Date())
  downloadText(`${baseName}.metadata.json`, buildMetadataJson(meta), 'application/json')
}

/**
 * 全部匹配导出：地图装载时已把全部登记点拉到 `formalFeatures`（见 loadFormalFeaturePage），
 * 因此这里不需要再单独翻页——直接用已加载的全量结果落盘，并在元数据里如实标注「全量」。
 * 若尚未取全（极端情况下地图装载被截断），`complete` 会据实为 false，文件内会写明。
 */
function exportFormalAllCsv(): void {
  if (!formalComplete.value) return
  const layer = formalLayer.value
  const meta = formalExportMeta('all')
  if (layer === null || meta === null) return
  const baseName = exportFileName(layer.id, 'all', new Date())
  const csv = buildCsv({
    rows: formalFeatures.value,
    columns: buildExportColumns(layer.fields),
    meta,
  })
  downloadText(`${baseName}.csv`, csv, 'text/csv')
}

function exportFormalAllGeoJson(): void {
  if (!formalComplete.value) return
  const layer = formalLayer.value
  const meta = formalExportMeta('all')
  if (layer === null || meta === null) return
  const baseName = exportFileName(layer.id, 'all', new Date())
  downloadText(`${baseName}.geojson`, buildGeoJson(formalFeatures.value), 'application/geo+json')
  downloadText(`${baseName}.metadata.json`, buildMetadataJson(meta), 'application/json')
}

watch(
  isFormalApi,
  (enabled) => {
    if (enabled) void loadFormalResult()
    else clearFormalState()
  },
  { immediate: true },
)

/** 地图组件实例：按年份存放；组件实例不是可序列化状态，不进 Pinia。 */
const mapInstances = new Map<ScenarioYear, InstanceType<typeof RiskMapCanvas>>()

function setMapRef(year: ScenarioYear): (instance: unknown) => void {
  return (instance) => {
    if (instance === null || instance === undefined) {
      mapInstances.delete(year)
      return
    }
    mapInstances.set(year, instance as InstanceType<typeof RiskMapCanvas>)
  }
}

/** 已成功装载的数据集（来源面板 prop 只收非空值）。 */
const loadedDatasets = computed<Partial<Record<ScenarioYear, ScenarioDataset>>>(() => {
  const out: Partial<Record<ScenarioYear, ScenarioDataset>> = {}
  for (const year of [2050, 2100] as const) {
    const dataset = store.datasetOf(year)
    if (dataset !== null) out[year] = dataset
  }
  return out
})

onMounted(() => {
  const requestedSource = route.query.source
  if (requestedSource === 'externalScenario' || requestedSource === 'projectAnalysis') {
    store.setSourceKind(requestedSource)
  } else if (session.mode === 'api') {
    // 正式接口默认展示已登记项目成果；外部 2050/2100 文件快照仍可通过控制面板或
    // ?source=externalScenario 明确进入，避免正式用户误把文件快照当成真库成果。
    store.setSourceKind('projectAnalysis')
  }
  if (store.sourceKind === 'externalScenario') void store.load()
})

watch(
  () => store.sourceKind,
  (sourceKind) => {
    if (sourceKind === 'externalScenario') void store.load()
  },
)

onBeforeUnmount(() => {
  formalController?.abort()
  formalRequestToken.value += 1
})

/* ------------------------------ 地图取数 ------------------------------ */

function recordsOf(year: ScenarioYear): ScenarioRecord[] {
  return store.filteredRecords(year)
}

const totalCountAll = computed(() => {
  if (isFormalApi.value) return formalTotal.value
  let sum = 0
  for (const year of store.visibleYears) {
    sum += store.datasetOf(year)?.total ?? 0
  }
  return sum
})

/** 对比模式下两期筛选后记录之和（图例/横幅用）。 */
const legendNullCount = computed(() => {
  let count = 0
  for (const year of store.visibleYears) {
    for (const record of recordsOf(year)) {
      if (record.values[store.metric] === null) count += 1
    }
  }
  return count
})

function mapRefOf(year: ScenarioYear): InstanceType<typeof RiskMapCanvas> | null {
  return mapInstances.get(year) ?? null
}

function fitAll(): void {
  for (const year of store.visibleYears) mapRefOf(year)?.fitToRecords()
}

function locateRecord(record: ScenarioRecord): void {
  store.select(record.glacierId)
  for (const year of store.visibleYears) {
    mapRefOf(year)?.focusCoordinate(record.longitude, record.latitude)
  }
}

/* --------------------------- 双图视野同步 --------------------------- */

interface SyncedView {
  center: number[]
  zoom: number
  at: number
}

let lastSync: SyncedView | null = null

function approxEqualView(a: { center: number[]; zoom: number }, b: SyncedView): boolean {
  if (Math.abs(a.zoom - b.zoom) > 0.01) return false
  return (
    Math.abs((a.center[0] ?? 0) - (b.center[0] ?? 0)) < 1 &&
    Math.abs((a.center[1] ?? 0) - (b.center[1] ?? 0)) < 1
  )
}

/**
 * 双图视野同步：以「时间窗 + 数值相等」双条件抑制回环——
 * 被同步方的 moveend 触发时，其视图与 lastSync 相等即忽略，
 * 避免两幅地图互相触发形成循环事件（03 §7-5）。
 */
function onViewChange(from: ScenarioYear, view: { center: number[]; zoom: number }): void {
  if (!store.isCompare) return
  if (lastSync !== null && Date.now() - lastSync.at < 500 && approxEqualView(view, lastSync)) {
    return
  }
  lastSync = { center: view.center, zoom: view.zoom, at: Date.now() }
  const other = mapRefOf(from === 2050 ? 2100 : 2050)
  other?.applyView(view)
}
</script>

<template>
  <div class="risk-page" data-testid="risk-page">
    <header class="page-head">
      <div>
        <h1 class="page-title">风险研判</h1>
        <p class="page-subtitle">项目成果与未来情景分开展示，可查看 2050 / 2100 情景对比。</p>
      </div>
    </header>

    <p
      v-if="store.sourceKind === 'externalScenario'"
      class="future-banner"
      data-testid="future-banner"
      role="note"
    >
      <b>未来情景，不是实时预警：</b>2050 / 2100 为模型情景输出，不是实时监测数据或预警结果；
      当前展示连续指数，不划分风险等级。
    </p>

    <RiskControlPanel :total-count="totalCountAll" @fit="fitAll" />

    <!-- 项目分析成果：API 模式直接读取 QTP_GEOHAZARD 的正式点成果；其它模式保留待联调边界。 -->
    <section
      v-if="store.sourceKind === 'projectAnalysis' && session.mode === 'api'"
      class="formal-result"
      data-testid="formal-risk-result"
    >
      <header class="formal-head">
        <div>
          <p class="formal-eyebrow">项目分析成果</p>
          <h2 class="formal-title">滑坡易发性成果</h2>
          <p class="formal-subtitle">
            来源：项目数据库中的滑坡易发性成果；等级和指数沿用成果记录。
          </p>
        </div>
        <span class="formal-badge">已发布成果</span>
      </header>

      <LoadingState
        v-if="formalStatus === 'loading' || formalStatus === 'idle'"
        label="正在读取滑坡易发性成果…"
      />
      <section v-else-if="formalStatus === 'failed'" class="load-error" role="alert">
        <h2>滑坡易发性成果暂时无法显示</h2>
        <p data-testid="formal-risk-error">
          {{
            formalError?.userMessage ?? formalError?.message ?? '当前成果暂时无法显示，请稍后重试。'
          }}
        </p>
        <p>请稍后重试，或返回成果中心查看其他已发布成果。</p>
        <button type="button" class="btn btn--primary" @click="loadFormalResult">重试</button>
      </section>

      <template v-else-if="formalResult !== null">
        <div class="formal-notes">
          <p>
            服务端成果总量
            <b data-testid="formal-risk-total">{{ formatCount(formalTotal) }}</b> 点；已取回
            <b data-testid="formal-risk-fetched">{{ formatCount(formalFetched) }}</b> 点；当前表格页
            <b data-testid="formal-risk-rendered">{{ formatCount(formalPageFeatures.length) }}</b>
            点；地图已加载
            <b data-testid="formal-risk-map-rendered">{{ formatCount(formalFeatures.length) }}</b>
            点。
            <template v-if="!formalComplete">
              {{
                formalIncompleteNote ??
                '服务端分页未完整取回，当前地图与导出仅代表已取回部分，不能视为全部成果；请重试。'
              }}
            </template>
            <template v-else-if="formalTotal > formalPageFeatures.length">
              表格当前页外尚有
              {{ formatCount(formalTotal - formalPageFeatures.length) }}
              点，请使用下方分页查看；地图已完整加载全部成果。
            </template>
            <template v-else>当前返回范围覆盖全部登记点成果。</template>
          </p>
          <p>等级沿用数据库成果记录；页面不会重新计算等级，也不会将该规则套用到外部情景指标。</p>
          <p v-if="formalResult.method === null" data-testid="formal-risk-method-missing">
            成果方法未在数据库登记，本页不补造模型方法或参数。
          </p>
          <p v-else data-testid="formal-risk-method">
            成果方法：{{ formalResult.method }}；方法来源：项目实习报告。
          </p>
        </div>

        <div
          v-if="formalLayer !== null && formalFeatures.length > 0"
          class="formal-actions"
          aria-label="正式成果当前页导出"
        >
          <span>当前页导出：</span>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="formal-risk-export-csv"
            @click="exportFormalCsv"
          >
            CSV
          </button>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="formal-risk-export-geojson"
            @click="exportFormalGeoJson"
          >
            空间数据 + 说明
          </button>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="formal-risk-export-metadata"
            @click="exportFormalMetadata"
          >
            仅下载说明
          </button>
        </div>

        <div
          v-if="formalLayer !== null && formalFeatures.length > 0 && formalComplete"
          class="formal-actions"
          aria-label="正式成果全部匹配导出"
        >
          <span>全部匹配导出（{{ formatCount(formalFeatures.length) }} 点）：</span>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="formal-risk-export-all-csv"
            @click="exportFormalAllCsv"
          >
            CSV · 全部
          </button>
          <button
            type="button"
            class="btn btn--ghost btn--small"
            data-testid="formal-risk-export-all-geojson"
            @click="exportFormalAllGeoJson"
          >
            空间数据 + 说明 · 全部
          </button>
        </div>

        <div
          v-if="formalLayerIds.length === 0"
          class="map-state"
          data-testid="formal-risk-layer-missing"
        >
          <h3>成果地图暂未准备完成</h3>
          <p>当前成果尚未提供可展示的空间要素。</p>
        </div>

        <div v-else class="formal-grid">
          <div class="formal-map-cell">
            <ResultMapCanvas
              :features="formalFeatures"
              :risk-level-field="null"
              :mode="session.mode"
            />
          </div>
          <aside class="formal-side">
            <section class="formal-facts" aria-label="正式成果读取状态">
              <div>
                <span>成果图层</span>
                <b>{{ formalLayer?.label ?? '滑坡易发性点成果' }}</b>
              </div>
              <div>
                <span>当前地图显示</span>
                <b>{{ formatCount(formalFeatures.length) }} 点</b>
              </div>
              <div>
                <span>显示范围</span>
                <b>
                  {{
                    formalTruncated
                      ? `第 ${formalPage} 页表格（每页 ${FORMAL_PAGE_SIZE} 点；地图已加载 ${formalFetched} / ${formalTotal} 点）`
                      : '全部登记点'
                  }}
                </b>
              </div>
              <div>
                <span>成果版本</span>
                <b>{{ formalResult.version || '未登记' }}</b>
              </div>
            </section>
            <ul class="formal-quality">
              <li v-for="(note, index) in formalResult.qualityNotes" :key="index">
                {{ note }}
              </li>
            </ul>
          </aside>
        </div>

        <nav
          v-if="formalLayerIds.length > 0 && formalTotal > FORMAL_PAGE_SIZE"
          class="formal-pager"
          aria-label="正式易发性成果分页"
          data-testid="formal-risk-pager"
        >
          <button
            type="button"
            data-testid="formal-risk-prev"
            :disabled="formalPage <= 1 || formalLoading"
            @click="gotoFormalPage(formalPage - 1)"
          >
            上一页
          </button>
          <span data-testid="formal-risk-page"
            >第 {{ formalPage }} / {{ formalTotalPages }} 页</span
          >
          <button
            type="button"
            data-testid="formal-risk-next"
            :disabled="formalPage >= formalTotalPages || formalLoading"
            @click="gotoFormalPage(formalPage + 1)"
          >
            下一页
          </button>
          <span
            >每页 {{ FORMAL_PAGE_SIZE }} 点 · 表格当前页 {{ formalPageFeatures.length }} 点 ·
            地图已加载 {{ formalFetched }} / {{ formalTotal }} 点</span
          >
        </nav>

        <section
          v-if="formalFeatures.length > 0"
          class="formal-records"
          aria-label="正式成果点表格"
        >
          <h3>成果字段（当前页全部 {{ formalTableFeatures.length }} 点）</h3>
          <div class="table-scroll">
            <table class="formal-table">
              <thead>
                <tr>
                  <th>对象ID</th>
                  <th>HAZ_LEVEL</th>
                  <th>SCORE</th>
                </tr>
              </thead>
              <tbody>
                <tr
                  v-for="feature in formalTableFeatures"
                  :key="`${feature.ref.layerId}:${feature.ref.id}`"
                >
                  <td>{{ feature.ref.id }}</td>
                  <td>{{ formalValue(feature, 'hazardLevel', 'hazLevel', 'HAZ_LEVEL') }}</td>
                  <td>{{ formalValue(feature, 'score', 'SCORE') }}</td>
                </tr>
              </tbody>
            </table>
          </div>
        </section>
      </template>
    </section>
    <section
      v-else-if="store.sourceKind === 'projectAnalysis'"
      class="pending"
      data-testid="project-analysis-pending"
    >
      <h2 class="pending-title">项目成果暂未加载</h2>
      <p>当前页面暂未加载项目分析成果明细。</p>
      <p>2050 / 2100 情景数据与项目分析成果分开展示，相关成果准备完成后会在此处显示。</p>
    </section>

    <template v-else>
      <!-- 清单失败：整体错误态 + 重试 -->
      <section
        v-if="store.manifestStatus === 'failed'"
        class="load-error"
        data-testid="risk-manifest-error"
        role="alert"
      >
        <h2>未来情景暂时无法显示</h2>
        <p>{{ store.manifestError }}</p>
        <button
          type="button"
          class="btn btn--primary"
          data-testid="risk-retry"
          @click="store.retry()"
        >
          重试
        </button>
      </section>

      <template v-else>
        <div class="risk-grid" :class="{ 'is-compare': store.isCompare }">
          <div class="map-area" data-testid="risk-map-area">
            <div
              v-for="year in store.visibleYears"
              :key="year"
              class="map-cell"
              :data-testid="`map-cell-${year}`"
            >
              <div v-if="store.statusByYear[year] === 'loading'" class="map-state">
                <LoadingState label="正在读取真实情景文件…" />
              </div>
              <div v-else-if="store.statusByYear[year] === 'failed'" class="map-state" role="alert">
                <h3>{{ year }} 情景读取失败</h3>
                <p data-testid="risk-error">{{ store.errorByYear[year] }}</p>
                <p>其它情景不受影响，可稍后重试。</p>
                <button
                  type="button"
                  class="btn btn--primary"
                  :data-testid="`risk-retry-${year}`"
                  @click="store.loadYear(year, true)"
                >
                  重试 {{ year }}
                </button>
              </div>
              <RiskMapCanvas
                v-else-if="store.statusByYear[year] === 'ready'"
                :ref="setMapRef(year)"
                :year="year"
                :metric="store.metric"
                :records="recordsOf(year)"
                :selected-id="store.selectedId"
                :mode="session.mode"
                @select="store.select"
                @view-change="onViewChange(year, $event)"
              />
            </div>
          </div>

          <aside class="side" data-testid="risk-side">
            <section
              v-if="store.matchStats !== null"
              class="match"
              data-testid="match-stats"
              aria-label="同对象匹配统计"
            >
              <h3 class="match-title">同对象匹配（glacier_id）</h3>
              <ul class="match-list">
                <li>
                  两期均有
                  <b data-testid="match-matched">{{ formatCount(store.matchStats.matched) }}</b>
                </li>
                <li>
                  仅 2050
                  <b data-testid="match-only-2050">{{
                    formatCount(store.matchStats.onlyIn2050)
                  }}</b>
                </li>
                <li>
                  仅 2100
                  <b data-testid="match-only-2100">{{
                    formatCount(store.matchStats.onlyIn2100)
                  }}</b>
                </li>
              </ul>
              <p class="match-note">
                匹配按 glacier_id
                精确匹配全量数据计算，不随筛选变化；仅一期的对象在详情中标注，不参与跨期对比。
              </p>
            </section>

            <RiskStatsPanel
              :metric="store.metric"
              :records="
                store.isCompare
                  ? [...recordsOf(2050), ...recordsOf(2100)]
                  : recordsOf(store.activeYear)
              "
              :bin-range="store.binRange"
              :total-count-all="totalCountAll"
              @bin-select="store.setBinRange"
            />

            <RiskTopList
              :metric="store.metric"
              :records="
                store.isCompare
                  ? [...recordsOf(2050), ...recordsOf(2100)]
                  : recordsOf(store.activeYear)
              "
              :selected-id="store.selectedId"
              @select="store.select"
              @locate="locateRecord"
            />

            <RiskDetailPanel :record="store.selectedRecord" @close="store.select(null)" />
          </aside>
        </div>

        <RiskLegend :metric="store.metric" :null-count="legendNullCount" />
      </template>
    </template>

    <RiskSourcePanel
      v-if="store.sourceKind === 'externalScenario'"
      :manifest="store.manifest"
      :datasets="loadedDatasets"
    />
  </div>
</template>

<style scoped>
.risk-page {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.page-title {
  margin: 0;
  font-size: var(--font-size-page-title);
  color: var(--color-text);
}

.page-subtitle {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
}

.future-banner {
  margin: 0;
  padding: var(--space-2) var(--space-3);
  border: 1px solid var(--color-warning);
  border-left-width: 4px;
  border-radius: var(--radius-sm);
  background: var(--color-warning-surface);
  color: var(--color-warning-text);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.formal-result {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.formal-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-3);
  flex-wrap: wrap;
}

.formal-eyebrow {
  margin: 0 0 var(--space-1);
  color: var(--color-primary);
  font-size: var(--font-size-caption);
}

.formal-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.formal-subtitle,
.formal-notes p {
  margin: var(--space-1) 0 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

.formal-badge {
  padding: 2px var(--space-2);
  border: 1px solid var(--badge-border-color);
  border-radius: var(--badge-radius);
  background: var(--color-info-surface);
  color: var(--color-primary-strong);
  font-size: var(--font-size-caption);
  white-space: nowrap;
}

.formal-notes {
  display: grid;
  gap: var(--space-1);
  padding: var(--space-3);
  border-left: 3px solid var(--color-primary);
  border-radius: var(--radius-sm);
  background: var(--color-info-surface);
}

.formal-actions {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.formal-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 320px;
  gap: var(--space-3);
  min-width: 0;
}

.formal-map-cell {
  height: clamp(340px, 52vh, 620px);
  min-width: 0;
  min-height: 0;
}

.formal-side {
  display: grid;
  align-content: start;
  gap: var(--space-3);
  min-width: 0;
}

.formal-facts {
  display: grid;
  gap: var(--space-2);
  margin: 0;
}

.formal-facts > div {
  display: grid;
  gap: 2px;
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
}

.formal-facts span {
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.formal-facts b {
  color: var(--color-text);
  font-size: var(--font-size-body);
  overflow-wrap: anywhere;
}

.formal-quality {
  display: grid;
  gap: var(--space-1);
  margin: 0;
  padding-left: var(--space-4);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

.formal-pager {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.formal-pager button {
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
  color: var(--color-text);
}

.formal-pager button:disabled {
  cursor: not-allowed;
  opacity: 0.55;
}

.formal-records {
  display: grid;
  gap: var(--space-2);
  min-width: 0;
}

.formal-records h3 {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
}

.table-scroll {
  max-width: 100%;
  overflow-x: auto;
}

.formal-table {
  width: 100%;
  min-width: 480px;
  border-collapse: collapse;
  font-size: var(--font-size-caption);
}

.formal-table th,
.formal-table td {
  padding: var(--space-2);
  border: 1px solid var(--color-border);
  text-align: left;
  white-space: nowrap;
}

.formal-table th {
  background: var(--color-info-surface);
  color: var(--color-text);
}

.pending {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-info-surface);
}

.pending-title {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-text);
}

.pending p {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
  line-height: var(--line-height-body);
}

.load-error {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-4);
  border: 1px solid var(--color-danger);
  border-radius: var(--radius-md);
  background: var(--color-danger-surface);
}

.load-error h2 {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-danger-text);
}

.load-error p {
  margin: 0;
  color: var(--color-text);
  font-size: var(--font-size-body);
  overflow-wrap: anywhere;
}

.risk-grid {
  display: grid;
  grid-template-columns: minmax(0, 1fr) 360px;
  gap: var(--space-3);
  align-items: start;
}

.risk-grid.is-compare {
  grid-template-columns: minmax(0, 1fr) 360px;
}

.map-area {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.risk-grid:not(.is-compare) .map-area {
  grid-template-columns: minmax(0, 1fr);
}

.risk-grid.is-compare .map-area {
  grid-template-columns: repeat(2, minmax(0, 1fr));
}

/* 地图行高必须确定（阶段2/3 的布局铁律），否则画布会被内容撑破。 */
.map-cell {
  height: clamp(340px, 52vh, 620px);
  min-height: 0;
  min-width: 0;
}

.map-state {
  display: grid;
  gap: var(--space-2);
  align-content: center;
  justify-items: start;
  height: 100%;
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.map-state h3 {
  margin: 0;
  font-size: var(--font-size-section-title);
  color: var(--color-danger-text);
}

.map-state p {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-body);
  overflow-wrap: anywhere;
}

.side {
  display: grid;
  gap: var(--space-3);
  min-width: 0;
}

.match {
  display: grid;
  gap: var(--space-2);
  padding: var(--space-3);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
}

.match-title {
  margin: 0;
  font-size: var(--font-size-body);
  font-weight: 600;
  color: var(--color-text);
}

.match-list {
  margin: 0;
  padding: 0;
  list-style: none;
  display: grid;
  grid-template-columns: repeat(3, minmax(0, 1fr));
  gap: var(--space-2);
}

.match-list li {
  padding: var(--space-1) var(--space-2);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-sm);
  background: var(--color-surface-sunken);
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  display: grid;
  gap: 2px;
  min-width: 0;
}

.match-list b {
  color: var(--color-text);
  font-size: var(--font-size-metric);
  font-variant-numeric: tabular-nums;
}

.match-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-body);
}

@media (max-width: 1100px) {
  .risk-grid,
  .risk-grid.is-compare {
    grid-template-columns: minmax(0, 1fr);
  }

  .risk-grid.is-compare .map-area {
    grid-template-columns: minmax(0, 1fr);
  }

  .map-cell {
    height: clamp(280px, 48vh, 480px);
  }

  .formal-grid {
    grid-template-columns: minmax(0, 1fr);
  }

  .formal-map-cell {
    height: clamp(280px, 48vh, 480px);
  }
}

@media (max-width: 600px) {
  .map-cell {
    height: 300px;
  }
}
</style>
