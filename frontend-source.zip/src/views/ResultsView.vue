<script setup lang="ts">
/**
 * 阶段6：成果中心。
 *
 * 按成果类型（风险研判/暴露评估/应急保障）与状态（已发布/草稿/归档）筛选；
 * 卡片列出版本、类型、时点、范围与关键指标。成果均来自 ResultRepository
 * 的已存登记；示例身份持续标注。
 */
import { onMounted } from 'vue'
import { RouterLink } from 'vue-router'

import ErrorState from '@/components/ui/ErrorState.vue'
import LoadingState from '@/components/ui/LoadingState.vue'
import RiskBadge from '@/components/ui/RiskBadge.vue'
import SourceBadge from '@/components/ui/SourceBadge.vue'
import { formatMetricValue, formatTimeWithRole } from '@/domain/format'
import { RESULT_KIND_LABEL } from '@/domain/labels'
import type { ResultKind, ResultStatus } from '@/domain/types'
import { useResultsStore } from '@/stores/results'
import { useSessionStore } from '@/stores/session'

const store = useResultsStore()
const session = useSessionStore()

// 客户入口只展示当前已形成真实成果的类别；没有成果表的专题不提供会报错的筛选按钮。
const kinds: ResultKind[] = ['risk', 'emergency']
const statuses: Array<{ key: ResultStatus; label: string }> = [
  { key: 'published', label: '已发布' },
  { key: 'draft', label: '草稿' },
  { key: 'archived', label: '已归档' },
]

onMounted(() => {
  void session.loadCapabilities()
  if (store.listStatus === 'idle') void store.loadList(1)
})
</script>

<template>
  <div class="results-view" data-testid="results-page">
    <header class="page-head">
      <div>
        <h1 class="page-heading">成果中心</h1>
        <p class="page-lead">
          已登记的分析成果：风险研判与应急保障。成果详情提供地图、指标、方法、
          输入来源与文件；只有真实存在的文件才提供下载。
        </p>
      </div>
      <SourceBadge
        :mode="session.mode"
        :snapshot-id="session.snapshotId ?? undefined"
        :scope-label="session.scopeLabel ?? undefined"
      />
    </header>

    <section class="filter-bar" data-testid="results-filters" aria-label="成果筛选">
      <div class="filter-group" role="group" aria-label="按类型筛选">
        <button
          type="button"
          class="chip"
          :class="{ 'is-active': store.kindFilter === null }"
          data-testid="results-kind-all"
          @click="store.setKind(null)"
        >
          全部类型
        </button>
        <button
          v-for="kind in kinds"
          :key="kind"
          type="button"
          class="chip"
          :class="{ 'is-active': store.kindFilter === kind }"
          :data-testid="`results-kind-${kind}`"
          @click="store.setKind(kind)"
        >
          {{ RESULT_KIND_LABEL[kind] }}
        </button>
      </div>

      <div class="filter-group" role="group" aria-label="按状态筛选">
        <button
          type="button"
          class="chip"
          :class="{ 'is-active': store.statusFilter === null }"
          data-testid="results-status-all"
          @click="store.setStatus(null)"
        >
          全部状态
        </button>
        <button
          v-for="item in statuses"
          :key="item.key"
          type="button"
          class="chip"
          :class="{ 'is-active': store.statusFilter === item.key }"
          :data-testid="`results-status-${item.key}`"
          @click="store.setStatus(item.key)"
        >
          {{ item.label }}
        </button>
      </div>

      <button
        type="button"
        class="btn btn--small"
        data-testid="results-clear"
        :disabled="!store.hasActiveFilters"
        @click="store.clearFilters()"
      >
        清除筛选
      </button>
    </section>

    <p
      v-if="store.listStatus === 'ready'"
      class="result-count"
      data-testid="results-count"
      role="status"
    >
      共 {{ store.rows.length }} 个成果<template v-if="store.hasActiveFilters">（筛选后）</template>
    </p>

    <LoadingState
      v-if="store.listStatus === 'loading' || store.listStatus === 'idle'"
      label="正在读取成果清单…"
    />
    <ErrorState
      v-else-if="store.listStatus === 'failed'"
      :error="store.listError"
      title="成果清单读取失败"
      data-testid="results-error"
      @retry="store.loadList()"
    />
    <div v-else class="result-grid">
      <RouterLink
        v-for="result in store.rows"
        :key="result.id"
        class="result-card"
        :to="{ name: 'result-detail', params: { resultId: result.id } }"
        :data-testid="`result-card-${result.id}`"
      >
        <div class="card-head">
          <span class="card-kind">{{ RESULT_KIND_LABEL[result.kind] }}</span>
          <span class="card-version tabular-nums">{{ result.version }}</span>
        </div>
        <h2 class="card-title">{{ result.title }}</h2>
        <p class="card-meta">
          {{ result.regionLabel }} · {{ formatTimeWithRole(result.time) }}
          <template v-if="result.scenarioYear !== undefined">
            · 情景年份 {{ result.scenarioYear }}（未来情景，不是实时预警）</template
          >
        </p>
        <dl class="card-metrics">
          <div v-for="metric in result.metrics" :key="metric.key" class="card-metric">
            <dt>{{ metric.label }}</dt>
            <dd class="tabular-nums">{{ formatMetricValue(metric) }}</dd>
          </div>
        </dl>
        <p class="card-foot">
          查看详情 →
          <RiskBadge
            v-if="result.kind === 'risk'"
            level="insufficient"
            class="card-badge"
            title="分级阈值未登记，详情页按连续指数显示"
          />
        </p>
      </RouterLink>
    </div>
  </div>
</template>

<style scoped>
.results-view {
  display: flex;
  flex-direction: column;
  gap: var(--space-4);
}

.page-head {
  display: flex;
  align-items: flex-start;
  justify-content: space-between;
  gap: var(--space-4);
}

.page-heading {
  margin: 0;
  font-size: 24px;
}

.page-lead {
  margin: 4px 0 0;
  color: var(--color-muted);
  font-size: 13px;
  max-width: 720px;
}

.filter-bar {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: var(--space-4);
}

.filter-group {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-1);
}

.chip {
  padding: 5px 12px;
  border: 1px solid var(--color-border);
  border-radius: 999px;
  background: var(--color-surface);
  color: var(--color-text);
  cursor: pointer;
  font: inherit;
  font-size: var(--font-size-caption);
}

.chip.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary);
  color: #fff;
  font-weight: 600;
}

.result-count {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.result-grid {
  display: grid;
  grid-template-columns: repeat(auto-fill, minmax(300px, 1fr));
  gap: var(--space-4);
}

.result-card {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  padding: var(--space-4);
  border: 1px solid var(--color-border);
  border-radius: var(--radius-md);
  background: var(--color-surface);
  color: inherit;
  text-decoration: none;
  transition: border-color 0.15s;
}

.result-card:hover {
  border-color: var(--color-primary);
}

.card-head {
  display: flex;
  justify-content: space-between;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.card-kind {
  color: var(--color-primary);
  font-weight: 600;
}

.card-title {
  margin: 0;
  font-size: var(--font-size-section-title);
}

.card-meta {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

.card-metrics {
  display: flex;
  flex-wrap: wrap;
  gap: var(--space-3);
  margin: 0;
  padding: var(--space-2) 0 0;
  border-top: 1px dashed var(--color-border);
}

.card-metric dt {
  color: var(--color-muted);
  font-size: 11px;
}

.card-metric dd {
  margin: 0;
  font-size: var(--font-size-caption);
  font-variant-numeric: tabular-nums;
}

.card-foot {
  margin: 0;
  color: var(--color-primary);
  font-size: var(--font-size-caption);
  display: flex;
  align-items: center;
  gap: var(--space-2);
}

.card-badge {
  transform: scale(0.85);
}

.tabular-nums {
  font-variant-numeric: tabular-nums;
}

@media (max-width: 720px) {
  .page-head {
    flex-direction: column;
  }

  .result-grid {
    grid-template-columns: 1fr;
  }
}
</style>
