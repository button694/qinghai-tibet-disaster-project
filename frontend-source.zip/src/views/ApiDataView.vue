<script setup lang="ts">
/**
 * 阶段8B：API 数据链路页（真实数据库只读浏览入口）。
 *
 * 定位：为首批已接通能力提供明确入口——数据目录摘要、数据来源/行政区/字典、
 * 白名单矢量图层与要素详情、已存救援路线及路线详情。只在 api 模式可用；
 * 其余模式显示运行说明，不提供任何模拟数据。未接入能力由 capabilities
 * 显式关闭并给出原因（界面显示「能力未接入」），不静默展示示例数据。
 *
 * 取数纪律：全部经 services/apiDataWorkspace.ts → HTTP Repository；
 * 失败显示错误态与重试，不回退 mock。
 */
import { computed, onBeforeUnmount, onMounted, reactive, ref } from 'vue'
import { RouterLink } from 'vue-router'

import { getApiDataWorkspaceService } from '@/services/apiDataWorkspace'
import { ROUTE_ROLE_LABEL } from '@/domain/labels'
import { useSessionStore } from '@/stores/session'
import type {
  CapabilityKey,
  Dataset,
  Dictionary,
  FeatureDetail,
  LayerDefinition,
  Page,
  RouteDetail,
  RouteSummary,
} from '@/domain/types'
import { isRepositoryError, type RepositoryError } from '@/repositories/types'

const session = useSessionStore()
const workspace = getApiDataWorkspaceService()

const isApiMode = computed(() => session.mode === 'api')

/**
 * 能力面板必须以服务返回的布尔开关为准。
 * 后端会为部分已启用能力同时提供说明文字（例如 readResults），
 * 不能因为 reasons 中出现文字就把它渲染成「能力未接入」。
 */
const CAPABILITY_KEYS: readonly CapabilityKey[] = [
  'readLayers',
  'attributeQuery',
  'spatialQuery',
  'readResults',
  'exportFormats',
  'authEnabled',
  'routeRecompute',
  'analysisSubmit',
  'dataEdit',
  'backupExecute',
]

const CAPABILITY_LABEL: Record<CapabilityKey, string> = {
  readLayers: '图层与要素查看',
  attributeQuery: '属性筛选',
  spatialQuery: '空间查询',
  readResults: '成果查看',
  exportFormats: '结果导出',
  authEnabled: '账号登录',
  routeRecompute: '路线重新规划',
  analysisSubmit: '专题分析',
  dataEdit: '数据编辑',
  backupExecute: '数据备份',
}

const CAPABILITY_ENABLED_TEXT: Partial<Record<CapabilityKey, string>> = {
  readLayers: '可查看图层与要素',
  readResults: '可查看成果目录与详情',
  attributeQuery: '可使用属性筛选',
  spatialQuery: '可使用空间查询',
  exportFormats: '可导出当前结果',
  authEnabled: '已启用账号登录',
  routeRecompute: '可进行路线重新规划',
  analysisSubmit: '可提交专题分析',
  dataEdit: '可编辑数据',
  backupExecute: '可执行数据备份',
}

const CAPABILITY_DISABLED_FALLBACK: Partial<Record<CapabilityKey, string>> = {
  exportFormats: '当前结果暂不支持导出。',
}

const capabilityRows = computed(() => {
  const current = session.capabilities
  if (current === null) return []
  return CAPABILITY_KEYS.map((key) => {
    const enabled =
      key === 'exportFormats' ? current.exportFormats.length > 0 : current[key] === true
    const reason = CAPABILITY_DISABLED_FALLBACK[key] ?? '该功能正在完善。'
    return {
      key,
      enabled,
      label: CAPABILITY_LABEL[key],
      text: enabled ? (CAPABILITY_ENABLED_TEXT[key] ?? '当前可用') : `暂未提供：${reason}`,
    }
  })
})

/* ---------------- 数据目录摘要 ---------------- */
const datasetPage = ref<Page<Dataset> | null>(null)
const datasetsError = ref<RepositoryError | null>(null)
const datasetsLoading = ref(false)

/* ---------------- 行政区 / 字典 ---------------- */
const regionCount = ref<number | null>(null)
const regionsError = ref<RepositoryError | null>(null)
const dictionary = ref<Dictionary | null>(null)
const dictionaryError = ref<RepositoryError | null>(null)

/* ---------------- 图层与要素 ---------------- */
const layers = ref<LayerDefinition[]>([])
const layersError = ref<RepositoryError | null>(null)
const selectedLayerId = ref('')
const featurePage = ref<Page<FeatureDetail> | null>(null)
const featuresError = ref<RepositoryError | null>(null)
const featuresLoading = ref(false)
const featureDetail = ref<FeatureDetail | null>(null)
const featureDetailError = ref<RepositoryError | null>(null)

const availableLayers = computed(() =>
  layers.value.filter((layer) => layer.source.type === 'geojson'),
)

/* ---------------- 路线（服务端分页，阶段8B返工） ---------------- */
const ROUTE_SCOPES = [
  { value: 'result.route.combined', label: '综合救援路线' },
  { value: 'result.route.2050', label: '2050 情景救援路线（未来情景）' },
  { value: 'result.route.2100', label: '2100 情景救援路线（未来情景）' },
] as const
const selectedScope = ref<string>('result.route.combined')
const routes = ref<RouteSummary[]>([])
const routesTotal = ref(0)
const routesPage = ref(1)
const routesPageSize = ref(20)
const routesError = ref<RepositoryError | null>(null)
const routesLoading = ref(false)
const routeDetail = ref<RouteDetail | null>(null)
const routeDetailError = ref<RepositoryError | null>(null)

const routesTotalPages = computed(() =>
  Math.max(1, Math.ceil(routesTotal.value / routesPageSize.value)),
)

const requestState = reactive({ failedRequests: 0 })

/*
 * 页面内的几个面板可以被用户连续切换。Repository 虽然支持 AbortSignal，
 * 但测试替身、缓存适配器或已发出的响应未必真的会中止，所以除了取消上一
 * 个请求，还用序号确认“最后一次请求”才有资格写回状态，避免旧响应覆盖新
 * 图层、路线页或详情。
 */
let datasetsRequest = 0
let catalogMetaRequest = 0
let layersRequest = 0
let featuresRequest = 0
let featureDetailRequest = 0
let routesRequest = 0
let routeDetailRequest = 0

let datasetsController: AbortController | null = null
let catalogMetaController: AbortController | null = null
let layersController: AbortController | null = null
let featuresController: AbortController | null = null
let featureDetailController: AbortController | null = null
let routesController: AbortController | null = null
let routeDetailController: AbortController | null = null

function abort(controller: AbortController | null): void {
  controller?.abort()
}

function errText(error: RepositoryError | null): string {
  if (error === null) return ''
  const suffix = error.requestId ? `（requestId: ${error.requestId}）` : ''
  return `${error.userMessage ?? error.message}${suffix}`
}

async function loadDatasets(): Promise<void> {
  const request = ++datasetsRequest
  abort(datasetsController)
  const controller = new AbortController()
  datasetsController = controller
  datasetsLoading.value = true
  datasetsError.value = null
  try {
    const page = await workspace.listDatasets(1, 10, { signal: controller.signal })
    if (request !== datasetsRequest) return
    datasetPage.value = page
  } catch (error) {
    if (request !== datasetsRequest) return
    datasetsError.value = isRepositoryError(error)
      ? error
      : (Object.assign(new Error(String(error)), { userMessage: String(error) }) as RepositoryError)
    requestState.failedRequests += 1
  } finally {
    if (request === datasetsRequest) {
      datasetsLoading.value = false
      datasetsController = null
    }
  }
}

async function loadCatalogMeta(): Promise<void> {
  const request = ++catalogMetaRequest
  abort(catalogMetaController)
  const controller = new AbortController()
  catalogMetaController = controller
  regionsError.value = null
  dictionaryError.value = null
  try {
    const regions = await workspace.listRegions({ signal: controller.signal })
    if (request !== catalogMetaRequest) return
    regionCount.value = regions.length
  } catch (error) {
    if (request !== catalogMetaRequest) return
    regionCount.value = null
    regionsError.value = error as RepositoryError
    requestState.failedRequests += 1
  }
  try {
    const nextDictionary = await workspace.getDictionary('gb13923-2022', {
      signal: controller.signal,
    })
    if (request !== catalogMetaRequest) return
    dictionary.value = nextDictionary
  } catch (error) {
    if (request !== catalogMetaRequest) return
    dictionary.value = null
    dictionaryError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (request === catalogMetaRequest) catalogMetaController = null
  }
}

async function loadLayers(): Promise<void> {
  const request = ++layersRequest
  abort(layersController)
  const controller = new AbortController()
  layersController = controller
  layersError.value = null
  try {
    const nextLayers = await workspace.listLayers({ signal: controller.signal })
    if (request !== layersRequest) return
    layers.value = nextLayers
  } catch (error) {
    if (request !== layersRequest) return
    layersError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (request === layersRequest) layersController = null
  }
}

async function selectLayer(layerId: string): Promise<void> {
  const request = ++featuresRequest
  abort(featuresController)
  const controller = new AbortController()
  featuresController = controller

  // 切换图层时，正在返回的旧要素详情也必须失效。
  ++featureDetailRequest
  abort(featureDetailController)
  featureDetailController = null
  selectedLayerId.value = layerId
  featureDetail.value = null
  featureDetailError.value = null
  if (layerId === '') {
    featurePage.value = null
    featuresError.value = null
    featuresLoading.value = false
    featuresController = null
    return
  }
  featuresLoading.value = true
  featuresError.value = null
  try {
    const page = await workspace.listFeatures(
      layerId,
      { page: 1, pageSize: 10 },
      { signal: controller.signal },
    )
    if (request !== featuresRequest || selectedLayerId.value !== layerId) return
    featurePage.value = page
  } catch (error) {
    if (request !== featuresRequest || selectedLayerId.value !== layerId) return
    featurePage.value = null
    featuresError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (request === featuresRequest && selectedLayerId.value === layerId) {
      featuresLoading.value = false
      featuresController = null
    }
  }
}

async function openFeature(refValue: { layerId: string; id: string }): Promise<void> {
  const request = ++featureDetailRequest
  abort(featureDetailController)
  const controller = new AbortController()
  featureDetailController = controller
  featureDetail.value = null
  featureDetailError.value = null
  try {
    const detail = await workspace.getFeature(refValue, { signal: controller.signal })
    if (request !== featureDetailRequest || selectedLayerId.value !== refValue.layerId) return
    featureDetail.value = detail
  } catch (error) {
    if (request !== featureDetailRequest || selectedLayerId.value !== refValue.layerId) return
    featureDetail.value = null
    featureDetailError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (request === featureDetailRequest) featureDetailController = null
  }
}

/** 加载当前页路线；只请求目标页（服务端分页），失败清空旧数据不回退 mock。 */
async function loadRoutes(): Promise<void> {
  const scope = selectedScope.value
  const pageNumber = routesPage.value
  const pageSize = routesPageSize.value
  const request = ++routesRequest
  abort(routesController)
  const controller = new AbortController()
  routesController = controller
  routesLoading.value = true
  routesError.value = null
  try {
    const page = await workspace.listRoutes(
      scope,
      { page: pageNumber, pageSize },
      { signal: controller.signal },
    )
    if (
      request !== routesRequest ||
      selectedScope.value !== scope ||
      routesPage.value !== pageNumber
    )
      return
    routes.value = page.items
    routesTotal.value = page.total
  } catch (error) {
    if (
      request !== routesRequest ||
      selectedScope.value !== scope ||
      routesPage.value !== pageNumber
    )
      return
    routes.value = []
    routesTotal.value = 0
    routesError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (
      request === routesRequest &&
      selectedScope.value === scope &&
      routesPage.value === pageNumber
    ) {
      routesLoading.value = false
      routesController = null
    }
  }
}

/** 切换成果：回到第1页并清空上一个成果的路线与详情。 */
async function selectScope(scope: string): Promise<void> {
  selectedScope.value = scope
  ++routeDetailRequest
  abort(routeDetailController)
  routeDetailController = null
  routeDetail.value = null
  routeDetailError.value = null
  routes.value = []
  routesTotal.value = 0
  routesPage.value = 1
  await loadRoutes()
}

/** 翻页：先清旧页路线再请求目标页；页码越界不发起请求。 */
async function gotoRoutesPage(page: number): Promise<void> {
  if (page < 1 || page > routesTotalPages.value || page === routesPage.value) return
  routesPage.value = page
  routes.value = []
  await loadRoutes()
}

async function openRoute(routeId: string): Promise<void> {
  const request = ++routeDetailRequest
  abort(routeDetailController)
  const controller = new AbortController()
  routeDetailController = controller
  routeDetail.value = null
  routeDetailError.value = null
  try {
    const detail = await workspace.getRoute(routeId, { signal: controller.signal })
    if (request !== routeDetailRequest) return
    routeDetail.value = detail
  } catch (error) {
    if (request !== routeDetailRequest) return
    routeDetail.value = null
    routeDetailError.value = error as RepositoryError
    requestState.failedRequests += 1
  } finally {
    if (request === routeDetailRequest) routeDetailController = null
  }
}

function formatMeters(value: number | null): string {
  if (value === null) return '未提供'
  return `${value} 米`
}

function geometrySummary(geometry: { type: string } | null): string {
  if (geometry === null) return '无几何（不画直线冒充）'
  if (geometry.type === 'LineString') {
    const line = geometry as { type: string; coordinates: number[][] }
    return `LineString，${line.coordinates.length} 个节点（EPSG:4326）`
  }
  return `${geometry.type}（EPSG:4326，由服务端重投影）`
}

onMounted(() => {
  // 与其他业务页一致：页面挂载时加载能力清单（能力面板据此渲染）。
  void session.loadCapabilities()
  if (!isApiMode.value) return
  void loadDatasets()
  void loadCatalogMeta()
  void loadLayers()
  void selectScope(selectedScope.value)
})

onBeforeUnmount(() => {
  ++datasetsRequest
  ++catalogMetaRequest
  ++layersRequest
  ++featuresRequest
  ++featureDetailRequest
  ++routesRequest
  ++routeDetailRequest
  abort(datasetsController)
  abort(catalogMetaController)
  abort(layersController)
  abort(featuresController)
  abort(featureDetailController)
  abort(routesController)
  abort(routeDetailController)
})
</script>

<template>
  <div class="api-data-view" data-testid="api-data-page">
    <header class="page-head">
      <h1>数据服务状态</h1>
      <p class="head-note">查看当前数据服务、成果、图层和救援路线的可用情况。</p>
      <p v-if="!isApiMode" class="mode-warn" data-testid="api-mode-warn" role="note">
        当前暂未连接项目数据库，数据服务状态无法查看。
      </p>
    </header>

    <template v-if="isApiMode">
      <!-- 能力清单 -->
      <section class="panel" aria-labelledby="cap-title">
        <h2 id="cap-title">功能状态</h2>
        <ul class="cap-list" data-testid="api-capabilities">
          <li
            v-for="row in capabilityRows"
            :key="row.key"
            class="cap-item"
            :class="{ 'is-ok': row.enabled }"
          >
            <span class="cap-key">{{ row.label }}</span>
            <span class="cap-reason">{{ row.text }}</span>
          </li>
        </ul>
      </section>

      <!-- 数据目录摘要 -->
      <section class="panel" aria-labelledby="ds-title">
        <h2 id="ds-title">数据目录</h2>
        <p v-if="datasetsError" class="error-note" role="alert">
          {{ errText(datasetsError) }}
          <button type="button" @click="loadDatasets">重试</button>
        </p>
        <p v-else-if="datasetPage" data-testid="api-datasets-total" class="count-line">
          共 <b>{{ datasetPage.total }}</b> 个数据集，当前显示前 {{ datasetPage.items.length }} 项：
        </p>
        <p v-else class="muted">加载中…</p>
        <div
          v-if="datasetPage"
          class="table-scroll"
          tabindex="0"
          aria-label="数据目录表格，可横向滚动"
        >
          <table class="data-table">
            <thead>
              <tr>
                <th>名称</th>
                <th>主题</th>
                <th>类型</th>
                <th>在线数据</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="dataset in datasetPage.items" :key="dataset.id">
                <td>{{ dataset.name }}</td>
                <td>{{ dataset.theme }}</td>
                <td>{{ dataset.dataType }}</td>
                <td>
                  <template v-if="dataset.serviceAvailable">可用</template>
                  <template v-else>暂未提供</template>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
      </section>

      <!-- 行政区 / 字典 -->
      <section class="panel" aria-labelledby="meta-title">
        <h2 id="meta-title">行政区与字典</h2>
        <p v-if="regionsError" class="error-note" role="alert">
          行政区读取失败：{{ errText(regionsError) }}
        </p>
        <p v-else-if="regionCount !== null" data-testid="api-regions-count" class="count-line">
          已收录行政区 <b>{{ regionCount }}</b> 条（省级 6 / 地级 80 / 县级 628）。
        </p>
        <p v-if="dictionaryError" class="error-note" role="alert">
          字典读取失败：{{ errText(dictionaryError) }}
        </p>
        <p v-else-if="dictionary" class="count-line">
          字典「{{ dictionary.label }}」共 <b>{{ dictionary.items.length }}</b> 条代码。
        </p>
      </section>

      <!-- 图层与要素 -->
      <section class="panel" aria-labelledby="layer-title">
        <h2 id="layer-title">地图图层与要素</h2>
        <p v-if="layersError" class="error-note" role="alert">
          图层读取失败：{{ errText(layersError) }}
          <button type="button" @click="loadLayers">重试</button>
        </p>
        <template v-else>
          <label class="field-label" for="api-layer-select">选择图层：</label>
          <select
            id="api-layer-select"
            data-testid="api-layer-select"
            :value="selectedLayerId"
            @change="selectLayer(($event.target as HTMLSelectElement).value)"
          >
            <option value="">（请选择）</option>
            <option v-for="layer in availableLayers" :key="layer.id" :value="layer.id">
              {{ layer.label }}（{{ layer.geometryType }}）
            </option>
          </select>
          <p class="muted">
            另有 {{ layers.length - availableLayers.length }} 个数据资源暂未提供在线要素查看。
          </p>
        </template>
        <p v-if="featuresError" class="error-note" role="alert">{{ errText(featuresError) }}</p>
        <p v-else-if="featuresLoading" class="muted">要素加载中…</p>
        <div
          v-else-if="featurePage"
          class="table-scroll"
          tabindex="0"
          aria-label="要素表格，可横向滚动"
        >
          <table class="data-table" data-testid="api-features-table">
            <thead>
              <tr>
                <th>要素</th>
                <th>操作</th>
              </tr>
            </thead>
            <tbody>
              <tr v-for="feature in featurePage.items" :key="feature.ref.id">
                <td>{{ feature.title }}（ID {{ feature.ref.id }}）</td>
                <td>
                  <button
                    type="button"
                    :data-testid="`api-feature-${feature.ref.id}`"
                    @click="openFeature(feature.ref)"
                  >
                    查看详情
                  </button>
                </td>
              </tr>
            </tbody>
          </table>
        </div>
        <p v-if="featurePage" class="muted">
          共 {{ featurePage.total }} 条要素（分页展示，本页 {{ featurePage.items.length }} 条）。
        </p>
        <p v-if="featureDetailError" class="error-note" role="alert">
          {{ errText(featureDetailError) }}
        </p>
        <div v-else-if="featureDetail" class="detail-box" data-testid="api-feature-detail">
          <h3>要素详情：{{ featureDetail.title }}</h3>
          <dl class="detail-list">
            <template v-for="(value, key) in featureDetail.properties" :key="key">
              <div class="detail-row">
                <dt>{{ key }}</dt>
                <dd>{{ value === null ? '未提供' : value }}</dd>
              </div>
            </template>
          </dl>
          <p class="muted">
            几何：{{
              featureDetail.geometry
                ? `${featureDetail.geometry.type}（EPSG:4326，由服务端重投影）`
                : '无几何'
            }}
          </p>
        </div>
      </section>

      <!-- 已存救援路线 -->
      <section class="panel" aria-labelledby="route-title">
        <h2 id="route-title">救援路线成果</h2>
        <label class="field-label" for="api-scope-select">选择成果：</label>
        <select
          id="api-scope-select"
          data-testid="api-scope-select"
          :value="selectedScope"
          @change="selectScope(($event.target as HTMLSelectElement).value)"
        >
          <option v-for="scope in ROUTE_SCOPES" :key="scope.value" :value="scope.value">
            {{ scope.label }}
          </option>
        </select>
        <p v-if="routesError" class="error-note" role="alert">{{ errText(routesError) }}</p>
        <p v-else-if="routesLoading" class="muted">路线加载中…</p>
        <template v-else>
          <p v-if="routesTotal > 0" data-testid="api-routes-count" class="count-line">
            成果「{{ selectedScope }}」共 <b data-testid="api-routes-total">{{ routesTotal }}</b>
            条路线（服务端分页）； 当前第
            <b data-testid="api-routes-page">{{ routesPage }}</b> /
            <span data-testid="api-routes-total-pages">{{ routesTotalPages }}</span> 页， 每页
            {{ routesPageSize }} 条， 本页 {{ routes.length }} 条。
          </p>
          <p v-else-if="routesPage > 1" class="muted" data-testid="api-routes-empty-page">
            当前页码超出范围（该成果共 {{ routesTotal }} 条），请返回有效页码。
          </p>
          <p v-else class="muted" data-testid="api-routes-empty">该成果未登记任何路线。</p>
          <div
            v-if="routes.length > 0"
            class="table-scroll"
            tabindex="0"
            aria-label="救援路线表格，可横向滚动"
          >
            <table class="data-table">
              <thead>
                <tr>
                  <th>路线（终点设施）</th>
                  <th>距离</th>
                  <th>角色</th>
                  <th>操作</th>
                </tr>
              </thead>
              <tbody>
                <tr v-for="route in routes" :key="route.id">
                  <td>{{ route.label }}</td>
                  <td>{{ formatMeters(route.distanceMeters) }}</td>
                  <td>{{ ROUTE_ROLE_LABEL[route.role] }}</td>
                  <td>
                    <button
                      type="button"
                      :data-testid="`api-route-${routes.indexOf(route)}`"
                      @click="openRoute(route.id)"
                    >
                      路线详情
                    </button>
                  </td>
                </tr>
              </tbody>
            </table>
          </div>
          <nav
            v-if="routesTotal > 0"
            class="route-pager"
            aria-label="救援路线分页"
            data-testid="api-routes-pager"
          >
            <button
              type="button"
              data-testid="api-routes-prev"
              :disabled="routesPage <= 1"
              @click="gotoRoutesPage(routesPage - 1)"
            >
              上一页
            </button>
            <span class="pager-label">第 {{ routesPage }} / {{ routesTotalPages }} 页</span>
            <button
              type="button"
              data-testid="api-routes-next"
              :disabled="routesPage >= routesTotalPages"
              @click="gotoRoutesPage(routesPage + 1)"
            >
              下一页
            </button>
            <span class="pager-label">共 {{ routesTotal }} 条 · 每页 {{ routesPageSize }} 条</span>
          </nav>
        </template>
        <p v-if="routeDetailError" class="error-note" role="alert">
          {{ errText(routeDetailError) }}
        </p>
        <div v-else-if="routeDetail" class="detail-box" data-testid="api-route-detail">
          <h3>路线详情：{{ routeDetail.label }}</h3>
          <p>
            状态：{{ routeDetail.status === 'reachable' ? '可达' : '不可达' }}； 距离：{{
              formatMeters(routeDetail.distanceMeters)
            }}； 通行时间：{{
              routeDetail.durationSeconds === null
                ? '未提供（数据库未登记）'
                : `${routeDetail.durationSeconds} 秒`
            }}
          </p>
          <p>路网版本：{{ routeDetail.networkVersion }}</p>
          <p>
            起点：{{ routeDetail.origin?.label ?? '未提供' }}； 终点：{{
              routeDetail.destination?.label ?? '未提供'
            }}
          </p>
          <p>几何：{{ geometrySummary(routeDetail.geometry) }}</p>
          <p class="muted">距离口径：{{ routeDetail.distanceSource }}</p>
          <ul class="assume-list">
            <li v-for="(note, index) in routeDetail.assumptions" :key="index">{{ note }}</li>
          </ul>
          <RouterLink
            class="workspace-link"
            data-testid="api-route-workspace-link"
            :to="{
              name: 'analysis-emergency',
              query: { resultId: routeDetail.resultId, routeId: routeDetail.id },
            }"
          >
            在应急保障中打开此路线 →
          </RouterLink>
        </div>
      </section>
    </template>
  </div>
</template>

<style scoped>
.api-data-view {
  max-width: 1080px;
  margin: 0 auto;
  padding: var(--space-5, 24px);
  display: flex;
  flex-direction: column;
  gap: var(--space-4, 16px);
}
.page-head h1 {
  font-size: var(--font-size-page-title, 24px);
  margin: 0 0 8px;
}
.head-note {
  color: var(--color-muted, #526477);
  margin: 0 0 8px;
}
.mode-warn {
  background: var(--color-info-surface, #eef4f8);
  border: 1px solid var(--color-border, #dde5ec);
  border-radius: var(--radius-md, 10px);
  padding: 12px;
  margin: 0;
}
.panel {
  background: var(--color-surface, #ffffff);
  border: 1px solid var(--color-border, #dde5ec);
  border-radius: var(--radius-md, 10px);
  padding: 16px;
  min-width: 0;
}
.panel h2 {
  font-size: var(--font-size-section-title, 18px);
  margin: 0 0 8px;
}
.cap-list {
  list-style: none;
  margin: 0;
  padding: 0;
  display: flex;
  flex-direction: column;
  gap: 6px;
}
.cap-item {
  display: flex;
  gap: 8px;
  font-size: 13px;
}
.cap-key {
  font-weight: 600;
  min-width: 130px;
}
.cap-item.is-ok .cap-reason {
  color: var(--color-success, #3d8f78);
}
.cap-reason {
  color: var(--color-muted, #526477);
  min-width: 0;
  overflow-wrap: anywhere;
}
.count-line {
  margin: 4px 0 8px;
}
.data-table {
  width: 100%;
  border-collapse: collapse;
  font-size: 13px;
}
.table-scroll {
  max-width: 100%;
  min-width: 0;
  overflow-x: auto;
}
.data-table th,
.data-table td {
  border: 1px solid var(--color-border, #dde5ec);
  padding: 6px 8px;
  text-align: left;
}
.data-table th {
  background: var(--color-info-surface, #eef4f8);
}
@media (max-width: 640px) {
  .data-table {
    min-width: 640px;
  }
}
.error-note {
  color: var(--color-danger-text, #8f2f35);
  background: color-mix(in srgb, var(--color-danger, #bf454b) 8%, transparent);
  border-radius: var(--radius-sm, 6px);
  padding: 8px 10px;
}
.muted {
  color: var(--color-muted, #526477);
  font-size: 13px;
}
.field-label {
  display: block;
  margin: 8px 0 4px;
  font-size: 13px;
}
select {
  min-width: 280px;
  max-width: 100%;
  padding: 6px 8px;
  border: 1px solid var(--color-border, #dde5ec);
  border-radius: var(--radius-sm, 6px);
  background: var(--color-surface, #ffffff);
  color: var(--color-text, #1b2b3b);
}
.detail-box {
  margin-top: 12px;
  border: 1px solid var(--color-border, #dde5ec);
  border-radius: var(--radius-sm, 6px);
  padding: 12px;
}
.workspace-link {
  display: inline-flex;
  margin-top: 10px;
  color: var(--color-primary-strong, #176bca);
  font-size: 13px;
  font-weight: 600;
}
.detail-box h3 {
  margin: 0 0 8px;
  font-size: 15px;
}
.detail-list {
  margin: 0;
}
.detail-row {
  display: flex;
  gap: 12px;
  font-size: 13px;
  padding: 2px 0;
}
.detail-row dt {
  min-width: 120px;
  color: var(--color-muted, #526477);
}
.detail-row dd {
  margin: 0;
}
.assume-list {
  margin: 8px 0 0;
  padding-left: 18px;
  font-size: 13px;
  color: var(--color-muted, #526477);
}
.route-pager {
  display: flex;
  flex-wrap: wrap;
  align-items: center;
  gap: 10px;
  margin-top: 10px;
}
.route-pager button {
  padding: 6px 14px;
  border: 1px solid var(--color-border, #dde5ec);
  border-radius: var(--radius-sm, 6px);
  background: var(--color-surface, #ffffff);
  color: var(--color-text, #1b2b3b);
  cursor: pointer;
  font-size: 14px;
  min-height: 34px;
}
.route-pager button:disabled {
  opacity: 0.5;
  cursor: not-allowed;
}
.pager-label {
  font-size: 13px;
  color: var(--color-muted, #526477);
}
</style>
