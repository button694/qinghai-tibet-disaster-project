import { installPublishedSnapshot } from '@/repositories/publishedSnapshot'
import '@/styles/tokens.css'
import '@/styles/base.css'

import { createApp } from 'vue'
import { createPinia } from 'pinia'

import App from '@/App.vue'
import { createAppRouter } from '@/app/router'
import { appEnv } from '@/config/env'
import { dataSourceUrl, getRepositories } from '@/repositories'

installPublishedSnapshot()

const app = createApp(App)
const pinia = createPinia()

app.use(pinia)
app.use(createAppRouter())

/**
 * 数据层按配置组装一次（`VITE_DATA_MODE`），页面通过 Repository 访问数据。
 * 这里只做“组装 + 打点”，不预取业务数据：真实接口未连接时由各页面显示失败，
 * 不会在启动阶段静默回退到示例数据。
 */
const repositories = getRepositories()
const sourceUrl = dataSourceUrl(repositories.mode)

console.info(
  `[qtp-risk] 数据模式 = ${repositories.mode}，数据来源 = ${sourceUrl}，默认路由 = ${appEnv.defaultRoute}`,
)

app.mount('#app')
