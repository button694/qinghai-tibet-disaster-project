<script setup lang="ts">
/**
 * 应用外壳。
 *
 * 阶段0 建立了标题、一级导航、路由出口；阶段1 起接入设计令牌与会话状态：
 * 模式徽标、快照标识、只读身份都取自 `useSessionStore`，不再直接读环境变量。
 * 工作台三栏布局在阶段2 按 01 §4.3 实现。
 * 阶段7：演示模式开关与答辩演示导览入口；打印路由下隐藏外壳（打印页自带动作条）。
 */
import { computed, onBeforeUnmount, onMounted } from 'vue'
import { RouterLink, RouterView, useRoute, useRouter } from 'vue-router'

import TourPanel from '@/components/shell/TourPanel.vue'
import { usePresentationStore } from '@/stores/presentation'
import { useSessionStore } from '@/stores/session'
import { setTourRouterBridge, useTourStore } from '@/stores/tour'
import { useLanguage } from '@/composables/useLanguage'

const { t, language, toggleLanguage } = useLanguage()
const englishNav: Record<string,string> = {'分析与情景':'Analysis & scenarios','救援路线':'Rescue routes','总览':'Overview','风险一张图':'Hazards & rescue','专题研判':'Risk analysis','应急保障':'Emergency routes','成果中心':'Results','数据目录':'Data catalog','环境因子地图':'Environmental factors','项目说明':'About'}

interface NavItem {
  to: string
  label: string
  /** 用于高亮的路径前缀，缺省等于 to */
  matchPrefix?: string
}

const navItems: NavItem[] = [
  { to: '/overview', label: '总览' },
  { to: '/map', label: '风险一张图' },
  { to: '/analysis/risk', label: '分析与情景' },
  { to: '/analysis/emergency', label: '救援路线' },
  { to: '/results', label: '成果中心' },
  { to: '/catalog', label: '数据目录' },
  { to: '/rasters', label: '环境因子地图' },
  { to: '/about', label: '项目说明' },
]

const route = useRoute()
const router = useRouter()
const session = useSessionStore()
const presentation = usePresentationStore()
const tour = useTourStore()
// 演示与项目交接工具只在开发/测试环境保留，最终交付界面不展示。
const showPresentationTools = import.meta.env.DEV

// 导览路由桥：store 动作在事件回调里执行（非组件上下文），这里在 setup 注入。
setTourRouterBridge(router)

const isPrintRoute = computed(() => route.meta.print === true)
const isPublishedSnapshot = import.meta.env.VITE_PUBLISHED_SNAPSHOT === 'true'
const modeLabel = computed(() => isPublishedSnapshot ? t('成果数据','Project data') : session.modeLabel)

function isActive(item: NavItem): boolean {
  const prefix = item.matchPrefix ?? item.to
  return route.path === prefix || route.path.startsWith(`${prefix}/`)
}

const pageTitle = computed(() => route.meta.title ?? '青藏高原地质灾害风险平台')

/** 演示模式开关（01 §4.2：投影演示正文 ≥16px，可明确进入与退出）。 */
function togglePresentation(): void {
  presentation.toggle()
}

onMounted(() => {
  // 清理上一会话可能残留的演示模式标记（tokens 依 data-presentation 放大正文）。
  presentation.reset()
})

onBeforeUnmount(() => presentation.reset())
</script>

<template>
  <div class="shell">
    <a class="skip-link" href="#main">跳到主要内容</a>

    <header v-if="!isPrintRoute" class="shell-header">
      <div class="brand">
        <span class="brand-title">{{ t('青藏高原地质灾害风险平台','Qinghai–Tibet Geohazard Platform') }}</span>
        <span class="brand-subtitle">{{ t('空间数据库成果展示与辅助分析','Spatial data · susceptibility · emergency response') }}</span>
      </div>

      <nav class="shell-nav" aria-label="一级导航">
        <RouterLink
          v-for="item in navItems.filter((item) => showPresentationTools || item.to !== '/about')"
          :key="item.to"
          class="nav-link"
          :class="{ 'is-active': isActive(item) }"
          :to="item.to"
          :data-testid="`nav-${item.to.replaceAll('/', '-').replace(/^-/, '')}`"
        >
          {{ language === 'en' ? englishNav[item.label] ?? item.label : item.label }}
        </RouterLink>
      </nav>

      <div class="shell-status">
        <button type="button" class="btn btn--small" @click="toggleLanguage" aria-label="Switch language / 切换语言">{{ language === 'zh' ? 'English' : '中文' }}</button>
        <span class="mode-badge" data-testid="mode-badge">{{ modeLabel }}</span>
        <button
          v-if="showPresentationTools"
          type="button"
          class="btn btn--small shell-action"
          :class="{ 'is-active': presentation.active }"
          :aria-pressed="presentation.active"
          :aria-label="presentation.active ? '退出演示模式' : '进入演示模式'"
          :title="
            presentation.active
              ? '退出演示模式（正文回到 14px）'
              : '进入演示模式（正文放大到 16px）'
          "
          data-testid="presentation-toggle"
          @click="togglePresentation"
        >
          {{ presentation.active ? '退出演示' : '演示模式' }}
        </button>
        <button
          v-if="showPresentationTools"
          type="button"
          class="btn btn--small shell-action shell-action--primary"
          :aria-label="tour.active ? '答辩演示导览进行中' : '开始答辩演示导览'"
          title="按固定顺序演示：总览→风险→暴露→应急→来源/成果→导出"
          data-testid="tour-start"
          @click="tour.start()"
        >
          演示导览
        </button>
      </div>
    </header>

    <main id="main" class="shell-main" :class="{ 'shell-main--print': isPrintRoute }">
      <p v-if="isPublishedSnapshot" class="snapshot-notice">{{ t('数据版本：2026年10月27日 · 搜索地区，探索危险点与关联救援路线','Data edition: 27 October 2026 · Search regions and explore hazard locations with linked rescue routes') }}</p>
      <RouterView />
    </main>

    <footer v-if="!isPrintRoute" class="shell-footer">
      <span data-testid="page-title">{{ t('当前页面','Current page') }}：{{ language === 'en' ? englishNav[pageTitle] ?? pageTitle : pageTitle }}</span>
      <span>
        {{ t('青藏高原地质灾害风险、应急救援路线与环境数据。数据来源可在目录追溯。','Geohazard analysis, rescue routes and environmental data. Source attribution is available in the catalog.') }}
      </span>
    </footer>

    <TourPanel v-if="showPresentationTools && !isPrintRoute" />
  </div>
</template>

<style scoped>
.snapshot-notice { margin: 0 0 16px; padding: 10px 0; color: #526575; font-size: 13px; line-height: 1.7; }
.shell {
  display: flex;
  flex-direction: column;
  min-height: 100vh;
}

.shell-header {
  display: flex;
  align-items: center;
  gap: var(--space-4);
  min-height: var(--header-height);
  padding: 0 var(--space-6);
  background: var(--color-shell);
  color: var(--color-shell-text);
  flex-wrap: wrap;
}

.brand {
  display: flex;
  flex-direction: column;
  line-height: 1.25;
}

.brand-title {
  font-size: 18px;
  font-weight: 600;
}

.brand-subtitle {
  font-size: 12px;
  color: var(--color-shell-muted);
}

.shell-nav {
  display: flex;
  gap: var(--space-1);
  margin-left: auto;
  flex-wrap: wrap;
}

.nav-link {
  padding: var(--space-2) var(--space-3);
  border-radius: var(--radius-sm);
  color: var(--color-shell-muted);
  text-decoration: none;
  font-size: 14px;
}

.nav-link:hover {
  color: var(--color-shell-text);
  background: rgb(255 255 255 / 8%);
}

.nav-link.is-active {
  color: var(--color-shell-text);
  background: rgb(255 255 255 / 14%);
  font-weight: 600;
}

.shell-status {
  display: flex;
  align-items: center;
  gap: var(--space-2);
  flex-wrap: wrap;
}

.mode-badge {
  padding: var(--space-1) var(--space-3);
  border: 1px solid rgb(255 255 255 / 28%);
  border-radius: 999px;
  font-size: 12px;
  color: var(--color-shell-text);
}

.status-chip {
  padding: var(--space-1) var(--space-2);
  border-radius: 999px;
  background: rgb(255 255 255 / 10%);
  color: var(--color-shell-muted);
  font-size: 12px;
}

.shell-main {
  flex: 1 1 auto;
  min-height: 0;
  padding: var(--space-6);
  background: var(--color-page);
}

/* 打印路由：页面自带动作条与留白，去掉外壳内边距。 */
.shell-main--print {
  padding: 0;
  max-width: none;
}

.shell-action {
  min-height: 28px;
  padding: 0 var(--space-2);
  font-size: var(--font-size-caption);
}

.shell-action.is-active {
  border-color: var(--color-primary);
  background: var(--color-primary-soft);
  color: var(--color-primary-strong);
}

.shell-action--primary {
  border-color: rgb(255 255 255 / 40%);
  background: rgb(255 255 255 / 12%);
  color: var(--color-shell-text);
}

.shell-footer {
  display: flex;
  justify-content: space-between;
  gap: var(--space-4);
  padding: var(--space-3) var(--space-6);
  border-top: 1px solid var(--color-border);
  background: var(--color-surface);
  color: var(--color-muted);
  font-size: 12px;
  flex-wrap: wrap;
}
.shell-header {
  padding-block: 14px;
  border-bottom: 3px solid var(--color-primary);
}
.shell-main {
  width: 100%;
  max-width: 1480px;
  margin-inline: auto;
}
.shell-nav {
  min-width: 0;
}
.brand-title {
  font-size: 17px;
  letter-spacing: 0.02em;
}
.shell-status {
  min-width: 0;
}
.status-chip {
  overflow-wrap: anywhere;
}
.nav-link {
  white-space: nowrap;
  transition: background-color 0.15s;
}
@media (max-width: 1100px) {
  .shell-nav {
    order: 3;
    flex-basis: 100%;
    margin-left: 0;
  }
  .shell-status {
    margin-left: auto;
  }
}
@media (max-width: 600px) {
  .shell-main {
    padding: var(--space-3);
  }
  .shell-header {
    padding-inline: var(--space-3);
  }
  .shell-status {
    margin-left: 0;
  }
  .nav-link {
    font-size: 12px;
    padding: 7px;
  }
}
</style>
