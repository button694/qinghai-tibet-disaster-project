<script setup lang="ts">
/**
 * 风险一张图工作台（03 §5 全部七项任务在此编排）。
 *
 * 结构（01 §4.3）：顶部工具栏 → 左栏图层树 / 中间地图与状态栏 / 右栏图例与对象详情 →
 * 底部可折叠对象列表。三个视口档位：
 * - >1366：左中右三栏；
 * - 1024—1366：左栏收窄，右栏仍未定宽；
 * - <1024：图层面板变抽屉，一次只开一个，地图仍保留可操作面积。
 *
 * 数据编排：图层注册表 → `LayerRepository.listLayers`；几何 → `LayerRepository.listFeatures`；
 * 图例 → `getLegend`；数据集与字典 → `CatalogRepository`。**页面不拼 GeoJSON 地址**。
 *
 * 失败语义：单层读取失败只影响该层（树上显示错误码、可重试），不影响其它图层与整页；
 * 注册表整体失败则整页显示错误状态，不展示任何示例图层。
 */
import { computed, nextTick, onBeforeUnmount, onMounted, ref, shallowRef, watch } from 'vue'

import ErrorState from '@/components/ui/ErrorState.vue'
import FeatureDetailPanel from '@/components/map/FeatureDetailPanel.vue'
import LayerMetadataPanel from '@/components/map/LayerMetadataPanel.vue'
import LayerTree from '@/components/map/LayerTree.vue'
import MapCanvas from '@/components/map/MapCanvas.vue'
import type { DrawMode } from '@/components/map/MapCanvas.vue'
import MapLegend from '@/components/map/MapLegend.vue'
import MapObjectList from '@/components/map/MapObjectList.vue'
import MapStatusBar from '@/components/map/MapStatusBar.vue'
import MapToolbar from '@/components/map/MapToolbar.vue'
import QueryPanel from '@/components/query/QueryPanel.vue'
import { layerAvailability } from '@/config/mapLayers'
import { featureKey } from '@/domain/format'
import type {
  DictionaryItem,
  FeatureDetail,
  FeatureRef,
  LayerDefinition,
  Legend,
  LonLat,
  Region,
} from '@/domain/types'
import type { Geometry as GeoJsonGeometry } from 'geojson'
import { RepositoryError } from '@/repositories/types'
import { getMapLayerService } from '@/services/mapLayers'
import { emptySummary, toDataSummary, useMapStore } from '@/stores/map'
import { useQueryStore } from '@/stores/query'
import { useSessionStore } from '@/stores/session'
import type { CanvasLayerState, MapRenderState } from '@/services/mapRenderState'

const store = useMapStore()
const queryStore = useQueryStore()
const session = useSessionStore()
const service = getMapLayerService()

/** 绘制模式：由查询面板发起，画布负责交互，结果回到查询 store（03 §6-3）。 */
const drawMode = ref<DrawMode>('none')
/** 行政区/流域条目：空间条件用，来自 `CatalogRepository.listRegions`。 */
const regions = ref<Region[]>([])
const regionNote = ref<string | null>(null)

/** 地图上的空间范围：绘制范围或行政区范围，二者取一。 */
const spatialGeometry = computed<GeoJsonGeometry | null>(() => {
  const draft = queryStore.spatial
  if (draft === null) return null
  if (draft.source === 'draw') return draft.geometry
  if (draft.source === 'region') {
    const region = regions.value.find((item) => item.id === draft.regionId)
    if (!region || region.extent === null) return null
    const [west, south, east, north] = region.extent
    return {
      type: 'Polygon',
      coordinates: [
        [
          [west, south],
          [east, south],
          [east, north],
          [west, north],
          [west, south],
        ],
      ],
    }
  }
  return null
})

/** 查询命中集合（本页）→ 地图覆盖层高亮。 */
const queryRefs = computed<FeatureRef[]>(() => queryStore.pageRefs)

const canvasRef = ref<InstanceType<typeof MapCanvas> | null>(null)
/** 已加载的要素：只用于列表与详情查找，不放进 Pinia（避免把大数组做成深度响应式）。 */
const layerData = shallowRef<Map<string, FeatureDetail[]>>(new Map())
const legendData = shallowRef<Map<string, { legend: Legend | null; note: string | null }>>(
  new Map(),
)
const dictionaryData = shallowRef(
  new Map<string, { items: Record<string, DictionaryItem[]>; notes: string[] }>(),
)
/** 在途装载：同一图层的并发调用共享一个 Promise，避免重复请求与「提前完成」。 */
const inFlight = new Map<string, Promise<void>>()
/** 每个图层在途请求的 AbortController，供「取消加载」按钮中止全量翻页循环。 */
const layerControllers = new Map<string, AbortController>()

const pointer = ref<LonLat | null>(null)
const zoom = ref(6)
const metadataLayer = ref<LayerDefinition | null>(null)

/* ------------------------------------------------------------------ *
 * 传给画布的图层状态
 * ------------------------------------------------------------------ */

const canvasStates = computed<CanvasLayerState[]>(() =>
  store.orderedLayers.map((layer, index) => ({
    definition: layer,
    visible: store.isVisible(layer.id),
    opacity: store.opacityOf(layer.id),
    zIndex: (store.orderedLayers.length - index) * 10,
    renderable: layerAvailability(layer).available,
  })),
)

const selectedKey = computed(() =>
  store.selected === null ? null : featureKey(store.selected.ref.layerId, store.selected.ref.id),
)

const selectedLayer = computed<LayerDefinition | null>(() => {
  const detail = store.selected
  if (detail === null) return null
  return store.layers.find((layer) => layer.id === detail.ref.layerId) ?? null
})

const activeFeatures = computed<FeatureDetail[]>(() => {
  const id = store.activeLayerId
  if (id === null) return []
  const cached = layerData.value.get(id)
  return cached === undefined ? [] : [...cached]
})

const activeSummary = computed(() =>
  store.activeLayerId === null ? null : store.summaryOf(store.activeLayerId),
)

/** 无几何记录（如示例风险区里的一条）只能从对象列表进入，定位会被禁用。 */
const canLocateSelected = computed(() => store.selected?.geometry != null)

const locateNote = computed(() => {
  const detail = store.selected
  if (detail === null) return '尚未选中对象。'
  if (detail.geometry !== null) return null
  return '该记录无几何：可在列表中查看属性，地图定位不可用，也不为其补造坐标。'
})

const legendEntries = computed(() =>
  canvasStates.value
    .filter((state) => state.visible && state.renderable)
    .map((state) => {
      const info = legendData.value.get(state.definition.id)
      return {
        layer: state.definition,
        legend: info?.legend ?? null,
        note: info?.note ?? null,
      }
    }),
)

const rightColumnVisible = computed(
  () => store.legendOpen || store.selected !== null || metadataLayer.value !== null,
)

/** 注册表失败时构造真实错误对象，交给 ErrorState 统一展示错误码与文案。 */
const registryError = computed(
  () =>
    new RepositoryError({
      code: store.errorCode ?? 'UNKNOWN',
      message: store.errorText ?? '图层注册表读取失败。',
      retryable: true,
    }),
)

const renderStateOfActive = computed(() => {
  const id = store.activeLayerId
  if (id === null) return null
  return store.renderState?.layers.find((layer) => layer.layerId === id) ?? null
})

const canFocusActive = computed(() => (renderStateOfActive.value?.featureCount ?? 0) > 0)

/* ------------------------------------------------------------------ *
 * 数据装载
 * ------------------------------------------------------------------ */

function setLayerData(layerId: string, features: FeatureDetail[]): void {
  const next = new Map(layerData.value)
  next.set(layerId, features)
  layerData.value = next
}

function setLegend(layerId: string, value: { legend: Legend | null; note: string | null }): void {
  const next = new Map(legendData.value)
  next.set(layerId, value)
  legendData.value = next
}

function syncRenderState(): void {
  const state: MapRenderState | undefined = canvasRef.value?.getRenderState()
  if (state) store.setRenderState(state)
}

/**
 * 按需装载图层数据。
 *
 * 四种情况共用同一个入口，避免三类问题：
 * - 首次进入：服务层真正发请求；
 * - 再次进入页面：本组件已销毁、`layerData` 为空，但服务层缓存还在，
 *   因此仍走这里重新灌几何，只是不发网络请求；
 * - 失败或服务未接入：不自动重试，必须由用户点「重试」，防止静默循环请求；
 * - **并发调用去重，但共享同一个在途 Promise**：初始装载会同时被「可见性监听」与
 *   「首次进入流程」触发。此前第二次调用直接返回，首次流程会以为装载已完成，
 *   于是在要素尚未进地图时就去适配视野——表现为「缩放停在默认级别、要素极小」。
 *   改为返回同一个 Promise 后，调用方观察到的完成时机才是真的完成。
 */
function loadLayerData(layer: LayerDefinition, options: { force?: boolean } = {}): Promise<void> {
  const pending = inFlight.get(layer.id)
  if (pending) return pending
  if (!options.force) {
    if (layerData.value.has(layer.id)) return Promise.resolve()
    const status = store.summaryOf(layer.id).status
    if (status === 'failed' || status === 'unavailable' || status === 'cancelled') {
      return Promise.resolve()
    }
  }
  const controller = new AbortController()
  layerControllers.set(layer.id, controller)
  const task = (async (): Promise<void> => {
    store.markLoading(layer.id)
    try {
      const result = await service.loadLayer(
        layer,
        { signal: controller.signal },
        (loaded, total) => store.setLoadProgress(layer.id, loaded, total),
      )
      const applied = canvasRef.value?.applyLayerData(layer.id, result.features) ?? {
        rendered: 0,
        skipped: 0,
      }
      setLayerData(layer.id, result.features)
      store.setDataSummary(layer.id, toDataSummary(result, applied.skipped, applied.rendered))
      if (!legendData.value.has(layer.id) && layer.legendId !== '') {
        setLegend(layer.id, await service.getLegend(layer.legendId))
      }
    } finally {
      inFlight.delete(layer.id)
      layerControllers.delete(layer.id)
      syncRenderState()
    }
  })()
  inFlight.set(layer.id, task)
  return task
}

/** 取消某图层的在途加载（尤其是重几何图层的全量翻页循环）；服务层据此返回 `cancelled`。 */
function cancelLayerLoad(layerId: string): void {
  layerControllers.get(layerId)?.abort()
}

/** 失败重试：先清空旧状态与旧几何，再重新加载，避免把上一次结果当成本次结果。 */
async function retryLayer(layer: LayerDefinition): Promise<void> {
  canvasRef.value?.clearLayerData(layer.id)
  setLayerData(layer.id, [])
  store.setDataSummary(layer.id, emptySummary())
  await loadLayerData(layer, { force: true })
}

/* ------------------------------------------------------------------ *
 * 阶段3：绘制与查询
 * ------------------------------------------------------------------ */

function onStartDraw(mode: 'box' | 'polygon'): void {
  drawMode.value = mode
}

function onClearDraw(): void {
  drawMode.value = 'none'
  if (queryStore.spatial?.source === 'draw') queryStore.updateSpatial({ geometry: null })
}

function onDrawComplete(geometry: GeoJsonGeometry): void {
  drawMode.value = 'none'
  if (queryStore.spatial?.source === 'draw') queryStore.updateSpatial({ geometry })
}

function onDrawCancel(): void {
  drawMode.value = 'none'
}

/** 结果表行定位：选中 + 地图聚焦；无几何记录不会走到这里（按钮已禁用）。 */
function onQueryLocate(ref: FeatureRef): void {
  onObjectLocate(ref)
}

async function ensureRegions(): Promise<void> {
  if (regions.value.length > 0) return
  const result = await service.listRegions()
  regions.value = result.regions
  regionNote.value = result.note
}

async function ensureDictionaries(layerId: string): Promise<void> {
  if (dictionaryData.value.has(layerId)) return
  const layer = store.layers.find((item) => item.id === layerId)
  if (!layer) return
  const next = new Map(dictionaryData.value)
  next.set(layerId, await service.getDictionaries(layer))
  dictionaryData.value = next
}

async function loadRegistry(force = false): Promise<void> {
  await store.loadRegistry({ force })
  if (store.status === 'failed') return
  // 默认对象列表图层：注册表里第一个「可查询且可渲染」的图层，选择结果可预期。
  const first = store.orderedLayers.find(
    (layer) => layer.queryable && layerAvailability(layer).available,
  )
  store.setActiveLayer(first?.id ?? null)
  await nextTick()
  await loadVisibleLayers()
  // 首次进入把视野适配到已加载图层范围，否则用户会停在一片空网格上找数据。
  canvasRef.value?.resetView()
  syncRenderState()
}

async function loadVisibleLayers(): Promise<void> {
  const targets = store.orderedLayers.filter((layer) => store.isVisible(layer.id))
  await Promise.all(targets.map((layer) => loadLayerData(layer)))
  syncRenderState()
}

/* ------------------------------------------------------------------ *
 * 交互
 * ------------------------------------------------------------------ */

function onSelect(payload: { layerId: string; featureId: string } | null): void {
  if (payload === null) {
    store.clearSelection()
    return
  }
  const detail =
    (layerData.value.get(payload.layerId) ?? []).find(
      (item) => item.ref.id === payload.featureId,
    ) ?? null
  if (detail === null) {
    store.clearSelection()
    return
  }
  store.setActiveLayer(payload.layerId)
  store.select(detail)
  void ensureDictionaries(payload.layerId)
}

function onObjectSelect(ref: FeatureRef): void {
  store.setActiveLayer(ref.layerId)
  const detail = (layerData.value.get(ref.layerId) ?? []).find((item) => item.ref.id === ref.id)
  if (detail) {
    store.select(detail)
    void ensureDictionaries(ref.layerId)
  }
  if (detail && detail.geometry !== null) canvasRef.value?.focusFeature(ref.layerId, ref.id)
}

function onObjectLocate(ref: FeatureRef): void {
  const detail = (layerData.value.get(ref.layerId) ?? []).find((item) => item.ref.id === ref.id)
  if (!detail || detail.geometry === null) return
  store.select(detail)
  canvasRef.value?.focusFeature(ref.layerId, ref.id)
  syncRenderState()
}

function onFocusLayer(layerId: string): void {
  const layer = store.layers.find((item) => item.id === layerId)
  if (!layer) return
  const focused = canvasRef.value?.focusLayer(layerId) ?? false
  if (focused) {
    syncRenderState()
    return
  }
  // 该层还没有已渲染要素：先按需加载，再定位；仍然为空时保持现状（树上会如实显示状态）。
  void loadLayerData(layer).then(() => {
    canvasRef.value?.focusLayer(layerId)
    syncRenderState()
  })
}

function onFocusActive(): void {
  const id = store.activeLayerId
  if (id === null) return
  onFocusLayer(id)
}

/** 右侧详情面板的「在地图上定位」：无几何记录不会走到这里（按钮已禁用）。 */
function locateSelected(): void {
  const detail = store.selected
  if (detail === null || detail.geometry === null) return
  canvasRef.value?.focusFeature(detail.ref.layerId, detail.ref.id)
  syncRenderState()
}

function onMetadata(layer: LayerDefinition): void {
  metadataLayer.value = layer
}

function closeMetadata(): void {
  metadataLayer.value = null
}

function onPointerMove(position: LonLat | null): void {
  pointer.value = position
}

function onZoomChange(next: number): void {
  zoom.value = next
}

function onRenderState(state: MapRenderState): void {
  store.setRenderState(state)
}

/* ------------------------------------------------------------------ *
 * 生命周期
 * ------------------------------------------------------------------ */

onMounted(async () => {
  void session.loadCapabilities()
  await loadRegistry()
  void ensureRegions()
})

/* ------------------------------------------------------------------ *
 * Esc 逐层关闭浮层（阶段7 键盘可访问性：弹层、抽屉支持 Esc 退出）
 *
 * 一次按键只关一个浮层，优先级从最上层（元数据/详情）到抽屉；
 * 绘制状态的 Esc 由 MapCanvas 自己处理，这里不重复响应。
 * ------------------------------------------------------------------ */

function onWorkspaceKeydown(event: KeyboardEvent): void {
  if (event.key !== 'Escape') return
  // 绘制进行中：Esc 由 MapCanvas 负责取消绘制，本处理器不抢（否则会误关查询面板）。
  if (drawMode.value !== 'none') return
  if (metadataLayer.value !== null) {
    metadataLayer.value = null
    return
  }
  if (queryStore.open) {
    queryStore.setOpen(false)
    return
  }
  if (store.detailOpen) {
    store.clearSelection()
    return
  }
  if (store.objectListOpen) {
    store.objectListOpen = false
    return
  }
  if (store.legendOpen) {
    store.legendOpen = false
    return
  }
  if (store.layerDrawerOpen) {
    store.layerDrawerOpen = false
  }
}

onMounted(() => document.addEventListener('keydown', onWorkspaceKeydown))

watch(
  () => store.visible,
  () => {
    void loadVisibleLayers()
  },
  { deep: true },
)

/** 数据模式变化：清空本页缓存与选中状态，重新按新模式装载（D-014）。 */
watch(
  () => session.mode,
  () => {
    service.clear()
    layerData.value = new Map()
    legendData.value = new Map()
    dictionaryData.value = new Map()
    metadataLayer.value = null
    drawMode.value = 'none'
    regions.value = []
    store.reset()
    queryStore.reset()
    void loadRegistry(true)
    void ensureRegions()
  },
)

onBeforeUnmount(() => {
  document.removeEventListener('keydown', onWorkspaceKeydown)
  // 只清本页的选中与渲染状态；注册表缓存留给下一次进入，避免重复请求。
  store.clearSelection()
  store.setRenderState(null)
  store.closeDrawers()
  metadataLayer.value = null
  // 查询状态一并复位：离开页面后在途查询作废，不把上一次结果带到下一次进入。
  queryStore.reset()
})
</script>

<template>
  <div class="workspace" :class="{ 'is-query-open': queryStore.open }" data-testid="map-workspace">
    <header class="workspace-head">
      <h1 class="workspace-title">图层工作台</h1>
      <p class="workspace-subtitle">
        图层目录 → 地图 → 对象详情；可使用查询、筛选、定位与导出功能。
        栅格通过栅格地图查看；所有数据来源可在数据目录追溯。
      </p>
    </header>

    <MapToolbar
      :has-selection="store.selected !== null"
      :can-focus-active="canFocusActive"
      :clear-disabled-reason="store.selected === null ? '当前没有选中对象。' : null"
      :query-open="queryStore.open"
      @zoom-in="canvasRef?.zoomBy(1)"
      @zoom-out="canvasRef?.zoomBy(-1)"
      @reset="canvasRef?.resetView()"
      @focus-active="onFocusActive"
      @clear-selection="store.clearSelection()"
      @toggle-legend="store.toggleLegend()"
      @toggle-object-list="store.toggleObjectList()"
      @toggle-layer-drawer="store.toggleLayerDrawer()"
      @toggle-query="queryStore.toggleOpen()"
    />

    <ErrorState
      v-if="store.status === 'failed'"
      title="图层注册表读取失败"
      :error="registryError"
      :retryable="true"
      @retry="loadRegistry(true)"
    />

    <p v-else-if="store.status === 'loading' || store.status === 'idle'" class="workspace-status">
      正在读取图层注册表…
    </p>

    <div
      v-else
      class="workspace-grid"
      :class="{
        'is-right-hidden': !rightColumnVisible,
        'is-drawer-open': store.layerDrawerOpen,
        'is-query-open': queryStore.open,
      }"
    >
      <div class="col-left">
        <LayerTree
          @focus="onFocusLayer"
          @metadata="onMetadata"
          @retry="retryLayer"
          @cancel="cancelLayerLoad"
        />
      </div>

      <div class="col-center">
        <MapCanvas
          ref="canvasRef"
          :layer-states="canvasStates"
          :selected-key="selectedKey"
          :draw-mode="drawMode"
          :spatial-geometry="spatialGeometry"
          :query-refs="queryRefs"
          @select="onSelect"
          @pointer-move="onPointerMove"
          @zoom-change="onZoomChange"
          @render-state="onRenderState"
          @draw-complete="onDrawComplete"
          @draw-cancel="onDrawCancel"
        />
        <MapStatusBar
          :pointer="pointer"
          :active-layer-label="store.activeLayer?.label ?? null"
          :active-layer-count="activeSummary?.matched ?? null"
        />
        <div v-if="queryStore.open" class="object-area">
          <QueryPanel
            :dictionaries="
              queryStore.layerId === null
                ? {}
                : (dictionaryData.get(queryStore.layerId)?.items ?? {})
            "
            :regions="regions"
            :draw-mode="drawMode"
            @start-draw="onStartDraw"
            @clear-draw="onClearDraw"
            @locate="onQueryLocate"
          />
          <p v-if="regionNote" class="region-note">{{ regionNote }}</p>
        </div>
        <div v-else-if="store.objectListOpen" class="object-area">
          <MapObjectList
            :features="activeFeatures"
            :layer="store.activeLayer"
            :loading="activeSummary?.status === 'loading'"
            :server-total="activeSummary?.serverTotal ?? activeFeatures.length"
            :complete="activeSummary?.complete ?? false"
            :note="activeSummary?.note ?? null"
            :error-text="activeSummary?.errorText ?? null"
            @select="onObjectSelect"
            @locate="onObjectLocate"
          />
          <div v-if="activeSummary?.status === 'failed' && store.activeLayer" class="retry-row">
            <button
              type="button"
              class="btn btn--small"
              data-testid="retry-layer"
              @click="retryLayer(store.activeLayer)"
            >
              重试该图层
            </button>
          </div>
        </div>
      </div>

      <div v-if="rightColumnVisible" class="col-right" data-testid="right-column">
        <MapLegend v-if="store.legendOpen" :entries="legendEntries" />
        <LayerMetadataPanel v-if="metadataLayer" :layer="metadataLayer" @close="closeMetadata" />
        <FeatureDetailPanel
          v-if="metadataLayer === null && store.detailOpen"
          :detail="store.selected"
          :layer="selectedLayer"
          :dictionaries="
            store.selected === null
              ? {}
              : (dictionaryData.get(store.selected.ref.layerId)?.items ?? {})
          "
          :dictionary-notes="
            store.selected === null
              ? []
              : (dictionaryData.get(store.selected.ref.layerId)?.notes ?? [])
          "
          :can-locate="canLocateSelected"
          :locate-note="locateNote"
          @close="store.clearSelection()"
          @locate="locateSelected"
        />
      </div>
    </div>
  </div>
</template>

<style scoped>
.workspace {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  /* 高度必须有确定值：否则图层树的内容高度会撑大网格行，把地图画布拉成上千像素高，
     适配视野与地图尺寸更新都会失去意义。左栏因此改为在自己的区域里滚动。 */
  height: calc(100vh - 200px);
  min-height: 560px;
}

.workspace-head {
  display: flex;
  flex-direction: column;
  gap: var(--space-1);
}

.workspace-title {
  margin: 0;
  font-size: var(--font-size-page-title);
}

.workspace-subtitle {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
  line-height: var(--line-height-tight);
}

.workspace-status {
  margin: 0;
  color: var(--color-muted);
}

.workspace-grid {
  display: grid;
  grid-template-columns: var(--panel-left) minmax(0, 1fr) var(--panel-right);
  gap: var(--space-3);
  align-items: stretch;
  flex: 1 1 auto;
  min-height: 0;
  overflow: hidden;
}

.workspace-grid.is-right-hidden {
  grid-template-columns: var(--panel-left) minmax(0, 1fr);
}

.col-left,
.col-center,
.col-right {
  min-width: 0;
  min-height: 0;
}

.col-left,
.col-center {
  overflow: hidden;
}

.col-center {
  display: grid;
  /* 地图行取剩余空间；最小高度在行上声明（组件内不再自带 min-height，避免画布溢出行）。 */
  grid-template-rows: minmax(320px, 1fr) auto auto;
  gap: var(--space-3);
}

.workspace.is-query-open .col-center {
  grid-template-rows: minmax(240px, 1fr) auto auto;
}

.col-right {
  display: flex;
  flex-direction: column;
  gap: var(--space-3);
  min-height: 0;
  overflow-y: auto;
}

.object-area {
  display: flex;
  flex-direction: column;
  gap: var(--space-2);
  min-height: 0;
  max-height: 320px;
  overflow-y: auto;
}

.retry-row {
  display: flex;
  justify-content: flex-end;
}

.analyze-entry {
  justify-self: start;
}

.region-note {
  margin: 0;
  color: var(--color-muted);
  font-size: var(--font-size-caption);
}

/*
 * 查询面板打开时的高度分配。
 *
 * 教训（阶段2 与本次都踩到）：**网格高度必须是确定值**。若把网格改成 auto 高度，
 * 左栏（图层树）的内容高度会把整行撑开，进而把地图画布带成上千像素高、
 * 并把栅格拉宽到超出视口（本次表现为 1366 宽下文档宽 1564，出现横向滚动条）。
 * 因此这里保持确定高度，只做两件事：
 * 1. 打开查询时把工作区整体抬高一点，给停靠区让出空间；
 * 2. 停靠区（对象列表 / 查询面板）定高并在内部滚动，地图行取剩余空间但不低于 220px。
 */
.workspace.is-query-open {
  height: calc(100vh - 140px);
  min-height: 520px;
}

.object-area {
  max-height: 320px;
  overflow-y: auto;
}

/* 1024—1366：左栏收窄，右栏保持但不定宽。 */
@media (max-width: 1366px) {
  .workspace-grid {
    grid-template-columns: var(--panel-left-compact) minmax(0, 1fr) minmax(280px, 320px);
  }
}

/* <1024：图层面板变抽屉（保留地图面积），右栏并入单列。 */
@media (max-width: 1023px) {
  .workspace {
    height: auto;
    min-height: calc(100vh - 220px);
  }

  .workspace-grid,
  .workspace-grid.is-right-hidden {
    grid-template-columns: minmax(0, 1fr);
    min-height: 0;
    overflow: visible;
  }

  .col-left {
    display: none;
  }

  .workspace-grid.is-drawer-open .col-left {
    display: block;
    max-height: 46vh;
    overflow-y: auto;
  }

  .col-center {
    grid-template-rows: minmax(300px, 1fr) auto auto;
    min-height: 60vh;
  }

  .col-right {
    max-height: none;
  }
}
</style>
