import { ref } from 'vue'

const language = ref<'zh' | 'en'>(localStorage.getItem('qtp-language') === 'en' ? 'en' : 'zh')
export function useLanguage() {
  function t(zh: string, en: string): string { return language.value === 'en' ? en : zh }
  function toggleLanguage() {
    language.value = language.value === 'zh' ? 'en' : 'zh'
    localStorage.setItem('qtp-language', language.value)
    document.documentElement.lang = language.value === 'en' ? 'en' : 'zh-CN'
  }
  return { language, t, toggleLanguage }
}
