/**
 * 元素尺寸变化监听（阶段2 任务6：面板/窗口变化后更新地图尺寸）。
 *
 * 地图的「黑边」「半屏空白」几乎都来自容器尺寸变了但地图没收到通知。
 * 这里同时监听 ResizeObserver 与 window resize，并在作用域销毁时全部清理，
 * 避免重复挂载后监听叠加。
 *
 * 说明：jsdom 没有 ResizeObserver，本组合式函数在没有该 API 时退回 window resize，
 * 不会因为缺少浏览器 API 抛错（单元测试因此可以直接调用）。
 */
import { getCurrentScope, onScopeDispose, watch, type Ref } from 'vue'

export interface ElementSize {
  width: number
  height: number
}

export interface ElementResizeHandle {
  /** 主动测量一次（地图初始化后立即调用）。 */
  measure: () => void
  /** 停止监听并释放引用，可重复调用。 */
  stop: () => void
}

export function useElementResize(
  target: Ref<HTMLElement | null>,
  onResize: (size: ElementSize) => void,
  options: { immediate?: boolean } = {},
): ElementResizeHandle {
  const immediate = options.immediate ?? true
  let stopped = false
  let observer: ResizeObserver | null = null

  const measure = (): void => {
    if (stopped) return
    const element = target.value
    if (!element) return
    onResize({ width: element.clientWidth, height: element.clientHeight })
  }

  if (typeof ResizeObserver !== 'undefined') {
    observer = new ResizeObserver(() => measure())
    watch(
      target,
      (element) => {
        observer?.disconnect()
        if (element) observer?.observe(element)
        measure()
      },
      { immediate: true, flush: 'post' },
    )
  } else if (immediate) {
    measure()
  }

  const onWindowResize = (): void => measure()
  if (typeof window !== 'undefined') window.addEventListener('resize', onWindowResize)

  const stop = (): void => {
    if (stopped) return
    stopped = true
    observer?.disconnect()
    observer = null
    if (typeof window !== 'undefined') window.removeEventListener('resize', onWindowResize)
  }

  if (getCurrentScope()) onScopeDispose(stop)

  return { measure, stop }
}
