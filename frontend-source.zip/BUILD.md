# Frontend source

The source archive contains application code and tests, without dependencies or credentials.
Unpack site.zip into a temporary directory, then copy published-snapshot/ into public/published-snapshot/ in this source project. This supplies the real, dated website data.

Install dependencies with pnpm install. Build with pnpm exec vite build --mode pages --base ./ and check types with pnpm type-check. Serve the build with an HTTP server (opening index.html directly is unsupported).

Original Chinese place names, facility names and data records are retained. The new hazard/region/rescue workflow, navigation and raster controls support Chinese/English switching. Legacy analytical and catalog pages retain their original detailed text.
