import { fileURLToPath } from 'node:url'
import { mergeConfig, defineConfig, configDefaults } from 'vitest/config'
import viteConfig from './vite.config.ts'

export default mergeConfig(
  viteConfig,
  defineConfig({
    test: {
      environment: 'jsdom',
      // 单元测试在 tests/unit；Playwright 用例在 tests/e2e，由 test:e2e 运行
      include: ['tests/unit/**/*.{test,spec}.?(c|m)[jt]s?(x)'],
      exclude: [...configDefaults.exclude, 'tests/e2e/**'],
      root: fileURLToPath(new URL('./', import.meta.url)),
    },
  }),
)
